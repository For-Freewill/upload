package com.patrol;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import com.patrol.config.PatrolProperties;
import com.patrol.engine.PatrolEngine;
import com.patrol.excel.ExcelConfigLoader;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.judge.HealthJudge;
import com.patrol.model.ActionInspection;
import com.patrol.model.ElementDigest;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.PatrolSummary;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import com.patrol.report.ExcelReportGenerator;
import com.patrol.report.HtmlReportGenerator;
import com.patrol.report.JsonReportWriter;
import com.patrol.runner.PatrolRunner;
import com.patrol.support.TestWebServer;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.testng.AssertJUnit.*;

/**
 * 端到端集成测试：本地测试站点 + 示例 Excel 配置 → 完整巡检 → 断言判定/证据/报告/动作巡检/登录态复用。
 */
public class PatrolIntegrationTest {

    private static final Logger log = LoggerFactory.getLogger(PatrolIntegrationTest.class);

    private TestWebServer webServer;
    private Path reportDir;
    private PatrolProperties properties;
    private ExcelConfigLoader loader;
    private List<SiteInspection> inspections;

    @BeforeClass
    public void setUp() throws Exception {
        webServer = new TestWebServer();
        webServer.start();

        // 输出目录（patrol- 前缀 + 时间戳，与正式巡检目录命名一致，可被索引页收录）
        reportDir = Path.of("target", "patrol-test-report",
                "patrol-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
        Files.createDirectories(reportDir);

        // 登录态缓存目录（隔离，便于断言；每次运行前清空，保证测试确定性）
        Path loginStateDir = Path.of("target", "login-state-test");
        if (Files.exists(loginStateDir)) {
            try (var walk = Files.walk(loginStateDir)) {
                walk.sorted(java.util.Comparator.reverseOrder())
                        .forEach(p -> p.toFile().delete());
            }
        }
        properties = new PatrolProperties();
        properties.setExcelPath(Path.of("target", "test-sites.xlsx").toString());
        properties.setOutputDir(reportDir.getParent().toString());
        properties.setLoginStateDir(loginStateDir.toString());
        properties.getDefaults().setLoadTimeoutMs(1000);   // 使 /slow 判 WARN
        properties.getDefaults().setMaxPages(10);
        properties.getDefaults().setMaxDepth(2);
        properties.getDefaults().setSitemapDiscovery(false); // 全局关闭，仅「孤立页面站」显式开启（保证其他站点页数确定性）

        // 构造测试 Excel 配置
        Path excel = Path.of("target", "test-sites.xlsx");
        writeTestExcel(excel);

        loader = new ExcelConfigLoader(properties);
        List<SiteConfig> sites = loader.load(excel).stream()
                .filter(SiteConfig::isEnabled).toList();
        List<PageActionConfig> pageActions = loader.loadPageActions(excel);

        PatrolEngine engine = new PatrolEngine(properties, new HealthJudge());

        // 阶段一：预认证（有头模式，串行）—— FORM 登录站弹出浏览器自动登录并保存登录态
        try (Playwright authPlaywright = com.patrol.engine.PlaywrightFactory.create(false)) {
            for (SiteConfig site : sites) {
                com.patrol.engine.AuthSupport.preAuthenticate(authPlaywright, properties, site,
                        Path.of(properties.getLoginStateDir()));
            }
        }

        // 阶段二：无头巡检（登录态已就绪，仅加载缓存）
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            inspections = sites.stream()
                    .map(site -> engine.inspect(site, browser, reportDir, pageActions))
                    .toList();
        }
        inspections.forEach(s -> log.info("站点 [{}] 结论: {} 页面数 {} 动作 {}",
                s.siteName(), s.verdict(), s.pagesVisited(), s.totalActions()));
    }

    /** 写入测试 Excel（新双表格式：Sites 主表 11 列 + 站点高级配置 sheet） */
    private void writeTestExcel(Path excel) throws Exception {
        String[][] sites = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"本地演示站", webServer.baseUrl() + "/", "true", "NONE", "", "",
                        "", "", "", "", "集成测试站点（ALL 全量按钮遍历）"},
                {"本地登录站", webServer.baseUrl() + "/home2", "true", "FORM", "admin", "admin123",
                        webServer.baseUrl() + "/login", "#username", "#password", "#loginBtn", "FORM 登录演示"},
                {"覆盖测试站", webServer.baseUrl() + "/coverage-page", "true", "NONE", "", "",
                        "", "", "", "",
                        "可点击元素覆盖演示（图标按钮/ARIA/伪链接/图片链接/下载链接/疑似可点击）"},
                {"孤立页面站", webServer.baseUrl() + "/isolated-home", "true", "NONE", "", "",
                        "", "", "", "",
                        "孤立菜单页面探索演示（hash 路由 / onclick 导航 / sitemap 发现 / 额外入口）"}
        };
        // 高级配置表头直接复用正式模板（列序一致）；列序：0站点 1页数 2深度 3额外入口 4包含
        //   5排除 6Sitemap 7动作开关 8动作模式 9动作上限 10-16关键词与阈值 17超时 18错误词
        //   19成功标识 20成功URL 21复用 22手动超时 23Token头 24Token值
        String[] advHead = com.patrol.excel.ExcelTemplateGenerator.ADVANCED_HEADERS;
        String[][] advanced = {
                advHead,
                // 演示站：排除 /api（防 onclick 提取的下载端点被当页面）；加载超时留空 → 回落全局默认
                {"本地演示站", "12", "2", "", "", "/logout,/api", "false",
                        "true", "ALL", "5", "", "", "", "", "", "", "", "1000", "",
                        "", "", "", "", "", ""},
                // 登录站：动作模式留空 → 回落全局默认 QUERY；登录成功标识从高级表合并
                {"本地登录站", "5", "1", "", "", "/logout", "false",
                        "true", "", "3", "", "", "", "", "", "", "", "", "",
                        "退出登录", "", "true", "", "", ""},
                {"覆盖测试站", "1", "0", "", "", "", "false",
                        "true", "ALL", "10", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // 孤立页面站：额外入口 /hidden-page（相对路径，加载时解析）；显式开启 sitemap 发现
                {"孤立页面站", "8", "2", "/hidden-page", "", "", "true",
                        "false", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""}
        };
        writeSheets(excel, sites, advanced);
    }

    /** 双表写出：Sites 主表 + 站点高级配置（表头灰色加粗样式与正式模板一致） */
    private static void writeSheets(Path excel, String[][] sites, String[][] advanced) throws Exception {
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            writeSheet(wb, "Sites", sites);
            writeSheet(wb, "站点高级配置", advanced);
            try (OutputStream out = Files.newOutputStream(excel)) {
                wb.write(out);
            }
        }
    }

    /** 通用 Excel 写出（表头灰色加粗样式与正式模板一致） */
    private static void writeExcel(Path excel, String[][] rows) throws Exception {
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            writeSheet(wb, "Sites", rows);
            try (OutputStream out = Files.newOutputStream(excel)) {
                wb.write(out);
            }
        }
    }

    private static void writeSheet(XSSFWorkbook wb, String name, String[][] rows) {
        XSSFSheet sheet = wb.createSheet(name);
        for (int r = 0; r < rows.length; r++) {
            XSSFRow row = sheet.createRow(r);
            for (int c = 0; c < rows[r].length; c++) {
                XSSFCell cell = row.createCell(c);
                cell.setCellValue(rows[r][c] == null ? "" : rows[r][c]);
                if (r == 0) {
                    XSSFCellStyle style = wb.createCellStyle();
                    style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
                    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                    XSSFFont bold = wb.createFont();
                    bold.setBold(true);
                    style.setFont(bold);
                    cell.setCellStyle(style);
                }
            }
        }
    }

    /**
     * 旧版 31 列宽表头（保留用于验证向后兼容：旧格式单宽表文件仍可正常加载，
     * 新格式请使用 Sites 主表 + 站点高级配置双表结构）。
     */
    private static class ExcelTemplateHeaders {
        static String[] headRow() {
            return new String[]{"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码", "登录URL",
                    "用户名选择器", "密码选择器", "提交按钮选择器", "登录成功标识", "登录成功URL包含",
                    "复用登录状态", "手动登录超时(秒)", "Token请求头", "Token值",
                    "最大页面数", "最大深度", "包含路径前缀", "排除路径前缀",
                    "启用动作巡检", "动作模式", "动作数上限", "查询按钮关键词", "排除按钮关键词",
                    "Console错误上限", "JS异常上限", "失败请求上限", "加载超时(ms)", "错误关键词", "备注"};
        }
    }

    private SiteInspection demoSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("本地演示站"))
                .findFirst().orElseThrow();
    }

    private SiteInspection loginSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("本地登录站"))
                .findFirst().orElseThrow();
    }

    private PageInspection page(String path) {
        return demoSite().pages().stream()
                .filter(p -> p.url().endsWith(path))
                .findFirst().orElse(null);
    }

    @Test
    public void advancedSheetOverridesMerged() throws Exception {
        List<SiteConfig> sites = loader.load(Path.of(properties.getExcelPath()));

        // 演示站：高级配置覆盖项应生效
        SiteConfig demo = sites.stream().filter(s -> s.getSiteName().equals("本地演示站"))
                .findFirst().orElseThrow();
        assertEquals("高级配置应覆盖最大页面数", 12, demo.getMaxPages());
        assertTrue("高级配置动作模式 ALL 应生效", demo.isAllButtonMode());
        assertEquals("高级配置留空的加载超时应回落全局默认", 1000, demo.getLoadTimeoutMs());

        // 登录站：认证类字段（登录成功标识）与探索参数从高级表合并，动作模式留空回落默认
        SiteConfig login = sites.stream().filter(s -> s.getSiteName().equals("本地登录站"))
                .findFirst().orElseThrow();
        assertEquals("高级配置登录成功标识应合并", "退出登录", login.getLoginSuccessText());
        assertEquals("高级配置动作数上限应合并", 3, login.getMaxActionsPerPage().intValue());
        assertFalse("高级配置动作模式留空应回落全局默认 QUERY", login.isAllButtonMode());

        // 覆盖站：只填覆盖项，认证字段来自主表
        SiteConfig cov = sites.stream().filter(s -> s.getSiteName().equals("覆盖测试站"))
                .findFirst().orElseThrow();
        assertEquals("覆盖站最大页面数", 1, cov.getMaxPages());
        assertTrue("覆盖站动作模式 ALL", cov.isAllButtonMode());
        assertNull("覆盖站无 TOKEN 配置", cov.getTokenHeader());

        // 孤立页面站：额外入口（相对路径）应解析为绝对地址；sitemap 开关显式覆盖全局默认
        SiteConfig iso = sites.stream().filter(s -> s.getSiteName().equals("孤立页面站"))
                .findFirst().orElseThrow();
        assertEquals("额外入口相对路径应解析为绝对地址", 1, iso.getExtraEntryUrls().size());
        assertTrue("额外入口应指向隐藏页面: " + iso.getExtraEntryUrls(),
                iso.getExtraEntryUrls().get(0).endsWith("/hidden-page"));
        assertEquals("孤立页面站显式开启 sitemap 发现", Boolean.TRUE, iso.getSitemapDiscovery());
        assertEquals("演示站显式关闭 sitemap 发现", Boolean.FALSE, demo.getSitemapDiscovery());
    }

    /** Sitemap 自动发现留空回落全局默认：高级配置留空（或无高级配置表）时回落 application.yml 全局默认值 */
    @Test
    public void sitemapDiscoveryFallsBackToGlobalDefault() throws Exception {
        String[][] rows = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"回落站", "http://localhost:9/", "true", "NONE", "", "",
                        "", "", "", "", "无高级配置表 → Sitemap 留空回落全局默认"}
        };
        Path excel = Files.createTempFile("sitemap-fallback", ".xlsx");
        try {
            writeExcel(excel, rows);

            // 全局默认 true（代码默认值）→ 留空回落 true
            assertTrue("全局默认 true 时留空应回落 true",
                    new ExcelConfigLoader(new PatrolProperties()).load(excel)
                            .get(0).getSitemapDiscovery());

            // 全局默认 false → 留空回落 false（修复前空值被硬编码为 true，全局配置不生效）
            PatrolProperties p = new PatrolProperties();
            p.getDefaults().setSitemapDiscovery(false);
            assertFalse("全局默认 false 时留空应回落 false",
                    new ExcelConfigLoader(p).load(excel).get(0).getSitemapDiscovery());
        } finally {
            Files.deleteIfExists(excel);
        }
    }

    /**
     * 孤立菜单页面全探索：hash 路由菜单、onclick 内联导航菜单、sitemap 孤立页面、
     * 额外入口配置的隐藏页面——四种探索通道应全部覆盖，每个页面都被巡检到。
     */
    @Test
    public void isolatedPagesAllExplored() {
        SiteInspection iso = inspections.stream().filter(s -> s.siteName().equals("孤立页面站"))
                .findFirst().orElseThrow();
        List<String> urls = iso.pages().stream().map(PageInspection::url).toList();
        assertEquals("孤立页面站应探索 7 个页面（首页 + 2 hash 菜单 + onclick 菜单 + 额外入口 + 2 sitemap 页）: "
                + urls, 7, iso.pagesVisited());
        assertEquals("孤立页面站全部页面应 PASS", Verdict.PASS, iso.verdict());
        assertTrue("hash 路由菜单A应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("#/hash-menu-a")));
        assertTrue("hash 路由菜单B应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("#/hash-menu-b")));
        assertTrue("onclick 内联导航菜单应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/onclick-menu")));
        assertTrue("额外入口配置的隐藏页面应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/hidden-page")));
        assertTrue("sitemap 孤立菜单1应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/isolated-menu1")));
        assertTrue("sitemap 孤立菜单2应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/isolated-menu2")));
        assertFalse("sitemap 中的外部地址不应被探索",
                urls.stream().anyMatch(u -> u.contains("external.example.com")));
    }

    @Test
    public void demoSiteVisitedAllPages() {
        SiteInspection site = demoSite();
        assertEquals("应巡检 11 个页面", 11, site.pagesVisited());
        assertEquals(Verdict.FAIL, site.verdict());
    }

    @Test
    public void normalPagesPass() {
        PageInspection home = page("/");
        assertNotNull(home);
        assertEquals(Verdict.PASS, home.verdict());
        assertTrue(home.requests().stream().anyMatch(r -> r.url().endsWith("/api/health")
                && r.status() == 200 && r.durationMs() >= 0));

        PageInspection ok = page("/ok-page");
        assertNotNull(ok);
        assertEquals(Verdict.PASS, ok.verdict());
    }

    @Test
    public void brokenApiPageFails() {
        PageInspection p = page("/broken-api");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue("应捕获 /api/fail 失败请求",
                p.requests().stream().anyMatch(r -> r.url().endsWith("/api/fail") && r.status() == 500));
        assertTrue("应捕获 console error",
                p.consoleLogs().stream().anyMatch(c -> c.isError() && c.text().contains("API 调用失败")));
        assertTrue("应包含后端失败与 console 问题",
                p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.BACKEND_FAILURE)
                        && p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.CONSOLE_ERROR));
    }

    @Test
    public void jsErrorPageFails() {
        PageInspection p = page("/js-error");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue(p.jsErrorCount() > 0);
        assertTrue(p.jsErrors().get(0).contains("模拟未捕获异常"));
    }

    @Test
    public void slowPageWarns() {
        PageInspection p = page("/slow");
        assertNotNull(p);
        assertEquals(Verdict.WARN, p.verdict());
        assertTrue(p.loadMs() >= 2900);
        assertTrue(p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.LOAD_TIMEOUT));
    }

    @Test
    public void notFoundPageFails() {
        PageInspection p = page("/error404");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertEquals(404, p.mainStatus());
    }

    @Test
    public void missingResourcePageFails() {
        PageInspection p = page("/missing-js");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue("应捕获 /not-exists.js 失败请求",
                p.requests().stream().anyMatch(r -> r.url().endsWith("/not-exists.js") && r.isFailed()));
    }

    @Test
    public void keywordPageFails() {
        PageInspection p = page("/keyword-page");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue(p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.ERROR_KEYWORD));
    }

    // ================= 动作巡检（查询按钮点击） =================

    @Test
    public void queryButtonActionPasses() {
        PageInspection p = page("/query-page");
        assertNotNull(p);
        assertEquals("ALL 模式遍历后（确认类排除词生效）页面应仍为 PASS", Verdict.PASS, p.verdict());
        assertEquals("应执行 1 个按钮动作（「查询」被遍历，「保存」被排除）", 1, p.actionCount());
        ActionInspection action = p.actions().get(0);
        assertEquals(Verdict.PASS, action.verdict());
        assertEquals("ALL 模式动作类型应为 ALL_BUTTON_CLICK", "ALL_BUTTON_CLICK", action.actionType());
        assertTrue("动作描述应标注全量遍历", action.description().contains("全量遍历按钮"));
        assertTrue("动作应触发 /api/query 请求",
                action.requests().stream().anyMatch(r -> r.url().contains("/api/query") && r.status() == 200));
        assertFalse("不应触发导航跳转", action.navigatedAway());
        assertNull("动作不应有异常", action.errorMessage());
    }

    @Test
    public void excludedConfirmButtonNeverClicked() {
        for (SiteInspection s : inspections) {
            for (PageInspection p : s.pages()) {
                assertFalse("确认类按钮（保存）不应被点击（页面请求）: " + p.url(),
                        p.requests().stream().anyMatch(r -> r.url().contains("/api/danger")));
                if (p.actions() != null) {
                    for (ActionInspection a : p.actions()) {
                        assertFalse("确认类按钮/弹窗确认不应被点击（动作请求）: " + a.description(),
                                a.requests().stream().anyMatch(r -> r.url().contains("/api/danger")));
                    }
                }
            }
        }
        assertEquals("危险端点（确认创建/确认删除/保存触发）调用计数应为 0",
                0, webServer.dangerCallCount());
    }

    // ================= 弹窗巡检：新增/编辑/删除可点击但不确认 =================

    @Test
    public void dialogButtonsClickedWithoutConfirm() {
        PageInspection p = page("/dialog-page");
        assertNotNull("弹窗演示页应被巡检", p);
        assertEquals("弹窗按钮点击+自动关闭（不确认）后页面应为 PASS", Verdict.PASS, p.verdict());
        assertNotNull(p.actions());
        assertEquals("应执行 3 个动作（新增/删除/导出），实际: "
                + (p.actions().stream().map(ActionInspection::description).toList()),
                3, p.actionCount());

        ActionInspection add = p.actions().stream()
                .filter(a -> a.description().contains("新增用户")).findFirst().orElseThrow();
        assertEquals("新增动作应为 PASS", Verdict.PASS, add.verdict());
        assertTrue("新增按钮点击应触发 /api/dialog-open 请求",
                add.requests().stream().anyMatch(r -> r.url().contains("/api/dialog-open") && r.status() == 200));
        assertTrue("新增动作描述应标注不确认: " + add.description(),
                add.description().contains("不确认"));

        ActionInspection del = p.actions().stream()
                .filter(a -> a.description().contains("删除用户")).findFirst().orElseThrow();
        assertEquals("删除动作应为 PASS（弹窗被自动关闭，未确认）", Verdict.PASS, del.verdict());
        assertEquals("危险端点未被调用（弹窗确认按钮绝未点击）", 0, webServer.dangerCallCount());
    }

    @Test
    public void exportDownloadExecutedAndRecorded() {
        PageInspection p = page("/dialog-page");
        assertNotNull(p);
        ActionInspection export = p.actions().stream()
                .filter(a -> a.description().contains("导出数据")).findFirst().orElseThrow();
        assertEquals("导出动作应为 PASS", Verdict.PASS, export.verdict());
        assertTrue("导出动作描述应标注下载: " + export.description(),
                export.description().contains("导出下载"));
        assertNotNull("导出动作应记录下载列表", export.downloads());
        assertTrue("下载记录应包含 patrol-export.txt: " + export.downloads(),
                export.downloads().stream().anyMatch(d -> d.contains("patrol-export.txt")));
        assertFalse("下载不应导致页面跳转", export.navigatedAway());
    }

    @Test
    public void brokenQueryActionFails() {
        PageInspection p = page("/query-broken");
        assertNotNull(p);
        assertEquals("动作 FAIL 应拖累页面结论", Verdict.FAIL, p.verdict());
        assertEquals(1, p.actionCount());
        ActionInspection action = p.actions().get(0);
        assertEquals(Verdict.FAIL, action.verdict());
        assertTrue("动作应捕获 /api/query-fail 失败请求",
                action.requests().stream().anyMatch(r -> r.url().endsWith("/api/query-fail") && r.status() == 500));
        assertTrue("动作应捕获 console error",
                action.consoleLogs().stream().anyMatch(c -> c.isError() && c.text().contains("查询接口失败")));
        assertTrue("动作 FAIL 应补充页面级问题",
                p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.ACTION_FAILURE));
        assertNotNull("动作 FAIL 应保存截图", action.screenshotPath());
        assertNotNull("动作 FAIL 应保存上下文", action.contextPath());
    }

    @Test
    public void elementsParsedOnPages() {
        PageInspection p = page("/query-page");
        assertNotNull(p);
        assertNotNull("页面应解析出元素清单", p.elements());
        assertTrue("应解析到查询/新增按钮等元素", p.elements().size() >= 2);
        assertTrue(p.elements().stream().anyMatch(e -> e.tag().equalsIgnoreCase("button")
                && e.text().contains("查询")));
    }

    // ================= 可点击元素全面覆盖：识别 + 分类路由 =================

    private SiteInspection coverageSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("覆盖测试站"))
                .findFirst().orElseThrow();
    }

    /** 按文本在覆盖演示页元素台账中查找元素 */
    private ElementDigest covElement(String text) {
        return coverageSite().pages().get(0).elements().stream()
                .filter(e -> text.equals(e.text()))
                .findFirst().orElse(null);
    }

    @Test
    public void clickableElementCoverageRecognizedAndRouted() {
        SiteInspection site = coverageSite();
        assertEquals("覆盖演示页所有动作应 PASS，实际: " + site.pages().get(0).issues(),
                Verdict.PASS, site.verdict());
        PageInspection p = site.pages().get(0);
        List<ActionInspection> actions = p.actions();
        assertEquals("应执行 6 个动作（图标按钮/卡片按钮/伪链接/标签页/折叠项/下载链接），实际: "
                + (actions == null ? List.of() : actions.stream().map(ActionInspection::description).toList()),
                6, p.actionCount());

        // 图标按钮：无可见文本，通过 aria-label 识别并点击
        ElementDigest icon = covElement("刷新数据");
        assertNotNull("图标按钮应通过 aria-label 识别", icon);
        assertEquals("图标按钮应为按钮类别", ElementDigest.K_BUTTON, icon.kind());
        assertEquals("已点击", icon.decision());
        assertTrue("图标按钮点击应触发 /api/refresh",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/refresh") && r.status() == 200)));

        // role=button 的 div 与 role=tab 的 span（ARIA 可点击角色）
        ElementDigest card = covElement("卡片按钮");
        assertNotNull("role=button 元素应被识别", card);
        assertEquals(ElementDigest.K_BUTTON, card.kind());
        assertEquals("已点击", card.decision());
        assertTrue("卡片按钮点击应触发 /api/aria-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/aria-click"))));
        ElementDigest tab = covElement("标签页一");
        assertNotNull("role=tab 元素应被识别", tab);
        assertEquals(ElementDigest.K_ARIA, tab.kind());
        assertEquals("已点击", tab.decision());
        assertTrue("标签页点击应触发 /api/tab-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/tab-click"))));

        // 无 href 的 JS 伪链接：作为可点击控件点击
        ElementDigest pseudo = covElement("展开更多");
        assertNotNull("无 href 伪链接应被识别", pseudo);
        assertEquals(ElementDigest.K_PSEUDO_LINK, pseudo.kind());
        assertEquals("已点击", pseudo.decision());
        assertTrue("伪链接点击应触发 /api/pseudo-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/pseudo-click"))));

        // 图片链接：锚文本兜底取 img alt；同源导航链接不点击（探索阶段覆盖）
        ElementDigest imgLink = covElement("图标链接说明");
        assertNotNull("图片链接应被识别（img alt 作文本）", imgLink);
        assertEquals("图片链接类别", ElementDigest.K_IMAGE_LINK, imgLink.kind());
        assertEquals("同源图片链接不点击（探索覆盖）", "导航链接·探索阶段覆盖", imgLink.decision());
        assertFalse("导航链接未被点击（不产生跳转动作）",
                actions.stream().anyMatch(a -> a.description().contains("图标链接说明")));

        // 外部链接：不点击
        ElementDigest ext = covElement("外部帮助文档");
        assertNotNull("外部链接应被识别", ext);
        assertEquals(ElementDigest.K_LINK, ext.kind());
        assertEquals("外部链接·不点击", ext.decision());
        assertTrue("外部链接地址应记录", ext.href().contains("example.com"));

        // 下载链接：真实点击执行下载并记录
        ElementDigest dl = covElement("下载报告");
        assertNotNull("下载链接应被识别", dl);
        assertEquals(ElementDigest.K_LINK, dl.kind());
        assertEquals("已点击·下载类", dl.decision());
        ActionInspection dlAction = actions.stream()
                .filter(a -> a.description().contains("下载报告")).findFirst().orElseThrow();
        assertTrue("下载链接动作应记录下载文件: " + dlAction.downloads(),
                dlAction.downloads() != null && dlAction.downloads()
                        .stream().anyMatch(d -> d.contains("patrol-export2.txt")));

        // 疑似可点击（cursor:pointer / tabindex 无语义标记）：仅记录不点击
        ElementDigest ptr = covElement("纯指针区域");
        assertNotNull("cursor:pointer 元素应被记录", ptr);
        assertEquals(ElementDigest.K_POINTER, ptr.kind());
        assertEquals("疑似可点击·仅记录", ptr.decision());
        ElementDigest focus = covElement("可聚焦卡片");
        assertNotNull("tabindex 元素应被记录", focus);
        assertEquals(ElementDigest.K_TABINDEX, focus.kind());
        assertEquals("疑似可点击·仅记录", focus.decision());

        // 折叠项 summary：作为可点击控件点击
        ElementDigest sum = covElement("折叠详情");
        assertNotNull("summary 折叠项应被识别", sum);
        assertEquals(ElementDigest.K_SUMMARY, sum.kind());
        assertEquals("已点击", sum.decision());

        // 输入类/表单元素：记录但不点击
        assertEquals("非按钮", covElement("名称标签").decision());
        ElementDigest input = p.elements().stream()
                .filter(e -> ElementDigest.K_INPUT.equals(e.kind()) && "nameInput".equals(e.id()))
                .findFirst().orElse(null);
        assertNotNull("文本输入框应被记录", input);
        assertEquals("非按钮", input.decision());
        ElementDigest sel = p.elements().stream()
                .filter(e -> ElementDigest.K_SELECT.equals(e.kind()))
                .findFirst().orElse(null);
        assertNotNull("下拉框应被记录", sel);
        assertEquals("非按钮", sel.decision());

        // 所有动作不应发生导航跳转（导航链接/外部链接均未点击）
        assertTrue("覆盖页动作不应跳转",
                actions.stream().noneMatch(ActionInspection::navigatedAway));
    }

    @Test
    public void summaryCountsActions() {
        assertEquals("演示站（ALL 模式）应有 5 个动作（查询+搜索+新增弹窗+删除弹窗+导出）",
                5, demoSite().totalActions());
        assertEquals("其中 1 个失败（异常查询页）", 1, demoSite().failedActions());
    }

    // ================= 认证与登录态复用 =================

    @Test
    public void formAuthSitePasses() {
        SiteInspection login = loginSite();
        assertNull("不应有站点级错误: " + login.errorMessage(), login.errorMessage());
        assertEquals(Verdict.PASS, login.verdict());
        assertTrue(login.pagesVisited() >= 1);
    }

    @Test
    public void loginStateCachedAndReused() throws Exception {
        Path stateFile = Path.of(properties.getLoginStateDir(), "本地登录站.json");
        assertTrue("FORM 登录后应缓存登录态: " + stateFile,
                Files.exists(stateFile) && Files.size(stateFile) > 50);
        long mtimeBefore = Files.getLastModifiedTime(stateFile).toMillis();

        // 第二次巡检同一站点：应复用缓存登录态（不再重新登录 → 状态文件不被更新）
        SiteConfig site = loader.load(Path.of(properties.getExcelPath())).stream()
                .filter(s -> s.getSiteName().equals("本地登录站"))
                .findFirst().orElseThrow();
        PatrolEngine engine = new PatrolEngine(properties, new HealthJudge());
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            SiteInspection second = engine.inspect(site, browser, reportDir, List.of());
            assertEquals("复用登录态后的巡检也应通过", Verdict.PASS, second.verdict());
        }
        assertEquals("应复用缓存登录态（状态文件未重新生成）",
                mtimeBefore, Files.getLastModifiedTime(stateFile).toMillis());
    }

    /**
     * MANUAL 人工登录第三种成功信号「登录成功Cookie」：
     * 登录在页面弹窗内完成、URL 不变化的站点（如百度 BDUSS）适用。
     * /manual-login 页加载 1.5s 后由 JS 种下 Cookie patrol_ok，框架应立即检测到并保存登录态，
     * 而不是等满手动登录超时。
     */
    @Test
    public void manualLoginCookieSignalDetected() throws Exception {
        SiteConfig site = new SiteConfig();
        site.setSiteName("手动登录站");
        site.setEntryUrl(webServer.baseUrl() + "/manual-login");
        site.setAuthType("MANUAL");
        site.setLoginSuccessCookie("patrol_ok");
        site.setManualLoginTimeoutSec(20);

        Path stateDir = Path.of("target", "login-state-manual-test");
        if (Files.exists(stateDir)) {
            try (var walk = Files.walk(stateDir)) {
                walk.sorted(java.util.Comparator.reverseOrder())
                        .forEach(p -> p.toFile().delete());
            }
        }

        long t0 = System.currentTimeMillis();
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false)) {
            com.patrol.engine.AuthSupport.preAuthenticate(playwright, properties, site, stateDir);
        }
        long elapsed = System.currentTimeMillis() - t0;

        Path state = stateDir.resolve("手动登录站.json");
        assertTrue("MANUAL 登录成功后应缓存登录态: " + state,
                Files.exists(state) && Files.size(state) > 50);
        String json = Files.readString(state);
        assertTrue("storageState 应包含登录 Cookie patrol_ok", json.contains("patrol_ok"));
        assertTrue("Cookie 信号应远早于超时被检测到（实际耗时 " + elapsed + "ms，超时 20s）",
                elapsed < 15_000);
    }

    // ================= 并行多站点巡检（PatrolRunner 两阶段端到端） =================

    /**
     * 验证执行编排：阶段一预认证（有头、串行）→ 阶段二并行无头巡检（Playwright 多实例）。
     * 4 个站点、并行度 2：3 个 NONE 站点正常巡检，1 个 FORM 站点登录地址不可达应判 FAIL 且不阻断其他站点。
     * 同时验证向后兼容：本用例刻意使用旧版 31 列宽表格式，旧配置文件无需迁移即可继续使用。
     */
    @Test
    public void parallelMultiSitePatrolWithTwoPhaseAuth() throws Exception {
        Path excel = Path.of("target", "parallel-sites.xlsx");
        String[][] rows = {
                ExcelTemplateHeaders.headRow(),
                parallelRow("并行站1", webServer.baseUrl() + "/ok-page", "NONE"),
                parallelRow("并行站2", webServer.baseUrl() + "/query-page", "NONE"),
                parallelRow("并行站3", webServer.baseUrl() + "/dialog-page", "NONE"),
                parallelRow("认证失败站", webServer.baseUrl() + "/ok-page", "FORM"),
        };
        // 认证失败站：登录地址端口不可达 → 阶段一有头认证快速失败
        rows[4][4] = "user";
        rows[4][5] = "pass";
        rows[4][6] = "http://127.0.0.1:1/login";
        rows[4][7] = "#u";
        rows[4][8] = "#p";
        rows[4][9] = "#s";
        writeExcel(excel, rows);

        PatrolProperties props = new PatrolProperties();
        props.setExcelPath(excel.toString());
        props.setOutputDir(Path.of("target", "parallel-report").toString());
        props.setLoginStateDir(Path.of("target", "login-state-parallel").toString());
        props.setMaxParallelSites(2);
        props.setStrictExit(false);
        props.getDefaults().setLoadTimeoutMs(2000);

        PatrolRunner runner = new PatrolRunner(props,
                new ExcelConfigLoader(props),
                new PatrolEngine(props, new HealthJudge()),
                new JsonReportWriter(), new ExcelReportGenerator(), new HtmlReportGenerator(),
                new com.patrol.report.ReportIndexGenerator());
        runner.run();

        // 读取最新报告目录中的 JSON 结果
        Path outRoot = Path.of("target", "parallel-report");
        Path latest;
        try (var stream = Files.list(outRoot)) {
            latest = stream.filter(Files::isDirectory)
                    .max(java.util.Comparator.comparing(p -> p.getFileName().toString()))
                    .orElseThrow(() -> new AssertionError("应生成报告目录"));
        }
        com.fasterxml.jackson.databind.JsonNode sites = new com.fasterxml.jackson.databind.ObjectMapper()
                .readTree(latest.resolve("patrol-result.json").toFile()).get("sites");

        assertEquals("4 个站点均应有结果（按配置顺序）", 4, sites.size());
        assertEquals("结果顺序应与配置一致: " + sites.get(0).get("siteName").asText(),
                "并行站1", sites.get(0).get("siteName").asText());
        assertEquals("并行站2", sites.get(1).get("siteName").asText());
        assertEquals("并行站3", sites.get(2).get("siteName").asText());
        assertEquals("认证失败站", sites.get(3).get("siteName").asText());

        for (int i = 0; i < 3; i++) {
            assertEquals("NONE 站点应巡检通过: " + sites.get(i).get("siteName").asText(),
                    "PASS", sites.get(i).get("verdict").asText());
            assertTrue("站点应巡检到页面: " + sites.get(i).get("siteName").asText(),
                    sites.get(i).get("pages").size() >= 1);
        }
        assertEquals("认证失败站点应判 FAIL", "FAIL", sites.get(3).get("verdict").asText());
        assertTrue("应记录认证失败原因: " + sites.get(3).get("errorMessage").asText(),
                sites.get(3).get("errorMessage").asText().contains("登录认证失败"));
        assertEquals("认证失败站点不应有页面", 0, sites.get(3).get("pages").size());

        // 三份报告文件应存在
        assertTrue(Files.exists(latest.resolve("report.html")));
        assertTrue(Files.exists(latest.resolve("patrol-report.xlsx")));

        // 历次巡检索引页应自动生成并包含本次巡检
        Path index = outRoot.resolve("index.html");
        assertTrue("应生成历次报告索引页", Files.exists(index));
        String indexHtml = Files.readString(index);
        assertTrue("索引页应链接本次报告目录", indexHtml.contains(latest.getFileName().toString()));
        assertTrue("索引页应展示站点统计", indexHtml.contains("并行站1"));
    }

    /** 并行测试行：单页、零深度、禁用动作 */
    private static String[] parallelRow(String name, String url, String auth) {
        String[] r = new String[31];
        r[0] = name;
        r[1] = url;
        r[2] = "true";
        r[3] = auth;
        r[16] = "1";       // 最大页面数
        r[17] = "0";       // 最大深度
        r[20] = "false";   // 禁用动作巡检（保持测试精简）
        r[22] = "0";       // 动作上限
        r[28] = "2000";    // 加载超时
        r[30] = "并行巡检测试站点";
        return r;
    }

    // ================= 证据与报告 =================

    @Test
    public void evidenceSavedForAbnormalPages() throws Exception {
        for (PageInspection p : demoSite().pages()) {
            if (p.verdict() == Verdict.FAIL || p.verdict() == Verdict.WARN) {
                assertNotNull("异常页应保存截图: " + p.url(), p.screenshotPath());
                assertNotNull("异常页应保存上下文 JSON: " + p.url(), p.contextPath());
                Path shot = reportDir.resolve(p.screenshotPath().replace('/', '\\').replace('\\', '/'));
                assertTrue("截图文件应存在: " + shot, Files.exists(shot) && Files.size(shot) > 100);
                Path ctx = reportDir.resolve(p.contextPath().replace('/', '\\').replace('\\', '/'));
                assertTrue("上下文 JSON 应存在: " + ctx, Files.exists(ctx) && Files.size(ctx) > 50);
            }
        }
    }

    @Test
    public void evidenceContextContainsDetails() throws Exception {
        PageInspection p = page("/broken-api");
        Path ctx = reportDir.resolve(p.contextPath());
        String json = Files.readString(ctx);
        assertTrue(json.contains("/api/fail"));
        assertTrue(json.contains("API 调用失败"));
        assertTrue(json.contains("responseSnippet"));
        assertTrue(json.contains("pageHtmlExcerpt"));
    }

    @Test
    public void reportsGenerated() throws Exception {
        int totalActions = inspections.stream().mapToInt(SiteInspection::totalActions).sum();
        int failedActions = inspections.stream().mapToInt(s -> (int) s.failedActions()).sum();
        PatrolSummary summary = new PatrolSummary(
                inspections.size(), inspections.size(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.PASS).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.WARN).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.FAIL).count(),
                inspections.stream().mapToInt(SiteInspection::pagesVisited).sum(),
                inspections.stream().mapToInt(s -> (int) s.passPages()).sum(),
                inspections.stream().mapToInt(s -> (int) s.warnPages()).sum(),
                inspections.stream().mapToInt(s -> (int) s.failPages()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.consoleErrorCount()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.jsErrorCount()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.failedRequestCount()).sum(),
                totalActions, failedActions, 0);
        PatrolReport report = new PatrolReport(
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                "target/test-sites.xlsx", "chromium (test)", inspections, summary);

        Path json = reportDir.resolve("patrol-result.json");
        new JsonReportWriter().write(report, json);
        Path xlsx = reportDir.resolve("patrol-report.xlsx");
        new ExcelReportGenerator().generate(report, xlsx);
        Path html = reportDir.resolve("report.html");
        new HtmlReportGenerator().generate(report, html);

        assertTrue(Files.exists(json) && Files.size(json) > 1000);
        assertTrue(Files.exists(xlsx) && Files.size(xlsx) > 5000);
        assertTrue(Files.exists(html) && Files.size(html) > 3000);

        // JSON 应包含动作明细字段
        String jsonText = Files.readString(json);
        assertTrue("JSON 应包含动作明细", jsonText.contains("\"actions\""));
        assertTrue("JSON 应包含元素解析", jsonText.contains("\"elements\""));
        assertTrue("JSON 应包含动作统计", jsonText.contains("\"totalActions\""));

        // Excel 应包含动作明细 sheet
        try (XSSFWorkbook wb = new XSSFWorkbook(xlsx.toFile())) {
            assertNotNull("Excel 应有动作明细 sheet", wb.getSheet("动作明细"));
            assertNotNull(wb.getSheet("页面明细"));
            // 动作明细 sheet 应有 2 条数据行（查询+搜索）
            assertTrue("动作明细应有数据行",
                    wb.getSheet("动作明细").getLastRowNum() >= 2);
        }

        // HTML 应包含动作区块
        String htmlText = Files.readString(html);
        assertTrue("HTML 应展示功能动作", htmlText.contains("功能动作"));
        assertTrue("HTML 应展示执行动作汇总", htmlText.contains("执行动作"));

        // 历次巡检索引页应可生成且包含本报告目录
        Path index = new com.patrol.report.ReportIndexGenerator().generate(reportDir.getParent());
        assertNotNull("索引页应生成", index);
        String indexHtml = Files.readString(index);
        assertTrue("索引页应链接本报告目录", indexHtml.contains(reportDir.getFileName().toString()));
        assertTrue("索引页应展示站点名称", indexHtml.contains("本地演示站"));
    }

    @AfterClass
    public void tearDown() {
        if (webServer != null) {
            webServer.stop();
        }
    }
}
