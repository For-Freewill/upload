package com.patrol.report;

import com.patrol.model.ConsoleRecord;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.RequestRecord;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Excel 巡检汇总报告：巡检总览 / 页面明细 / 动作明细 / 子页面链接 / 页面元素 / 失败请求 / Console错误 七个 sheet。
 * 「子页面链接」记录页面探索父子关系；「页面元素」记录每个按钮的处理决策台账。
 */
@Component
public class ExcelReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(ExcelReportGenerator.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void generate(PatrolReport report, Path file) {
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            XSSFCellStyle headerStyle = headerStyle(wb);
            XSSFCellStyle failStyle = verdictStyle(wb, IndexedColors.ROSE);
            XSSFCellStyle warnStyle = verdictStyle(wb, IndexedColors.LIGHT_ORANGE);
            XSSFCellStyle passStyle = verdictStyle(wb, IndexedColors.LIGHT_GREEN);

            overviewSheet(wb, report, headerStyle, passStyle, warnStyle, failStyle);
            pageSheet(wb, report, headerStyle, passStyle, warnStyle, failStyle);
            actionSheet(wb, report, headerStyle, passStyle, warnStyle, failStyle);
            linkSheet(wb, report, headerStyle, passStyle, warnStyle, failStyle);
            elementSheet(wb, report, headerStyle);
            failedRequestSheet(wb, report, headerStyle, failStyle);
            consoleSheet(wb, report, headerStyle);

            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                wb.write(out);
            }
            log.info("Excel 报告已生成: {}", file);
        } catch (Exception e) {
            log.error("Excel 报告生成失败: {}", e.getMessage(), e);
        }
    }

    private void overviewSheet(XSSFWorkbook wb, PatrolReport report,
                              XSSFCellStyle header, XSSFCellStyle pass, XSSFCellStyle warn, XSSFCellStyle fail) {
        XSSFSheet sheet = wb.createSheet("巡检总览");
        // 元信息块
        String[][] meta = {
                {"巡检报告", ""},
                {"开始时间", report.startedAt()},
                {"结束时间", report.finishedAt()},
                {"配置文件", report.excelConfigPath()},
                {"浏览器", report.browserInfo()},
                {"站点总数", String.valueOf(report.summary().totalSites())},
                {"巡检页面总数", String.valueOf(report.summary().totalPages())},
                {"执行动作总数", String.valueOf(report.summary().totalActions())},
                {"失败动作数", String.valueOf(report.summary().failedActions())},
        };
        for (int r = 0; r < meta.length; r++) {
            XSSFRow row = sheet.createRow(r);
            row.createCell(0).setCellValue(meta[r][0]);
            row.createCell(1).setCellValue(meta[r][1]);
            if (r == 0) {
                XSSFFont bold = wb.createFont();
                bold.setBold(true);
                bold.setFontHeight(14);
                row.getCell(0).getCellStyle().setFont(bold);
            }
        }
        int start = meta.length + 1;
        String[] headers = {"站点", "入口URL", "认证方式", "巡检页面数", "PASS", "WARN",
                "FAIL", "执行动作", "失败动作", "发现链接数", "站点结论", "错误信息"};
        XSSFRow headerRow = sheet.createRow(start);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, c == 1 ? 14000 : 7000);
        }
        int r = start + 1;
        for (SiteInspection s : report.sites()) {
            XSSFRow row = sheet.createRow(r++);
            row.createCell(0).setCellValue(s.siteName());
            row.createCell(1).setCellValue(s.entryUrl());
            row.createCell(2).setCellValue(s.authType());
            row.createCell(3).setCellValue(s.pagesVisited());
            row.createCell(4).setCellValue(s.passPages());
            row.createCell(5).setCellValue(s.warnPages());
            row.createCell(6).setCellValue(s.failPages());
            row.createCell(7).setCellValue(s.totalActions());
            row.createCell(8).setCellValue(s.failedActions());
            row.createCell(9).setCellValue(s.linksFound());
            XSSFCell verdict = row.createCell(10);
            verdict.setCellValue(s.verdict().name());
            verdict.setCellStyle(styleOf(s.verdict(), pass, warn, fail));
            row.createCell(11).setCellValue(s.errorMessage() == null ? "" : s.errorMessage());
        }
    }

    private void pageSheet(XSSFWorkbook wb, PatrolReport report, XSSFCellStyle header,
                           XSSFCellStyle pass, XSSFCellStyle warn, XSSFCellStyle fail) {
        XSSFSheet sheet = wb.createSheet("页面明细");
        String[] headers = {"站点", "URL", "标题", "父页面", "主文档状态码", "加载耗时(ms)", "console错误",
                "JS异常", "失败请求", "执行动作", "失败动作", "子页面链接", "已巡检子页面",
                "页面结论", "问题摘要", "截图", "上下文JSON"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, (c == 1 || c == 3 || c == 14) ? 14000 : 6400);
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                XSSFRow row = sheet.createRow(r++);
                row.createCell(0).setCellValue(s.siteName());
                row.createCell(1).setCellValue(p.url());
                row.createCell(2).setCellValue(p.title() == null ? "" : p.title());
                row.createCell(3).setCellValue(p.parentUrl() == null ? "(入口页)" : p.parentUrl());
                row.createCell(4).setCellValue(p.mainStatus());
                row.createCell(5).setCellValue(p.loadMs());
                row.createCell(6).setCellValue(p.consoleErrorCount());
                row.createCell(7).setCellValue(p.jsErrorCount());
                row.createCell(8).setCellValue(p.failedRequestCount());
                row.createCell(9).setCellValue(p.actionCount());
                row.createCell(10).setCellValue(p.failedActionCount());
                row.createCell(11).setCellValue(p.childLinks() == null ? 0 : p.childLinks().size());
                row.createCell(12).setCellValue(p.exploredChildCount());
                XSSFCell verdict = row.createCell(13);
                verdict.setCellValue(p.verdict().name());
                verdict.setCellStyle(styleOf(p.verdict(), pass, warn, fail));
                row.createCell(14).setCellValue(issueSummary(p));
                row.createCell(15).setCellValue(p.screenshotPath() == null ? "" : p.screenshotPath());
                row.createCell(16).setCellValue(p.contextPath() == null ? "" : p.contextPath());
            }
        }
    }

    /** 功能动作明细 sheet：页面元素点击巡检的逐动作结果 */
    private void actionSheet(XSSFWorkbook wb, PatrolReport report, XSSFCellStyle header,
                             XSSFCellStyle pass, XSSFCellStyle warn, XSSFCellStyle fail) {
        XSSFSheet sheet = wb.createSheet("动作明细");
        String[] headers = {"站点", "页面URL", "动作类型", "动作描述", "按钮类别", "触发请求数", "失败请求",
                "console错误", "JS异常", "是否跳转", "是否跳过", "动作结论", "下载文件", "异常信息", "动作截图", "动作上下文JSON"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, (c == 1 ? 14000 : (c == 3 || c == 11 ? 10000 : 6400)));
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.actions() == null) continue;
                for (com.patrol.model.ActionInspection a : p.actions()) {
                    XSSFRow row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.siteName());
                    row.createCell(1).setCellValue(p.url());
                    row.createCell(2).setCellValue(a.actionType());
                    row.createCell(3).setCellValue(a.description());
                    row.createCell(4).setCellValue(a.buttonCategory() == null ? "" : a.buttonCategory());
                    row.createCell(5).setCellValue(a.requests() == null ? 0 : a.requests().size());
                    row.createCell(6).setCellValue(a.failedRequestCount());
                    row.createCell(7).setCellValue(a.consoleErrorCount());
                    row.createCell(8).setCellValue(a.jsErrorCount());
                    row.createCell(9).setCellValue(a.navigatedAway() ? "是" : "否");
                    row.createCell(10).setCellValue(a.skipped() ? "是" : "否");
                    XSSFCell verdict = row.createCell(11);
                    verdict.setCellValue(a.verdict().name());
                    verdict.setCellStyle(styleOf(a.verdict(), pass, warn, fail));
                    row.createCell(12).setCellValue(a.downloads() == null ? ""
                            : String.join("; ", a.downloads()));
                    row.createCell(13).setCellValue(a.errorMessage() == null ? "" : a.errorMessage());
                    row.createCell(14).setCellValue(a.screenshotPath() == null ? "" : a.screenshotPath());
                    row.createCell(15).setCellValue(a.contextPath() == null ? "" : a.contextPath());
                }
            }
        }
    }

    /** 子页面链接 sheet：页面探索过程发现的子页面链接及巡检状态 */
    private void linkSheet(XSSFWorkbook wb, PatrolReport report, XSSFCellStyle header,
                           XSSFCellStyle pass, XSSFCellStyle warn, XSSFCellStyle fail) {
        XSSFSheet sheet = wb.createSheet("子页面链接");
        String[] headers = {"站点", "来源页面", "子页面URL", "链接文本", "是否已巡检", "子页面结论"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, (c == 1 || c == 2 ? 14000 : (c == 3 ? 8000 : 6400)));
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.childLinks() == null) continue;
                for (com.patrol.model.LinkRecord l : p.childLinks()) {
                    XSSFRow row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.siteName());
                    row.createCell(1).setCellValue(p.url());
                    row.createCell(2).setCellValue(l.url());
                    row.createCell(3).setCellValue(l.text() == null ? "" : l.text());
                    row.createCell(4).setCellValue(l.explored() ? "是" : "否");
                    if (l.explored() && l.childVerdict() != null) {
                        XSSFCell verdict = row.createCell(5);
                        verdict.setCellValue(l.childVerdict().name());
                        verdict.setCellStyle(styleOf(l.childVerdict(), pass, warn, fail));
                    } else {
                        row.createCell(5).setCellValue("");
                    }
                }
            }
        }
    }

    /** 页面元素 sheet：每个页面的可点击元素台账（含类别、链接地址与处理决策） */
    private void elementSheet(XSSFWorkbook wb, PatrolReport report, XSSFCellStyle header) {
        XSSFSheet sheet = wb.createSheet("页面元素");
        String[] headers = {"站点", "页面URL", "元素", "类别", "文本", "ID", "类型", "链接地址", "可见", "处理决策"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, (c == 1 ? 14000 : (c == 4 || c == 7 ? 8000 : 6400)));
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.elements() == null) continue;
                for (com.patrol.model.ElementDigest el : p.elements()) {
                    XSSFRow row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.siteName());
                    row.createCell(1).setCellValue(p.url());
                    row.createCell(2).setCellValue(el.tag());
                    row.createCell(3).setCellValue(el.kindLabel());
                    row.createCell(4).setCellValue(el.text());
                    row.createCell(5).setCellValue(el.id());
                    row.createCell(6).setCellValue(el.type());
                    row.createCell(7).setCellValue(el.href() == null ? "" : el.href());
                    row.createCell(8).setCellValue(el.visible() ? "是" : "否");
                    row.createCell(9).setCellValue(el.decision() == null ? "" : el.decision());
                }
            }
        }
    }

    private void failedRequestSheet(XSSFWorkbook wb, PatrolReport report,
                                    XSSFCellStyle header, XSSFCellStyle fail) {
        XSSFSheet sheet = wb.createSheet("失败请求");
        String[] headers = {"站点", "页面URL", "请求URL", "方法", "资源类型", "状态码", "失败原因", "耗时(ms)"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, c == 1 || c == 2 ? 14000 : 6400);
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                for (RequestRecord req : p.requests()) {
                    if (!req.isFailed()) continue;
                    XSSFRow row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.siteName());
                    row.createCell(1).setCellValue(p.url());
                    row.createCell(2).setCellValue(req.url());
                    row.createCell(3).setCellValue(req.method());
                    row.createCell(4).setCellValue(req.resourceType());
                    XSSFCell status = row.createCell(5);
                    status.setCellValue(req.status());
                    status.setCellStyle(fail);
                    row.createCell(6).setCellValue(req.failureText() == null ? "" : req.failureText());
                    row.createCell(7).setCellValue(req.durationMs());
                }
                // 动作触发的失败请求
                if (p.actions() == null) continue;
                for (com.patrol.model.ActionInspection a : p.actions()) {
                    if (a.requests() == null) continue;
                    for (RequestRecord req : a.requests()) {
                        if (!req.isFailed()) continue;
                        XSSFRow row = sheet.createRow(r++);
                        row.createCell(0).setCellValue(s.siteName());
                        row.createCell(1).setCellValue(p.url() + " ← " + a.description());
                        row.createCell(2).setCellValue(req.url());
                        row.createCell(3).setCellValue(req.method());
                        row.createCell(4).setCellValue(req.resourceType());
                        XSSFCell status = row.createCell(5);
                        status.setCellValue(req.status());
                        status.setCellStyle(fail);
                        row.createCell(6).setCellValue(req.failureText() == null ? "" : req.failureText());
                        row.createCell(7).setCellValue(req.durationMs());
                    }
                }
            }
        }
    }

    private void consoleSheet(XSSFWorkbook wb, PatrolReport report, XSSFCellStyle header) {
        XSSFSheet sheet = wb.createSheet("Console错误");
        String[] headers = {"站点", "页面URL", "级别", "内容", "定位"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(header);
            sheet.setColumnWidth(c, c == 3 ? 14000 : (c == 1 ? 14000 : 6400));
        }
        int r = 1;
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                for (ConsoleRecord c : p.consoleLogs()) {
                    if (!c.isError()) continue;
                    XSSFRow row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.siteName());
                    row.createCell(1).setCellValue(p.url());
                    row.createCell(2).setCellValue(c.level());
                    row.createCell(3).setCellValue(c.text());
                    row.createCell(4).setCellValue(c.location() == null ? "" : c.location());
                }
                // 动作期间的 console 错误
                if (p.actions() == null) continue;
                for (com.patrol.model.ActionInspection a : p.actions()) {
                    if (a.consoleLogs() == null) continue;
                    for (ConsoleRecord c : a.consoleLogs()) {
                        if (!c.isError()) continue;
                        XSSFRow row = sheet.createRow(r++);
                        row.createCell(0).setCellValue(s.siteName());
                        row.createCell(1).setCellValue(p.url() + " ← " + a.description());
                        row.createCell(2).setCellValue(c.level());
                        row.createCell(3).setCellValue(c.text());
                        row.createCell(4).setCellValue(c.location() == null ? "" : c.location());
                    }
                }
            }
        }
    }

    private static String issueSummary(PageInspection p) {
        if (p.issues() == null || p.issues().isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (com.patrol.model.IssueRecord ir : p.issues()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(ir.type().label()).append(": ").append(ir.message());
        }
        return sb.toString();
    }

    private static XSSFCellStyle headerStyle(XSSFWorkbook wb) {
        XSSFCellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        XSSFFont bold = wb.createFont();
        bold.setBold(true);
        style.setFont(bold);
        return style;
    }

    private static XSSFCellStyle verdictStyle(XSSFWorkbook wb, IndexedColors color) {
        XSSFCellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(color.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        XSSFFont bold = wb.createFont();
        bold.setBold(true);
        style.setFont(bold);
        return style;
    }

    private static XSSFCellStyle styleOf(Verdict v, XSSFCellStyle pass, XSSFCellStyle warn, XSSFCellStyle fail) {
        return switch (v) {
            case FAIL -> fail;
            case WARN -> warn;
            default -> pass;
        };
    }
}
