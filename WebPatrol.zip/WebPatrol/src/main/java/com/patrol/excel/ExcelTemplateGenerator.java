package com.patrol.excel;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * 生成 sites.xlsx 配置模板。
 *
 * <p>双表结构，降低日常配置门槛：</p>
 * <ul>
 *   <li><b>Sites 主表（11 列核心字段）</b>：站点名称/入口URL/启用/认证方式/用户名/密码/
 *       登录URL/用户名选择器/密码选择器/提交按钮选择器/备注。日常巡检只需填这张表。</li>
 *   <li><b>站点高级配置 sheet（可选）</b>：按「站点名称」关联 Sites 行，提供探索参数、
 *       动作巡检、健康阈值、登录成功标识、Token 等覆盖项。全部留空 = 使用 application.yml
 *       全局默认值；只有需要个性化调优的站点才需要填。</li>
 * </ul>
 * <p>旧版 33 列宽表格式仍然兼容（加载器按表头别名解析，与列顺序无关）。</p>
 */
public class ExcelTemplateGenerator {

    private static final Logger log = LoggerFactory.getLogger(ExcelTemplateGenerator.class);

    /** Sites 主表：核心字段（认证所需信息） */
    public static final String[] HEADERS = {
            "站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
            "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"
    };

    private static final String[][] EXAMPLES = {
            {"示例-无认证", "https://example.com", "true", "NONE", "", "",
                    "", "", "", "", "匿名站点：改好入口URL 即可巡检（唯一启用的示例行，可随时关闭）"},
            {"示例-表单登录", "http://your-site.local/home", "false", "FORM", "admin", "admin123",
                    "http://your-site.local/login", "#username", "#password", "#loginBtn",
                    "自动填表登录；「登录成功标识」等在 站点高级配置 表中填写"},
            {"示例-手动登录", "http://your-site.local/home", "false", "MANUAL", "", "",
                    "http://your-site.local/login", "", "", "",
                    "弹出浏览器人工登录（验证码/短信均可）；「登录成功URL包含」在 站点高级配置 表中填写"},
            {"示例-SSO单点登录", "http://your-app.local/home", "false", "SSO", "", "",
                    "https://sso.company.com/cas/login", "", "", "",
                    "弹出浏览器完成 SSO 跳转登录；「登录成功URL包含」在 站点高级配置 表中填写"},
            {"示例-Basic认证", "http://your-site.local/home", "false", "BASIC", "admin", "admin123",
                    "", "", "", "", "HTTP Basic 认证：仅需 用户名/密码，无需高级配置"},
            {"示例-Token认证", "http://your-api-site.local/home", "false", "TOKEN", "", "",
                    "", "", "", "",
                    "以自定义请求头注入 Token；「Token请求头/Token值」在 站点高级配置 表中填写"}
    };

    /** 站点高级配置表：全部可选，留空 = application.yml 全局默认 */
    public static final String[] ADVANCED_HEADERS = {
            "站点名称", "最大页面数", "最大深度", "额外入口URL", "包含路径前缀", "排除路径前缀",
            "Sitemap自动发现",
            "启用动作巡检", "动作模式", "动作数上限",
            "查询按钮关键词", "排除按钮关键词", "对话框按钮关键词", "下载按钮关键词",
            "Console错误上限", "JS异常上限", "失败请求上限", "加载超时(ms)", "错误关键词",
            "登录成功标识", "登录成功URL包含", "登录成功Cookie", "复用登录状态", "手动登录超时(秒)",
            "Token请求头", "Token值"
    };

    private static final String[][] ADVANCED_EXAMPLES = {
            {"示例-无认证", "10", "2", "", "", "/logout",
                    "",
                    "true", "QUERY", "5",
                    "", "", "", "",
                    "", "", "", "", "",
                    "", "", "", "", "",
                    "", "", ""},
            {"示例-表单登录", "15", "2", "/reports,/settings", "", "/logout,/api",
                    "",
                    "true", "ALL", "8",
                    "", "", "", "",
                    "0", "0", "0", "20000", "",
                    "退出登录", "", "", "true", "",
                    "", ""},
            {"示例-手动登录", "", "", "", "", "/logout",
                    "false",
                    "true", "QUERY", "",
                    "", "", "", "",
                    "", "", "", "", "",
                    "", "home", "", "true", "300",
                    "", ""},
            {"示例-SSO单点登录", "", "", "", "", "/logout",
                    "false",
                    "true", "QUERY", "",
                    "", "", "", "",
                    "", "", "", "", "",
                    "", "home", "", "true", "600",
                    "", ""},
            {"示例-Token认证", "", "", "", "", "",
                    "",
                    "true", "QUERY", "",
                    "", "", "", "",
                    "", "", "", "", "",
                    "", "", "", "true", "",
                    "Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.example-token"}
    };

    private static final String[][] DOCS = {
            {"站点名称", "siteName", "必填", "站点唯一标识，用于报告分组、高级配置关联与证据目录命名"},
            {"入口URL", "entryUrl", "必填", "巡检起始地址，从该页开始自动探索"},
            {"启用", "enabled", "默认true", "false/否/0 时跳过该站点"},
            {"认证方式", "authType", "默认NONE", "NONE / BASIC / FORM / TOKEN / MANUAL / SSO 六选一"},
            {"用户名/密码", "username/password", "看认证方式", "BASIC 与 FORM 认证使用"},
            {"登录URL", "loginUrl", "FORM 必填，MANUAL 可选", "登录页地址（MANUAL 不填则打开入口URL）"},
            {"用户名选择器", "usernameSelector", "FORM 必填", "登录页用户名输入框 CSS 选择器"},
            {"密码选择器", "passwordSelector", "FORM 必填", "登录页密码输入框 CSS 选择器"},
            {"提交按钮选择器", "submitSelector", "FORM 必填", "登录提交按钮 CSS 选择器"},
            {"备注", "notes", "可选", "任意说明"}
    };

    private static final String[][] ADVANCED_DOCS = {
            {"站点名称", "siteName", "必填", "必须与 Sites 表中的站点名称一致，用于关联覆盖项"},
            {"最大页面数", "maxPages", "默认10", "该站点最多巡检的页面数"},
            {"最大深度", "maxDepth", "默认2", "从入口页起算的最大链接深度"},
            {"额外入口URL", "extraEntryUrls", "可选", "逗号分隔；孤立菜单页面等链接不可达的页面在此登记，作为 depth 0 种子探索（支持相对路径，如 /tools）"},
            {"包含路径前缀", "pathIncludePrefixes", "可选", "逗号分隔；仅探索匹配前缀的链接，空=不限"},
            {"排除路径前缀", "pathExcludePrefixes", "建议填写", "逗号分隔；匹配的链接不巡检（建议排除 /logout；API 前缀如 /api 也可排除，避免下载/接口被当页面巡检）"},
            {"Sitemap自动发现", "sitemapDiscovery", "默认true", "探索前抓取同源 /sitemap.xml 自动补充孤立页面（无 sitemap 则静默跳过）；设 false 关闭"},
            {"启用动作巡检", "enableActions", "默认true", "是否解析页面元素并自动点击操作按钮"},
            {"动作模式", "actionMode", "默认QUERY", "QUERY=只点查询按钮；ALL=遍历全部按钮型元素（三类安全策略生效，适合完整功能遍历）"},
            {"动作数上限", "maxActionsPerPage", "默认5", "单页最大动作数（自定义动作+自动按钮点击总数）"},
            {"查询按钮关键词", "queryButtonKeywords", "全局默认", "逗号分隔；QUERY 模式下文本匹配的按钮将被点击"},
            {"排除按钮关键词", "excludedButtonKeywords", "全局默认", "逗号分隔；确认类按钮（保存/提交/确认/登录/退出…）永不点击"},
            {"对话框按钮关键词", "dialogButtonKeywords", "全局默认", "逗号分隔；新增/编辑/删除类按钮允许点击，随后自动关闭对话框、绝不点确认"},
            {"下载按钮关键词", "downloadButtonKeywords", "全局默认", "逗号分隔；导出/下载类按钮真实执行下载并记录文件名与来源URL"},
            {"Console错误上限", "consoleErrorsMax", "默认0", "超过即判 FAIL（页面访问与每个动作分别判定）"},
            {"JS异常上限", "jsErrorsMax", "默认0", "未捕获 JS 异常超过即判 FAIL"},
            {"失败请求上限", "failedRequestsMax", "默认0", "HTTP>=400 或网络层失败的请求数超过即判 FAIL"},
            {"加载超时(ms)", "loadTimeoutMs", "默认15000", "主文档加载超过即判 WARN(超时)/FAIL(失败)"},
            {"错误关键词", "errorKeywords", "全局默认", "逗号分隔；页面内容命中即判 FAIL"},
            {"登录成功标识", "loginSuccessText", "建议填写", "登录成功后页面应出现的文本，验证登录是否生效"},
            {"登录成功URL包含", "loginSuccessUrlContains", "MANUAL/SSO 建议", "登录成功后 URL 应包含的串（人工登录完成的信号，三种信号任一命中即可）"},
            {"登录成功Cookie", "loginSuccessCookie", "MANUAL/SSO 可选", "登录成功后浏览器出现的 Cookie 名（如百度 BDUSS）——适用于登录在页面弹窗内完成、URL 不变的站点"},
            {"复用登录状态", "reuseLoginState", "默认true", "FORM/MANUAL/SSO 登录态缓存到 login-state/，跨巡检复用"},
            {"手动登录超时(秒)", "manualLoginTimeoutSec", "默认300", "MANUAL/SSO 等待人工完成登录的最长时间"},
            {"Token请求头", "tokenHeader", "TOKEN 必填", "以自定义请求头注入 Token（如 Authorization）"},
            {"Token值", "tokenValue", "TOKEN 必填", "Token 内容（如 Bearer xxx）"}
    };

    private static final String[] ACTION_HEADERS = {
            "站点名称", "页面URL匹配", "动作类型", "元素选择器", "填充值", "说明", "启用"
    };

    private static final String[][] ACTION_EXAMPLES = {
            {"示例-表单登录", "/home", "CLICK", "#btnSearch", "input[name=keyword]=巡检", "点击查询按钮前先填关键字", "false"}
    };

    private static final String[][] ACTION_DOCS = {
            {"站点名称", "siteName", "必填", "动作所属站点（须与 Sites 表中的站点名称一致）"},
            {"页面URL匹配", "urlMatch", "可选", "精确 URL；以 * 结尾表示前缀匹配（如 /list*）；空=该站点所有页面"},
            {"动作类型", "actionType", "CLICK", "当前仅支持 CLICK"},
            {"元素选择器", "selector", "必填", "目标元素 CSS 选择器"},
            {"填充值", "fills", "可选", "点击前填充：选择器=值;选择器=值（多个分号分隔）"},
            {"说明", "description", "可选", "动作说明（报告中展示）"},
            {"启用", "enabled", "true", "false 时跳过该动作"}
    };

    /** 生成模板文件（存在则跳过） */
    public static void generateIfAbsent(Path target) throws Exception {
        if (Files.exists(target)) {
            log.info("配置模板已存在，跳过生成: {}", target);
            return;
        }
        Files.createDirectories(target.getParent());
        generate(target);
    }

    /** 强制生成模板文件 */
    public static void generate(Path target) throws Exception {
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            XSSFCellStyle headerStyle = wb.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont bold = wb.createFont();
            bold.setBold(true);
            headerStyle.setFont(bold);

            // Sites 主表（核心字段）
            dataSheet(wb, "Sites", HEADERS, EXAMPLES, headerStyle);
            // 站点高级配置表（可选覆盖项）
            dataSheet(wb, "站点高级配置", ADVANCED_HEADERS, ADVANCED_EXAMPLES, headerStyle);
            // 页面动作表
            dataSheet(wb, "页面动作", ACTION_HEADERS, ACTION_EXAMPLES, headerStyle);
            // 文档表
            docSheet(wb, "字段说明", DOCS, headerStyle);
            docSheet(wb, "高级配置说明", ADVANCED_DOCS, headerStyle);
            docSheet(wb, "页面动作说明", ACTION_DOCS, headerStyle);

            Files.createDirectories(target.getParent());
            try (OutputStream out = Files.newOutputStream(target)) {
                wb.write(out);
            }
        }
        log.info("已生成巡检配置模板: {}", target.toAbsolutePath());
    }

    private static void dataSheet(XSSFWorkbook wb, String name, String[] headers,
                                 String[][] examples, XSSFCellStyle headerStyle) {
        XSSFSheet sheet = wb.createSheet(name);
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < headers.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(headers[c]);
            cell.setCellStyle(headerStyle);
            sheet.setColumnWidth(c, Math.max(headers[c].length() * 512, 4200));
        }
        for (int r = 0; r < examples.length; r++) {
            XSSFRow row = sheet.createRow(r + 1);
            for (int c = 0; c < headers.length; c++) {
                row.createCell(c).setCellValue(c < examples[r].length ? examples[r][c] : "");
            }
        }
    }

    private static void docSheet(XSSFWorkbook wb, String name, String[][] docs, XSSFCellStyle headerStyle) {
        XSSFSheet sheet = wb.createSheet(name);
        String[] docHeaders = {"列名", "英文别名", "必填性", "说明"};
        XSSFRow headerRow = sheet.createRow(0);
        for (int c = 0; c < docHeaders.length; c++) {
            XSSFCell cell = headerRow.createCell(c);
            cell.setCellValue(docHeaders[c]);
            cell.setCellStyle(headerStyle);
            sheet.setColumnWidth(c, c == 3 ? 14000 : 6400);
        }
        for (int r = 0; r < docs.length; r++) {
            XSSFRow row = sheet.createRow(r + 1);
            for (int c = 0; c < docs[r].length; c++) {
                row.createCell(c).setCellValue(docs[r][c]);
            }
        }
    }

    /** 模板表头（供报告/校验复用） */
    public static List<String> headers() {
        return List.of(HEADERS);
    }

    /** 直接运行：java -cp ... com.patrol.excel.ExcelTemplateGenerator [输出路径] */
    public static void main(String[] args) throws Exception {
        Path target = args.length > 0 ? Path.of(args[0]) : Path.of("config/sites.xlsx");
        generateIfAbsent(target);
    }

    private ExcelTemplateGenerator() {
    }
}
