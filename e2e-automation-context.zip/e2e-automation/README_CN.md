# E2E 自动化测试框架

> 基于 Java 17 + Spring Boot 4 + TestNG 7 的端到端自动化测试框架，以「数据驱动 + 单点操作注册」为核心设计理念。

## 框架简介

本框架将测试用例数据与执行代码彻底解耦：完整测试用例由 Excel 模版（Scenarios / Steps / _GlobalConfig 三张表）描述，新增用例只需加数据行，零代码改动。每个 APP 域的单点操作（ACTION）通过 `@ActionSpec` 注解自动注册，新增 APP / 新操作三步完成。

### 核心能力

| 能力 | 说明 |
|---|---|
| 数据驱动 | Excel/YAML 双数据源，Scenarios + Steps + GlobalConfig 三表描述完整用例 |
| Action SPI | `@ActionSpec(apps, action)` + `AppAction` 接口，Spring 自动扫描注册 |
| DAG 调度 | DEPENDS_ON 依赖图分层调度，支持层内并行 |
| 场景上下文 | `ScenarioExecutionContext` 管理场景生命周期内的变量存储、步骤历史、跨步骤变量传递 |
| 超时重试 | 步骤级超时 + 重试（RETRY 列 / ON_FAILURE=RETRY）+ 场景级 TestNG IRetryAnalyzer |
| 失败策略 | STOP / CONTINUE / SCREENSHOT / RETRY / SAVE_EVIDENCE 五种模式 |
| 异步断言 | Awaitility 轮询式 WAIT_UNTIL，适配 MQ 异步消费 / DB 最终一致性 |
| 变量引擎 | `${global.}` / `${extract.}` / `${env.}` 三类占位符 |
| 协议层 | DB(原生JDBC + MyBatis-Plus) / HTTP(REST Assured) / MQ / SSH(JSch) / CMD / UI(Playwright) |
| demo/live 双模式 | demo 内置桩开箱即跑；live 切换真实协议连接 |
| AI 预留 | TestCaseGenerator / ReportInterpreter / StepOptimizer / AnomalyDetector 四个 SPI 接入点 |
| 报告 | HTML + JSON 报告，含饼图、汇总表、DAG 依赖图、步骤明细、数据质量提示 |

### 技术栈

| 组件 | 技术 | 版本 |
|---|---|---|
| 运行时 | Java | 17 |
| 框架 | Spring Boot | 4.1.1 |
| 测试 | TestNG | 7.12.0 |
| Excel | EasyExcel | 4.0.3 |
| JSON | fastjson2 | 2.0.65 |
| HTTP | REST Assured | 5.5.7 |
| UI | Playwright | 1.63.0 |
| DB | MyBatis-Plus / 原生 JDBC | 3.5.17 |
| SSH | JSch | 2.28.8 |
| 异步 | Awaitility | 4.3.0 |

---

## 快速开始

### 环境要求
- JDK 17+
- Maven 3.9+

### 三种运行方式

#### 方式一：IDE 右键运行（推荐测试人员使用）

在 IDE（IntelliJ IDEA / Eclipse）中打开 `E2ETestRunner.java`，右键 → Run：

```
文件位置：src/test/java/com/e2e/test/E2ETestRunner.java
```

此方式自动执行 `main()` 方法：
1. 引导 Spring 上下文
2. 加载全部启用的场景（默认从 `classpath:cases/E2E-Test-Scenarios.xlsx`）
3. 逐个执行场景
4. 生成 `test-output/test_report.html`
5. 控制台输出汇总（通过/失败/跳过/耗时）

#### 方式二：Maven 命令行

```bash
# 完整套件运行（含 Excel 生成器 + 测试 + DB 双驱动验证）
mvn clean test

# 仅运行 E2ETestRunner（独立入口，不经过 testng.xml）
mvn exec:java -Dexec.mainClass=com.e2e.test.E2ETestRunner -Dexec.classpathScope=test

# 指定外部 Excel 数据源
mvn clean test -De2e.data.excel.path=file:C:/my-test-cases.xlsx

# 切换 YAML 数据源
mvn clean test -De2e.data.source=yaml

# 切换 live 模式（真实协议连接）
mvn clean test -De2e.mode=live \
        -De2e.db.mode=LIVE \
        -De2e.db.driver=mybatis-plus \
        -Dspring.datasource.url="jdbc:h2:mem:test;DB_CLOSE_DELAY=-1" \
        -Dspring.datasource.driver-class-name=org.h2.Driver
```

#### 方式三：命令行直接执行

```bash
# 编译后直接运行
mvn clean test-compile
java -cp target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DforceStdout) \
     com.e2e.test.E2ETestRunner
```

### 生成 Excel 用例文件

```bash
# 生成 E2E-Test-Scenarios.xlsx（14 场景 / 52 步骤 / 8 全局变量）
mvn test -Dsurefire.suiteXmlFiles=testng-gen.xml

# 文件输出到：src/test/resources/cases/E2E-Test-Scenarios.xlsx
```

### 生成全局场景 DAG 报告

```bash
# 生成 Global_Scenarios_Dag_Report.html（纯拓扑 DAG，不执行测试）
mvn test -Dsurefire.suiteXmlFiles=testng-global-dag.xml

# 文件输出到：test-output/Global_Scenarios_Dag_Report.html
```

此报告从 Excel 直接加载场景定义，为每个场景渲染 DAG 拓扑图（节点=序号-APP，边=依赖箭头），方便在执行前预览全部场景的依赖结构。

### 查看报告

| 报告文件 | 生成条件 | 内容 |
|---|---|---|
| `test-output/test_report.html` | 执行测试时自动生成 | 侧边栏导航 + 汇总表 + 饼图 + DAG 依赖图 + 步骤明细 |
| `test-output/test_report.json` | 执行测试时自动生成 | JSON 格式完整结果 |
| `test-output/Global_Scenarios_Dag_Report.html` | 单独执行 global-dag 时生成 | 全部场景的拓扑 DAG（卡片式布局，APP 域配色） |

---

## 场景执行上下文（ScenarioExecutionContext）

### 概述

`ScenarioExecutionContext` 是场景执行期间的完整共享状态，生命周期与单个场景执行同生共死。不同场景的上下文完全隔离，无法互传数据。

### 架构

```
ScenarioExecutor.doExecute()
  │
  ├── 创建 ScenarioExecutionContext（场景级，生命周期=场景执行期间）
  │     │
  │     ├── 变量存储 extractVars (ConcurrentHashMap)
  │     │     └── Step A → ctx.putExtract("x", value)  ← 写入变量
  │     │     └── Step B → ${extract.x} 引用              ← 读取变量
  │     │
  │     ├── 步骤历史 stepHistory (ConcurrentHashMap<stepId, StepResult>)
  │     │     └── 每个步骤执行后 → ctx.recordStepResult(result)
  │     │     └── 后续步骤可查询 → ctx.getStepResult(stepId)
  │     │
  │     ├── 步骤时间线 stepStartTimes
  │     │     └── ctx.markStepStart(stepId)
  │     │
  │     ├── 终止控制 aborted (volatile)
  │     │     └── STOP 策略 → ctx.abort() → 后续步骤自动跳过
  │     │
  │     └── 生命周期 startTime / endTime
  │           └── ctx.markEnd() → 场景结束，上下文可回收
  │
  └── GC 回收（不同场景上下文完全隔离）
```

### 在 Action 中使用上下文

Action 通过 `ActionContext` 访问 `ScenarioExecutionContext` 的全部能力：

```java
@Override
public ActionResult execute(ActionContext ctx) {
    // ① 协议参数
    JSONObject params = ctx.jsonParams("HTTP");
    String url = params.getString("url");

    // ② 场景级变量读写（EXTRACT，跨步骤传递）
    ctx.setVar("orderId", "123");                    // 写入变量
    String prevId = ctx.getVar("orderId");            // 读取前序步骤写入的变量
    Integer code = ctx.getVar("httpCode", Integer.class); // 带类型转换

    // ③ 前序步骤查询
    StepResult prev = ctx.getStepResult("HTTP-POST-SEND");       // 获取前序步骤结果
    Object status = ctx.getStepOutput("HTTP-POST-SEND", "status"); // 获取前序步骤输出
    boolean done = ctx.isStepCompleted("DB-INSERT-LOG");          // 检查前序步骤是否通过

    // ④ 协议客户端
    ctx.clients().http().execute(spec);
    ctx.clients().db().query(sql);

    // ⑤ 返回结果（outputs 供 ASSERT / EXTRACT 使用）
    return ActionResult.ok("成功", Map.of("status", 200));
}
```

### 变量流转示例

```
┌─────────────────────────────────────────────────────────────────┐
│ ScenarioExecutionContext (场景级，场景执行期间存活)              │
│                                                                 │
│  Step 1: TAP:SEND_HTTP_REQUEST                                  │
│    → ctx.setVar("httpStatus", 200)           ← Action 写入变量  │
│    → return ActionResult.ok(outputs={"status":200})            │
│    → ctx.recordStepResult(result)             ← 引擎记录历史    │
│                                                                 │
│  Step 2: SMARTS:COMMON_DB_EXECUTE (depends on Step 1)          │
│    → INPUT 中 ${extract.httpStatus} → "200"   ← 变量引擎替换   │
│    → ctx.getStepOutput("STEP-1", "status") → 200  ← 查询输出   │
│    → ctx.isStepCompleted("STEP-1") → true       ← 检查状态      │
│                                                                 │
│  Step 3: SMARTS:COMMON_DB_ASSERTIONS (depends on Step 2)       │
│    → ctx.getVar("httpStatus") → 200           ← 变量仍然可见    │
│    → ASSERT: DB SELECT ... OP=EQ EXPECTED=["200"]              │
│                                                                 │
│  场景结束 → ctx.markEnd() → 上下文 GC 回收                      │
└─────────────────────────────────────────────────────────────────┘
```

### 生命周期保证

- 每个 Scenario 在 `doExecute()` 创建**独立** `ScenarioExecutionContext`
- 场景执行完毕后调用 `ctx.markEnd()` 并由 GC 回收
- **不同 Scenario 的上下文完全隔离**，无法互传数据
- 线程安全：`ConcurrentHashMap` + `volatile`，支持 DAG 层内并行步骤安全写入

### ScenarioExecutionContext API 速查

| 方法 | 用途 |
|---|---|
| `ctx.putExtract(name, value)` | 写入 EXTRACT 变量 |
| `ctx.getExtract(name)` | 读取 EXTRACT 变量 |
| `ctx.getExtractVars()` | 获取全部变量（只读） |
| `ctx.markStepStart(stepId)` | 记录步骤开始时间 |
| `ctx.recordStepResult(result)` | 记录步骤执行结果到历史 |
| `ctx.getStepResult(stepId)` | 查询前序步骤结果 |
| `ctx.isStepCompleted(stepId)` | 检查前序步骤是否通过 |
| `ctx.getStepOutput(stepId, key)` | 获取前序步骤输出值 |
| `ctx.getStepHistory()` | 获取全部步骤历史（只读） |
| `ctx.isAborted()` / `ctx.abort()` | 终止控制 |
| `ctx.markEnd()` | 标记场景结束 |
| `ctx.summarize()` | 生成上下文摘要 |

---

## 新增 APP / Action 指南

### 三步完成

```java
// 第 1 步：实现 AppAction 接口 + 标注 @ActionSpec
@Component
@ActionSpec(apps = {"NEWAPP"}, action = "NEW_OPERATION",
            description = "新 APP 的单点操作")
public class NewAppOperationAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext ctx) {
        // 取协议参数
        JSONObject params = ctx.jsonParams("HTTP");
        if (params == null) {
            return ActionResult.fail("缺少 HTTP 协议载荷");
        }

        // 读写场景级变量
        ctx.setVar("requestUrl", params.getString("url"));

        // 调用协议客户端
        HttpResult result = ctx.clients().http().execute(spec);

        // 返回结果
        return ActionResult.ok("操作成功",
                Map.of("status", result.getStatusCode()));
    }
}
```

```text
第 2 步：在 Excel Steps 表新增行
Scenario_ID | SEQ_NO | STEP_ID | APP    | ACTION        | DEPENDS_ON | INPUT                              | ...
E2E-NEW-001 | 1      | STEP-1 | NEWAPP | NEW_OPERATION | []         | [{"HTTP":{"url":"...","method":"GET"}}] | ...

第 3 步：运行
mvn clean test
# 或 IDE 右键 E2ETestRunner → Run
```

### ActionContext API 速查

| 方法 | 用途 |
|---|---|
| `ctx.jsonParams("HTTP")` | 取 HTTP 协议参数为 JSONObject（缺失返回 null） |
| `ctx.requireJsonParams("DB")` | 取 DB 参数（缺失时抛带提示的异常） |
| `ctx.paramStr("HTTP", "url")` | 取协议参数的字符串值 |
| `ctx.setVar("key", value)` | **写入场景级变量**（供后续步骤 ${extract.key} 引用） |
| `ctx.getVar("key")` | **读取场景级变量**（前序步骤写入的） |
| `ctx.getVar("key", Type.class)` | 读取变量（带类型转换） |
| `ctx.getStepResult("stepId")` | **查询前序步骤执行结果** |
| `ctx.getStepOutput("stepId", "key")` | **获取前序步骤输出值** |
| `ctx.isStepCompleted("stepId")` | **检查前序步骤是否通过** |
| `ctx.scenarioContext()` | 获取底层 ScenarioExecutionContext（高级 API） |
| `ctx.clients().http()` | 获取 HTTP 客户端 |
| `ctx.clients().db()` | 获取 DB 客户端 |
| `ctx.clients().ssh()` | 获取 SSH 客户端 |
| `ctx.clients().cmd()` | 获取本地命令客户端 |
| `ctx.props()` | 获取框架配置 |

### 内置 Action 索引

| APP | ACTION | 说明 |
|---|---|---|
| TAP / STP | SEND_HTTP_REQUEST | 发送 HTTP 请求 |
| SMARTS | COMMON_DB_EXECUTE | 执行 SQL（数据准备/清理） |
| SMARTS / TMS / DNS | COMMON_DB_ASSERTIONS | DB 断言（ASSERT 列驱动） |
| DATAHUB | TAP_WINDOWS_CMD | Windows 本地命令执行 |
| DATAHUB | TAP_LINUX_CMD | Linux 命令执行 |
| TAP | TAP_SSH_ALPHA2 | SSH 远程命令执行 |
| STP | SEND_MQ | 发送 MQ 报文 |
| DRP | DRP_UI_REPORTS | UI 报表浏览（Playwright） |
| SMARTS | 104_UI_BOOK / 109_UPLOAD | UI 交互操作 |

---

## 数据驱动格式

### Scenarios 表

| Seq | Scenario_ID | Scenario_Name | Enabled | Tags | Env | Timeout | Description | Owner |
|---|---|---|---|---|---|---|---|---|
| 1 | E2E-CASE-HTTP-001 | HTTP 测试 | Y | http;smoke | demo | 120 | 验证 HTTP 请求 | e2e-team |

### Steps 表

| Scenario_ID | SEQ_NO | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

### ASSERT 列格式

```json
[
  {"DB": "SELECT * FROM orders WHERE id=1", "OP": "EQ", "EXPECTED": ["1"]},
  {"HTTP": "status", "OP": "CONTAINS", "EXPECTED": ["200"]},
  {"DB": "SELECT COUNT(*) FROM x", "OP": "WAIT_UNTIL", "EXPECTED": ["1"], "TIMEOUT": 30, "POLL_INTERVAL": 2000}
]
```

支持的操作符：EQ / NE / CONTAINS / NOT_CONTAINS / EMPTY / NOT_EMPTY / SIZE / GT / GTE / LT / LTE / REGEX / EXISTS / WAIT_UNTIL

### EXTRACT 列格式

```json
[{"name": "orderId", "from": "HTTP", "path": "status"}]
```

### 变量引擎

| 占位符 | 来源 |
|---|---|
| `${global.x}` | _GlobalConfig 表 |
| `${extract.x}` | 前序步骤 EXTRACT 提取的值（或 Action 中 `ctx.setVar("x", ...)` 写入的） |
| `${env.x}` | 环境变量 / `-Dx=...` 系统属性 |

---

## 配置参考

```yaml
e2e:
  mode: demo              # demo / live
  strict: false            # 严格模式
  data:
    source: excel          # excel / yaml
    excel:
      path: classpath:cases/E2E-Test-Scenarios.xlsx
    yaml:
      path: classpath:cases/scenarios-examples.yml
  executor:
    parallel-threads: 1    # 步骤并行度
    step-timeout-default-seconds: 180
  retry:
    scenario-retry-count: 0    # 场景级重试次数
    step-retry-default: 0      # 步骤级默认重试
  db:
    mode: AUTO              # AUTO / STUB / LIVE
    driver: jdbc            # jdbc / mybatis-plus
  http:
    default-url: http://localhost:18080/ping
  ui:
    browser: chromium
    headless: true
  ai:
    enabled: false
    provider: noop          # noop / custom / openai
```

---

## 工程结构

```
e2e-automation/
├── pom.xml / testng.xml / testng-gen.xml / testng-global-dag.xml
├── src/main/java/com/e2e/framework/
│   ├── ai/             # AI 辅助 SPI（4 个接入点 + NoOp 默认实现）
│   ├── registry/       # Action SPI：@ActionSpec + AppAction + ActionRegistry + ActionContext
│   ├── engine/         # DAG 调度 / 步骤执行 / ScenarioExecutionContext / 断言引擎 / 截图
│   ├── actions/        # 内置 Action 实现（11 个）
│   ├── data/           # Excel/YAML 加载器 + JSON 修复 + 变量引擎
│   ├── protocol/       # 协议接口 + impl（demo桩 / live实现）
│   ├── model/          # 场景/步骤/断言/提取/结果 模型
│   ├── report/         # HTML/JSON 报告生成（test_report.html）
│   ├── config/         # Spring 装配与属性
│   └── test/           # 测试基础设施（E2ESpringBootstrap / ResultStore / 监听器 / 生成器）
├── src/test/java/com/e2e/test/
│   ├── E2ETestRunner.java       # ★ 测试入口（@Factory + main() 独立运行）
│   └── GlobalDagReport.java    # ★ 全局 DAG 报告生成器
├── src/test/resources/
│   ├── cases/          # E2E-Test-Scenarios.xlsx（默认用例）+ 模版参考
│   ├── data/           # MQ 报文等数据文件
│   └── (无 application.yml，在 main/resources)
└── src/main/resources/
    └── application.yml  # Spring 配置
```
