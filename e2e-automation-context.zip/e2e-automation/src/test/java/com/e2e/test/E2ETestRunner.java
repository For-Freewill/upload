package com.e2e.test;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.data.TestDataBootstrap;
import com.e2e.framework.data.TestDataLoader;
import com.e2e.framework.engine.ScenarioExecutor;
import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.TestDataBundle;
import com.e2e.framework.model.results.ScenarioResult;
import com.e2e.framework.model.results.ScenarioStatus;
import com.e2e.framework.report.ConsoleReportPrinter;
import com.e2e.framework.report.ReportWriter;
import com.e2e.framework.test.E2EScenarioRetryAnalyzer;
import com.e2e.framework.test.E2ESpringBootstrap;
import com.e2e.framework.test.E2ESuiteLifecycleListener;
import com.e2e.framework.test.ResultStore;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * E2E 数据驱动测试入口 —— 每个启用的场景一个 TestNG 测试实例（@Factory）。
 *
 * <p>数据在 TestNG 工厂阶段独立于 Spring 装载（保证不依赖监听器启动顺序），
 * 执行时从 Spring 上下文获取 ScenarioExecutor（含 Action 注册表 / 协议客户端 / 变量引擎）。
 *
 * <p><b>三种运行方式：</b>
 * <ul>
 *   <li><b>mvn test</b> — 通过 testng.xml 运行，含 CasesExcelGenerator + E2ETestRunner + DbDriverModesTest</li>
 *   <li><b>IDE 右键 Run E2ETestRunner</b> — 直接运行 main() 方法，自动加载全部场景并生成报告</li>
 *   <li><b>命令行</b> — java -cp ... com.e2e.test.E2ETestRunner</li>
 * </ul>
 *
 * <p>可选参数：
 * <ul>
 *   <li>-De2e.data.excel.path=classpath:cases/E2E-Test-Scenarios.xlsx（默认）</li>
 *   <li>-De2e.mode=live 切换真实协议连接</li>
 * </ul>
 */
@Listeners(E2ESuiteLifecycleListener.class)
public class E2ETestRunner {

    private final ScenarioDefinition scenario;

    @Factory(dataProvider = "scenarios")
    public E2ETestRunner(ScenarioDefinition scenario) {
        this.scenario = scenario;
    }

    @DataProvider(name = "scenarios")
    public static Object[][] scenarios() {
        TestDataLoader loader = TestDataBootstrap.createLoader();
        TestDataBundle bundle = loader.load();
        List<ScenarioDefinition> enabled = bundle.getScenarios().values().stream()
                .filter(ScenarioDefinition::isEnabled)
                .collect(Collectors.toList());
        Object[][] data = new Object[enabled.size()][1];
        for (int i = 0; i < enabled.size(); i++) {
            data[i][0] = enabled.get(i);
        }
        return data;
    }

    @Test(groups = "e2e", description = "数据驱动 E2E 场景",
            retryAnalyzer = E2EScenarioRetryAnalyzer.class)
    public void runScenario() {
        ScenarioExecutor executor = E2ESpringBootstrap.getInstance().getBean(ScenarioExecutor.class);
        ScenarioResult result = executor.execute(scenario);
        ResultStore.put(result);

        switch (result.getStatus()) {
            case PASSED -> { /* 通过 */ }
            case SKIPPED -> throw new SkipException(scenario.getScenarioId() + " 跳过: " + result.getMessage());
            default -> throw new AssertionError(scenario.getScenarioId() + " " + result.getStatus()
                    + ": " + result.getMessage() + "\n" + stepsSummary(result));
        }
    }

    private String stepsSummary(ScenarioResult result) {
        StringBuilder sb = new StringBuilder("步骤明细:\n");
        result.getStepResults().forEach(r -> sb.append("  ").append(r.summaryLine()).append('\n'));
        return sb.toString();
    }

    @Override
    public String toString() {
        return scenario.getScenarioId() + " [" + scenario.getEnv() + "]";
    }

    // ===================== 独立入口（IDE 右键运行 / 命令行） =====================

    /**
     * 独立运行入口 —— 无需 testng.xml，直接加载全部场景、执行、生成报告。
     *
     * <p>使用方式：
     * <ul>
     *   <li>IDE：右键 E2ETestRunner → Run（自动执行 main 方法）</li>
     *   <li>命令行：java -cp ... com.e2e.test.E2ETestRunner</li>
     *   <li>Maven：mvn compile exec:java -Dexec.mainClass=com.e2e.test.E2ETestRunner</li>
     * </ul>
     *
     * @param args 不需要参数（通过 -D 系统属性配置）
     */
    public static void main(String[] args) {
        E2ESpringBootstrap bootstrap = null;
        try {
            // 1. 引导 Spring 上下文（加载 application.yml 配置）
            bootstrap = E2ESpringBootstrap.getInstance();
            E2EProperties props = bootstrap.getBean(E2EProperties.class);
            TestDataLoader loader = bootstrap.getBean(TestDataLoader.class);
            TestDataBundle bundle = loader.load();

            // 2. 打印实际配置（从 application.yml 读取，非硬编码）
            System.out.println("========================================");
            System.out.println("  E2E Test Runner - 独立运行模式");
            System.out.println("  数据源: " + props.getData().getSource()
                    + " -> " + (props.getData().getSource().equals("excel")
                            ? props.getData().getExcel().getPath()
                            : props.getData().getYaml().getPath()));
            System.out.println("  运行模式: " + props.getMode());
            System.out.println("  DB 模式: " + props.getDb().getMode()
                    + " (driver=" + props.getDb().getDriver() + ")");
            System.out.println("  并行度: " + props.getExecutor().getParallelThreads()
                    + " (超时=" + props.getExecutor().getStepTimeoutDefaultSeconds() + "s)");
            System.out.println("  数据源名: " + loader.sourceName());
            System.out.println("========================================");

            // 3. 筛选启用的场景
            List<ScenarioDefinition> scenarios = new ArrayList<>(bundle.getScenarios().values().stream()
                    .filter(ScenarioDefinition::isEnabled)
                    .collect(Collectors.toList()));
            System.out.println("启用场景数: " + scenarios.size()
                    + " (总场景数: " + bundle.getScenarios().size() + ")"
                    + " (步骤数: " + scenarios.stream().mapToInt(s -> s.getSteps().size()).sum() + ")");

            // 3. 执行全部场景
            ScenarioExecutor executor = bootstrap.getBean(ScenarioExecutor.class);
            ResultStore.clear();
            int passed = 0, failed = 0, skipped = 0;
            long startTime = System.currentTimeMillis();

            for (ScenarioDefinition scenario : scenarios) {
                System.out.println("\n>>> 执行: " + scenario.getScenarioId()
                        + " (" + scenario.getName() + ")");
                ScenarioResult result = executor.execute(scenario);
                ResultStore.put(result);

                switch (result.getStatus()) {
                    case PASSED -> {
                        passed++;
                        System.out.println("    结果: PASSED ("
                                + result.passedCount() + " 步通过, "
                                + result.getDurationMs() + "ms)");
                    }
                    case SKIPPED -> {
                        skipped++;
                        System.out.println("    结果: SKIPPED - " + result.getMessage());
                    }
                    default -> {
                        failed++;
                        System.out.println("    结果: " + result.getStatus()
                                + " - " + result.getMessage());
                        result.getStepResults().forEach(sr ->
                                System.out.println("      " + sr.summaryLine()));
                    }
                }
            }

            long totalTime = System.currentTimeMillis() - startTime;

            // 4. 按模版定义顺序排序结果
            List<String> definitionOrder = new ArrayList<>(bundle.getScenarios().keySet());
            List<ScenarioResult> results = new ArrayList<>(ResultStore.all());
            results.sort(Comparator.comparingInt(r -> {
                int idx = definitionOrder.indexOf(r.getScenario().getScenarioId());
                return idx >= 0 ? idx : Integer.MAX_VALUE;
            }));

            // 5. 生成报告
            var issues = bundle.getIssues();
            bootstrap.getBean(ConsoleReportPrinter.class).print(results, issues);
            ReportWriter reportWriter = bootstrap.getBean(ReportWriter.class);
            reportWriter.write(results, issues, loader.sourceName());

            // 6. 汇总
            System.out.println("\n========================================");
            System.out.println("  执行完成: " + scenarios.size() + " 场景"
                    + " (通过 " + passed + " / 失败 " + failed + " / 跳过 " + skipped + ")"
                    + " 耗时 " + totalTime + "ms");
            System.out.println("  报告: test-output/test_report.html");
            System.out.println("========================================");

            if (failed > 0) {
                System.exit(1);
            }
        } catch (Exception e) {
            System.err.println("执行异常: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } finally {
            E2ESpringBootstrap.shutdown();
        }
    }
}
