package com.e2e.framework.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 框架配置项（前缀 e2e.*），对应 application.yml。
 */
@ConfigurationProperties(prefix = "e2e")
public class E2EProperties {

    /** 运行模式：demo（内置桩，开箱即跑） / live（真实协议连接） */
    private String mode = "demo";

    /** 严格模式：数据质量/依赖问题直接失败，而不是降级为告警 */
    private boolean strict = false;

    private final Data data = new Data();
    private final Executor executor = new Executor();
    private final Report report = new Report();
    private final Db db = new Db();
    private final Http http = new Http();
    private final Cmd cmd = new Cmd();
    private final Mq mq = new Mq();
    private final Ssh ssh = new Ssh();
    private final Ui ui = new Ui();
    private final Retry retry = new Retry();
    private final Ai ai = new Ai();

    public static class Data {
        /** 数据源类型：excel / yaml */
        private String source = "excel";
        private final Excel excel = new Excel();
        private final Yaml yaml = new Yaml();
        /** INPUT 中 file 字段（如 MQ 报文）的基准目录，支持 classpath: 或 file: 前缀 */
        private String payloadBase = "classpath:";

        public static class Excel {
            /** Excel 模版路径，支持 classpath: / file: / 绝对路径 */
            private String path = "classpath:cases/E2E-Test-Scenarios.xlsx";
            public String getPath() { return path; }
            public void setPath(String path) { this.path = path; }
        }

        public static class Yaml {
            private String path = "classpath:cases/scenarios-examples.yml";
            public String getPath() { return path; }
            public void setPath(String path) { this.path = path; }
        }

        public String getSource() { return source; }
        public void setSource(String source) { this.source = source; }
        public Excel getExcel() { return excel; }
        public Yaml getYaml() { return yaml; }
        public String getPayloadBase() { return payloadBase; }
        public void setPayloadBase(String payloadBase) { this.payloadBase = payloadBase; }
    }

    public static class Executor {
        /** 同一 DAG 层内可并行执行的步骤线程数，1 = 串行 */
        private int parallelThreads = 1;
        /** 步骤默认超时（秒），Steps 表 TIMEOUT 列缺省时使用 */
        private int stepTimeoutDefaultSeconds = 180;
        /** 重试间隔（毫秒） */
        private long retryDelayMs = 1000;
        public int getParallelThreads() { return parallelThreads; }
        public void setParallelThreads(int v) { this.parallelThreads = v; }
        public int getStepTimeoutDefaultSeconds() { return stepTimeoutDefaultSeconds; }
        public void setStepTimeoutDefaultSeconds(int v) { this.stepTimeoutDefaultSeconds = v; }
        public long getRetryDelayMs() { return retryDelayMs; }
        public void setRetryDelayMs(long v) { this.retryDelayMs = v; }
    }

    public static class Report {
        /** 报告输出目录 */
        private String outputDir = "test-output";
        public String getOutputDir() { return outputDir; }
        public void setOutputDir(String v) { this.outputDir = v; }
    }

    public static class Db {
        /** AUTO：live 模式下未配置 DataSource 时自动降级 stub；STUB / LIVE 强制指定 */
        private String mode = "AUTO";
        /**
         * live 模式 DB 驱动方式（DbClient 实现选择）：
         * <ul>
         *   <li>jdbc —— 原生 JDBC（DataSource + PreparedStatement 手写执行，默认）；</li>
         *   <li>mybatis-plus —— MyBatis-Plus（自动装配的 SqlSessionFactory + SqlRunner 执行任意 SQL）。</li>
         * </ul>
         */
        private String driver = "jdbc";
        public String getMode() { return mode; }
        public void setMode(String mode) { this.mode = mode; }
        public String getDriver() { return driver; }
        public void setDriver(String driver) { this.driver = driver; }
        public boolean useMybatisPlus() {
            return "mybatis-plus".equalsIgnoreCase(driver) || "mybatisplus".equalsIgnoreCase(driver);
        }
    }

    public static class Http {
        private String defaultUrl = "http://localhost:18080/ping";
        public String getDefaultUrl() { return defaultUrl; }
        public void setDefaultUrl(String v) { this.defaultUrl = v; }
    }

    public static class Cmd {
        /** live 模式下本地命令是否真正执行（默认 false，dry-run） */
        private boolean allowLocalExecution = false;
        public boolean isAllowLocalExecution() { return allowLocalExecution; }
        public void setAllowLocalExecution(boolean v) { this.allowLocalExecution = v; }
    }

    public static class Mq {
        /** live 模式 MQ 接入参数（示例预留，真实实现可在自定义 MqClient 中读取） */
        private String host = "localhost";
        private int port = 1414;
        private String queueManager = "QM1";
        private String queue = "E2E.IN";
        public String getHost() { return host; }
        public void setHost(String v) { this.host = v; }
        public int getPort() { return port; }
        public void setPort(int v) { this.port = v; }
        public String getQueueManager() { return queueManager; }
        public void setQueueManager(String v) { this.queueManager = v; }
        public String getQueue() { return queue; }
        public void setQueue(String v) { this.queue = v; }
    }

    public static class Ssh {
        private String user = "e2e";
        private String password = "";
        private int port = 22;
        public String getUser() { return user; }
        public void setUser(String v) { this.user = v; }
        public String getPassword() { return password; }
        public void setPassword(String v) { this.password = v; }
        public int getPort() { return port; }
        public void setPort(int v) { this.port = v; }
    }

    /** Playwright UI 自动化（live 模式生效；demo 模式 UI 处理器走桩不启动浏览器） */
    public static class Ui {
        /** 浏览器引擎：chromium / firefox / webkit */
        private String browser = "chromium";
        /** 无头模式 */
        private boolean headless = true;
        /** JAVA 载荷未指定 url 时导航的基础地址（live 模式） */
        private String baseUrl = "";
        public String getBrowser() { return browser; }
        public void setBrowser(String v) { this.browser = v; }
        public boolean isHeadless() { return headless; }
        public void setHeadless(boolean v) { this.headless = v; }
        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String v) { this.baseUrl = v; }
    }

    /** 失败重试配置（场景级 TestNG IRetryAnalyzer + 步骤级 StepExecutor retry） */
    public static class Retry {
        /** 场景级失败重试次数（TestNG IRetryAnalyzer，0=不重试） */
        private int scenarioRetryCount = 0;
        /** 场景重试间隔（毫秒） */
        private long scenarioRetryDelayMs = 3000;
        /** 步骤级默认重试次数（Steps 表 RETRY 列缺省时使用，0=不重试） */
        private int stepRetryDefault = 0;
        /** 步骤重试间隔（毫秒） */
        private long stepRetryDelayMs = 1000;
        /** 重试时是否忽略上次失败的具体原因（仅日志层面） */
        private boolean logPreviousFailure = true;
        public int getScenarioRetryCount() { return scenarioRetryCount; }
        public void setScenarioRetryCount(int v) { this.scenarioRetryCount = v; }
        public long getScenarioRetryDelayMs() { return scenarioRetryDelayMs; }
        public void setScenarioRetryDelayMs(long v) { this.scenarioRetryDelayMs = v; }
        public int getStepRetryDefault() { return stepRetryDefault; }
        public void setStepRetryDefault(int v) { this.stepRetryDefault = v; }
        public long getStepRetryDelayMs() { return stepRetryDelayMs; }
        public void setStepRetryDelayMs(long v) { this.stepRetryDelayMs = v; }
        public boolean isLogPreviousFailure() { return logPreviousFailure; }
        public void setLogPreviousFailure(boolean v) { this.logPreviousFailure = v; }
    }

    /**
     * AI 辅助接入配置（预留 SPI，默认关闭）。
     * <p>接入方式：实现 com.e2e.framework.ai.AiAssistant 接口并注册为 Spring Bean，
     * 或设置 e2e.ai.enabled=true + e2e.ai.provider=openai 走内置 HTTP 调用器。
     */
    public static class Ai {
        /** 是否启用 AI 辅助（默认关闭，NoOp 实现） */
        private boolean enabled = false;
        /** 提供方：noop / openai / azure-openai / custom */
        private String provider = "noop";
        /** API base URL（如 https://api.openai.com/v1） */
        private String baseUrl = "";
        /** API Key（支持 ${env.X} 占位） */
        private String apiKey = "";
        /** 模型名（如 gpt-4o / deepseek-chat） */
        private String model = "";
        /** 各能力开关 */
        private final AiFeatures features = new AiFeatures();

        public static class AiFeatures {
            /** 测试用例生成 */
            private boolean testCaseGeneration = false;
            /** 测试报告解读 */
            private boolean reportInterpretation = false;
            /** 步骤优化建议 */
            private boolean stepOptimization = false;
            /** 异常诊断 */
            private boolean anomalyDetection = false;
            public boolean isTestCaseGeneration() { return testCaseGeneration; }
            public void setTestCaseGeneration(boolean v) { this.testCaseGeneration = v; }
            public boolean isReportInterpretation() { return reportInterpretation; }
            public void setReportInterpretation(boolean v) { this.reportInterpretation = v; }
            public boolean isStepOptimization() { return stepOptimization; }
            public void setStepOptimization(boolean v) { this.stepOptimization = v; }
            public boolean isAnomalyDetection() { return anomalyDetection; }
            public void setAnomalyDetection(boolean v) { this.anomalyDetection = v; }
        }

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean v) { this.enabled = v; }
        public String getProvider() { return provider; }
        public void setProvider(String v) { this.provider = v; }
        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String v) { this.baseUrl = v; }
        public String getApiKey() { return apiKey; }
        public void setApiKey(String v) { this.apiKey = v; }
        public String getModel() { return model; }
        public void setModel(String v) { this.model = v; }
        public AiFeatures getFeatures() { return features; }
    }

    /** live 模式：按子配置强制/自动选择协议客户端 */
    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }
    public boolean isStrict() { return strict; }
    public void setStrict(boolean strict) { this.strict = strict; }
    public Data getData() { return data; }
    public Executor getExecutor() { return executor; }
    public Report getReport() { return report; }
    public Db getDb() { return db; }
    public Http getHttp() { return http; }
    public Cmd getCmd() { return cmd; }
    public Mq getMq() { return mq; }
    public Ssh getSsh() { return ssh; }
    public Ui getUi() { return ui; }
    public Retry getRetry() { return retry; }
    public Ai getAi() { return ai; }

    public boolean isDemoMode() { return "demo".equalsIgnoreCase(mode); }

    /** live 模式：按子配置强制/自动选择协议客户端 */
    public boolean useLiveDb() {
        String dbMode = db.getMode().toUpperCase();
        if ("STUB".equals(dbMode)) return false;
        if ("LIVE".equals(dbMode)) return true;
        return !isDemoMode(); // AUTO：demo -> stub, live -> live
    }
}
