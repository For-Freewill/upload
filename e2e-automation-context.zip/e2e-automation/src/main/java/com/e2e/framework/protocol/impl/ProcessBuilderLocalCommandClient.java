package com.e2e.framework.protocol.impl;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.LocalCommandClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * 本地命令实现：ProcessBuilder 真实执行。
 *
 * <p>安全开关：e2e.cmd.allow-local-execution=true 且 live 模式才真正执行，否则 dry-run。
 */
public class ProcessBuilderLocalCommandClient implements LocalCommandClient {

    private static final Logger log = LoggerFactory.getLogger(ProcessBuilderLocalCommandClient.class);

    private final boolean allowed;

    public ProcessBuilderLocalCommandClient(E2EProperties.Cmd cmdProps) {
        this.allowed = cmdProps.isAllowLocalExecution();
    }

    @Override
    public CommandResult run(List<String> commands, String baseDir, boolean windows) {
        StringBuilder stdout = new StringBuilder();
        int exit = 0;
        for (String cmd : commands) {
            if (!allowed) {
                log.info("[cmd-dryrun] {} (e2e.cmd.allow-local-execution=false，未真正执行)", cmd);
                stdout.append("[dry-run] ").append(cmd).append('\n');
                continue;
            }
            try {
                String[] command = windows
                        ? new String[]{"cmd", "/c", cmd}
                        : new String[]{"sh", "-c", cmd};
                ProcessBuilder pb = new ProcessBuilder(command);
                if (baseDir != null && !baseDir.isBlank()) {
                    pb.directory(new File(baseDir));
                }
                pb.redirectErrorStream(true);
                Process p = pb.start();
                String output = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                exit = p.waitFor();
                stdout.append(output).append('\n');
                log.info("[cmd] {} -> exit={}", cmd, exit);
            } catch (Exception e) {
                return new CommandResult(-1, stdout.toString(), "本地命令执行失败: " + cmd + " -> " + e.getMessage());
            }
        }
        return new CommandResult(exit, stdout.toString(), "");
    }

    @Override
    public String describe() {
        return "process-builder-cmd (allowed=" + allowed + ")";
    }
}
