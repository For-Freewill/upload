package com.e2e.framework.protocol.impl;

import com.e2e.framework.protocol.DbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DB 桩实现（demo 模式 / 未配置数据源时）。
 *
 * <p>演示语义：从 SQL 中解析 WHERE 条件列与值，返回对应结果行，
 * 使模版中的 EQ 断言能够真实走通「查询 -> 比对」链路。
 */
public class StubDbClient implements DbClient {

    private static final Logger log = LoggerFactory.getLogger(StubDbClient.class);
    private static final Pattern WHERE_EQ = Pattern.compile("WHERE\\s+(\\w+)\\s*=\\s*'?([^'\\s;)]+)?", Pattern.CASE_INSENSITIVE);

    @Override
    public List<Map<String, Object>> query(String sql) {
        log.info("[stub-db] query: {}", sql);
        List<Map<String, Object>> rows = new ArrayList<>();
        Matcher m = WHERE_EQ.matcher(sql);
        if (m.find()) {
            String column = m.group(1);
            String value = m.group(2) == null ? "" : m.group(2);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put(column, value);
            rows.add(row);
        }
        return rows;
    }

    @Override
    public int[] execute(List<String> sqls) {
        int[] counts = new int[sqls.size()];
        for (int i = 0; i < sqls.size(); i++) {
            log.info("[stub-db] execute: {} -> 1 row affected (simulated)", sqls.get(i));
            counts[i] = 1;
        }
        return counts;
    }

    @Override
    public String describe() {
        return "stub-db (demo)";
    }
}
