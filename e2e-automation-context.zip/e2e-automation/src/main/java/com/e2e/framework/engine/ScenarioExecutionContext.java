package com.e2e.framework.engine;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.data.VariableResolver;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.protocol.ProtocolClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 场景执行上下文（Scenario Context）—— 一次场景执行内的完整共享状态。
 *
 * <p><b>生命周期</b>：与单个 Scenario 执行同生共死。ScenarioExecutor.doExecute() 创建，
 * 场景执行完毕后由 GC 回收。不同 Scenario 的上下文完全隔离，无法互传数据。
 *
 * <p><b>核心能力</b>：
 * <ul>
 *   <li><b>变量存储</b>：EXTRACT 提取变量（跨步骤传递），通过 {@code ${extract.x}} 引用</li>
 *   <li><b>步骤历史</b>：记录全部 StepResult，可通过 stepId 查询前序步骤的执行结果和输出</li>
 *   <li><b>终止标记</b>：STOP 策略触发后标记 aborted，后续步骤自动跳过</li>
 *   <li><b>协议客户端</b>：DB/HTTP/MQ/SSH/CMD/UI 客户端单例</li>
 *   <li><b>时间追踪</b>：场景开始/结束时间戳</li>
 * </ul>
 *
 * <p><b>线程安全</b>：extractVars 和 stepHistory 使用 ConcurrentHashMap，
 * 支持 DAG 层内并行步骤安全写入。aborted 使用 volatile 保证可见性。
 */
public class ScenarioExecutionContext {

    private static final Logger log = LoggerFactory.getLogger(ScenarioExecutionContext.class);

    private final ScenarioDefinition scenario;
    private final VariableResolver resolver;
    private final ProtocolClients clients;
    private final E2EProperties props;

    // ---- 跨步骤变量存储（EXTRACT 提取） ----
    private final Map<String, Object> extractVars = new ConcurrentHashMap<>();

    // ---- 步骤执行历史（stepId → StepResult） ----
    private final Map<String, StepResult> stepHistory = new ConcurrentHashMap<>();

    // ---- 步骤时间线（stepId → 开始时间戳 ms） ----
    private final Map<String, Long> stepStartTimes = new ConcurrentHashMap<>();

    // ---- 场景生命周期 ----
    private final long scenarioStartTime;
    private volatile long scenarioEndTime;
    private volatile boolean aborted;

    public ScenarioExecutionContext(ScenarioDefinition scenario, VariableResolver resolver,
                            ProtocolClients clients, E2EProperties props) {
        this.scenario = scenario;
        this.resolver = resolver;
        this.clients = clients;
        this.props = props;
        this.scenarioStartTime = System.currentTimeMillis();
        this.scenarioEndTime = 0;
        log.debug("[{}] 上下文创建: scenario={}", scenario.getScenarioId(), scenario.getScenarioId());
    }

    // ===================== 场景信息 =====================

    public ScenarioDefinition getScenario() { return scenario; }
    public String getScenarioId() { return scenario.getScenarioId(); }
    public VariableResolver resolver() { return resolver; }
    public ProtocolClients clients() { return clients; }
    public E2EProperties props() { return props; }

    // ===================== 变量存储（EXTRACT） =====================

    /** 写入 EXTRACT 变量（步骤执行后提取的值，供后续步骤 ${extract.x} 引用） */
    public void putExtract(String name, Object value) {
        extractVars.put(name, value);
        log.debug("[{}] 变量存储: {} = {}", scenario.getScenarioId(), name, value);
    }

    /** 读取 EXTRACT 变量 */
    public Object getExtract(String name) {
        return extractVars.get(name);
    }

    /** 获取全部 EXTRACT 变量（只读视图） */
    public Map<String, Object> getExtractVars() {
        return Collections.unmodifiableMap(extractVars);
    }

    // ===================== 步骤历史 =====================

    /** 记录步骤开始执行 */
    public void markStepStart(String stepId) {
        stepStartTimes.put(stepId, System.currentTimeMillis());
    }

    /** 记录步骤执行结果（步骤执行完毕后调用） */
    public void recordStepResult(StepResult result) {
        stepHistory.put(result.getStep().getStepId(), result);
        log.debug("[{}] 步骤记录: {} -> {} ({}ms)",
                scenario.getScenarioId(), result.getStep().getStepId(),
                result.getStatus(), result.getDurationMs());
    }

    /** 查询前序步骤的执行结果 */
    public StepResult getStepResult(String stepId) {
        return stepHistory.get(stepId);
    }

    /** 查询前序步骤是否已执行（用于 DAG 依赖检查） */
    public boolean isStepCompleted(String stepId) {
        StepResult r = stepHistory.get(stepId);
        return r != null && r.getStatus().name().equals("PASSED");
    }

    /** 获取前序步骤的输出值（便捷方法） */
    public Object getStepOutput(String stepId, String key) {
        StepResult r = stepHistory.get(stepId);
        if (r == null || r.getOutputs() == null) {
            return null;
        }
        return r.getOutputs().get(key);
    }

    /** 获取全部步骤历史（只读视图，按写入序） */
    public List<StepResult> getStepHistory() {
        return List.copyOf(stepHistory.values());
    }

    /** 获取步骤开始时间 */
    public Long getStepStartTime(String stepId) {
        return stepStartTimes.get(stepId);
    }

    // ===================== 终止控制 =====================

    public boolean isAborted() { return aborted; }
    public void abort() {
        this.aborted = true;
        log.warn("[{}] 上下文标记终止（STOP 策略触发）", scenario.getScenarioId());
    }

    // ===================== 生命周期 =====================

    /** 标记场景执行结束 */
    public void markEnd() {
        this.scenarioEndTime = System.currentTimeMillis();
        log.debug("[{}] 上下文销毁: duration={}ms, steps={}, vars={}",
                scenario.getScenarioId(),
                scenarioEndTime - scenarioStartTime,
                stepHistory.size(),
                extractVars.size());
    }

    /** 获取场景执行耗时（ms） */
    public long getScenarioDurationMs() {
        long end = scenarioEndTime > 0 ? scenarioEndTime : System.currentTimeMillis();
        return end - scenarioStartTime;
    }

    /** 获取场景开始时间戳 */
    public long getScenarioStartTime() {
        return scenarioStartTime;
    }

    // ===================== 上下文摘要 =====================

    /** 生成上下文摘要（用于日志和报告） */
    public String summarize() {
        return String.format("scenario=%s, steps=%d, extractVars=%s, duration=%dms, aborted=%s",
                scenario.getScenarioId(),
                stepHistory.size(),
                extractVars.keySet(),
                getScenarioDurationMs(),
                aborted);
    }
}
