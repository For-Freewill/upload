package com.e2e.framework.actions.smarts;

import com.e2e.framework.actions.common.AbstractUiAction;
import com.e2e.framework.registry.ActionSpec;

/** SMARTS 域：109_UPLOAD —— 109 报文文件上传（JAVA 协议 UI 操作） */
@ActionSpec(apps = {"SMARTS"}, action = "109_UPLOAD", description = "109 报文上传（JAVA 协议 UI 操作）")
public class Upload109Action extends AbstractUiAction {
    @Override
    protected String businessName() { return "109 报文上传"; }
}
