package com.e2e.framework.ai;

import com.e2e.framework.config.E2EProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * AI 助手 Spring 装配 —— 按 e2e.ai 配置选择实现。
 *
 * <p>装配规则：
 * <ul>
 *   <li>e2e.ai.enabled=false（默认）→ {@link NoOpAiAssistant}（全空操作）；</li>
 *   <li>e2e.ai.enabled=true + e2e.ai.provider=custom → 查找用户自定义 AiAssistant Bean；</li>
 *   <li>e2e.ai.enabled=true + e2e.ai.provider=openai/azure-openai →
 *       预留：未来可接入 LlmAiAssistant（通过 AiHttpClient 调用大模型 API），当前降级为 NoOp + WARN。</li>
 * </ul>
 *
 * <p><b>扩展指南</b>：实现 {@link AiAssistant} 接口（或各子接口）并标注 @Component，
 * 然后设置 e2e.ai.enabled=true + e2e.ai.provider=custom，框架自动使用你的实现。
 */
@Configuration
public class AiConfig {

    private static final Logger log = LoggerFactory.getLogger(AiConfig.class);

    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean(AiAssistant.class)
    public AiAssistant aiAssistant(E2EProperties props) {
        if (!props.getAi().isEnabled()) {
            log.info("AI 辅助: 未启用（e2e.ai.enabled=false），使用 NoOp 实现");
            return new NoOpAiAssistant();
        }
        String provider = props.getAi().getProvider();
        if ("custom".equalsIgnoreCase(provider)) {
            // 用户自定义实现应已通过 @Component 注册，此处不应到达
            log.warn("AI 辅助: provider=custom 但未找到自定义 AiAssistant Bean，降级为 NoOp");
            return new NoOpAiAssistant();
        }
        // 预留：openai / azure-openai 的 LLM 接入
        log.warn("AI 辅助: provider={} 的 LLM 接入尚未实现（预留阶段），降级为 NoOp。"
                + "接入方式：实现 AiAssistant 接口并注册为 Spring Bean，设置 e2e.ai.provider=custom", provider);
        return new NoOpAiAssistant();
    }
}
