package com.e2e.framework.registry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Action 注册表 —— 框架「灵活注册新增 APP 操作」的核心。
 *
 * <p>两条注册路径：
 * <ul>
 *   <li><b>注解自动注册</b>（推荐）：Spring 扫描 {@link ActionSpec} 标注的 {@link AppAction}
 *       Bean，启动时自动完成 (APP:ACTION) 索引；</li>
 *   <li><b>编程式注册</b>：{@link #register(String, String, AppAction)}，支持运行期插件
 *       / 非 Spring 管理实现。</li>
 * </ul>
 *
 * <p>同名覆盖：相同 (APP:ACTION) 时 @ActionSpec(order) 大者生效 ——
 * 团队可用更高 order 的实现替换框架内置 demo 行为，无需改框架代码。
 */
@Component
public class ActionRegistry {

    private static final Logger log = LoggerFactory.getLogger(ActionRegistry.class);

    private final Map<String, AppAction> actions = new ConcurrentHashMap<>();
    private final Map<String, ActionSpec> specs = new ConcurrentHashMap<>();
    private final Map<String, String> implementations = new ConcurrentHashMap<>();

    @Autowired
    public void collect(ApplicationContext context) {
        Map<String, Object> beans = context.getBeansWithAnnotation(ActionSpec.class);
        // 排序保证重复注册的确定性：order 升序，后注册（order 相同按类名）覆盖前者
        List<Map.Entry<String, Object>> ordered = new ArrayList<>(beans.entrySet());
        ordered.sort((a, b) -> {
            ActionSpec sa = a.getValue().getClass().getAnnotation(ActionSpec.class);
            ActionSpec sb = b.getValue().getClass().getAnnotation(ActionSpec.class);
            int byOrder = Integer.compare(sa == null ? 0 : sa.order(), sb == null ? 0 : sb.order());
            if (byOrder != 0) {
                return byOrder;
            }
            return a.getKey().compareTo(b.getKey());
        });
        for (Map.Entry<String, Object> e : ordered) {
            Object bean = e.getValue();
            ActionSpec spec = bean.getClass().getAnnotation(ActionSpec.class);
            if (!(bean instanceof AppAction action)) {
                log.warn("Bean {} 标注了 @ActionSpec 但未实现 AppAction 接口，跳过", e.getKey());
                continue;
            }
            for (String app : spec.apps()) {
                register(app, spec.action(), action, spec);
            }
        }
        log.info("ActionRegistry 就绪: {} 个注册项 -> {}", actions.size(), describe());
    }

    /** 编程式注册（order 视为 0，可覆盖同名低优先级实现） */
    public void register(String app, String action, AppAction impl) {
        register(app, action, impl, null);
    }

    private void register(String app, String action, AppAction impl, ActionSpec spec) {
        String key = key(app, action);
        ActionSpec oldSpec = specs.get(key);
        if (oldSpec != null) {
            int oldOrder = oldSpec.order();
            int newOrder = spec == null ? 0 : spec.order();
            if (newOrder < oldOrder) {
                log.info("注册表跳过低优先级实现 {} (order={}) -> 保留 {}", key, newOrder,
                        implementations.get(key));
                return;
            }
            log.warn("注册表覆盖 {} : {} (order={}) 覆盖 {} (order={})", key,
                    impl.getClass().getName(), newOrder, implementations.get(key), oldOrder);
        }
        actions.put(key, impl);
        specs.put(key, spec);
        implementations.put(key, impl.getClass().getName());
    }

    /** 按 (APP, ACTION) 查找（大小写不敏感） */
    public AppAction lookup(String app, String action) {
        return actions.get(key(app, action));
    }

    /** 错误提示用：列出全部已注册操作 */
    public String describe() {
        Map<String, List<String>> byApp = new TreeMap<>();
        specs.forEach((key, spec) -> {
            String app = key.substring(0, key.indexOf(':'));
            byApp.computeIfAbsent(app, k -> new ArrayList<>()).add(key.substring(key.indexOf(':') + 1));
        });
        StringBuilder sb = new StringBuilder();
        byApp.forEach((app, list) -> {
            if (sb.length() > 0) {
                sb.append("; ");
            }
            sb.append(app).append("=[").append(String.join(",", list)).append("]");
        });
        return sb.toString();
    }

    public int size() {
        return actions.size();
    }

    static String key(String app, String action) {
        return (app == null ? "?" : app.trim().toUpperCase()) + ":"
                + (action == null ? "?" : action.trim().toUpperCase());
    }
}
