package com.e2e.framework.protocol.impl;

import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.SshCommandClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/** SSH 桩实现（demo 模式）：模拟命令执行成功 */
public class StubSshCommandClient implements SshCommandClient {

    private static final Logger log = LoggerFactory.getLogger(StubSshCommandClient.class);

    @Override
    public CommandResult run(SshSpec spec) {
        log.info("[stub-ssh] {}@{}:{} baseDir={} commands={}",
                spec.getUser(), spec.getHost(), spec.getPort(), spec.getBaseDir(), spec.getCommands());
        String stdout = "[stub-ssh] executed " + spec.getCommands().size() + " commands on " + spec.getHost() + "\n"
                + String.join("\n", spec.getCommands());
        return new CommandResult(0, stdout, "");
    }

    @Override
    public String describe() {
        return "stub-ssh (demo)";
    }
}
