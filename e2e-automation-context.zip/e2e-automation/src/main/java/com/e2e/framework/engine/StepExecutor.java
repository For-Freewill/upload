package com.e2e.framework.engine;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionRegistry;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.AppAction;
import com.e2e.framework.ai.AiAssistant;
import com.e2e.framework.data.ResourcePathResolver;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.model.ExtractRule;
import com.e2e.framework.model.OnFailure;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.model.results.StepStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 步骤执行器 —— 单个步骤的完整生命周期：
 * 变量替换 -> Action 查找 -> 带超时执行 -> 失败重试 -> 断言评估 -> 变量提取 -> 失败策略。
 */
@Component
public class StepExecutor {

    private static final Logger log = LoggerFactory.getLogger(StepExecutor.class);

    private final ActionRegistry registry;
    private final AssertionEngine assertionEngine;
    private final ScreenshotService screenshotService;
    private final E2EProperties props;
    private final ExecutorService stepPool;
    private final AiAssistant aiAssistant;

    public StepExecutor(ActionRegistry registry, AssertionEngine assertionEngine,
                        ScreenshotService screenshotService, E2EProperties props,
                        @Qualifier("e2eStepPool") ExecutorService stepPool,
                        AiAssistant aiAssistant) {
        this.registry = registry;
        this.assertionEngine = assertionEngine;
        this.screenshotService = screenshotService;
        this.props = props;
        this.stepPool = stepPool;
        this.aiAssistant = aiAssistant;
    }

    public StepResult execute(StepDefinition step, ScenarioExecutionContext ctx) {
        StepResult result = new StepResult(step);
        long start = System.currentTimeMillis();
        ctx.markStepStart(step.getStepId()); // 记录步骤开始时间到上下文

        // 0. 步骤级 enable 过滤（与场景级 enable 同语义，颗粒度更细）
        if (!step.isEnabled()) {
            result.setStatus(StepStatus.SKIPPED);
            result.setMessage("步骤 Enabled=N，未启用");
            log.info("  -- 步骤 {} 跳过（未启用）", step.getStepId());
            result.setDurationMs(System.currentTimeMillis() - start);
            return result;
        }

        log.info("  -> 步骤 {} [{}] 开始（输入载荷 {} 个，断言 {} 条，提取 {} 条）",
                step.getStepId(), step.actionKey(), step.getInputPayloads().size(),
                step.getAssertRules().size(), step.getExtractRules().size());

        // 1. 变量替换（INPUT 载荷 + 断言目标）
        Map<String, Object> extractVars = ctx.getExtractVars();
        List<ProtocolPayload> resolvedPayloads = resolvePayloads(step, extractVars, ctx);
        List<AssertionRule> resolvedAsserts = resolveAsserts(step, extractVars, ctx);

        // 2. Action 查找（SPI 注册表）
        AppAction action = registry.lookup(step.getApp(), step.getAction());
        if (action == null) {
            result.setStatus(StepStatus.DATA_ERROR);
            result.setMessage("未注册的 APP 操作: " + step.actionKey()
                    + "。当前注册表: " + registry.describe()
                    + "。注册方式：实现 AppAction 接口并标注 @ActionSpec(apps={\"" + step.getApp()
                    + "\"}, action=\"" + step.getAction() + "\"})");
            log.error("  xx 步骤 {} 失败(未注册): {}", step.getStepId(), result.getMessage());
            result.setDurationMs(System.currentTimeMillis() - start);
            return result;
        }

        // 3. 带超时 + 重试执行
        // 步骤 RETRY 列 > e2e.retry.step-retry-default > 0；ON_FAILURE=RETRY 时强制至少 1 次重试
        int stepRetry = Math.max(step.getRetry(), props.getRetry().getStepRetryDefault());
        if (step.getOnFailure() == OnFailure.RETRY && stepRetry == 0) {
            stepRetry = 1;
        }
        int maxAttempts = stepRetry + 1;
        StepStatus status = StepStatus.PASSED;
        String failureMessage = "";
        ActionResult actionResult = null;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            result.setAttempts(attempt);
            Future<ActionResult> future = null;
            try {
                future = stepPool.submit(() ->
                        action.execute(new ActionContext(step.getScenarioId(), step.getStepId(),
                                resolvedPayloads, ctx)));
                int timeoutSeconds = step.getTimeoutSeconds() > 0
                        ? step.getTimeoutSeconds() : props.getExecutor().getStepTimeoutDefaultSeconds();
                actionResult = future.get(timeoutSeconds, TimeUnit.SECONDS);
                if (!actionResult.isSuccess()) {
                    status = StepStatus.FAILED;
                    failureMessage = actionResult.getMessage();
                }
            } catch (TimeoutException e) {
                if (future != null) {
                    future.cancel(true);
                }
                status = StepStatus.TIMEOUT;
                failureMessage = "步骤超时（>" + step.getTimeoutSeconds() + "s）: " + e.getMessage();
            } catch (Exception e) {
                status = StepStatus.FAILED;
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                failureMessage = cause.getClass().getSimpleName() + ": " + cause.getMessage();
            }

            if (status == StepStatus.PASSED) {
                break; // action 成功，进入断言
            }
            if (attempt < maxAttempts) {
                long delay = props.getRetry().getStepRetryDelayMs() > 0
                        ? props.getRetry().getStepRetryDelayMs() : props.getExecutor().getRetryDelayMs();
                log.warn("  !! 步骤 {} 第 {} 次尝试失败: {}（{}ms 后重试）", step.getStepId(), attempt,
                        failureMessage, delay);
                sleep(delay);
            }
        }

        // 4. 断言评估（DB 断言支持异步数据最终一致性 —— 断言失败同样参与重试语义）
        Map<String, Object> outputs = new LinkedHashMap<>();
        if (actionResult != null && actionResult.getOutputs() != null) {
            outputs.putAll(actionResult.getOutputs());
        }
        if (status == StepStatus.PASSED && !resolvedAsserts.isEmpty()) {
            try {
                assertionEngine.evaluate(resolvedAsserts, outputs, ctx);
            } catch (AssertionEngine.AssertionFailureException e) {
                status = StepStatus.FAILED;
                failureMessage = e.getMessage();
            }
        }

        // 5. 变量提取（EXTRACT）
        if (status == StepStatus.PASSED && !step.getExtractRules().isEmpty()) {
            for (ExtractRule rule : step.getExtractRules()) {
                try {
                    Object value = evaluatePath(rule, outputs, ctx);
                    ctx.putExtract(rule.getName(), value);
                    log.info("    提取变量: {} = {}", rule.getName(), value);
                } catch (Exception e) {
                    status = StepStatus.FAILED;
                    failureMessage = "变量提取失败 " + rule.getName() + ": " + e.getMessage();
                }
            }
        }

        // 6. 失败策略（ON_FAILURE）
        if (status.isTerminalFailure()) {
            result.setStatus(status);
            result.setMessage(failureMessage);
            result.setOutputs(outputs);
            switch (step.getOnFailure()) {
                case SCREENSHOT -> {
                    String path = screenshotService.capture(step.getScenarioId(), step.getStepId());
                    result.setScreenshotPath(path);
                    log.error("  xx 步骤 {} 失败({}), 已留存截图证据: {}", step.getStepId(), status, path);
                }
                case SAVE_EVIDENCE -> {
                    // 保存截图 + outputs 快照
                    String path = screenshotService.capture(step.getScenarioId(), step.getStepId());
                    result.setScreenshotPath(path);
                    result.setOutputs(outputs);
                    log.error("  xx 步骤 {} 失败({}), 已保存全部证据: screenshot={}, outputs={}",
                            step.getStepId(), status, path, outputs.keySet());
                }
                default -> {
                    // STOP / CONTINUE / RETRY 耗尽：CONTINUE 不在此分支（非 terminal failure 例外）
                    log.error("  xx 步骤 {} 失败({}): {}", step.getStepId(), status, failureMessage);
                }
            }
            // AI 钩子：步骤失败时调用 AI 优化器给出建议（e2e.ai.features.step-optimization=true 时生效）
            if (aiAssistant.isEnabled() && props.getAi().getFeatures().isStepOptimization()) {
                try {
                    var suggestions = aiAssistant.stepOptimizer()
                            .suggest(step, result, null);
                    if (suggestions != null && !suggestions.isEmpty()) {
                        for (var s : suggestions) {
                            log.info("    [AI 建议] {}: {} → {}", s.type(), s.description(), s.suggestedChange());
                        }
                    }
                } catch (Exception e) {
                    log.debug("    [AI] 步骤优化建议调用失败: {}", e.getMessage());
                }
            }
        } else {
            result.setStatus(StepStatus.PASSED);
            result.setOutputs(outputs);
            result.setMessage(actionResult == null ? "" : actionResult.getMessage());
            log.info("  ok 步骤 {} 完成 ({} 次尝试)", step.getStepId(), result.getAttempts());
        }

        result.setDurationMs(System.currentTimeMillis() - start);
        ctx.recordStepResult(result); // 记录步骤结果到上下文历史
        return result;
    }

    // ---------------- 变量替换 ----------------

    private List<ProtocolPayload> resolvePayloads(StepDefinition step, Map<String, Object> extractVars,
                                                  ScenarioExecutionContext ctx) {
        List<ProtocolPayload> resolved = new ArrayList<>();
        for (ProtocolPayload payload : step.getInputPayloads()) {
            Object node = ctx.resolver().resolveInJson(payload.getParams(), extractVars);
            resolved.add(new ProtocolPayload(payload.getProtocol(), node));
        }
        return resolved;
    }

    private List<AssertionRule> resolveAsserts(StepDefinition step, Map<String, Object> extractVars,
                                               ScenarioExecutionContext ctx) {
        List<AssertionRule> resolved = new ArrayList<>();
        for (AssertionRule rule : step.getAssertRules()) {
            String target = ctx.resolver().resolve(rule.getTarget(), extractVars);
            List<String> expected = new ArrayList<>();
            for (String e : rule.getExpected()) {
                expected.add(ctx.resolver().resolve(e, extractVars));
            }
            resolved.add(new AssertionRule(rule.getSource(), target, rule.getOp(), expected, rule.getRaw()));
        }
        return resolved;
    }

    // ---------------- EXTRACT 路径求值 ----------------

    /** 路径语法：[0].ACCT_NO / rows[0].ACCT_NO / ACCT_NO（相对 rule.from 指向的对象） */
    private Object evaluatePath(ExtractRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        if ("DB".equalsIgnoreCase(rule.getFrom()) && rule.getPath() != null && !rule.getPath().isBlank()) {
            // DB 来源若 outputs 中没有（无 DB 断言时），则按目标 SQL 直查
            if (!outputs.containsKey("DB") && rule.getRaw().contains(":")) {
                // 简化：DB 提取依赖断言阶段回写；未命中时报错提示
                throw new IllegalArgumentException("DB 提取需要步骤同时配置 DB 断言（或 action 输出 DB 结果）");
            }
        }
        Object base = outputs.get(rule.getFrom());
        if (base == null) {
            throw new IllegalArgumentException("输出中不存在来源键 " + rule.getFrom() + "（可用: " + outputs.keySet() + "）");
        }
        String path = rule.getPath() == null ? "" : rule.getPath().trim();
        if (path.isEmpty()) {
            return base;
        }
        Object current = base;
        String normalized = path.startsWith("rows") ? path.substring(4) : path;
        for (String token : normalized.split("\\.")) {
            current = navigate(current, token);
            if (current == null) {
                throw new IllegalArgumentException("路径 " + path + " 在 " + token + " 处中断");
            }
        }
        return current;
    }

    private Object navigate(Object current, String token) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\w+)?(?:\\[(\\d+)])?$").matcher(token);
        if (!m.find()) {
            throw new IllegalArgumentException("非法路径片段: " + token);
        }
        if (m.group(1) != null && current instanceof Map<?, ?> map) {
            current = map.get(m.group(1));
        } else if (m.group(1) != null) {
            throw new IllegalArgumentException("片段 " + m.group(1) + " 需要 Map 但当前是 " + current.getClass().getSimpleName());
        }
        if (m.group(2) != null) {
            if (current instanceof List<?> list) {
                int idx = Integer.parseInt(m.group(2));
                current = idx < list.size() ? list.get(idx) : null;
            } else {
                throw new IllegalArgumentException("下标 " + m.group(2) + " 需要 List 但当前是 " + current.getClass().getSimpleName());
            }
        }
        return current;
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
