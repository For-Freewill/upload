package com.e2e.framework.engine;

/** ON_FAILURE=SCREENSHOT 时的截图钩子（真实接入：Selenium/Playwright 截图实现本接口即可） */
public interface ScreenshotService {

    /** @return 截图/证据文件路径 */
    String capture(String scenarioId, String stepId);
}
