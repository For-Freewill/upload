package com.e2e.framework.protocol.impl;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.HttpApiClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/** HTTP 桩实现（demo 模式）：回显请求并返回 200 */
public class StubHttpApiClient implements HttpApiClient {

    private static final Logger log = LoggerFactory.getLogger(StubHttpApiClient.class);

    @Override
    public HttpResult execute(HttpSpec spec) {
        log.info("[stub-http] {} {}", spec.getMethod(), spec.getUrl());
        JSONObject echo = new JSONObject();
        echo.put("stub", true);
        echo.put("method", spec.getMethod());
        echo.put("url", spec.getUrl());
        echo.put("echoBody", spec.getBody() == null ? new JSONObject() : spec.getBody());
        HttpResult result = new HttpResult();
        result.setStatusCode(200);
        result.setBody(echo.toJSONString());
        for (Map.Entry<String, String> h : spec.getHeaders().entrySet()) {
            result.getHeaders().put(h.getKey(), h.getValue());
        }
        return result;
    }

    @Override
    public String describe() {
        return "stub-http (demo)";
    }
}
