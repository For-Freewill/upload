package com.e2e.framework.protocol;

import java.util.List;

/** SSH 协议客户端（远程命令执行） */
public interface SshCommandClient {

    CommandResult run(SshSpec spec);

    String describe();

    /** SSH 命令规格 */
    class SshSpec {
        private String host;
        private int port = 22;
        private String user;
        private String password;
        private List<String> commands;
        private String baseDir;

        public String getHost() { return host; }
        public void setHost(String host) { this.host = host; }
        public int getPort() { return port; }
        public void setPort(int port) { this.port = port; }
        public String getUser() { return user; }
        public void setUser(String user) { this.user = user; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public List<String> getCommands() { return commands == null ? List.of() : commands; }
        public void setCommands(List<String> commands) { this.commands = commands; }
        public String getBaseDir() { return baseDir; }
        public void setBaseDir(String baseDir) { this.baseDir = baseDir; }
    }
}
