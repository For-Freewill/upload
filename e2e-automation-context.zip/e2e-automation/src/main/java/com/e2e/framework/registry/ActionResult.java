package com.e2e.framework.registry;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Action 执行结果：成功标志 + 消息 + 输出变量（供断言与 EXTRACT） */
public class ActionResult {

    private final boolean success;
    private final String message;
    private final Map<String, Object> outputs;

    private ActionResult(boolean success, String message, Map<String, Object> outputs) {
        this.success = success;
        this.message = message == null ? "" : message;
        this.outputs = outputs == null ? new LinkedHashMap<>() : outputs;
    }

    public static ActionResult ok(String message) {
        return new ActionResult(true, message, null);
    }

    public static ActionResult ok(String message, Map<String, Object> outputs) {
        return new ActionResult(true, message, outputs);
    }

    public static ActionResult fail(String message) {
        return new ActionResult(false, message, null);
    }

    public static ActionResult fail(String message, Map<String, Object> partialOutputs) {
        return new ActionResult(false, message, partialOutputs);
    }

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public Map<String, Object> getOutputs() { return Collections.unmodifiableMap(outputs); }
}
