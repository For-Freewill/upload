package com.e2e.framework.protocol;

/** MQ 协议客户端（SEND_MQ 使用；live 实现为框架预留扩展点） */
public interface MqClient {

    /**
     * @param params  INPUT 中 MQ 载荷参数（fastjson2 对象，可含 queue/topic 覆盖项）
     * @param message 报文内容（由 file 字段加载的 XML/JSON 文本）
     */
    void send(Object params, String message);

    String describe();
}
