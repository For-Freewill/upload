package com.e2e.framework.ai;

/**
 * AI 辅助统一门面 —— 聚合四大 AI 能力，供框架各层通过单一入口调用。
 *
 * <p>默认实现 {@link NoOpAiAssistant} 为全空操作（所有方法返回空/null），
 * 当 {@code e2e.ai.enabled=false}（默认）时生效，框架行为与无 AI 时完全一致。
 *
 * <p>接入真实 AI：
 * <ol>
 *   <li>实现本接口（或各子接口）并注册为 Spring Bean；</li>
 *   <li>设置 e2e.ai.enabled=true + e2e.ai.provider=openai/azure-openai/custom；</li>
 *   <li>按需开启各能力：e2e.ai.features.test-case-generation/report-interpretation/step-optimization/anomaly-detection。</li>
 * </ol>
 *
 * <p>各能力对应的框架接入点：
 * <ul>
 *   <li>{@link #testCaseGenerator()} —— 数据装载后 / CLI 用例生成命令；</li>
 *   <li>{@link #reportInterpreter()} —— ReportWriter 生成报告后；</li>
 *   <li>{@link #stepOptimizer()} —— StepExecutor 步骤失败后；</li>
 *   <li>{@link #anomalyDetector()} —— TestDataAssembler 装载后 / 执行中。</li>
 * </ul>
 */
public interface AiAssistant {

    AiTestCaseGenerator testCaseGenerator();

    AiReportInterpreter reportInterpreter();

    AiStepOptimizer stepOptimizer();

    AiAnomalyDetector anomalyDetector();

    /** AI 是否已启用（非 NoOp 实现） */
    boolean isEnabled();
}
