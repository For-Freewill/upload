package com.e2e.framework.protocol;

import java.util.LinkedHashMap;
import java.util.Map;

/** HTTP 协议客户端（SEND_HTTP_REQUEST / TAP_SSH_ALPHA2 输入使用） */
public interface HttpApiClient {

    HttpResult execute(HttpSpec spec);

    String describe();

    /** HTTP 请求规格（来自 INPUT 的 HTTP 载荷，body 为 fastjson2 对象/数组） */
    class HttpSpec {
        private String url;
        private String method = "GET";
        private Map<String, String> headers = new LinkedHashMap<>();
        private Object body;

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public String getMethod() { return method; }
        public void setMethod(String method) { this.method = method == null ? "GET" : method.toUpperCase(); }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers == null ? new LinkedHashMap<>() : headers; }
        public Object getBody() { return body; }
        public void setBody(Object body) { this.body = body; }
    }

    /** HTTP 响应 */
    class HttpResult {
        private int statusCode;
        private String body = "";
        private Map<String, String> headers = new LinkedHashMap<>();

        public int getStatusCode() { return statusCode; }
        public void setStatusCode(int statusCode) { this.statusCode = statusCode; }
        public String getBody() { return body; }
        public void setBody(String body) { this.body = body == null ? "" : body; }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers; }
    }
}
