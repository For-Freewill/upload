package com.e2e.framework.test;

import com.e2e.framework.E2EApplication;
import com.e2e.framework.protocol.DbClient;
import com.e2e.framework.protocol.ProtocolClients;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * DB 协议双驱动（live）验证：基于 H2 内存库分别以
 * <ul>
 *   <li>① e2e.db.driver=jdbc —— 原生 JDBC（DataSource + PreparedStatement 手写执行）；</li>
 *   <li>② e2e.db.driver=mybatis-plus —— MyBatis-Plus（SqlSessionFactory 动态 MappedStatement
 *       + SqlSessionTemplate 完整 MyBatis 执行链）；</li>
 * </ul>
 * 启动独立 live 上下文，对同一套 CRUD 语义断言行为一致（驱动实现可替换性的回归保障）。
 */
public class DbDriverModesTest {

    @Test
    public void nativeJdbcDriverRoundTrip() {
        verifyDriverMode("jdbc", "e2e_dbmode_jdbc");
    }

    @Test(dependsOnMethods = "nativeJdbcDriverRoundTrip")
    public void mybatisPlusDriverRoundTrip() {
        verifyDriverMode("mybatis-plus", "e2e_dbmode_mp");
    }

    private void verifyDriverMode(String driver, String dbName) {
        // 注意：命令行参数（--key=value）优先级高于 application.yml，确保覆盖 demo 默认值；
        // SpringApplicationBuilder.properties() 是 defaultProperties（最低优先级），会被 yml 覆盖。
        try (ConfigurableApplicationContext ctx = new SpringApplicationBuilder(E2EApplication.class)
                .web(WebApplicationType.NONE)
                .run(
                        "--spring.application.name=e2e-db-mode-test",
                        "--e2e.mode=live",
                        "--e2e.db.mode=LIVE",
                        "--e2e.db.driver=" + driver,
                        "--spring.datasource.url=jdbc:h2:mem:" + dbName + ";DB_CLOSE_DELAY=-1",
                        "--spring.datasource.driver-class-name=org.h2.Driver",
                        "--spring.datasource.username=sa",
                        "--spring.datasource.password=",
                        "--e2e.report.output-dir=test-output/dbmode-" + driver,
                        "--logging.level.com.e2e=INFO"
                )) {

            DbClient db = ctx.getBean(ProtocolClients.class).db();

            // 1) 驱动身份断言
            String desc = db.describe();
            if ("jdbc".equals(driver)) {
                Assert.assertTrue(desc.startsWith("jdbc(native"),
                        "应为原生 JDBC 驱动实现，实际: " + desc);
            } else {
                Assert.assertTrue(desc.startsWith("mybatis-plus"),
                        "应为 MyBatis-Plus 驱动实现，实际: " + desc);
            }

            // 2) DDL 建表
            db.execute(List.of("CREATE TABLE IF NOT EXISTS e2e_db_driver_test (" +
                    "id INT PRIMARY KEY, biz_name VARCHAR(64), qty INT)"));

            // 3) 批量 DML
            int[] inserts = db.execute(List.of(
                    "INSERT INTO e2e_db_driver_test VALUES (1, 'alpha', 10)",
                    "INSERT INTO e2e_db_driver_test VALUES (2, 'beta', 20)"));
            Assert.assertEquals(inserts, new int[]{1, 1}, "两条插入应各影响 1 行");

            // 4) 查询结果映射（列名 -> 值）
            List<Map<String, Object>> rows = db.query(
                    "SELECT id, biz_name, qty FROM e2e_db_driver_test WHERE id = 1");
            Assert.assertEquals(rows.size(), 1, "应查到 1 行");
            Map<String, Object> row = rows.get(0);
            Assert.assertEquals(String.valueOf(row.get("ID")), "1");
            Assert.assertEquals(String.valueOf(row.get("BIZ_NAME")), "alpha");
            Assert.assertEquals(String.valueOf(row.get("QTY")), "10");

            // 5) 更新 + 验证生效
            int[] updates = db.execute(List.of(
                    "UPDATE e2e_db_driver_test SET qty = 30 WHERE id = 2"));
            Assert.assertEquals(updates, new int[]{1});
            List<Map<String, Object>> updated = db.query(
                    "SELECT qty FROM e2e_db_driver_test WHERE id = 2");
            Assert.assertEquals(updated.size(), 1);
            Assert.assertEquals(String.valueOf(updated.get(0).get("QTY")), "30");

            // 6) COUNT(*) 聚合（数值型结果对象）
            List<Map<String, Object>> count = db.query(
                    "SELECT COUNT(*) FROM e2e_db_driver_test");
            Assert.assertEquals(String.valueOf(firstValue(count)), "2");

            // 7) 删除 + 终态
            int[] deletes = db.execute(List.of(
                    "DELETE FROM e2e_db_driver_test WHERE id = 1"));
            Assert.assertEquals(deletes, new int[]{1});
            List<Map<String, Object>> finalCount = db.query(
                    "SELECT COUNT(*) FROM e2e_db_driver_test");
            Assert.assertEquals(String.valueOf(firstValue(finalCount)), "1");
        }
    }

    private static Object firstValue(List<Map<String, Object>> rows) {
        return rows.get(0).values().iterator().next();
    }
}
