package com.e2e.framework.data;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.config.E2EProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 变量引擎 —— 执行期将步骤 INPUT/ASSERT/EXTRACT 中的占位符替换为真实值。
 *
 * <p>支持三种作用域：
 * <ul>
 *   <li>${global.key} —— 模版 _GlobalConfig 表（yaml: globalConfig）；</li>
 *   <li>${extract.key} —— 上游步骤 EXTRACT 提取的场景级变量；</li>
 *   <li>${env.key} —— Spring Environment（application.yml）+ 系统属性/环境变量；</li>
 *   <li>无前缀 ${key} —— 依次尝试 global -> env。</li>
 * </ul>
 */
@Component
public class VariableResolver {

    private static final Logger log = LoggerFactory.getLogger(VariableResolver.class);
    private static final Pattern VAR = Pattern.compile("\\$\\{([^}]+)}");

    private final Map<String, String> globalConfig;
    private final Environment environment;
    private final boolean strict;

    public VariableResolver(TestDataLoader loader, E2EProperties props, Environment environment) {
        this.environment = environment;
        this.strict = props.isStrict();
        this.globalConfig = loader.load().getGlobalConfig();
        log.info("变量引擎初始化: {} 个全局变量, strict={}", globalConfig.size(), strict);
    }

    /** 在任意文本中做占位符替换（SQL、URL、参数等） */
    public String resolve(String text, Map<String, Object> extractVars) {
        if (text == null || text.isEmpty() || !text.contains("${")) {
            return text;
        }
        Matcher m = VAR.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb, Matcher.quoteReplacement(lookup(m.group(1).trim(), extractVars)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * 深度替换 JSON 树（fastjson2 JSONObject/JSONArray）中所有字符串值内的占位符（保持结构合法）。
     *
     * @return 替换后的新树（原树不被修改）；字符串值原样返回替换结果
     */
    public Object resolveInJson(Object node, Map<String, Object> extractVars) {
        if (node == null) {
            return null;
        }
        if (node instanceof String s) {
            return resolve(s, extractVars);
        }
        if (node instanceof JSONObject obj) {
            JSONObject copy = new JSONObject();
            for (Map.Entry<String, Object> e : obj.entrySet()) {
                copy.put(e.getKey(), resolveInJson(e.getValue(), extractVars));
            }
            return copy;
        }
        if (node instanceof JSONArray arr) {
            JSONArray copy = new JSONArray();
            for (Object o : arr) {
                copy.add(resolveInJson(o, extractVars));
            }
            return copy;
        }
        return node;
    }

    private String lookup(String ref, Map<String, Object> extractVars) {
        String value;
        String scope = "";
        String key = ref;
        int dot = ref.indexOf('.');
        if (dot > 0) {
            scope = ref.substring(0, dot).toLowerCase();
            key = ref.substring(dot + 1);
        }
        switch (scope) {
            case "global" -> value = globalConfig.get(key);
            case "extract" -> {
                Object v = extractVars == null ? null : extractVars.get(key);
                value = v == null ? null : String.valueOf(v);
            }
            case "env" -> value = fromEnv(key);
            default -> {
                value = globalConfig.get(ref);
                if (value == null) {
                    value = fromEnv(ref);
                }
            }
        }
        if (value == null) {
            String msg = "未解析的变量 ${" + ref + "}（global=" + globalConfig.containsKey(key)
                    + ", extract=" + (extractVars != null && extractVars.containsKey(key)) + "）";
            if (strict) {
                throw new E2EDataException(msg);
            }
            log.warn(msg + "，保留原文");
            return "${" + ref + "}";
        }
        return value;
    }

    private String fromEnv(String key) {
        if (environment != null) {
            String v = environment.getProperty(key);
            if (v != null) {
                return v;
            }
        }
        String v = System.getProperty(key);
        return v != null ? v : System.getenv(key);
    }
}
