package com.e2e.framework.data;

import com.alibaba.fastjson2.JSON;
import com.e2e.framework.model.TestDataBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * YAML 数据源装载器 —— 与 Excel 模版等价的数据驱动入口（resources/cases/scenarios-examples.yml）。
 *
 * <p>适合 Git 版本管理、Code Review 与 CI 差异比对；结构与 Scenarios/Steps/_GlobalConfig 三表一一对应，
 * 装配校验逻辑与 Excel 完全共用（TestDataAssembler）。
 */
public class YamlTestDataLoader implements TestDataLoader {

    private static final Logger log = LoggerFactory.getLogger(YamlTestDataLoader.class);

    private final String path;
    private final boolean strict;

    public YamlTestDataLoader(String path, boolean strict) {
        this.path = path;
        this.strict = strict;
    }

    @Override
    public String sourceName() {
        return "yaml:" + path;
    }

    @Override
    @SuppressWarnings("unchecked")
    public TestDataBundle load() {
        log.info("从 YAML 数据源加载: {}", path);
        Map<String, Object> root;
        try (InputStream in = ResourcePathResolver.open(path)) {
            root = new Yaml().load(in);
        } catch (Exception e) {
            throw new E2EDataException("读取 YAML 失败: " + path + " (" + e.getMessage() + ")", e);
        }
        if (root == null) {
            root = new LinkedHashMap<>();
        }

        List<Map<String, String>> scenarioRows = new ArrayList<>();
        List<Map<String, String>> stepRows = new ArrayList<>();
        Map<String, String> globalConfig = new LinkedHashMap<>();

        List<Map<String, Object>> scenarios = asList(root.get("scenarios"));
        for (Map<String, Object> s : scenarios) {
            Map<String, String> srow = new LinkedHashMap<>();
            srow.put("SCENARIOID", str(s.get("scenarioId")));
            srow.put("SCENARIONAME", str(s.get("name")));
            srow.put("ENABLED", str(s.get("enabled")));
            srow.put("TAGS", str(s.get("tags")));
            srow.put("ENV", str(s.get("env")));
            srow.put("TIMEOUT", str(s.get("timeout")));
            srow.put("DESCRIPTION", str(s.get("description")));
            srow.put("OWNER", str(s.get("owner")));
            scenarioRows.add(srow);

            int seq = 1;
            for (Map<String, Object> st : asList(s.get("steps"))) {
                Map<String, String> trow = new LinkedHashMap<>();
                trow.put("SCENARIOID", str(s.get("scenarioId")));
                trow.put("SEQNO", str(st.get("seqNo") == null ? seq : st.get("seqNo")));
                trow.put("STEPID", str(st.get("stepId")));
                trow.put("APP", str(st.get("app")));
                trow.put("ACTION", str(st.get("action")));
                trow.put("DEPENDSON", str(st.get("dependsOn")));
                trow.put("INPUT", jsonOf(st.get("input")));
                trow.put("ASSERT", jsonOf(st.get("assert")));
                trow.put("EXTRACT", jsonOf(st.get("extract")));
                trow.put("TIMEOUT", str(st.get("timeout")));
                trow.put("RETRY", str(st.get("retry")));
                trow.put("ONFAILURE", str(st.get("onFailure")));
                trow.put("ENABLED", str(st.get("enabled")));
                stepRows.add(trow);
                seq++;
            }
        }

        Map<String, Object> gc = (Map<String, Object>) root.getOrDefault("globalConfig", new LinkedHashMap<>());
        gc.forEach((k, v) -> globalConfig.put(k, v == null ? "" : String.valueOf(v)));

        TestDataBundle bundle = new TestDataAssembler(sourceName(), strict)
                .assemble(scenarioRows, stepRows, globalConfig);
        log.info("加载完成: {} 个场景, {} 个全局变量", bundle.getScenarios().size(), bundle.getGlobalConfig().size());
        return bundle;
    }

    private String jsonOf(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String s) {
            return s;
        }
        try {
            return JSON.toJSONString(value);
        } catch (Exception e) {
            return String.valueOf(value);
        }
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> asList(Object value) {
        if (value == null) {
            return List.of();
        }
        if (value instanceof List<?> list) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object o : list) {
                if (o instanceof Map) {
                    result.add((Map<String, Object>) o);
                }
            }
            return result;
        }
        return List.of();
    }

    private String str(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof List<?> list) {
            StringBuilder sb = new StringBuilder();
            for (Object o : list) {
                if (sb.length() > 0) {
                    sb.append(";");
                }
                sb.append(String.valueOf(o));
            }
            return sb.toString();
        }
        return String.valueOf(value).trim().toUpperCase(Locale.ROOT).equals("NULL") ? "" : String.valueOf(value);
    }
}
