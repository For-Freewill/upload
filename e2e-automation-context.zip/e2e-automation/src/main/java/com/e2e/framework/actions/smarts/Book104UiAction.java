package com.e2e.framework.actions.smarts;

import com.e2e.framework.actions.common.AbstractUiAction;
import com.e2e.framework.registry.ActionSpec;

/** SMARTS 域：104_UI_BOOK —— 104 报文预订/BOOK 操作（JAVA 协议 UI 操作） */
@ActionSpec(apps = {"SMARTS"}, action = "104_UI_BOOK", description = "104 报文 BOOK 预订（JAVA 协议 UI 操作）")
public class Book104UiAction extends AbstractUiAction {
    @Override
    protected String businessName() { return "104 BOOK 预订"; }
}
