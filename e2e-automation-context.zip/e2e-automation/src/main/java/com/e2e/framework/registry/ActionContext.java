package com.e2e.framework.registry;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.engine.ScenarioExecutionContext;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.protocol.ProtocolClients;

import java.util.List;
import java.util.Map;

/**
 * Action 执行上下文 —— 由执行引擎在调用 {@link AppAction#execute} 前组装。
 *
 * <p>封装 {@link ScenarioExecutionContext}，提供 Action 开发者常用的便捷 API。
 *
 * <h3>新增 Action 实现时最常用的 API</h3>
 * <pre>
 * &#64;Override
 * public ActionResult execute(ActionContext ctx) {
 *     // ① 取协议参数（JSON 对象）
 *     JSONObject params = ctx.jsonParams("HTTP");
 *     String url = params.getString("url");
 *
 *     // ② 取协议参数（必填，缺失时抛异常）
 *     JSONObject db = ctx.requireJsonParams("DB");
 *
 *     // ③ 调用协议客户端
 *     ctx.clients().http().execute(spec);
 *     ctx.clients().db().query(sql);
 *
 *     // ④ 读写场景级变量（EXTRACT，供后续步骤 ${extract.x} 引用）
 *     ctx.setVar("orderId", "123");           // 写入变量
 *     String prevId = ctx.getVar("orderId");   // 读取前序步骤写入的变量
 *
 *     // ⑤ 查询前序步骤的执行结果和输出
 *     StepResult prev = ctx.getStepResult("HTTP-POST-SEND");
 *     Object status = ctx.getStepOutput("HTTP-POST-SEND", "status");
 *     boolean done = ctx.isStepCompleted("DB-INSERT-LOG");
 *
 *     // ⑥ 返回结果（outputs 供 ASSERT / EXTRACT 使用）
 *     return ActionResult.ok("成功", Map.of("status", 200));
 * }
 * </pre>
 */
public class ActionContext {

    private final String scenarioId;
    private final String stepId;
    private final List<ProtocolPayload> payloads;
    private final ScenarioExecutionContext scenarioCtx;

    public ActionContext(String scenarioId, String stepId, List<ProtocolPayload> payloads,
                         ScenarioExecutionContext scenarioCtx) {
        this.scenarioId = scenarioId;
        this.stepId = stepId;
        this.payloads = payloads;
        this.scenarioCtx = scenarioCtx;
    }

    // ===================== 基础信息 =====================

    public String getScenarioId() { return scenarioId; }
    public String getStepId() { return stepId; }
    public List<ProtocolPayload> getPayloads() { return payloads; }

    /** 获取底层场景上下文（高级 API，一般不需要直接使用） */
    public ScenarioExecutionContext scenarioContext() { return scenarioCtx; }

    // ===================== 协议参数 =====================

    /** 取第一个指定协议的载荷（大小写不敏感），没有则返回 null */
    public ProtocolPayload payload(String protocol) {
        for (ProtocolPayload p : payloads) {
            if (p.getProtocol().equalsIgnoreCase(protocol)) {
                return p;
            }
        }
        return null;
    }

    /** 取协议参数为 JSONObject（便捷方法） */
    public JSONObject jsonParams(String protocol) {
        ProtocolPayload p = payload(protocol);
        return p == null ? null : p.paramsAsObject();
    }

    /** 取协议参数为 JSONObject（必填，缺失时抛异常带提示） */
    public JSONObject requireJsonParams(String protocol) {
        JSONObject params = jsonParams(protocol);
        if (params == null) {
            throw new IllegalArgumentException(
                    "步骤 " + stepId + " 缺少 " + protocol + " 协议载荷。"
                            + "INPUT 格式: [{\"" + protocol + "\":{...}}]");
        }
        return params;
    }

    /** 取协议参数的字符串值（便捷方法） */
    public String paramStr(String protocol, String key) {
        JSONObject params = jsonParams(protocol);
        return params == null ? null : params.getString(key);
    }

    // ===================== 场景级变量（EXTRACT） =====================

    /** 写入场景级变量（供后续步骤通过 ${extract.name} 引用） */
    public void setVar(String name, Object value) {
        scenarioCtx.putExtract(name, value);
    }

    /** 读取场景级变量（前序步骤写入的） */
    public Object getVar(String name) {
        return scenarioCtx.getExtract(name);
    }

    /** 读取场景级变量（带类型转换） */
    @SuppressWarnings("unchecked")
    public <T> T getVar(String name, Class<T> type) {
        Object v = scenarioCtx.getExtract(name);
        if (v == null) return null;
        if (type.isInstance(v)) return (T) v;
        return type.cast(v);
    }

    /** 获取全部场景级变量（只读） */
    public Map<String, Object> extractVars() {
        return scenarioCtx.getExtractVars();
    }

    // ===================== 前序步骤查询 =====================

    /** 查询前序步骤的执行结果 */
    public StepResult getStepResult(String stepId) {
        return scenarioCtx.getStepResult(stepId);
    }

    /** 查询前序步骤是否已通过 */
    public boolean isStepCompleted(String stepId) {
        return scenarioCtx.isStepCompleted(stepId);
    }

    /** 获取前序步骤的输出值 */
    public Object getStepOutput(String stepId, String key) {
        return scenarioCtx.getStepOutput(stepId, key);
    }

    // ===================== 协议客户端 & 配置 =====================

    public ProtocolClients clients() { return scenarioCtx.clients(); }
    public E2EProperties props() { return scenarioCtx.props(); }
}
