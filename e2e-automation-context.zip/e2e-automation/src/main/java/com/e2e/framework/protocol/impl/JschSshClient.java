package com.e2e.framework.protocol.impl;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.SshCommandClient;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** SSH live 实现：基于 JSch（com.github.mwiede:jsch） */
public class JschSshClient implements SshCommandClient {

    private static final Logger log = LoggerFactory.getLogger(JschSshClient.class);

    private final E2EProperties.Ssh sshProps;

    public JschSshClient(E2EProperties.Ssh sshProps) {
        this.sshProps = sshProps;
    }

    @Override
    public CommandResult run(SshSpec spec) {
        String user = spec.getUser() != null ? spec.getUser() : sshProps.getUser();
        String password = spec.getPassword() != null ? spec.getPassword() : sshProps.getPassword();
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(user, spec.getHost(), spec.getPort());
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect(15_000);
            try {
                StringBuilder stdout = new StringBuilder();
                StringBuilder stderr = new StringBuilder();
                int exit = 0;
                List<String> commands = spec.getCommands();
                if (spec.getBaseDir() != null && !spec.getBaseDir().isBlank()) {
                    commands = new java.util.ArrayList<>(commands);
                    commands.add(0, "cd " + spec.getBaseDir());
                }
                for (String cmd : commands) {
                    ChannelExec channel = (ChannelExec) session.openChannel("exec");
                    try {
                        channel.setCommand(cmd);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        ByteArrayOutputStream err = new ByteArrayOutputStream();
                        channel.setOutputStream(out);
                        channel.setErrStream(err);
                        channel.connect(30_000);
                        while (!channel.isClosed()) {
                            Thread.sleep(50);
                        }
                        exit = channel.getExitStatus();
                        stdout.append(out.toString(StandardCharsets.UTF_8)).append('\n');
                        stderr.append(err.toString(StandardCharsets.UTF_8)).append('\n');
                        log.info("[ssh] {} -> exit={}", cmd, exit);
                    } finally {
                        channel.disconnect();
                    }
                }
                return new CommandResult(exit, stdout.toString(), stderr.toString());
            } finally {
                session.disconnect();
            }
        } catch (Exception e) {
            return new CommandResult(-1, "", "SSH 执行失败 " + spec.getHost() + ": " + e.getMessage());
        }
    }

    @Override
    public String describe() {
        return "jsch-ssh (live)";
    }
}
