package com.e2e.framework.protocol.impl;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.MqClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MQ 桩实现（demo 模式）：记录报文与目标队列。
 *
 * <p>live 接入：实现 MqClient（如基于 IBM MQ / RocketMQ 客户端），
 * 并通过 ProtocolClients 或自定义 @ActionSpec 覆盖（见 README 扩展指南）。
 */
public class StubMqClient implements MqClient {

    private static final Logger log = LoggerFactory.getLogger(StubMqClient.class);

    private final String defaultQueue;

    public StubMqClient(String defaultQueue) {
        this.defaultQueue = defaultQueue;
    }

    @Override
    public void send(Object params, String message) {
        String queue = params instanceof JSONObject jo && jo.containsKey("queue")
                ? jo.getString("queue") : defaultQueue;
        log.info("[stub-mq] send to queue='{}' messageBytes={} messageHead={}",
                queue, message == null ? 0 : message.length(), head(message));
    }

    private static String head(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        String one = s.replaceAll("\\s+", " ");
        return one.length() > 120 ? one.substring(0, 120) + "..." : one;
    }

    @Override
    public String describe() {
        return "stub-mq (demo, queue=" + defaultQueue + ")";
    }
}
