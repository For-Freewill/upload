package com.e2e.framework.actions.stp;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.data.ResourcePathResolver;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * STP 域：SEND_MQ —— 发送 MQ 报文（报文来自 file 字段引用的 XML/JSON 文件）。
 *
 * <p>INPUT 示例：{@code [{"MQ":{"file":"data/e2e/stp/mq/test-001.xml"}}]}
 */
@ActionSpec(apps = {"STP"}, action = "SEND_MQ", description = "向 MQ 队列发送报文（file 引用报文文件）")
public class SendMqAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("MQ");
        if (payload == null) {
            return ActionResult.fail("SEND_MQ 需要 MQ 协议载荷: [{\"MQ\":{\"file\":\"...\"}}]");
        }
        String fileRef = payload.getParams() instanceof JSONObject jo ? jo.getString("file") : null;
        if (fileRef == null || fileRef.isBlank()) {
            return ActionResult.fail("MQ 载荷缺少 file 字段");
        }
        String message = ResourcePathResolver.readText(fileRef, context.props().getData().getPayloadBase());
        context.clients().mq().send(payload.getParams(), message);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("MQ", "SENT");
        outputs.put("file", fileRef);
        outputs.put("messageBytes", message.length());
        return ActionResult.ok("已发送 MQ 报文: " + fileRef + " (" + message.length() + " bytes)", outputs);
    }
}
