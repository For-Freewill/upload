package com.e2e.framework.actions.tap;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.SshCommandClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * DATAHUB 域：TAP_WINDOWS_CMD —— 执行 Windows 命令。
 *
 * <p>INPUT 示例：{@code [{"WINDOWS-CMD":{"host":"local","base_dir":"c:/scratch","cmd":["dir","set_env alpha pimco U"]}}]}
 * host=local 走本地命令客户端（默认 dry-run），否则走 SSH。
 *
 * <p>载荷宽容（模版数据现状）：WINDOWS-CMD -&gt; LINUX-CMD -&gt; SSH 逐级回退识别，
 * SSH 载荷按远程命令语义执行。
 */
@ActionSpec(apps = {"DATAHUB"}, action = "TAP_WINDOWS_CMD", description = "执行 Windows 命令（local 或远程 SSH）")
public class TapWindowsCmdAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(TapWindowsCmdAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("WINDOWS-CMD");
        if (payload == null) {
            payload = context.payload("LINUX-CMD");
        }
        if (payload == null) {
            // 模版数据错位容错：WINDOWS-CMD 步骤可能携带 SSH 载荷（host + body）
            payload = context.payload("SSH");
            if (payload != null) {
                log.warn("步骤 {} 声明为 CMD 操作但携带 SSH 载荷，按远程命令语义执行（模版数据错位容错）",
                        context.getStepId());
                return executeSshPayload(context, payload.paramsAsObject());
            }
        }
        if (payload == null) {
            return ActionResult.fail("TAP_WINDOWS_CMD 需要 WINDOWS-CMD（或 LINUX-CMD/SSH）协议载荷");
        }
        return executeCmd(context, payload.paramsAsObject(), true);
    }

    /** 命令载荷执行：{host, base_dir, cmd[]}，host=local 走本地命令，否则 SSH */
    protected ActionResult executeCmd(ActionContext context, JSONObject params, boolean windows) {
        List<String> commands = new ArrayList<>();
        Object cmdObj = params.get("cmd");
        if (cmdObj instanceof JSONArray cmdArr) {
            for (Object n : cmdArr) {
                commands.add(n instanceof String s ? s : String.valueOf(n));
            }
        } else if (cmdObj instanceof String s) {
            commands.add(s);
        }
        if (commands.isEmpty()) {
            return ActionResult.fail("命令载荷缺少 cmd 字段");
        }
        String host = params.getString("host");
        if (host == null || host.isBlank()) {
            host = "local";
        }
        String baseDir = params.getString("base_dir");

        CommandResult result;
        if ("local".equalsIgnoreCase(host) || "localhost".equalsIgnoreCase(host)) {
            result = context.clients().cmd().run(commands, baseDir, windows);
        } else {
            SshCommandClient.SshSpec spec = new SshCommandClient.SshSpec();
            spec.setHost(host);
            spec.setCommands(commands);
            spec.setBaseDir(baseDir);
            result = context.clients().ssh().run(spec);
        }

        Map<String, Object> outputs = Map.of(
                "CMD", result.getExitCode(),
                "STDOUT", result.getStdout());
        if (result.getExitCode() == 0) {
            return ActionResult.ok((windows ? "WINDOWS-CMD" : "LINUX-CMD") + "@" + host
                    + " 执行 " + commands.size() + " 条命令成功", outputs);
        }
        return ActionResult.fail("命令执行失败 exit=" + result.getExitCode()
                + " stderr=" + result.getStderr(), outputs);
    }

    /** SSH 载荷容错执行：{host, group, body} 按远程命令语义转换 */
    private ActionResult executeSshPayload(ActionContext context, JSONObject sshParams) {
        SshCommandClient.SshSpec spec = new SshCommandClient.SshSpec();
        String host = sshParams.getString("host");
        spec.setHost(host == null || host.isBlank() ? "remote-host" : stripScheme(host));
        List<String> commands = new ArrayList<>();
        Object bodyObj = sshParams.get("body");
        if (bodyObj instanceof JSONObject body) {
            body.forEach((k, v) -> commands.add(k + "=" + String.valueOf(v)));
        }
        Object cmdObj = sshParams.get("cmd");
        if (cmdObj instanceof JSONArray cmdArr) {
            for (Object n : cmdArr) {
                commands.add(String.valueOf(n));
            }
        }
        if (commands.isEmpty()) {
            commands.add("echo e2e-ssh-fallback");
        }
        spec.setCommands(commands);
        CommandResult result = context.clients().ssh().run(spec);
        Map<String, Object> outputs = Map.of(
                "SSH", result.getExitCode(),
                "STDOUT", result.getStdout());
        if (result.getExitCode() == 0) {
            return ActionResult.ok("SSH@" + spec.getHost() + " 执行 " + commands.size() + " 条命令成功（SSH 载荷容错）", outputs);
        }
        return ActionResult.fail("SSH 命令执行失败 exit=" + result.getExitCode()
                + " stderr=" + result.getStderr(), outputs);
    }

    private static String stripScheme(String url) {
        String s = url.replaceFirst("^https?://", "");
        int slash = s.indexOf('/');
        return slash > 0 ? s.substring(0, slash) : s;
    }
}
