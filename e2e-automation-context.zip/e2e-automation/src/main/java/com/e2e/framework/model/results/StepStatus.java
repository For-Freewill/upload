package com.e2e.framework.model.results;

/** 步骤执行状态 */
public enum StepStatus {
    PENDING, RUNNING, PASSED, FAILED, TIMEOUT, SKIPPED, DATA_ERROR;

    public boolean isTerminalFailure() {
        return this == FAILED || this == TIMEOUT || this == DATA_ERROR;
    }
}
