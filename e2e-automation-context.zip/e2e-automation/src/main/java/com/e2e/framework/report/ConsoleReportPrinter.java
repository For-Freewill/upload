package com.e2e.framework.report;

import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.results.ScenarioResult;
import org.springframework.stereotype.Component;

import java.util.List;

/** 控制台执行摘要打印 */
@Component
public class ConsoleReportPrinter {

    public void print(List<ScenarioResult> results, List<DataQualityIssue> issues) {
        System.out.println();
        System.out.println("==================== E2E 执行摘要 ====================");
        System.out.printf("%-24s %-10s %10s %8s %8s %8s %10s%n",
                "Scenario", "Status", "Steps", "Pass", "Fail", "Skip", "Duration");
        System.out.println("------------------------------------------------------");
        results.forEach(r -> System.out.printf("%-24s %-10s %10d %8d %8d %8d %9dms%n",
                abbreviate(r.getScenario().getScenarioId(), 24),
                r.getStatus(),
                r.getStepResults().size(),
                r.passedCount(),
                r.failedCount(),
                r.skippedCount(),
                r.getDurationMs()));
        long passed = results.stream().filter(r -> r.getStatus().name().equals("PASSED")).count();
        long failed = results.stream().filter(r -> r.getStatus().name().equals("FAILED")).count();
        long skipped = results.stream().filter(r -> r.getStatus().name().equals("SKIPPED")).count();
        System.out.println("------------------------------------------------------");
        System.out.printf("合计: %d 个场景（通过 %d / 失败 %d / 跳过 %d）%n", results.size(), passed, failed, skipped);

        if (issues != null && !issues.isEmpty()) {
            System.out.println();
            System.out.println("-------------- 数据质量提示（模版数据问题） --------------");
            issues.forEach(i -> System.out.println("  ! " + i));
        }
        System.out.println("======================================================");
    }

    private static String abbreviate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "~" : s;
    }
}
