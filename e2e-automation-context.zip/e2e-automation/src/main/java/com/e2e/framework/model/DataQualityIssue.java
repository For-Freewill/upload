package com.e2e.framework.model;

/**
 * 数据质量问题 —— 加载模版（xlsx/yaml）时发现的容错修复、拼写、孤儿引用等问题。
 *
 * <p>非严格模式下降级为告警输出到报告；严格模式（e2e.strict=true）下直接终止加载。
 */
public class DataQualityIssue {

    private final String source;
    private final String scenarioId;
    private final String stepId;
    private final String field;
    private final String issue;
    private final String handling;

    public DataQualityIssue(String source, String scenarioId, String stepId, String field, String issue, String handling) {
        this.source = source;
        this.scenarioId = scenarioId;
        this.stepId = stepId;
        this.field = field;
        this.issue = issue;
        this.handling = handling;
    }

    public String getSource() { return source; }
    public String getScenarioId() { return scenarioId; }
    public String getStepId() { return stepId; }
    public String getField() { return field; }
    public String getIssue() { return issue; }
    public String getHandling() { return handling; }

    @Override
    public String toString() {
        return "[" + source + "] " + (stepId != null ? stepId + " " : "") + field + ": " + issue
                + " -> " + handling;
    }
}
