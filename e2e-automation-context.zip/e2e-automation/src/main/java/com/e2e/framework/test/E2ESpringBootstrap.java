package com.e2e.framework.test;

import com.e2e.framework.E2EApplication;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Spring 上下文引导（TestNG 侧懒加载单例）。
 *
 * <p>不依赖 TestNG 监听器启动顺序：首个测试方法执行时按需初始化，
 * 套件结束时由 {@code E2ESuiteLifecycleListener} 统一关闭。
 */
public final class E2ESpringBootstrap {

    private static volatile E2ESpringBootstrap instance;
    private final ConfigurableApplicationContext ctx;

    private E2ESpringBootstrap() {
        SpringApplication app = new SpringApplication(E2EApplication.class);
        app.setBannerMode(Banner.Mode.OFF);
        app.setWebApplicationType(WebApplicationType.NONE);
        this.ctx = app.run();
    }

    public static E2ESpringBootstrap getInstance() {
        if (instance == null) {
            synchronized (E2ESpringBootstrap.class) {
                if (instance == null) {
                    instance = new E2ESpringBootstrap();
                }
            }
        }
        return instance;
    }

    public <T> T getBean(Class<T> type) {
        return ctx.getBean(type);
    }

    public static synchronized void shutdown() {
        if (instance != null) {
            instance.ctx.close();
            instance = null;
        }
    }
}
