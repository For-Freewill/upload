package com.e2e.framework.protocol.impl;

import com.alibaba.fastjson2.JSON;
import com.e2e.framework.protocol.HttpApiClient;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * HTTP live 实现：基于 REST Assured（given / when / then DSL）。
 *
 * <p>非 2xx 响应不抛异常（与桩实现语义一致，由 Action 层按状态码判定成败）。
 */
public class RestAssuredHttpApiClient implements HttpApiClient {

    private static final Logger log = LoggerFactory.getLogger(RestAssuredHttpApiClient.class);

    @Override
    public HttpResult execute(HttpSpec spec) {
        log.info("[http] {} {}", spec.getMethod(), spec.getUrl());

        RequestSpecification request = given()
                .relaxedHTTPSValidation();
        for (Map.Entry<String, String> h : spec.getHeaders().entrySet()) {
            request.header(h.getKey(), h.getValue());
        }
        Object body = spec.getBody();
        String method = spec.getMethod();
        if (body != null && !"GET".equals(method) && !"DELETE".equals(method)) {
            request.contentType(ContentType.JSON).body(JSON.toJSONString(body));
        }

        Response response = request.request(method, spec.getUrl());

        HttpResult result = new HttpResult();
        result.setStatusCode(response.getStatusCode());
        result.setBody(response.getBody() == null ? "" : response.getBody().asString());
        for (Header h : response.getHeaders()) {
            result.getHeaders().put(h.getName(), h.getValue());
        }
        return result;
    }

    @Override
    public String describe() {
        return "rest-assured (live)";
    }
}
