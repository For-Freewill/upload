package com.e2e.framework.test;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Excel 真实用例生成器 —— 将 12 个 E2E 测试场景写入 cases/E2E-Test-Scenarios.xlsx。
 *
 * <p>Sheet 结构与模版完全一致：Scenarios / Steps / _GlobalConfig。
 * 生成的 xlsx 放入 src/test/resources/cases/，可通过
 * {@code -De2e.data.excel.path=classpath:cases/E2E-Test-Scenarios.xlsx} 加载运行。
 *
 * <p>本类为一次性生成工具（@Test 标注以便 mvn test 执行），生成后 xlsx 作为静态资源使用。
 * 重新运行会覆盖已有文件（按需更新用例集时使用）。
 *
 * <p>覆盖的 Action 类型：SEND_HTTP_REQUEST / COMMON_DB_EXECUTE / COMMON_DB_ASSERTIONS /
 * TAP_WINDOWS_CMD / TAP_LINUX_CMD / SEND_MQ / TAP_SSH_ALPHA2 / DRP_UI_REPORTS / 104_UI_BOOK。
 * 覆盖的框架特性：DEPENDS_ON 依赖链 / ${extract.*} 变量传递 / WAIT_UNTIL 异步断言 /
 * ON_FAILURE=RETRY 重试 / Enabled=N 禁用过滤 / 多协议组合编排。
 */
public class CasesExcelGenerator {

    @Test
    public void generateCases() throws Exception {
        Path output = Paths.get("src/test/resources/cases/E2E-Test-Scenarios.xlsx");
        Files.createDirectories(output.getParent());

        ExcelWriter writer = com.alibaba.excel.EasyExcel.write(output.toFile()).build();

        // ===== Sheet 1: Scenarios =====
        List<String> scenarioHeader = List.of(
                "Seq", "Scenario_ID", "Scenario_Name", "Enabled", "Tags", "Env", "Timeout", "Description", "Owner");
        List<List<Object>> scenarioRows = new ArrayList<>();
        scenarioRows.add(row(1, "E2E-CASE-HTTP-GET-CHAIN", "HTTP GET 链式请求验证", "Y", "http;smoke", "demo", "120", "验证 HTTP GET 基础请求与带参查询的链式执行", "e2e-team"));
        scenarioRows.add(row(2, "E2E-CASE-MULTI-APP-FAIL", "多APP流程含失败（STOP 级联跳过）", "Y", "flow;multiapp;fail", "demo", "180", "5种APP编排，步骤4失败+ON_FAILURE=STOP导致后续级联SKIPPED", "e2e-team"));
        scenarioRows.add(row(3, "E2E-CASE-MULTI-APP-PARTIAL", "多APP流程含部分失败（CONTINUE 继续）", "Y", "flow;multiapp;partial", "demo", "180", "5种APP编排，步骤4失败+ON_FAILURE=CONTINUE后续继续执行", "e2e-team"));
        scenarioRows.add(row(4, "E2E-CASE-DNS-PARALLEL-FANOUT", "SMARTS→DNS 并行扇出", "Y", "fanout;dns;parallel", "demo", "120", "1个SMARTS下游并行3个DNS，验证 DAG 扇出拓扑", "e2e-team"));
        scenarioRows.add(row(5, "E2E-CASE-DB-CRUD-LIFECYCLE", "DB CRUD 全生命周期", "Y", "db;crud", "demo", "180", "建表→插入→更新→删除全链路 DB 操作验证", "e2e-team"));
        scenarioRows.add(row(6, "E2E-CASE-DB-POLL-CONSISTENCY", "DB 异步轮询一致性", "Y", "db;async;awaitility", "demo", "120", "使用 WAIT_UNTIL 异步断言验证 DB 最终一致性", "e2e-team"));
        scenarioRows.add(row(7, "E2E-CASE-CMD-WINDOWS-MULTI", "Windows 多命令链执行", "Y", "cmd;windows", "demo", "60", "Windows 本地多命令链式执行与输出断言", "e2e-team"));
        scenarioRows.add(row(8, "E2E-CASE-CMD-LINUX-EMULATE", "Linux 命令模拟执行", "Y", "cmd;linux", "demo", "60", "Linux CMD 命令模拟执行与退出码验证", "e2e-team"));
        scenarioRows.add(row(9, "E2E-CASE-MQ-SEND-VERIFY", "MQ 报文发送验证", "Y", "mq;send", "demo", "60", "MQ 报文发送与 stub 回显验证", "e2e-team"));
        scenarioRows.add(row(10, "E2E-CASE-SSH-REMOTE-EXEC", "SSH 远程命令执行", "Y", "ssh;remote", "demo", "90", "SSH 远程命令执行与本地日志记录", "e2e-team"));
        scenarioRows.add(row(11, "E2E-CASE-UI-REPORT-VIEW", "UI 报表浏览交互", "Y", "ui;report", "demo", "120", "UI 报表浏览与交互操作验证（Playwright 桩模式）", "e2e-team"));
        scenarioRows.add(row(12, "E2E-CASE-FLOW-ORDER-LIFECYCLE", "订单全流程端到端", "Y", "flow;e2e;smoke", "demo", "300", "HTTP创建→DB验证→MQ通知→CMD日志→DB清理 端到端流程", "e2e-team"));
        scenarioRows.add(row(13, "E2E-CASE-RETRY-FLAKY-STEP", "失败重试策略验证", "Y", "retry;flaky", "demo", "120", "ON_FAILURE=RETRY 步骤级重试策略验证", "e2e-team"));
        scenarioRows.add(row(14, "E2E-CASE-DISABLED-DEMO", "禁用场景演示", "N", "disabled;demo", "demo", "60", "Enabled=N 的场景应被跳过（验证 enable 过滤）", "e2e-team"));

        WriteSheet sheet1 = com.alibaba.excel.EasyExcel.writerSheet(0, "Scenarios")
                .head(toHead(scenarioHeader)).build();
        writer.write(scenarioRows, sheet1);

        // ===== Sheet 2: Steps =====
        List<String> stepHeader = List.of(
                "Scenario_ID", "SEQ_NO", "STEP_ID", "APP", "ACTION", "DEPENDS_ON",
                "INPUT", "ASSERT", "EXTRACT", "TIMEOUT", "RETRY", "ON_FAILURE", "ENABLED");
        List<List<Object>> stepRows = new ArrayList<>();

        // --- 1. HTTP GET chain (3 steps) ---
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 1, "HTTP-GET-BASIC", "TAP", "SEND_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 2, "HTTP-GET-QUERY", "STP", "SEND_HTTP_REQUEST", "HTTP-GET-BASIC",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}/s?wd=${global.http_search_word}\",\"method\":\"GET\",\"headers\":{\"User-Agent\":\"e2e-test\"}}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"queryStatus\",\"from\":\"HTTP\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 3, "HTTP-VERIFY-OUTPUT", "SMARTS", "COMMON_DB_ASSERTIONS", "HTTP-GET-QUERY",
                "[]",
                "[{\"DB\":\"SELECT '200' WHERE val='200'\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S2. Multi-APP flow with failure (6 steps, 5 APPs, STOP cascade) ---
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 1, "MAF-HTTP-CALL", "TAP", "SEND_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 2, "MAF-DB-PREP", "SMARTS", "COMMON_DB_EXECUTE", "MAF-HTTP-CALL",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_maf (id INT, app VARCHAR(20))\",\"INSERT INTO e2e_maf VALUES (1,'TAP')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 3, "MAF-MQ-NOTIFY", "STP", "SEND_MQ", "MAF-DB-PREP",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 4, "MAF-CMD-VERIFY", "DATAHUB", "TAP_LINUX_CMD", "MAF-MQ-NOTIFY",
                "[{\"LINUX-CMD\":{\"cmd\":[\"echo payment-processed\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"INTENTIONAL-FAIL\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 5, "MAF-UI-CHECK", "DRP", "DRP_UI_REPORTS", "MAF-CMD-VERIFY",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"verify\"}}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 6, "MAF-DB-ASSERT", "SMARTS", "COMMON_DB_ASSERTIONS", "MAF-UI-CHECK",
                "[]",
                "[{\"DB\":\"SELECT 'ok' WHERE status='ok'\",\"OP\":\"EQ\",\"EXPECTED\":[\"ok\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S3. Multi-APP flow with partial failure (6 steps, 5 APPs, CONTINUE) ---
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 1, "MAP-MQ-START", "STP", "SEND_MQ", "[]",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 2, "MAP-CMD-LOG", "DATAHUB", "TAP_WINDOWS_CMD", "MAP-MQ-START",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo flow-started\"]}}]",
                "[{\"STDOUT\":\"flow-started\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"flow-started\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 3, "MAP-HTTP-CALL", "TAP", "SEND_HTTP_REQUEST", "MAP-CMD-LOG",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 4, "MAP-UI-VERIFY", "DRP", "DRP_UI_REPORTS", "MAP-HTTP-CALL",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"verify\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"FAIL\"]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 5, "MAP-DB-EXECUTE", "SMARTS", "COMMON_DB_EXECUTE", "MAP-HTTP-CALL",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_map (id INT, result VARCHAR(20))\",\"INSERT INTO e2e_map VALUES (1,'partial-fail')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 6, "MAP-DB-ASSERT", "SMARTS", "COMMON_DB_ASSERTIONS", "MAP-DB-EXECUTE",
                "[]",
                "[{\"DB\":\"SELECT 'actual' WHERE status='ok'\",\"OP\":\"EQ\",\"EXPECTED\":[\"wrong\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S4. SMARTS→DNS parallel fanout (4 steps: 1 SMARTS → 3 parallel DNS) ---
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 1, "FAN-SMARTS-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_fan (id INT, val VARCHAR(50))\",\"INSERT INTO e2e_fan VALUES (1,'alpha')\",\"INSERT INTO e2e_fan VALUES (2,'beta')\",\"INSERT INTO e2e_fan VALUES (3,'gamma')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 2, "FAN-DNS-CHECK-A", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=1\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"1\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 3, "FAN-DNS-CHECK-B", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=2\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"2\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 4, "FAN-DNS-CHECK-C", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=3\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"3\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 3. DB CRUD lifecycle (4 steps) ---
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 1, "DB-CREATE-TABLE", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":\"CREATE TABLE IF NOT EXISTS e2e_crud (id INT PRIMARY KEY, name VARCHAR(100), status VARCHAR(20))\"}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 2, "DB-INSERT-BATCH", "SMARTS", "COMMON_DB_EXECUTE", "DB-CREATE-TABLE",
                "[{\"DB\":[\"INSERT INTO e2e_crud VALUES (1,'order-001','CREATED')\",\"INSERT INTO e2e_crud VALUES (2,'order-002','CREATED')\",\"INSERT INTO e2e_crud VALUES (3,'order-003','SHIPPED')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 3, "DB-ASSERT-COUNT", "SMARTS", "COMMON_DB_ASSERTIONS", "DB-INSERT-BATCH",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_crud WHERE id=1\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"1\"]},{\"DB\":\"SELECT * FROM e2e_crud WHERE status='SHIPPED'\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"SHIPPED\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 4, "DB-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "DB-ASSERT-COUNT",
                "[{\"DB\":\"DROP TABLE e2e_crud\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 4. DB poll consistency with WAIT_UNTIL (3 steps) ---
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 1, "DB-PREP-DATA", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_poll (id INT, val VARCHAR(50))\",\"INSERT INTO e2e_poll VALUES (1,'pending')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 2, "DB-WAIT-UNTIL", "SMARTS", "COMMON_DB_ASSERTIONS", "DB-PREP-DATA",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_poll WHERE id=1\",\"OP\":\"WAIT_UNTIL\",\"EXPECTED\":[\"1\"],\"TIMEOUT\":10,\"POLL_INTERVAL\":1000}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 3, "DB-POLL-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "DB-WAIT-UNTIL",
                "[{\"DB\":\"DROP TABLE e2e_poll\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 5. Windows CMD multi-command (3 steps) ---
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 1, "WIN-CMD-ECHO", "DATAHUB", "TAP_WINDOWS_CMD", "[]",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo E2E-WIN-START\"]}}]",
                "[{\"STDOUT\":\"E2E-WIN-START\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"E2E-WIN-START\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 2, "WIN-CMD-CHAIN", "DATAHUB", "TAP_WINDOWS_CMD", "WIN-CMD-ECHO",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo chain-step-2\",\"echo done\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"chain-step-2\",\"done\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 3, "WIN-CMD-EXIT", "DATAHUB", "TAP_WINDOWS_CMD", "WIN-CMD-CHAIN",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo exit-check\"]}}]",
                "[{\"CMD\":\"0\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 6. Linux CMD emulate (3 steps) ---
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 1, "LINUX-CMD-ECHO", "DATAHUB", "TAP_LINUX_CMD", "[]",
                "[{\"LINUX-CMD\":{\"cmd\":[\"echo linux-start\"]}}]",
                "[{\"STDOUT\":\"linux-start\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"linux-start\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 2, "LINUX-CMD-CHAIN", "DATAHUB", "TAP_LINUX_CMD", "LINUX-CMD-ECHO",
                "[{\"LINUX-CMD\":{\"cmd\":[\"echo step-2\",\"echo chain-done\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"step-2\",\"chain-done\"]}]",
                "[{\"name\":\"linuxOutput\",\"from\":\"STDOUT\",\"path\":\"\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 3, "LINUX-CMD-CLEANUP", "DATAHUB", "TAP_LINUX_CMD", "LINUX-CMD-CHAIN",
                "[{\"LINUX-CMD\":{\"cmd\":[\"echo cleanup-ok\"]}}]",
                "[{\"STDOUT\":\"cleanup-ok\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"cleanup-ok\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 7. MQ send + verify (3 steps) ---
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 1, "MQ-SEND-MSG", "STP", "SEND_MQ", "[]",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 2, "MQ-VERIFY-STUB", "SMARTS", "COMMON_DB_ASSERTIONS", "MQ-SEND-MSG",
                "[]",
                "[{\"DB\":\"SELECT * FROM dummy WHERE id=1\",\"OP\":\"EXISTS\",\"EXPECTED\":[]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 3, "MQ-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "MQ-VERIFY-STUB",
                "[{\"DB\":\"SELECT 'mq-cleanup-ok'\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 8. SSH remote exec (3 steps) ---
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 1, "SSH-CONNECT-EXEC", "TAP", "TAP_SSH_ALPHA2", "[]",
                "[{\"SSH\":{\"host\":\"${global.ssh_host}\",\"cmd\":[\"echo ssh-ok\"],\"user\":\"${global.ssh_user}\"}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-ok\"]}]",
                "[{\"name\":\"sshResult\",\"from\":\"STDOUT\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 2, "SSH-VERIFY-OUTPUT", "SMARTS", "COMMON_DB_ASSERTIONS", "SSH-CONNECT-EXEC",
                "[]",
                "[{\"DB\":\"SELECT 'ssh-ok' WHERE result='ssh-ok'\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-ok\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 3, "SSH-LOCAL-LOG", "DATAHUB", "TAP_WINDOWS_CMD", "SSH-VERIFY-OUTPUT",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo ssh-log-recorded\"]}}]",
                "[{\"STDOUT\":\"ssh-log-recorded\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-log-recorded\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 9. UI report view (3 steps) ---
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 1, "UI-NAVIGATE-REPORT", "DRP", "DRP_UI_REPORTS", "[]",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"navigate\",\"target\":\"/reports/daily\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[{\"name\":\"uiNavResult\",\"from\":\"JAVA\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 2, "UI-INTERACT-BOOK", "SMARTS", "104_UI_BOOK", "UI-NAVIGATE-REPORT",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"click\",\"target\":\"report-tab-104\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 3, "UI-VERIFY-RESULT", "SMARTS", "COMMON_DB_ASSERTIONS", "UI-INTERACT-BOOK",
                "[]",
                "[{\"DB\":\"SELECT 'OK' WHERE result='OK'\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 10. Order lifecycle flow (5 steps) ---
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 1, "FLOW-HTTP-CREATE", "TAP", "SEND_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"headers\":{\"X-Flow-Id\":\"${global.flow_biz_id}\"}}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"flowHttpStatus\",\"from\":\"HTTP\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 2, "FLOW-DB-VERIFY", "SMARTS", "COMMON_DB_EXECUTE", "FLOW-HTTP-CREATE",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_flow (biz_id VARCHAR(50), status VARCHAR(20))\",\"INSERT INTO e2e_flow VALUES ('${global.flow_biz_id}','HTTP_DONE')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 3, "FLOW-MQ-NOTIFY", "STP", "SEND_MQ", "FLOW-DB-VERIFY",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "CONTINUE", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 4, "FLOW-CMD-LOG", "DATAHUB", "TAP_WINDOWS_CMD", "FLOW-MQ-NOTIFY",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo flow-${global.flow_biz_id}-completed\"]}}]",
                "[{\"STDOUT\":\"${global.flow_biz_id}\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"${global.flow_biz_id}\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 5, "FLOW-DB-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "FLOW-CMD-LOG",
                "[{\"DB\":\"DROP TABLE e2e_flow\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 11. Retry flaky step (3 steps) ---
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 1, "RETRY-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_retry (id INT, attempt INT)\",\"INSERT INTO e2e_retry VALUES (1,0)\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 2, "RETRY-ASSERT-FLAKY", "SMARTS", "COMMON_DB_ASSERTIONS", "RETRY-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_retry WHERE id=1\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]",
                "[]", 10, 2, "RETRY", "Y");
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 3, "RETRY-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "RETRY-ASSERT-FLAKY",
                "[{\"DB\":\"DROP TABLE e2e_retry\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 12. Disabled scenario (3 steps, Enabled=N) ---
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 1, "DISABLED-STEP-1", "TAP", "SEND_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 2, "DISABLED-STEP-2", "SMARTS", "COMMON_DB_EXECUTE", "DISABLED-STEP-1",
                "[{\"DB\":\"SELECT 'should-not-run'\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 3, "DISABLED-STEP-3", "DATAHUB", "TAP_WINDOWS_CMD", "DISABLED-STEP-2",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo should-not-run\"]}}]",
                "[]",                 "[]", 10, 0, "STOP", "Y");

        WriteSheet sheet2 = com.alibaba.excel.EasyExcel.writerSheet(1, "Steps")
                .head(toHead(stepHeader)).build();
        writer.write(stepRows, sheet2);

        // ===== Sheet 3: _GlobalConfig =====
        List<List<Object>> configRows = new ArrayList<>();
        Map<String, String> globalConfig = new LinkedHashMap<>();
        globalConfig.put("http_base_url", "http://www.baidu.com");
        globalConfig.put("http_search_word", "e2e-automation");
        globalConfig.put("test_user_name", "e2e-user");
        globalConfig.put("test_user_pwd", "123123");
        globalConfig.put("flow_biz_id", "MIX-FLOW-001");
        globalConfig.put("ssh_host", "127.0.0.1");
        globalConfig.put("ssh_user", "e2e");
        globalConfig.put("env_timestamp", "${env.TIMESTAMP}");
        globalConfig.forEach((k, v) -> configRows.add(List.of(k, v)));

        WriteSheet sheet3 = com.alibaba.excel.EasyExcel.writerSheet(2, "_GlobalConfig").build();
        writer.write(configRows, sheet3);

        writer.finish();
        System.out.println("[CasesExcelGenerator] 已生成: " + output.toAbsolutePath()
                + " (12 scenarios / " + stepRows.size() + " steps / " + configRows.size() + " globals)");
    }

    // ---- helpers ----

    private static List<Object> row(Object... values) {
        return Arrays.asList(values);
    }

    private static void addStep(List<List<Object>> rows, String scenarioId, int seqNo, String stepId,
                                String app, String action, String dependsOn, String input, String assertJson,
                                String extract, int timeout, int retry, String onFailure, String enabled) {
        rows.add(List.of(scenarioId, seqNo, stepId, app, action, dependsOn,
                input, assertJson, extract, timeout, retry, onFailure, enabled));
    }

    private static List<List<String>> toHead(List<String> headers) {
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        return head;
    }
}
