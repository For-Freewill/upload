package com.e2e.framework.actions.common;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.protocol.HttpApiClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TAP 域：SEND_HTTP_REQUEST —— 发送 HTTP 请求。
 *
 * <p>INPUT 示例：{@code [{"HTTP":{"url":"${global.alpha_taps_url}/get/001","method":"GET",
 * "body":{"user":"123","pwd":"123"}},"headers":{"token":"..."}}]}
 * （游离的 headers 键会被装载期容错并入 HTTP 参数体）
 */
@ActionSpec(apps = {"TAP", "STP"}, action = "SEND_HTTP_REQUEST", description = "发送 HTTP 请求")
public class SendHttpRequestAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        // ① 协议参数
        JSONObject params = context.jsonParams("HTTP");
        String url = params.getString("url");

        // ② 场景级变量读写（EXTRACT，跨步骤传递）
        context.setVar("httpStatusCode", "WWLLL");                    // 写入变量
        //获取上一步的变量
        StepResult stepResult= context.getStepResult("HTTP-GET-BASIC");
        System.out.println("上一步骤的结果是："+stepResult);
//        String prevId = context.getVar("orderId").toString();            // 读取前序步骤写入的变量
//        Integer code = context.getVar("httpCode", Integer.class); // 带类型转换

        //old
        ProtocolPayload payload = context.payload("HTTP");
        if (payload == null) {
            // 模版中 TAP-HTTP 步骤 INPUT 留空：使用默认 URL 发起探测请求
            HttpApiClient.HttpSpec spec = new HttpApiClient.HttpSpec();
            spec.setUrl(context.props().getHttp().getDefaultUrl());
            return doRequest(context, spec);
        }
        JSONObject params2 = payload.paramsAsObject();
        HttpApiClient.HttpSpec spec = new HttpApiClient.HttpSpec();
        String url2 = params.getString("url");
        spec.setUrl(url == null || url.isBlank() ? context.props().getHttp().getDefaultUrl() : url);
        String method = params.getString("method");
        if (method != null && !method.isBlank()) {
            spec.setMethod(method);
        }
        Object headersObj = params.get("headers");
        if (headersObj instanceof JSONObject headers) {
            Map<String, String> headerMap = new LinkedHashMap<>();
            headers.forEach((k, v) -> headerMap.put(k, v == null ? "" : String.valueOf(v)));
            spec.setHeaders(headerMap);
        }
        if (params.containsKey("body")) {
            spec.setBody(params.get("body"));
        }
        return doRequest(context, spec);
    }

    private ActionResult doRequest(ActionContext context, HttpApiClient.HttpSpec spec) {
        HttpApiClient.HttpResult response = context.clients().http().execute(spec);
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("HTTP", response.getStatusCode());
        outputs.put("HTTP_BODY", response.getBody());
        outputs.put("HTTP_HEADERS", response.getHeaders());
        if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
            return ActionResult.ok("HTTP " + spec.getMethod() + " " + spec.getUrl()
                    + " -> " + response.getStatusCode(), outputs);
        }
        return ActionResult.fail("HTTP " + spec.getMethod() + " " + spec.getUrl()
                + " -> " + response.getStatusCode() + " body=" + abbreviate(response.getBody()), outputs);
    }

    private static String abbreviate(String s) {
        if (s == null) {
            return "";
        }
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }
}
