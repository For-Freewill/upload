package com.e2e.framework.ai;

import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.TestDataBundle;

import java.util.List;

/**
 * AI 异常检测器 —— 在数据装载、执行、报告三个阶段检测异常模式。
 *
 * <p>预留接入点：
 * <ul>
 *   <li>数据装载后：检测用例设计缺陷（依赖循环、断言缺失、变量未提取等）；</li>
 *   <li>执行过程中：检测异常模式（集体超时、断言模式一致失败等）；</li>
 *   <li>报告生成时：标注需要人工关注的异常点。</li>
 * </ul>
 */
public interface AiAnomalyDetector {

    /**
     * 检测数据装载阶段的异常。
     *
     * @param bundle 加载完成的用例数据包
     * @return 异常描述列表（空列表 = 无异常）
     */
    List<String> detectDataAnomalies(TestDataBundle bundle);

    /**
     * 基于已知数据质量问题进行智能分类与优先级标注。
     *
     * @param issues 数据质量问题列表
     * @return 每个问题的分类与建议（问题索引 -> 分类描述）
     */
    java.util.Map<Integer, String> classifyIssues(List<DataQualityIssue> issues);
}
