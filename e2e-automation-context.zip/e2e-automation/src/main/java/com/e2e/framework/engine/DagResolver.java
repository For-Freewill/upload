package com.e2e.framework.engine;

import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * DAG 依赖解析 —— 将步骤的 DEPENDS_ON 关系解析为分层执行计划。
 *
 * <p>规则：
 * <ul>
 *   <li>仅启用步骤参与构图（依赖被禁用步骤时降级为根节点并告警）；</li>
 *   <li>引用不存在的步骤（如模版中的跨场景依赖）→ 非严格模式降级为根节点并告警；</li>
 *   <li>层内按 SEQ_NO 升序保证稳定；层间满足全部依赖；</li>
 *   <li>依赖环 → E2EEngineException。</li>
 * </ul>
 */
@Component
public class DagResolver {

    private static final Logger log = LoggerFactory.getLogger(DagResolver.class);

    /**
     * @param issues 数据质量问题输出（孤儿依赖、禁用依赖等）
     * @return 分层执行计划（每层内的步骤可并行执行）
     */
    public List<List<StepDefinition>> resolve(ScenarioDefinition scenario, List<DataQualityIssue> issues) {
        List<StepDefinition> steps = scenario.getSteps().stream()
                .filter(StepDefinition::isEnabled)
                .collect(Collectors.toList());
        List<List<StepDefinition>> levels = new ArrayList<>();

        Set<String> definedIds = steps.stream().map(StepDefinition::getStepId)
                .collect(Collectors.toCollection(LinkedHashSet::new));
        Set<String> allIds = scenario.getSteps().stream().map(StepDefinition::getStepId)
                .collect(Collectors.toCollection(LinkedHashSet::new));

        // 依赖清洗
        java.util.Map<String, Set<String>> deps = new java.util.LinkedHashMap<>();
        for (StepDefinition step : steps) {
            Set<String> valid = new LinkedHashSet<>();
            for (String dep : step.getDependsOn()) {
                if (definedIds.contains(dep)) {
                    valid.add(dep);
                } else if (allIds.contains(dep)) {
                    issues.add(new DataQualityIssue("DAG", scenario.getScenarioId(), step.getStepId(), "DEPENDS_ON",
                            "依赖的步骤 " + dep + " 已被禁用(ENABLED=N)", "该依赖降级为根节点"));
                } else {
                    issues.add(new DataQualityIssue("DAG", scenario.getScenarioId(), step.getStepId(), "DEPENDS_ON",
                            "依赖的步骤 " + dep + " 不在本场景内（模版存在跨场景依赖引用）", "该依赖降级为根节点"));
                    log.warn("[{}] 步骤 {} 的依赖 {} 不在本场景内，已降级为根节点",
                            scenario.getScenarioId(), step.getStepId(), dep);
                }
            }
            deps.put(step.getStepId(), valid);
        }

        // Kahn 分层
        Set<String> remaining = new LinkedHashSet<>(definedIds);
        Set<String> completed = new HashSet<>();
        while (!remaining.isEmpty()) {
            List<StepDefinition> level = new ArrayList<>();
            for (StepDefinition step : steps) {
                if (remaining.contains(step.getStepId()) && completed.containsAll(deps.get(step.getStepId()))) {
                    level.add(step);
                }
            }
            if (level.isEmpty()) {
                throw new E2EEngineException("场景 " + scenario.getScenarioId() + " 存在依赖环: " + remaining
                        + "（请检查 DEPENDS_ON 列）");
            }
            level.sort(java.util.Comparator.comparingInt(StepDefinition::getSeqNo));
            for (StepDefinition step : level) {
                remaining.remove(step.getStepId());
                completed.add(step.getStepId());
            }
            levels.add(level);
        }

        if (log.isDebugEnabled()) {
            log.debug("[{}] DAG 解析: {} 层 -> {}", scenario.getScenarioId(), levels.size(),
                    levels.stream().map(l -> l.stream().map(StepDefinition::getStepId).toList()).toList());
        }
        return levels;
    }
}
