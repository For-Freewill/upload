package com.e2e.framework.protocol;

/** 命令执行统一结果（SSH / 本地 CMD 共用） */
public class CommandResult {

    private final int exitCode;
    private final String stdout;
    private final String stderr;

    public CommandResult(int exitCode, String stdout, String stderr) {
        this.exitCode = exitCode;
        this.stdout = stdout == null ? "" : stdout;
        this.stderr = stderr == null ? "" : stderr;
    }

    public int getExitCode() { return exitCode; }
    public String getStdout() { return stdout; }
    public String getStderr() { return stderr; }

    @Override
    public String toString() {
        return "exit=" + exitCode + " stdout=" + abbrev(stdout) + (stderr.isBlank() ? "" : " stderr=" + abbrev(stderr));
    }

    private static String abbrev(String s) {
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
