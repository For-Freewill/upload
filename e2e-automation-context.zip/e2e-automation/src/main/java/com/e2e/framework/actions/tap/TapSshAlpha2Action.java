package com.e2e.framework.actions.tap;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.SshCommandClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * TAP 域：TAP_SSH_ALPHA2 —— 通过 SSH 在 alpha2 环境执行远程命令。
 *
 * <p>INPUT 支持 SSH 载荷（host/group/body）；兼容模版中混用 HTTP 载荷的情况
 * （取其 url/host 作为目标地址），载荷协议宽容是模版数据的实际现状。
 */
@ActionSpec(apps = {"TAP"}, action = "TAP_SSH_ALPHA2", description = "SSH 到 alpha2 执行远程命令（兼容 SSH/HTTP 载荷）")
public class TapSshAlpha2Action implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload ssh = context.payload("SSH");
        ProtocolPayload http = context.payload("HTTP");
        if (ssh == null && http == null) {
            return ActionResult.fail("TAP_SSH_ALPHA2 需要 SSH 或 HTTP 协议载荷（host/url 字段）");
        }
        JSONObject params = (ssh != null ? ssh : http).paramsAsObject();

        SshCommandClient.SshSpec spec = new SshCommandClient.SshSpec();
        String host = textOf(params, "host", "url", "server");
        if (host != null) {
            spec.setHost(stripScheme(host));
        } else {
            spec.setHost("alpha2");
        }
        String user = params.getString("user");
        if (user != null && !user.isBlank()) {
            spec.setUser(user);
        }
        List<String> commands = new ArrayList<>();
        Object bodyObj = params.get("body");
        if (bodyObj instanceof JSONObject body) {
            body.forEach((k, v) -> commands.add(k + "=" + String.valueOf(v)));
        } else if (bodyObj instanceof String s) {
            commands.add(s);
        }
        Object cmdObj = params.get("cmd");
        if (cmdObj instanceof JSONArray cmdArr) {
            for (Object n : cmdArr) {
                commands.add(String.valueOf(n));
            }
        }
        if (commands.isEmpty()) {
            commands.add("echo e2e-tap-ssh-alpha2");
        }
        spec.setCommands(commands);

        CommandResult result = context.clients().ssh().run(spec);
        Map<String, Object> outputs = Map.of(
                "SSH", result.getExitCode(),
                "STDOUT", result.getStdout());
        if (result.getExitCode() == 0) {
            return ActionResult.ok("SSH " + spec.getHost() + " 执行 " + commands.size() + " 条命令成功", outputs);
        }
        return ActionResult.fail("SSH " + spec.getHost() + " 失败 exit=" + result.getExitCode()
                + " stderr=" + result.getStderr(), outputs);
    }

    private static String textOf(JSONObject obj, String... keys) {
        for (String k : keys) {
            Object v = obj.get(k);
            if (v instanceof String s && !s.isBlank()) {
                return s;
            }
        }
        return null;
    }

    private static String stripScheme(String url) {
        String s = url.replaceFirst("^https?://", "");
        int slash = s.indexOf('/');
        return slash > 0 ? s.substring(0, slash) : s;
    }
}
