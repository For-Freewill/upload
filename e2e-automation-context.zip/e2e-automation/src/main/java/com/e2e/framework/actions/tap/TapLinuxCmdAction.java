package com.e2e.framework.actions.tap;

import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

/**
 * DATAHUB 域：TAP_LINUX_CMD —— 执行 Linux 命令。
 *
 * <p>优先消费 LINUX-CMD 载荷；兼容模版中 LINUX 步骤实际携带 WINDOWS-CMD 载荷的数据现状
 * （host=local 时按本地命令 dry-run 执行，语义由载荷协议字段决定）。
 */
@ActionSpec(apps = {"DATAHUB"}, action = "TAP_LINUX_CMD",
        description = "执行 Linux 命令（LINUX-CMD 载荷，兼容 WINDOWS-CMD 载荷透传）")
public class TapLinuxCmdAction extends TapWindowsCmdAction {

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("LINUX-CMD");
        if (payload == null) {
            // 模版数据兼容：LINUX 步骤可能携带 WINDOWS-CMD 载荷
            payload = context.payload("WINDOWS-CMD");
        }
        if (payload == null) {
            return ActionResult.fail("TAP_LINUX_CMD 需要 LINUX-CMD（或 WINDOWS-CMD）协议载荷");
        }
        return executeCmd(context, payload.paramsAsObject(), false);
    }
}
