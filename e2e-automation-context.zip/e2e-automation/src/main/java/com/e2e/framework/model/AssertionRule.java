package com.e2e.framework.model;

import java.util.List;

/**
 * 断言规则 —— ASSERT 列 JSON 数组中的对象，如
 * {"DB":"SELECT ...","OP":"EQ","EXPECTED":["1"]}。
 *
 * <p>source 指明断言数据来源协议：
 * <ul>
 *   <li>DB —— 规则自带 SQL，由断言引擎直接查询并比对（模版中的主要用法）；</li>
 *   <li>OUTPUT / HTTP / SSH 等非 DB 来源 —— 从当前步骤 action 的 outputs 中按键取值比对。</li>
 * </ul>
 *
 * <p>异步轮询断言（配合 awaitility）：
 * 设置 {@code OP="WAIT_UNTIL"} + {@code TIMEOUT=30} + {@code POLL_INTERVAL=1000}，
 * 引擎会在 timeout 内每隔 pollInterval 重新查询/取值，直到断言通过或超时。
 * 适用于 MQ 异步消费、DB 最终一致性、HTTP 异步回调等场景。
 */
public class AssertionRule {

    private final String source;
    private final String target;
    private final String op;
    private final List<String> expected;
    private final String raw;
    private final int timeoutSeconds;      // 异步轮询超时（秒），仅 WAIT_UNTIL 生效
    private final long pollIntervalMs;     // 轮询间隔（毫秒），仅 WAIT_UNTIL 生效

    public AssertionRule(String source, String target, String op, List<String> expected, String raw) {
        this(source, target, op, expected, raw, 0, 0);
    }

    public AssertionRule(String source, String target, String op, List<String> expected, String raw,
                         int timeoutSeconds, long pollIntervalMs) {
        this.source = source;
        this.target = target;
        this.op = op == null || op.isBlank() ? "EQ" : op.toUpperCase();
        this.expected = expected == null ? List.of() : expected;
        this.raw = raw;
        this.timeoutSeconds = timeoutSeconds;
        this.pollIntervalMs = pollIntervalMs;
    }

    public String getSource() { return source; }
    public String getTarget() { return target; }
    public String getOp() { return op; }
    public List<String> getExpected() { return expected; }
    public String getRaw() { return raw == null ? "" : raw; }
    public int getTimeoutSeconds() { return timeoutSeconds; }
    public long getPollIntervalMs() { return pollIntervalMs; }

    /** 是否为异步轮询断言 */
    public boolean isAsync() {
        return "WAIT_UNTIL".equals(op) || "POLL_UNTIL".equals(op);
    }

    @Override
    public String toString() { return source + "[" + op + "] " + target; }
}
