package com.e2e.framework.model;

/**
 * 提取规则 —— EXTRACT 列 JSON 数组中的对象，将步骤输出提取为场景级变量，
 * 供下游步骤通过 ${extract.name} 引用。
 *
 * <p>格式约定（scenarios.yml 示例中有完整演示）：
 * <pre>[{"name":"acctNo","from":"DB","path":"rows[0].ACCT_NO"}]</pre>
 * <ul>
 *   <li>name —— 提取后的变量名；</li>
 *   <li>from —— 取值来源（DB/OUTPUT 等，对应 action 输出的 key）；</li>
 *   <li>path —— 简化路径：rows[0].ACCT_NO 表示 outputs.DB[0].ACCT_NO。</li>
 * </ul>
 */
public class ExtractRule {

    private final String name;
    private final String from;
    private final String path;
    private final String raw;

    public ExtractRule(String name, String from, String path, String raw) {
        this.name = name;
        this.from = from;
        this.path = path;
        this.raw = raw;
    }

    public String getName() { return name; }
    public String getFrom() { return from; }
    public String getPath() { return path; }
    public String getRaw() { return raw == null ? "" : raw; }

    @Override
    public String toString() { return name + " <- " + from + "." + path; }
}
