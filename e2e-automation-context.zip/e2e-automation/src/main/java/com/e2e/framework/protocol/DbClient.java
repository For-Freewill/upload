package com.e2e.framework.protocol;

import java.util.List;
import java.util.Map;

/** DB 协议客户端（COMMON_DB_ASSERTIONS / COMMON_DB_EXECUTE 使用） */
public interface DbClient {

    /** 执行查询，返回行列表（列名 -> 值） */
    List<Map<String, Object>> query(String sql);

    /** 批量执行（DDL/DML），返回每条语句的影响行数 */
    int[] execute(List<String> sqls);

    String describe();
}
