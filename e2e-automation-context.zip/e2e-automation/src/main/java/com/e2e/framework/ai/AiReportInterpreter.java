package com.e2e.framework.ai;

import com.e2e.framework.model.results.ScenarioResult;

import java.util.List;

/**
 * AI 测试报告解读器 —— 对执行结果进行智能分析与总结。
 *
 * <p>预留接入点：在 ReportWriter 生成报告后调用，产出人类可读的执行摘要、
 * 失败根因分析、趋势洞察等。
 */
public interface AiReportInterpreter {

    /**
     * 生成执行摘要报告（自然语言）。
     *
     * @param results 全部场景执行结果
     * @return 摘要文本（Markdown 格式，含通过率、失败根因、建议行动项）
     */
    String summarize(List<ScenarioResult> results);

    /**
     * 对失败场景进行根因分析。
     *
     * @param failedResults 失败的场景结果列表
     * @return 每个失败场景的根因分析（场景 ID -> 分析文本）
     */
    java.util.Map<String, String> analyzeFailures(List<ScenarioResult> failedResults);
}
