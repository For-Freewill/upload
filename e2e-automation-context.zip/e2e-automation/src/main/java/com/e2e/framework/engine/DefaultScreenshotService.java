package com.e2e.framework.engine;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.ui.PlaywrightUiEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 截图证据实现 —— Playwright 优先 + 占位兜底。
 *
 * <ul>
 *   <li>live 模式且存在活动 Playwright 页面：全页 PNG 截图（真实页面证据）；</li>
 *   <li>其余场景：写入证据占位文件（保留失败上下文与接入说明）。</li>
 * </ul>
 */
@Component
public class DefaultScreenshotService implements ScreenshotService {

    private static final Logger log = LoggerFactory.getLogger(DefaultScreenshotService.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private final E2EProperties props;
    private final PlaywrightUiEngine uiEngine;

    public DefaultScreenshotService(E2EProperties props, PlaywrightUiEngine uiEngine) {
        this.props = props;
        this.uiEngine = uiEngine;
    }

    @Override
    public String capture(String scenarioId, String stepId) {
        // 1. Playwright 活动页面 -> 真实截图
        String shot = uiEngine.captureIfActive(scenarioId, stepId);
        if (shot != null) {
            return shot;
        }
        // 2. 兜底：证据占位文件
        String file = scenarioId + "_" + stepId + "_" + LocalDateTime.now().format(TS) + ".evidence.txt";
        Path dir = Paths.get(props.getReport().getOutputDir(), "screenshots");
        try {
            Files.createDirectories(dir);
            Path path = dir.resolve(file);
            Files.writeString(path, """
                    E2E 失败证据占位文件（无活动 Playwright 页面时的兜底）
                    scenario: %s
                    step:     %s
                    time:     %s
                    说明: live 模式下 UI 步骤失败时，若存在 Playwright 活动页面会自动留存全页 PNG 截图；
                    非 UI 场景可实现 ScreenshotService 并 @Primary 注册，留存接口报文/日志等证据。
                    """.formatted(scenarioId, stepId, LocalDateTime.now()), StandardCharsets.UTF_8);
            return path.toString();
        } catch (IOException e) {
            log.warn("截图证据写入失败: {}", e.getMessage());
            return dir.resolve(file).toString();
        }
    }
}
