package com.e2e.framework.actions.common;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.ui.UiAction;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.AppAction;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JAVA 协议 UI 单点操作通用骨架 —— 子类只需提供业务名称与 @ActionSpec 注册信息。
 *
 * <p>INPUT 中 url 字段指向 {@code UiActionRegistry} 的注册名（@UiHandler），
 * params 透传给 UI 处理器；处理器返回的变量进入步骤 outputs（可断言、可 EXTRACT）。
 */
public abstract class AbstractUiAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("JAVA");
        if (payload == null) {
            return ActionResult.fail("需要 JAVA 协议载荷: [{\"JAVA\":{\"url\":\"处理器注册名\",\"params\":\"...\"}}]");
        }
        JSONObject params = payload.paramsAsObject();
        String handlerName = params.getString("url");
        if (handlerName == null || handlerName.isBlank()) {
            return ActionResult.fail("JAVA 载荷缺少 url 字段（UI 处理器注册名）");
        }
        Object rawParamsObj = params.get("params");
        String rawParams = rawParamsObj == null ? ""
                : (rawParamsObj instanceof String s ? s : JSON.toJSONString(rawParamsObj));

        UiAction handler = context.clients().ui().lookup(handlerName);
        if (handler == null) {
            return ActionResult.fail("未注册的 UI 处理器: '" + handlerName + "'。已注册: "
                    + context.clients().ui().describe()
                    + "。注册方式：实现 UiAction 并标注 @UiHandler(\"" + handlerName + "\")");
        }
        Map<String, Object> handlerOutputs = handler.execute(rawParams);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("JAVA", "OK");
        outputs.putAll(handlerOutputs);
        return ActionResult.ok(businessName() + " 通过 UI 处理器 '" + handlerName + "' 完成, params=" + rawParams, outputs);
    }

    protected abstract String businessName();
}
