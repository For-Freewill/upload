package com.e2e.framework.model.results;

/** 场景执行状态 */
public enum ScenarioStatus {
    PASSED, FAILED, SKIPPED, TIMEOUT, ERROR
}
