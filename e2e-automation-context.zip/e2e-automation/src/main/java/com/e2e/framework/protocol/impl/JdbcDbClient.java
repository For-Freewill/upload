package com.e2e.framework.protocol.impl;

import com.e2e.framework.protocol.DbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DB live 实现 ②（原生 JDBC 方式，e2e.db.driver=jdbc 默认启用）。
 *
 * <p>不依赖任何 ORM / JdbcTemplate：直接 {@code DataSource.getConnection()} +
 * {@link PreparedStatement} 手写执行，结果集按 {@link ResultSetMetaData} 列名映射为
 * {@code List<Map>}（{@link LinkedHashMap} 保持列序）。适合需要完全掌控 SQL 执行细节的场景。
 *
 * <p>批量执行采用「单连接 + 显式事务」：全部成功才 commit，任一失败整体 rollback，
 * 保证数据准备/清理语句的原子性（部分数据库的 DDL 会隐式提交，属库级语义）。
 */
public class JdbcDbClient implements DbClient {

    private static final Logger log = LoggerFactory.getLogger(JdbcDbClient.class);

    private final DataSource dataSource;

    public JdbcDbClient(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public List<Map<String, Object>> query(String sql) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Map<String, Object>> rows = new ArrayList<>();
            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>(columnCount * 2);
                for (int c = 1; c <= columnCount; c++) {
                    // 保留 JDBC 原生类型（与断言引擎的字符串化比对兼容）
                    row.put(meta.getColumnLabel(c), rs.getObject(c));
                }
                rows.add(row);
            }
            log.debug("[native-jdbc] query -> {} rows: {}", rows.size(), abbreviate(sql));
            return rows;
        } catch (SQLException e) {
            throw new IllegalStateException("原生 JDBC 查询失败: " + abbreviate(sql) + " -> " + e.getMessage(), e);
        }
    }

    @Override
    public int[] execute(List<String> sqls) {
        if (sqls == null || sqls.isEmpty()) {
            return new int[0];
        }
        int[] counts = new int[sqls.size()];
        try (Connection conn = dataSource.getConnection()) {
            boolean originalAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);
            try {
                for (int i = 0; i < sqls.size(); i++) {
                    try (PreparedStatement ps = conn.prepareStatement(sqls.get(i))) {
                        counts[i] = ps.executeUpdate();
                        log.debug("[native-jdbc] execute -> {} rows: {}", counts[i], abbreviate(sqls.get(i)));
                    }
                }
                conn.commit();
                return counts;
            } catch (SQLException batchFailure) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackFailure) {
                    batchFailure.addSuppressed(rollbackFailure);
                }
                throw batchFailure;
            } finally {
                conn.setAutoCommit(originalAutoCommit);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("原生 JDBC 批量执行失败（已回滚）: " + e.getMessage(), e);
        }
    }

    @Override
    public String describe() {
        return "jdbc(native-PreparedStatement):" + dataSource;
    }

    private static String abbreviate(String sql) {
        String s = sql.replaceAll("\\s+", " ").trim();
        return s.length() > 120 ? s.substring(0, 120) + "..." : s;
    }
}
