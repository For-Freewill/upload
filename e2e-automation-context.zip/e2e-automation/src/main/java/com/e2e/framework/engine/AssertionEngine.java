package com.e2e.framework.engine;

import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.protocol.DbClient;
import org.awaitility.Awaitility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 断言引擎 —— 统一评估步骤 ASSERT 列的规则。
 *
 * <p>数据来源：
 * <ul>
 *   <li>DB：规则自带 SQL，引擎直接查询，取结果集第一列的值列表作为 actual；</li>
 *   <li>OUTPUT / HTTP / SSH / CMD / UI 等：从当前步骤 action 的 outputs 中按键取 actual。</li>
 * </ul>
 *
 * <p>比较语义（集合语义，忽略行序）：
 * EQ/NE/CONTAINS/NOT_CONTAINS/EMPTY/NOT_EMPTY/SIZE/GT/GTE/LT/LTE/REGEX/EXISTS。
 *
 * <p>异步轮询断言（awaitility）：
 * OP=WAIT_UNTIL 时在 timeout 内每隔 pollInterval 重新取值，直到断言通过或超时。
 * 适用于 MQ 异步消费、DB 最终一致性、HTTP 异步回调等场景。
 */
@Component
public class AssertionEngine {

    private static final Logger log = LoggerFactory.getLogger(AssertionEngine.class);

    /**
     * @param outputs action 输出（DB 断言的查询结果会回写到 outputs 供 EXTRACT 使用）
     * @throws AssertionFailureException 断言失败（带实际值与期望值差异详情）
     */
    public void evaluate(List<AssertionRule> rules, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        for (AssertionRule rule : rules) {
            if (rule.isAsync()) {
                evaluateAsync(rule, outputs, ctx);
            } else {
                List<String> actual = loadActual(rule, outputs, ctx);
                evaluateRule(rule, actual);
            }
            log.info("    断言通过: {} [{}] actual={} expected={}", rule.getSource(), rule.getOp(),
                    abbreviate(rule.getSource(), outputs), rule.getExpected());
        }
    }

    /** 异步轮询断言：使用 awaitility 在 timeout 内反复取值直到断言通过 */
    private void evaluateAsync(AssertionRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        int timeoutSec = rule.getTimeoutSeconds() > 0 ? rule.getTimeoutSeconds() : 30;
        long pollMs = rule.getPollIntervalMs() > 0 ? rule.getPollIntervalMs() : 1000;
        log.info("    异步断言开始轮询: {} [{}] timeout={}s pollInterval={}ms",
                rule.getSource(), rule.getOp(), timeoutSec, pollMs);

        Awaitility.await()
                .atMost(timeoutSec, TimeUnit.SECONDS)
                .pollDelay(0, TimeUnit.MILLISECONDS)
                .pollInterval(pollMs, TimeUnit.MILLISECONDS)
                .untilAsserted(() -> {
                    // ThrowingRunnable 语义：断言通过则正常返回，失败则抛出 AssertionFailureException
                    List<String> actual = loadActual(rule, outputs, ctx);
                    evaluateRule(rule, actual);
                });
    }

    private List<String> loadActual(AssertionRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        if ("DB".equalsIgnoreCase(rule.getSource())) {
            DbClient db = ctx.clients().db();
            List<Map<String, Object>> rows = db.query(rule.getTarget());
            List<String> actual = new ArrayList<>();
            for (Map<String, Object> row : rows) {
                if (!row.isEmpty()) {
                    Object first = row.values().iterator().next();
                    actual.add(first == null ? null : String.valueOf(first));
                }
            }
            // 回写查询结果供 EXTRACT 引用（from=DB）
            outputs.putIfAbsent("DB", rows);
            outputs.putIfAbsent("DB_ROWS", rows);
            return actual;
        }
        // 非 DB 来源：从 outputs 取
        Object value = outputs.get(rule.getSource());
        List<String> actual = new ArrayList<>();
        if (value == null) {
            return actual;
        }
        if (value instanceof List<?> list) {
            for (Object o : list) {
                actual.add(o == null ? null : String.valueOf(o));
            }
        } else {
            actual.add(String.valueOf(value));
        }
        return actual;
    }

    private void evaluateRule(AssertionRule rule, List<String> actual) {
        String op = rule.getOp();
        List<String> expected = rule.getExpected();
        switch (op) {
            case "EQ" -> requireEqual(rule, actual, expected);
            case "NE" -> {
                if (sortedCopy(actual).equals(sortedCopy(expected))) {
                    fail(rule, actual, "实际值与期望值不应相等");
                }
            }
            case "CONTAINS" -> {
                for (String e : expected) {
                    boolean found = actual.stream().anyMatch(a -> a != null && a.contains(e));
                    if (!found) {
                        fail(rule, actual, "缺少期望值: " + e);
                    }
                }
            }
            case "NOT_CONTAINS" -> {
                for (String e : expected) {
                    boolean found = actual.stream().anyMatch(a -> a != null && a.contains(e));
                    if (found) {
                        fail(rule, actual, "出现了不应出现的值: " + e);
                    }
                }
            }
            case "EMPTY" -> {
                if (!actual.isEmpty()) {
                    fail(rule, actual, "期望结果为空");
                }
            }
            case "NOT_EMPTY" -> {
                if (actual.isEmpty()) {
                    fail(rule, actual, "期望结果非空");
                }
            }
            case "SIZE", "GT", "GTE", "LT", "LTE" -> compareSize(rule, actual, op, expected);
            case "REGEX" -> {
                if (expected.isEmpty()) {
                    fail(rule, actual, "REGEX 断言缺少期望表达式");
                }
                boolean matched = actual.stream().anyMatch(a -> a != null && a.matches(expected.get(0)));
                if (!matched) {
                    fail(rule, actual, "无任何值匹配正则: " + expected.get(0));
                }
            }
            case "EXISTS" -> {
                if (actual.isEmpty()) {
                    fail(rule, actual, "期望存在值");
                }
            }
            case "WAIT_UNTIL", "POLL_UNTIL" -> {
                // 异步轮询的同步化评估（awaitility 已经在外层反复调用此方法）
                if (actual.isEmpty() && !expected.isEmpty()) {
                    fail(rule, actual, "轮询条件未满足: 实际为空");
                }
                if (!expected.isEmpty() && !actual.containsAll(expected)) {
                    fail(rule, actual, "轮询条件未满足: 缺少期望值 " + expected);
                }
            }
            default -> fail(rule, actual, "不支持的断言操作符: " + op
                    + "（支持 EQ/NE/CONTAINS/NOT_CONTAINS/EMPTY/NOT_EMPTY/SIZE/GT/GTE/LT/LTE/REGEX/EXISTS/WAIT_UNTIL）");
        }
    }

    private void compareSize(AssertionRule rule, List<String> actual, String op, List<String> expected) {
        if (expected.isEmpty()) {
            fail(rule, actual, op + " 断言缺少期望值");
        }
        int expectedSize;
        try {
            expectedSize = Integer.parseInt(expected.get(0).trim());
        } catch (NumberFormatException e) {
            fail(rule, actual, "期望值不是数字: " + expected.get(0));
            return;
        }
        int actualSize = actual.size();
        boolean ok = switch (op) {
            case "SIZE" -> actualSize == expectedSize;
            case "GT" -> actualSize > expectedSize;
            case "GTE" -> actualSize >= expectedSize;
            case "LT" -> actualSize < expectedSize;
            case "LTE" -> actualSize <= expectedSize;
            default -> false;
        };
        if (!ok) {
            fail(rule, actual, "实际条数 " + actualSize + " 不满足 " + op + " " + expectedSize);
        }
    }

    private void requireEqual(AssertionRule rule, List<String> actual, List<String> expected) {
        if (!sortedCopy(actual).equals(sortedCopy(expected))) {
            fail(rule, actual, "实际值 " + actual + " != 期望值 " + expected);
        }
    }

    private List<String> sortedCopy(List<String> list) {
        List<String> copy = new ArrayList<>();
        for (String s : list) {
            copy.add(s == null ? "<null>" : s);
        }
        copy.sort(String::compareTo);
        return copy;
    }

    private String abbreviate(String source, Map<String, Object> outputs) {
        Object v = outputs.get(source);
        String s = Objects.toString(v, "");
        return s.length() > 80 ? s.substring(0, 80) + "..." : s;
    }

    private void fail(AssertionRule rule, List<String> actual, String reason) {
        throw new AssertionFailureException("断言失败 [" + rule.getSource() + " " + rule.getOp() + "] "
                + reason + "\n  规则原文: " + rule.getRaw());
    }

    /** 断言失败（含差异详情） */
    public static class AssertionFailureException extends RuntimeException {
        public AssertionFailureException(String message) { super(message); }
    }
}
