package com.e2e.framework.test;

import com.e2e.framework.config.E2EProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * TestNG 场景级失败重试分析器。
 *
 * <p>当 E2E 场景失败时，按 {@code e2e.retry.scenario-retry-count} 配置自动重试。
 * 适用于偶发性失败（网络抖动、MQ 延迟、DB 锁竞争等），避免 CI 误报。
 *
 * <p>启用方式：在 {@link E2ETestRunner#runScenario()} 的 @Test 注解中设置
 * {@code retryAnalyzer = E2EScenarioRetryAnalyzer.class}，并配置
 * {@code e2e.retry.scenario-retry-count=1}（默认 0=不重试）。
 */
public class E2EScenarioRetryAnalyzer implements IRetryAnalyzer {

    private static final Logger log = LoggerFactory.getLogger(E2EScenarioRetryAnalyzer.class);

    private int retryCount = 0;

    @Override
    public boolean retry(ITestResult result) {
        E2EProperties props = E2ESpringBootstrap.getInstance().getBean(E2EProperties.class);
        int maxRetry = props.getRetry().getScenarioRetryCount();

        if (retryCount < maxRetry) {
            retryCount++;
            long delay = props.getRetry().getScenarioRetryDelayMs();
            log.warn("[{}] 场景失败，准备第 {} 次重试（共允许 {} 次，延迟 {}ms）。上次失败: {}",
                    result.getName(), retryCount, maxRetry, delay,
                    result.getThrowable() != null ? result.getThrowable().getMessage() : "N/A");
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            return true;
        }
        return false;
    }
}
