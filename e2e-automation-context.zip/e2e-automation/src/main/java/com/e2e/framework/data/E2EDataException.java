package com.e2e.framework.data;

/** 数据装载失败（严格模式下数据质量问题直接终止） */
public class E2EDataException extends RuntimeException {
    public E2EDataException(String message) { super(message); }
    public E2EDataException(String message, Throwable cause) { super(message, cause); }
}
