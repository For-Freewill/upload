# E2E Test Automation Framework

> A data-driven end-to-end test automation framework built on Java 17 + Spring Boot 4 + TestNG 7, designed around the principle of **data-driven test cases + pluggable action registration**.

## Overview

This framework fully decouples test case data from execution code: complete test scenarios are described in Excel templates (Scenarios / Steps / _GlobalConfig sheets), and adding new test cases requires only adding data rows — zero code changes. Each APP domain's single-point operations (ACTIONs) are auto-registered via the `@ActionSpec` annotation, making it trivial to add new APPs and actions.

### Core Capabilities

| Feature | Description |
|---|---|
| Data-Driven | Excel/YAML dual data sources; Scenarios + Steps + GlobalConfig sheets describe complete test cases |
| Action SPI | `@ActionSpec(apps, action)` + `AppAction` interface; Spring auto-scans and registers |
| DAG Scheduling | DEPENDS_ON dependency graph with layered topological sort; supports intra-layer parallelism |
| Scenario Context | `ScenarioExecutionContext` manages variable storage, step history, and cross-step variable passing within scenario lifetime |
| Timeout & Retry | Step-level timeout + retry (RETRY column / ON_FAILURE=RETRY) + scenario-level TestNG IRetryAnalyzer |
| Failure Strategy | STOP / CONTINUE / SCREENSHOT / RETRY / SAVE_EVIDENCE — five modes |
| Async Assertions | Awaitility-based WAIT_UNTIL polling — for MQ async consumption / DB eventual consistency |
| Variable Engine | `${global.}` / `${extract.}` / `${env.}` placeholder substitution |
| Protocol Layer | DB(JDBC + MyBatis-Plus) / HTTP(REST Assured) / MQ / SSH(JSch) / CMD / UI(Playwright) |
| Demo/Live Dual Mode | Demo mode with built-in stubs runs out-of-the-box; live mode switches to real protocol connections |
| AI Hooks | TestCaseGenerator / ReportInterpreter / StepOptimizer / AnomalyDetector — four SPI extension points |
| Reporting | HTML + JSON reports with pie chart, summary table, DAG diagrams, step details, data quality hints |

### Technology Stack

| Component | Technology | Version |
|---|---|---|
| Runtime | Java | 17 |
| Framework | Spring Boot | 4.1.1 |
| Testing | TestNG | 7.12.0 |
| Excel | EasyExcel | 4.0.3 |
| JSON | fastjson2 | 2.0.65 |
| HTTP | REST Assured | 5.5.7 |
| UI | Playwright | 1.63.0 |
| Database | MyBatis-Plus / Native JDBC | 3.5.17 |
| SSH | JSch | 2.28.8 |
| Async | Awaitility | 4.3.0 |

---

## Quick Start

### Prerequisites
- JDK 17+
- Maven 3.9+

### Three Ways to Run

#### Option 1: IDE Right-Click Run (Recommended for Testers)

Open `E2ETestRunner.java` in your IDE (IntelliJ IDEA / Eclipse), right-click → Run:

```
File location: src/test/java/com/e2e/test/E2ETestRunner.java
```

This automatically executes the `main()` method:
1. Bootstraps Spring context
2. Loads all enabled scenarios (default from `classpath:cases/E2E-Test-Scenarios.xlsx`)
3. Executes each scenario
4. Generates `test-output/test_report.html`
5. Prints summary to console (passed/failed/skipped/duration)

#### Option 2: Maven Command Line

```bash
# Full suite (includes Excel generator + tests + DB driver verification)
mvn clean test

# Run E2ETestRunner only (standalone entry, bypasses testng.xml)
mvn exec:java -Dexec.mainClass=com.e2e.test.E2ETestRunner -Dexec.classpathScope=test

# Specify external Excel data source
mvn clean test -De2e.data.excel.path=file:C:/my-test-cases.xlsx

# Switch to YAML data source
mvn clean test -De2e.data.source=yaml

# Switch to live mode (real protocol connections)
mvn clean test -De2e.mode=live \
        -De2e.db.mode=LIVE \
        -De2e.db.driver=mybatis-plus \
        -Dspring.datasource.url="jdbc:h2:mem:test;DB_CLOSE_DELAY=-1" \
        -Dspring.datasource.driver-class-name=org.h2.Driver
```

#### Option 3: Command Line Direct Execution

```bash
# Compile then run directly
mvn clean test-compile
java -cp target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DforceStdout) \
     com.e2e.test.E2ETestRunner
```

### Generate Excel Test Case File

```bash
# Generate E2E-Test-Scenarios.xlsx (14 scenarios / 52 steps / 8 global variables)
mvn test -Dsurefire.suiteXmlFiles=testng-gen.xml

# Output: src/test/resources/cases/E2E-Test-Scenarios.xlsx
```

### Generate Global Scenario DAG Report

```bash
# Generate Global_Scenarios_Dag_Report.html (topology DAG only, no test execution)
mvn test -Dsurefire.suiteXmlFiles=testng-global-dag.xml

# Output: test-output/Global_Scenarios_Dag_Report.html
```

This report loads scenario definitions directly from Excel and renders a DAG topology diagram for each scenario (nodes=seq-APP, edges=dependency arrows), useful for previewing all scenario dependency structures before execution.

### Report Files

| Report File | Generated When | Content |
|---|---|---|
| `test-output/test_report.html` | When tests are executed | Sidebar navigation + summary table + pie chart + DAG diagrams + step details |
| `test-output/test_report.json` | When tests are executed | JSON format complete results |
| `test-output/Global_Scenarios_Dag_Report.html` | When global-dag is run separately | All scenarios' topology DAG (card layout, APP-domain colored) |

---

## ScenarioExecutionContext

### Overview

`ScenarioExecutionContext` is the complete shared state during scenario execution. Its lifecycle is tied to a single scenario execution — created when the scenario starts, garbage-collected when it ends. Contexts from different scenarios are completely isolated and cannot share data.

### Architecture

```
ScenarioExecutor.doExecute()
  │
  ├── Create ScenarioExecutionContext (scenario-scoped, lifecycle = scenario execution)
  │     │
  │     ├── Variable Storage extractVars (ConcurrentHashMap)
  │     │     └── Step A → ctx.putExtract("x", value)  ← write variable
  │     │     └── Step B → ${extract.x} reference         ← read variable
  │     │
  │     ├── Step History stepHistory (ConcurrentHashMap<stepId, StepResult>)
  │     │     └── After each step → ctx.recordStepResult(result)
  │     │     └── Subsequent steps → ctx.getStepResult(stepId)
  │     │
  │     ├── Step Timeline stepStartTimes
  │     │     └── ctx.markStepStart(stepId)
  │     │
  │     ├── Abort Control aborted (volatile)
  │     │     └── STOP strategy → ctx.abort() → subsequent steps auto-skipped
  │     │
  │     └── Lifecycle startTime / endTime
  │           └── ctx.markEnd() → scenario ends, context eligible for GC
  │
  └── GC collected (different scenario contexts fully isolated)
```

### Using Context in Actions

Actions access the full `ScenarioExecutionContext` via `ActionContext`:

```java
@Override
public ActionResult execute(ActionContext ctx) {
    // ① Protocol parameters
    JSONObject params = ctx.jsonParams("HTTP");
    String url = params.getString("url");

    // ② Scenario-level variable read/write (EXTRACT, cross-step passing)
    ctx.setVar("orderId", "123");                    // write variable
    String prevId = ctx.getVar("orderId");            // read variable from previous step
    Integer code = ctx.getVar("httpCode", Integer.class); // with type conversion

    // ③ Previous step queries
    StepResult prev = ctx.getStepResult("HTTP-POST-SEND");       // get previous step result
    Object status = ctx.getStepOutput("HTTP-POST-SEND", "status"); // get previous step output
    boolean done = ctx.isStepCompleted("DB-INSERT-LOG");          // check if previous step passed

    // ④ Protocol clients
    ctx.clients().http().execute(spec);
    ctx.clients().db().query(sql);

    // ⑤ Return result (outputs available for ASSERT / EXTRACT)
    return ActionResult.ok("Success", Map.of("status", 200));
}
```

### Variable Flow Example

```
┌─────────────────────────────────────────────────────────────────┐
│ ScenarioExecutionContext (scenario-scoped, alive during execution) │
│                                                                 │
│  Step 1: TAP:SEND_HTTP_REQUEST                                  │
│    → ctx.setVar("httpStatus", 200)           ← Action writes    │
│    → return ActionResult.ok(outputs={"status":200})            │
│    → ctx.recordStepResult(result)             ← Engine records  │
│                                                                 │
│  Step 2: SMARTS:COMMON_DB_EXECUTE (depends on Step 1)          │
│    → INPUT ${extract.httpStatus} → "200"     ← Variable engine  │
│    → ctx.getStepOutput("STEP-1", "status") → 200  ← Query output │
│    → ctx.isStepCompleted("STEP-1") → true       ← Check status   │
│                                                                 │
│  Step 3: SMARTS:COMMON_DB_ASSERTIONS (depends on Step 2)       │
│    → ctx.getVar("httpStatus") → 200           ← Variable visible  │
│    → ASSERT: DB SELECT ... OP=EQ EXPECTED=["200"]              │
│                                                                 │
│  Scenario ends → ctx.markEnd() → context GC collected           │
└─────────────────────────────────────────────────────────────────┘
```

### Lifecycle Guarantees

- Each Scenario creates an **independent** `ScenarioExecutionContext` in `doExecute()`
- `ctx.markEnd()` is called when execution completes, then GC collects it
- **Different Scenario contexts are fully isolated** — no cross-scenario data leakage
- Thread-safe: `ConcurrentHashMap` + `volatile`, supports DAG intra-layer parallel step writes

### ScenarioExecutionContext API Reference

| Method | Purpose |
|---|---|
| `ctx.putExtract(name, value)` | Write EXTRACT variable |
| `ctx.getExtract(name)` | Read EXTRACT variable |
| `ctx.getExtractVars()` | Get all variables (read-only) |
| `ctx.markStepStart(stepId)` | Record step start time |
| `ctx.recordStepResult(result)` | Record step result to history |
| `ctx.getStepResult(stepId)` | Query previous step result |
| `ctx.isStepCompleted(stepId)` | Check if previous step passed |
| `ctx.getStepOutput(stepId, key)` | Get previous step output value |
| `ctx.getStepHistory()` | Get all step history (read-only) |
| `ctx.isAborted()` / `ctx.abort()` | Abort control |
| `ctx.markEnd()` | Mark scenario end |
| `ctx.summarize()` | Generate context summary |

---

## Adding New APPs and Actions

### Three Simple Steps

```java
// Step 1: Implement AppAction interface + annotate with @ActionSpec
@Component
@ActionSpec(apps = {"NEWAPP"}, action = "NEW_OPERATION",
            description = "New APP single-point operation")
public class NewAppOperationAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext ctx) {
        // Get protocol parameters
        JSONObject params = ctx.jsonParams("HTTP");
        if (params == null) {
            return ActionResult.fail("Missing HTTP protocol payload");
        }

        // Read/write scenario-level variables
        ctx.setVar("requestUrl", params.getString("url"));

        // Call protocol client
        HttpResult result = ctx.clients().http().execute(spec);

        // Return result
        return ActionResult.ok("Operation succeeded",
                Map.of("status", result.getStatusCode()));
    }
}
```

```text
Step 2: Add a row in the Excel Steps sheet
Scenario_ID | SEQ_NO | STEP_ID | APP    | ACTION        | DEPENDS_ON | INPUT                              | ...
E2E-NEW-001 | 1      | STEP-1 | NEWAPP | NEW_OPERATION | []         | [{"HTTP":{"url":"...","method":"GET"}}] | ...

Step 3: Run
mvn clean test
# Or IDE right-click E2ETestRunner → Run
```

### ActionContext API Reference

| Method | Purpose |
|---|---|
| `ctx.jsonParams("HTTP")` | Get HTTP protocol params as JSONObject (null if missing) |
| `ctx.requireJsonParams("DB")` | Get DB params (throws descriptive error if missing) |
| `ctx.paramStr("HTTP", "url")` | Get a string value from protocol params |
| `ctx.setVar("key", value)` | **Write scenario-level variable** (for subsequent steps ${extract.key}) |
| `ctx.getVar("key")` | **Read scenario-level variable** (written by previous steps) |
| `ctx.getVar("key", Type.class)` | Read variable (with type conversion) |
| `ctx.getStepResult("stepId")` | **Query previous step execution result** |
| `ctx.getStepOutput("stepId", "key")` | **Get previous step output value** |
| `ctx.isStepCompleted("stepId")` | **Check if previous step passed** |
| `ctx.scenarioContext()` | Get underlying ScenarioExecutionContext (advanced API) |
| `ctx.clients().http()` | Get HTTP client |
| `ctx.clients().db()` | Get DB client |
| `ctx.clients().ssh()` | Get SSH client |
| `ctx.clients().cmd()` | Get local command client |
| `ctx.props()` | Get framework configuration |

### Built-in Action Index

| APP | ACTION | Description |
|---|---|---|
| TAP / STP | SEND_HTTP_REQUEST | Send HTTP request |
| SMARTS | COMMON_DB_EXECUTE | Execute SQL (data setup/cleanup) |
| SMARTS / TMS / DNS | COMMON_DB_ASSERTIONS | DB assertion (driven by ASSERT column) |
| DATAHUB | TAP_WINDOWS_CMD | Windows local command execution |
| DATAHUB | TAP_LINUX_CMD | Linux command execution |
| TAP | TAP_SSH_ALPHA2 | SSH remote command execution |
| STP | SEND_MQ | Send MQ message |
| DRP | DRP_UI_REPORTS | UI report browsing (Playwright) |
| SMARTS | 104_UI_BOOK / 109_UPLOAD | UI interaction operations |

---

## Data-Driven Format

### Scenarios Sheet

| Seq | Scenario_ID | Scenario_Name | Enabled | Tags | Env | Timeout | Description | Owner |
|---|---|---|---|---|---|---|---|---|
| 1 | E2E-CASE-HTTP-001 | HTTP Test | Y | http;smoke | demo | 120 | Verify HTTP requests | e2e-team |

### Steps Sheet

| Scenario_ID | SEQ_NO | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

### ASSERT Column Format

```json
[
  {"DB": "SELECT * FROM orders WHERE id=1", "OP": "EQ", "EXPECTED": ["1"]},
  {"HTTP": "status", "OP": "CONTAINS", "EXPECTED": ["200"]},
  {"DB": "SELECT COUNT(*) FROM x", "OP": "WAIT_UNTIL", "EXPECTED": ["1"], "TIMEOUT": 30, "POLL_INTERVAL": 2000}
]
```

Supported operators: EQ / NE / CONTAINS / NOT_CONTAINS / EMPTY / NOT_EMPTY / SIZE / GT / GTE / LT / LTE / REGEX / EXISTS / WAIT_UNTIL

### EXTRACT Column Format

```json
[{"name": "orderId", "from": "HTTP", "path": "status"}]
```

### Variable Engine

| Placeholder | Source |
|---|---|
| `${global.x}` | _GlobalConfig sheet |
| `${extract.x}` | Value extracted by a prior step's EXTRACT rule (or written via `ctx.setVar("x", ...)` in Action) |
| `${env.x}` | Environment variable / `-Dx=...` system property |

---

## Configuration Reference

```yaml
e2e:
  mode: demo              # demo / live
  strict: false            # Strict mode
  data:
    source: excel          # excel / yaml
    excel:
      path: classpath:cases/E2E-Test-Scenarios.xlsx
    yaml:
      path: classpath:cases/scenarios-examples.yml
  executor:
    parallel-threads: 1    # Step parallelism
    step-timeout-default-seconds: 180
  retry:
    scenario-retry-count: 0    # Scenario-level retry count
    step-retry-default: 0      # Step-level default retry
  db:
    mode: AUTO              # AUTO / STUB / LIVE
    driver: jdbc            # jdbc / mybatis-plus
  http:
    default-url: http://localhost:18080/ping
  ui:
    browser: chromium
    headless: true
  ai:
    enabled: false
    provider: noop          # noop / custom / openai
```

---

## Project Structure

```
e2e-automation/
├── pom.xml / testng.xml / testng-gen.xml / testng-global-dag.xml
├── src/main/java/com/e2e/framework/
│   ├── ai/             # AI assistance SPI (4 extension points + NoOp default)
│   ├── registry/       # Action SPI: @ActionSpec + AppAction + ActionRegistry + ActionContext
│   ├── engine/         # DAG scheduling / step execution / ScenarioExecutionContext / assertion engine / screenshots
│   ├── actions/        # Built-in action implementations (11 actions)
│   ├── data/           # Excel/YAML loaders + JSON sanitizer + variable engine
│   ├── protocol/       # Protocol interfaces + impl (demo stubs / live implementations)
│   ├── model/          # Scenario/step/assertion/extract/result models
│   ├── report/         # HTML/JSON report generation (test_report.html)
│   ├── config/         # Spring wiring and properties
│   └── test/           # Test infrastructure (E2ESpringBootstrap / ResultStore / listeners / generators)
├── src/test/java/com/e2e/test/
│   ├── E2ETestRunner.java       # ★ Test entry point (@Factory + main() standalone run)
│   └── GlobalDagReport.java    # ★ Global DAG report generator
├── src/test/resources/
│   ├── cases/          # E2E-Test-Scenarios.xlsx (default test cases) + template reference
│   ├── data/           # MQ message payloads and other data files
│   └── (no application.yml, it's in main/resources)
└── src/main/resources/
    └── application.yml  # Spring configuration
```
