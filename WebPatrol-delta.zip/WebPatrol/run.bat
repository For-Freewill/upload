@echo off
rem ============================================================
rem  frontend-patrol 一键巡检脚本（Windows）
rem  用法:
rem    run.bat            执行巡检（config/sites.xlsx）
rem    run.bat template   仅生成配置模板后退出
rem  依赖: JDK 17+ / Maven（不在 PATH 时请修改下方 MAVEN_HOME）
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"

rem ---- Maven 路径：按本机环境修改 ----
set "MAVEN_HOME=C:\Users\wulei001\tools\apache-maven-3.9.9"
where mvn >nul 2>nul || set "PATH=%MAVEN_HOME%\bin;%PATH%"

where mvn >nul 2>nul || (
    echo [错误] 未找到 Maven，请安装或将 MAVEN_HOME 修改为实际路径。
    pause & exit /b 1
)

set "ARGS=--excel=config/sites.xlsx"
if /i "%~1"=="template" set "ARGS=--gen-template"

call mvn spring-boot:run -Dspring-boot.run.arguments="%ARGS%"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ============================================================
    echo  巡检完成！
    echo   - 历次报告索引: reports\index.html
    echo   - 本次报告目录: reports\ 下最新 patrol-* 文件夹
    echo ============================================================
) else (
    echo ============================================================
    echo  巡检结束（退出码 %RC%，含 FAIL 站点或执行异常）。
    echo   - 历次报告索引: reports\index.html
    echo ============================================================
)
pause
