package com.patrol.judge;

import com.patrol.excel.SiteConfig;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.IssueRecord;
import com.patrol.model.IssueType;
import com.patrol.model.RequestRecord;
import com.patrol.model.Verdict;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 健康判定器：基于嗅探采集的数据，按可配置规则判定页面 PASS / WARN / FAIL。
 *
 * <p>规则（阈值均可按站点在 Excel 覆盖，默认值来自 application.yml）：</p>
 * <ol>
 *  <li>主文档 HTTP 状态 &gt;=400 或导航失败 → FAIL</li>
 *  <li>未捕获 JS 异常数 &gt; jsErrorsMax → FAIL</li>
 *  <li>console error 条数 &gt; consoleErrorsMax → FAIL</li>
 *  <li>后端失败请求数（HTTP&gt;=400 或网络层失败）&gt; failedRequestsMax → FAIL</li>
 *  <li>主文档加载耗时 &gt; loadTimeoutMs → WARN（超时失败则 FAIL）</li>
 *  <li>页面内容命中错误关键词 → FAIL</li>
 * </ol>
 */
@Component
public class HealthJudge {

    /** 一次访问的判定输入（由引擎采集填充） */
    public static class VisitFacts {
        public String url;
        public int mainStatus = -1;      // -1 = 导航失败/无响应
        public long loadMs;
        public List<ConsoleRecord> consoleLogs = new ArrayList<>();
        public List<String> jsErrors = new ArrayList<>();
        public List<RequestRecord> requests = new ArrayList<>();
        public String pageContent;
        public String navigateError;     // 导航阶段抛出的异常信息
    }

    /** 判定结果 */
    public record JudgeResult(Verdict verdict, List<IssueRecord> issues) {
    }

    public JudgeResult judge(SiteConfig cfg, VisitFacts facts) {
        List<IssueRecord> issues = new ArrayList<>();

        // 1. 主文档状态 / 导航失败
        if (facts.navigateError != null) {
            issues.add(new IssueRecord(IssueType.EXPLORE_ERROR, Verdict.FAIL,
                    "页面访问失败: " + truncate(facts.navigateError, 300)));
        } else if (facts.mainStatus < 0) {
            issues.add(new IssueRecord(IssueType.MAIN_DOC_STATUS, Verdict.FAIL,
                    "主文档未返回有效响应（status=" + facts.mainStatus + "）"));
        } else if (facts.mainStatus >= 400) {
            issues.add(new IssueRecord(IssueType.MAIN_DOC_STATUS, Verdict.FAIL,
                    "主文档返回 " + facts.mainStatus));
        }

        // 2. JS 未捕获异常
        long jsErr = facts.jsErrors.size();
        if (jsErr > cfg.getJsErrorsMax()) {
            issues.add(new IssueRecord(IssueType.JS_EXCEPTION, Verdict.FAIL,
                    "未捕获 JS 异常 " + jsErr + " 处（上限 " + cfg.getJsErrorsMax() + "）"));
        }

        // 3. console error
        long consoleErr = facts.consoleLogs.stream().filter(ConsoleRecord::isError).count();
        if (consoleErr > cfg.getConsoleErrorsMax()) {
            issues.add(new IssueRecord(IssueType.CONSOLE_ERROR, Verdict.FAIL,
                    "console error " + consoleErr + " 条（上限 " + cfg.getConsoleErrorsMax() + "）"));
        }

        // 4. 后端失败请求（排除主文档本身，主文档问题已在规则1覆盖）
        long failedReq = facts.requests.stream()
                .filter(RequestRecord::isFailed)
                .filter(r -> !r.isMainDoc())
                .count();
        if (failedReq > cfg.getFailedRequestsMax()) {
            issues.add(new IssueRecord(IssueType.BACKEND_FAILURE, Verdict.FAIL,
                    "后端失败请求 " + failedReq + " 个（上限 " + cfg.getFailedRequestsMax() + "）"));
        }

        // 5. 加载耗时
        if (facts.navigateError == null && facts.mainStatus > 0 && facts.loadMs > cfg.getLoadTimeoutMs()) {
            issues.add(new IssueRecord(IssueType.LOAD_TIMEOUT, Verdict.WARN,
                    "主文档加载 " + facts.loadMs + "ms，超过阈值 " + cfg.getLoadTimeoutMs() + "ms"));
        }

        // 6. 错误关键词
        if (facts.pageContent != null && !cfg.getErrorKeywords().isEmpty()) {
            for (String kw : cfg.getErrorKeywords()) {
                if (kw.isBlank()) continue;
                if (facts.pageContent.contains(kw)) {
                    issues.add(new IssueRecord(IssueType.ERROR_KEYWORD, Verdict.FAIL,
                            "页面内容命中错误关键词「" + kw + "」"));
                    break;
                }
            }
        }

        Verdict verdict = issues.stream()
                .map(IssueRecord::severity)
                .reduce(Verdict.PASS, Verdict::worstOf);
        return new JudgeResult(verdict, issues);
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
