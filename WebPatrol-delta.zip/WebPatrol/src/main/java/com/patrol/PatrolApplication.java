package com.patrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Excel 驱动的前端巡检框架入口（Spring Boot CLI 应用，不启动 Web 容器）。
 *
 * <p><b>IDE 直接运行 / 调试</b>：直接运行本类的 main 即可，无需任何参数——
 * 默认读取 {@code config/sites.xlsx}，路径与全部默认值见 {@code application.yml}；
 * 需要换配置文件或生成模板时，把 {@code --excel=路径} / {@code --gen-template}
 * 作为 Program arguments 传入。断点建议：总编排 {@code PatrolRunner.run()}、
 * 认证 {@code AuthSupport}、探索与动作 {@code PageExplorer} / {@code PageInteractor}。</p>
 *
 * <p>命令行等价入口：{@code run.bat}、{@code mvn spring-boot:run}、
 * {@code java -jar frontend-patrol.jar}，详见 README「运行方式」。</p>
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class PatrolApplication {

    public static void main(String[] args) {
        System.exit(SpringApplication.exit(SpringApplication.run(PatrolApplication.class, args)));
    }
}
