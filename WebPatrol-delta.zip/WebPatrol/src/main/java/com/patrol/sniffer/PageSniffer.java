package com.patrol.sniffer;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Request;
import com.microsoft.playwright.Response;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.RequestRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 页面嗅探器：在单个 Page 上一次性挂载 console / pageError / 网络事件监听，
 * 按访问（visit）维度复位与汇总采集结果。
 *
 * <p>事件监听器只注册一次，跨多次导航复用；每次导航前调用 {@link #beginVisit(String)}，
 * 导航完成后调用 {@link #finishVisit()} 得到该次访问的完整采集数据。</p>
 */
public class PageSniffer {

    private static final Logger log = LoggerFactory.getLogger(PageSniffer.class);

    /**
     * 响应体抓取线程池（守护线程）。{@code Response.body()} 没有超时语义——
     * 外网半断时 4xx 响应的 body 可能永远悬挂，直接调用会拖死巡检 worker，
     * 因此外层用 {@link Future#get(long, TimeUnit)} 限时兜底，超时放弃该片段（证据为尽力而为）。
     */
    private static final ExecutorService SNIPPET_EXECUTOR = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "patrol-snippet-reader");
        t.setDaemon(true);
        return t;
    });
    /** 单个失败响应体片段的抓取超时（毫秒） */
    private static final long SNIPPET_TIMEOUT_MS = 3_000;

    private final Page page;

    // 当前访问的采集容器
    private volatile boolean active = false;
    private final List<ConsoleRecord> consoleLogs = new ArrayList<>();
    private final List<String> jsErrors = new ArrayList<>();
    private final List<RequestRecord> requests = new ArrayList<>();
    /** 进行中的请求: key = url#method -> 发出时刻(nano) */
    private final Map<String, Long> pending = new LinkedHashMap<>();
    /** 失败请求的响应体片段: key = url#method */
    private final Map<String, String> failureSnippets = new LinkedHashMap<>();
    /**
     * 失败响应句柄: key = url#method。
     *
     * <p><b>事件回调内绝不调用 {@code Response.body()}</b>——Playwright 事件监听器运行在
     * 连接的消息分发循环里，嵌套发起 body() 请求会在无后续消息到达时永久阻塞（典型死锁：
     * 外网请求悬挂时首次导航即卡死）。因此监听器只登记句柄，
     * 统一延迟到 {@link #finishVisit()}（分发循环之外）再抓取响应体。</p>
     */
    private final Map<String, Response> failedResponses = new LinkedHashMap<>();

    public PageSniffer(Page page) {
        this.page = page;
        attach();
    }

    private void attach() {
        // 注意：页面导航/销毁竞态时 Playwright 可能向监听器传入 null 载荷
        // （如事件排队期间对象已被 dispose），所有载荷必须先做空检查，绝不让监听器异常炸掉巡检。
        page.onConsoleMessage(msg -> {
            if (!active || msg == null) return;
            synchronized (consoleLogs) {
                consoleLogs.add(new ConsoleRecord(
                        msg.type(), msg.text(), msg.location(), System.currentTimeMillis()));
            }
        });
        page.onPageError(err -> {
            if (!active || err == null) return;
            synchronized (jsErrors) {
                jsErrors.add(err);
            }
        });
        page.onRequest(req -> {
            if (!active || req == null) return;
            String key = keyOf(req);
            synchronized (pending) {
                pending.put(key, System.nanoTime());
            }
        });
        page.onResponse(resp -> {
            if (!active || resp == null) return;
            Request req = resp.request();
            if (req == null) return;
            String key = keyOf(req);
            Long start;
            synchronized (pending) {
                start = pending.remove(key);
            }
            long dur = start == null ? -1 : (System.nanoTime() - start) / 1_000_000;
            synchronized (requests) {
                requests.add(new RequestRecord(req.url(), req.method(), req.resourceType(),
                        resp.status(), null, dur, isMainDoc(req)));
            }
            if (resp.status() >= 400) {
                // 只登记句柄，响应体延迟到 finishVisit() 再抓取（见字段注释）
                synchronized (failedResponses) {
                    failedResponses.putIfAbsent(key, resp);
                }
            }
        });
        page.onRequestFailed(req -> {
            if (!active || req == null) return;
            String key = keyOf(req);
            Long start;
            synchronized (pending) {
                start = pending.remove(key);
            }
            long dur = start == null ? -1 : (System.nanoTime() - start) / 1_000_000;
            synchronized (requests) {
                requests.add(new RequestRecord(req.url(), req.method(), req.resourceType(),
                        -1, req.failure(), dur, isMainDoc(req)));
            }
        });
    }

    private boolean isMainDoc(Request req) {
        try {
            return req.isNavigationRequest() && req.frame() == page.mainFrame();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 抓取本次访问中失败响应（状态码 ≥ 400）的响应体片段。
     *
     * <p>只能在 {@link #finishVisit()}（事件分发循环之外）调用；每个片段限时
     * {@link #SNIPPET_TIMEOUT_MS}，超时 / 重定向 / 无 body / 页面已跳转均静默降级，
     * 绝不阻塞巡检主流程。</p>
     */
    private void drainFailedResponses() {
        synchronized (failedResponses) {
            for (Map.Entry<String, Response> e : failedResponses.entrySet()) {
                Response resp = e.getValue();
                byte[] body;
                try {
                    Future<byte[]> future = SNIPPET_EXECUTOR.submit(resp::body);
                    body = future.get(SNIPPET_TIMEOUT_MS, TimeUnit.MILLISECONDS);
                } catch (TimeoutException te) {
                    log.debug("抓取失败响应体超时放弃: {}", resp.url());
                    continue;
                } catch (Exception ex) {
                    // 重定向 / 无 body 的响应会抛异常，属正常情况
                    log.debug("读取失败响应体失败 {} : {}", resp.url(), ex.getMessage());
                    continue;
                }
                if (body == null || body.length == 0) continue;
                synchronized (failureSnippets) {
                    failureSnippets.putIfAbsent(e.getKey(),
                            new String(body, java.nio.charset.StandardCharsets.UTF_8));
                }
            }
            failedResponses.clear();
        }
    }

    private static String keyOf(Request req) {
        return req.url() + "#" + req.method();
    }

    /** 开始一次新的页面访问，复位采集容器 */
    public void beginVisit() {
        synchronized (consoleLogs) { consoleLogs.clear(); }
        synchronized (jsErrors) { jsErrors.clear(); }
        synchronized (requests) { requests.clear(); }
        synchronized (pending) { pending.clear(); }
        synchronized (failureSnippets) { failureSnippets.clear(); }
        synchronized (failedResponses) { failedResponses.clear(); }
        active = true;
    }

    /** 停止采集（页面关闭前调用） */
    public void stop() {
        active = false;
    }

    public List<ConsoleRecord> consoleLogs() {
        synchronized (consoleLogs) { return new ArrayList<>(consoleLogs); }
    }

    public List<String> jsErrors() {
        synchronized (jsErrors) { return new ArrayList<>(jsErrors); }
    }

    public Map<String, String> failureSnippets() {
        synchronized (failureSnippets) { return new LinkedHashMap<>(failureSnippets); }
    }

    /** 结束一次访问：抓取失败响应体片段、挂起未响应的请求以 -1 状态补录，返回完整请求列表 */
    public List<RequestRecord> finishVisit() {
        active = false;
        // 响应体片段在事件分发循环之外抓取（调用方线程），避免监听器内嵌套 body() 死锁
        drainFailedResponses();
        synchronized (pending) {
            for (Map.Entry<String, Long> e : pending.entrySet()) {
                long dur = (System.nanoTime() - e.getValue()) / 1_000_000;
                String key = e.getKey();
                String url = key.substring(0, key.lastIndexOf('#'));
                String method = key.substring(key.lastIndexOf('#') + 1);
                synchronized (requests) {
                    requests.add(new RequestRecord(url, method, "other",
                            -1, "no-response(pending)", dur, false));
                }
            }
            pending.clear();
        }
        synchronized (requests) { return new ArrayList<>(requests); }
    }
}
