package com.patrol.excel;

/**
 * Excel「页面动作」sheet 中的一条自定义动作配置。
 *
 * <p>用于对指定页面上的元素执行点击等操作（当前支持 CLICK），
 * 点击前可先填充输入框，配合嗅探器完成动作触发的接口 / console 校验。</p>
 */
public class PageActionConfig {

    /** 动作类型（当前仅支持 CLICK） */
    public static final String TYPE_CLICK = "CLICK";

    private String siteName;
    /** 页面匹配：精确 URL、或以 * 结尾的前缀（如 /list*）；空 = 该站点所有页面 */
    private String urlMatch;
    /** 目标元素 CSS 选择器 */
    private String selector;
    /** 点击前填充：selector=value;selector=value */
    private String fills;
    private String actionType = TYPE_CLICK;
    private String description;
    private boolean enabled = true;

    /** URL 是否匹配该动作配置的页面范围 */
    public boolean matchesUrl(String url) {
        if (urlMatch == null || urlMatch.isBlank()) return true;
        String t = urlMatch.trim();
        if (t.endsWith("*")) {
            return url.startsWith(t.substring(0, t.length() - 1));
        }
        return url.equals(t);
    }

    public boolean isClick() {
        return TYPE_CLICK.equalsIgnoreCase(actionType);
    }

    public String getSiteName() { return siteName; }
    public void setSiteName(String siteName) { this.siteName = siteName; }
    public String getUrlMatch() { return urlMatch; }
    public void setUrlMatch(String urlMatch) { this.urlMatch = urlMatch; }
    public String getSelector() { return selector; }
    public void setSelector(String selector) { this.selector = selector; }
    public String getFills() { return fills; }
    public void setFills(String fills) { this.fills = fills; }
    public String getActionType() { return actionType; }
    public void setActionType(String actionType) { this.actionType = actionType; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    @Override
    public String toString() {
        return "PageAction{" + siteName + " " + urlMatch + " " + actionType + " " + selector + "}";
    }
}
