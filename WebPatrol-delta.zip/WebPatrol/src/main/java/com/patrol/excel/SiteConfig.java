package com.patrol.excel;

import java.util.List;

/**
 * 单个巡检站点的完整配置（对应 sites.xlsx 中一行，已合并全局默认值）。
 */
public class SiteConfig {

    private String siteName;
    private String entryUrl;
    private boolean enabled = true;

    /**
     * 认证方式：
     * NONE  —— 匿名访问
     * BASIC —— HTTP Basic（用户名/密码）
     * FORM  —— 表单登录（选择器自动填装提交），登录态可缓存复用
     * TOKEN —— 自定义请求头注入 Token
     * MANUAL —— 有头浏览器打开登录页，人工手动完成登录（含验证码/短信等任意方式），
     *           登录态保存 storageState 并跨巡检缓存复用
     * SSO   —— 与 MANUAL 相同的人工登录流程（适用于 SSO 统一认证跳转场景）
     */
    private String authType = "NONE";

    // ---- BASIC ----
    private String username;
    private String password;

    // ---- FORM / MANUAL / SSO 登录 ----
    private String loginUrl;
    private String usernameSelector;
    private String passwordSelector;
    private String submitSelector;
    /** 登录成功后页面应出现的文本，用于校验登录是否成功 */
    private String loginSuccessText;
    /** 登录成功后 URL 应包含的串（与成功文本二选一或配合使用，MANUAL/SSO 常用） */
    private String loginSuccessUrlContains;
    /**
     * 登录成功后浏览器应出现的 Cookie 名（第三种登录成功信号，MANUAL/SSO 常用）。
     * 适用于「登录在页面弹窗内完成、URL 不变化」的站点（如百度登录后种下 BDUSS）。
     */
    private String loginSuccessCookie;
    /** 是否复用缓存的登录状态（FORM/MANUAL/SSO，默认 true） */
    private Boolean reuseLoginState;
    /** MANUAL/SSO 手动登录最长等待秒数 */
    private Integer manualLoginTimeoutSec;

    // ---- TOKEN（注入自定义请求头） ----
    private String tokenHeader;
    private String tokenValue;

    // ---- 探索控制 ----
    private int maxPages;
    private int maxDepth;
    /** 额外探索入口（孤立菜单页面等入口页不可达的页面；支持相对路径，作为 depth 0 种子） */
    private List<String> extraEntryUrls = List.of();
    /** 只探索这些路径前缀下的链接（逗号分隔，空 = 不限制） */
    private List<String> pathIncludePrefixes = List.of();
    /** 排除这些路径前缀的链接（逗号分隔） */
    private List<String> pathExcludePrefixes = List.of();
    /** 探索前是否抓取同源 /sitemap.xml 补充孤立页面（空 = 用全局默认） */
    private Boolean sitemapDiscovery;

    // ---- 功能动作巡检 ----
    /** 是否启用动作巡检（空 = 用全局默认） */
    private Boolean enableActions;
    /** 动作模式：QUERY = 只点查询关键词按钮；ALL = 遍历全部按钮型元素（空 = 用全局默认） */
    private String actionMode;
    private Integer maxActionsPerPage;
    /** 查询类按钮文本关键词（空 = 用全局默认） */
    private List<String> queryButtonKeywords = List.of();
    /** 永不点击的确认类按钮关键词（空 = 用全局默认） */
    private List<String> excludedButtonKeywords = List.of();
    /** 对话框类按钮关键词：可点击但自动关闭对话框、不确认（空 = 用全局默认） */
    private List<String> dialogButtonKeywords = List.of();
    /** 下载类按钮关键词：真实执行并记录下载（空 = 用全局默认） */
    private List<String> downloadButtonKeywords = List.of();

    /** 是否为全量按钮遍历模式 */
    public boolean isAllButtonMode() {
        return "ALL".equalsIgnoreCase(actionMode == null ? "" : actionMode);
    }

    // ---- 健康阈值覆盖 ----
    private int consoleErrorsMax;
    private int jsErrorsMax;
    private int failedRequestsMax;
    private int loadTimeoutMs;
    private List<String> errorKeywords = List.of();

    private String notes;

    public boolean isFormAuth() { return "FORM".equalsIgnoreCase(authType); }
    public boolean isBasicAuth() { return "BASIC".equalsIgnoreCase(authType); }
    public boolean isTokenAuth() { return "TOKEN".equalsIgnoreCase(authType); }
    public boolean isManualAuth() {
        return "MANUAL".equalsIgnoreCase(authType) || "SSO".equalsIgnoreCase(authType);
    }

    public String getSiteName() { return siteName; }
    public void setSiteName(String siteName) { this.siteName = siteName; }
    public String getEntryUrl() { return entryUrl; }
    public void setEntryUrl(String entryUrl) { this.entryUrl = entryUrl; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getAuthType() { return authType; }
    public void setAuthType(String authType) { this.authType = authType; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getLoginUrl() { return loginUrl; }
    public void setLoginUrl(String loginUrl) { this.loginUrl = loginUrl; }
    public String getUsernameSelector() { return usernameSelector; }
    public void setUsernameSelector(String usernameSelector) { this.usernameSelector = usernameSelector; }
    public String getPasswordSelector() { return passwordSelector; }
    public void setPasswordSelector(String passwordSelector) { this.passwordSelector = passwordSelector; }
    public String getSubmitSelector() { return submitSelector; }
    public void setSubmitSelector(String submitSelector) { this.submitSelector = submitSelector; }
    public String getLoginSuccessText() { return loginSuccessText; }
    public void setLoginSuccessText(String loginSuccessText) { this.loginSuccessText = loginSuccessText; }
    public String getTokenHeader() { return tokenHeader; }
    public void setTokenHeader(String tokenHeader) { this.tokenHeader = tokenHeader; }
    public String getTokenValue() { return tokenValue; }
    public void setTokenValue(String tokenValue) { this.tokenValue = tokenValue; }
    public int getMaxPages() { return maxPages; }
    public void setMaxPages(int maxPages) { this.maxPages = maxPages; }
    public int getMaxDepth() { return maxDepth; }
    public void setMaxDepth(int maxDepth) { this.maxDepth = maxDepth; }
    public List<String> getPathIncludePrefixes() { return pathIncludePrefixes; }
    public void setPathIncludePrefixes(List<String> pathIncludePrefixes) { this.pathIncludePrefixes = pathIncludePrefixes; }
    public List<String> getPathExcludePrefixes() { return pathExcludePrefixes; }
    public void setPathExcludePrefixes(List<String> pathExcludePrefixes) { this.pathExcludePrefixes = pathExcludePrefixes; }
    public List<String> getExtraEntryUrls() { return extraEntryUrls; }
    public void setExtraEntryUrls(List<String> extraEntryUrls) { this.extraEntryUrls = extraEntryUrls; }
    public Boolean getSitemapDiscovery() { return sitemapDiscovery; }
    public void setSitemapDiscovery(Boolean sitemapDiscovery) { this.sitemapDiscovery = sitemapDiscovery; }
    public int getConsoleErrorsMax() { return consoleErrorsMax; }
    public void setConsoleErrorsMax(int consoleErrorsMax) { this.consoleErrorsMax = consoleErrorsMax; }
    public int getJsErrorsMax() { return jsErrorsMax; }
    public void setJsErrorsMax(int jsErrorsMax) { this.jsErrorsMax = jsErrorsMax; }
    public int getFailedRequestsMax() { return failedRequestsMax; }
    public void setFailedRequestsMax(int failedRequestsMax) { this.failedRequestsMax = failedRequestsMax; }
    public int getLoadTimeoutMs() { return loadTimeoutMs; }
    public void setLoadTimeoutMs(int loadTimeoutMs) { this.loadTimeoutMs = loadTimeoutMs; }
    public List<String> getErrorKeywords() { return errorKeywords; }
    public void setErrorKeywords(List<String> errorKeywords) { this.errorKeywords = errorKeywords; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public String getLoginSuccessUrlContains() { return loginSuccessUrlContains; }
    public void setLoginSuccessUrlContains(String loginSuccessUrlContains) { this.loginSuccessUrlContains = loginSuccessUrlContains; }
    public String getLoginSuccessCookie() { return loginSuccessCookie; }
    public void setLoginSuccessCookie(String loginSuccessCookie) { this.loginSuccessCookie = loginSuccessCookie; }
    public Boolean getReuseLoginState() { return reuseLoginState; }
    public void setReuseLoginState(Boolean reuseLoginState) { this.reuseLoginState = reuseLoginState; }
    public Integer getManualLoginTimeoutSec() { return manualLoginTimeoutSec; }
    public void setManualLoginTimeoutSec(Integer manualLoginTimeoutSec) { this.manualLoginTimeoutSec = manualLoginTimeoutSec; }
    public Boolean getEnableActions() { return enableActions; }
    public String getActionMode() { return actionMode; }
    public void setActionMode(String actionMode) { this.actionMode = actionMode; }
    public void setEnableActions(Boolean enableActions) { this.enableActions = enableActions; }
    public Integer getMaxActionsPerPage() { return maxActionsPerPage; }
    public void setMaxActionsPerPage(Integer maxActionsPerPage) { this.maxActionsPerPage = maxActionsPerPage; }
    public List<String> getQueryButtonKeywords() { return queryButtonKeywords; }
    public void setQueryButtonKeywords(List<String> queryButtonKeywords) { this.queryButtonKeywords = queryButtonKeywords; }
    public List<String> getExcludedButtonKeywords() { return excludedButtonKeywords; }
    public void setExcludedButtonKeywords(List<String> excludedButtonKeywords) { this.excludedButtonKeywords = excludedButtonKeywords; }
    public List<String> getDialogButtonKeywords() { return dialogButtonKeywords; }
    public void setDialogButtonKeywords(List<String> dialogButtonKeywords) { this.dialogButtonKeywords = dialogButtonKeywords; }
    public List<String> getDownloadButtonKeywords() { return downloadButtonKeywords; }
    public void setDownloadButtonKeywords(List<String> downloadButtonKeywords) { this.downloadButtonKeywords = downloadButtonKeywords; }

    @Override
    public String toString() {
        return "SiteConfig{" + siteName + ", " + entryUrl + ", auth=" + authType + ", enabled=" + enabled + '}';
    }
}
