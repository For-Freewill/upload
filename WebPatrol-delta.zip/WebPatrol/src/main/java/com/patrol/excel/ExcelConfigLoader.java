package com.patrol.excel;

import com.alibaba.excel.EasyExcel;
import com.patrol.config.PatrolProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 从 sites.xlsx 读取多站点巡检配置（基于 EasyExcel）。
 *
 * <p>表头支持中文或英文别名，列顺序不限。读取后与全局默认值合并：
 * 单元格留空的阈值/探索参数列自动回落到 application.yml 中的 defaults。</p>
 */
@Component
public class ExcelConfigLoader {

    private static final Logger log = LoggerFactory.getLogger(ExcelConfigLoader.class);

    /** 表头别名映射：canonical -> 中文/英文写法 */
    private static final Map<String, List<String>> ALIASES = Map.ofEntries(
            Map.entry("siteName", List.of("站点名称", "siteName", "站点", "name")),
            Map.entry("entryUrl", List.of("入口URL", "entryUrl", "url", "地址")),
            Map.entry("enabled", List.of("启用", "enabled", "是否启用")),
            Map.entry("authType", List.of("认证方式", "authType", "认证")),
            Map.entry("username", List.of("用户名", "username", "账号")),
            Map.entry("password", List.of("密码", "password")),
            Map.entry("loginUrl", List.of("登录URL", "loginUrl")),
            Map.entry("usernameSelector", List.of("用户名选择器", "usernameSelector")),
            Map.entry("passwordSelector", List.of("密码选择器", "passwordSelector")),
            Map.entry("submitSelector", List.of("提交按钮选择器", "submitSelector")),
            Map.entry("loginSuccessText", List.of("登录成功标识", "loginSuccessText")),
            Map.entry("loginSuccessUrlContains", List.of("登录成功URL包含", "loginSuccessUrlContains")),
            Map.entry("loginSuccessCookie", List.of("登录成功Cookie", "登录成功Cookie包含", "loginSuccessCookie")),
            Map.entry("reuseLoginState", List.of("复用登录状态", "reuseLoginState")),
            Map.entry("manualLoginTimeoutSec", List.of("手动登录超时秒", "manualLoginTimeoutSec", "手动登录超时(秒)")),
            Map.entry("tokenHeader", List.of("Token请求头", "tokenHeader")),
            Map.entry("tokenValue", List.of("Token值", "tokenValue")),
            Map.entry("maxPages", List.of("最大页面数", "maxPages")),
            Map.entry("maxDepth", List.of("最大深度", "maxDepth")),
            Map.entry("extraEntryUrls", List.of("额外入口URL", "extraEntryUrls", "额外探索入口")),
            Map.entry("pathIncludePrefixes", List.of("包含路径前缀", "pathIncludePrefixes")),
            Map.entry("pathExcludePrefixes", List.of("排除路径前缀", "pathExcludePrefixes")),
            Map.entry("sitemapDiscovery", List.of("Sitemap自动发现", "sitemapDiscovery", "Sitemap发现")),
            Map.entry("enableActions", List.of("启用动作巡检", "enableActions")),
            Map.entry("actionMode", List.of("动作模式", "actionMode")),
            Map.entry("maxActionsPerPage", List.of("动作数上限", "maxActionsPerPage")),
            Map.entry("queryButtonKeywords", List.of("查询按钮关键词", "queryButtonKeywords")),
            Map.entry("excludedButtonKeywords", List.of("排除按钮关键词", "excludedButtonKeywords")),
            Map.entry("dialogButtonKeywords", List.of("对话框按钮关键词", "dialogButtonKeywords")),
            Map.entry("downloadButtonKeywords", List.of("下载按钮关键词", "downloadButtonKeywords")),
            Map.entry("consoleErrorsMax", List.of("Console错误上限", "consoleErrorsMax")),
            Map.entry("jsErrorsMax", List.of("JS异常上限", "jsErrorsMax")),
            Map.entry("failedRequestsMax", List.of("失败请求上限", "failedRequestsMax")),
            Map.entry("loadTimeoutMs", List.of("加载超时ms", "loadTimeoutMs", "加载超时(ms)")),
            Map.entry("errorKeywords", List.of("错误关键词", "errorKeywords")),
            Map.entry("notes", List.of("备注", "notes"))
    );

    private final PatrolProperties properties;

    public ExcelConfigLoader(PatrolProperties properties) {
        this.properties = properties;
    }

    /**
     * 加载全部站点配置（含禁用的，调用方自行过滤）。
     *
     * <p>Sites 主表提供核心字段；「站点高级配置」sheet（可选）按站点名称关联，
     * 其中非空的单元格覆盖主表/全局默认值。旧版 33 列宽表仍然兼容。</p>
     */
    public List<SiteConfig> load(Path excelPath) throws Exception {
        if (!Files.exists(excelPath)) {
            throw new IllegalStateException("巡检配置文件不存在: " + excelPath
                    + "（可运行模板生成器 ExcelTemplateGenerator 生成后填写）");
        }
        List<Map<String, String>> mainRows = new ArrayList<>();
        Map<String, Map<String, String>> advancedBySite = new LinkedHashMap<>();
        // 主表：优先读 Sites sheet，不存在时回落第一个 sheet（含表头行的原始行）
        List<Map<Integer, String>> mainSheetRows = readSheetRows(excelPath, List.of("Sites"), true);
        if (mainSheetRows.isEmpty()) {
            throw new IllegalStateException("Excel 中没有可用的配置行: " + excelPath);
        }
        Map<Integer, String> columnKeys = resolveHeaderColumns(mainSheetRows.get(0));
        if (!columnKeys.containsValue("siteName") || !columnKeys.containsValue("entryUrl")) {
            throw new IllegalStateException("Excel 缺少必需列: 站点名称 / 入口URL");
        }
        // 逐行读取主表（首行为表头）
        for (int r = 1; r < mainSheetRows.size(); r++) {
            Map<Integer, String> raw = mainSheetRows.get(r);
            if (isRowBlank(raw, columnKeys)) continue;
            Map<String, String> cells = new LinkedHashMap<>();
            for (Map.Entry<Integer, String> e : columnKeys.entrySet()) {
                String value = raw.get(e.getKey());
                cells.put(e.getValue(), value == null ? "" : value.trim());
            }
            mainRows.add(cells);
        }
        // 读取「站点高级配置」sheet（可选，不存在按空处理）
        List<Map<Integer, String>> advSheetRows = readSheetRows(excelPath, List.of("站点高级配置"), false);
        if (!advSheetRows.isEmpty()) {
            Map<Integer, String> advColumns = resolveHeaderColumns(advSheetRows.get(0));
            for (int r = 1; r < advSheetRows.size(); r++) {
                Map<Integer, String> raw = advSheetRows.get(r);
                if (isRowBlank(raw, advColumns)) continue;
                String advSiteName = "";
                Map<String, String> overrides = new LinkedHashMap<>();
                for (Map.Entry<Integer, String> e : advColumns.entrySet()) {
                    String value = raw.get(e.getKey());
                    value = value == null ? "" : value.trim();
                    if ("siteName".equals(e.getValue())) {
                        advSiteName = value;
                    } else if (!value.isEmpty()) {
                        overrides.put(e.getValue(), value);
                    }
                }
                if (advSiteName.isBlank()) {
                    log.warn("站点高级配置 第 {} 行缺少站点名称，已忽略", r + 1);
                } else if (!overrides.isEmpty()) {
                    advancedBySite.put(advSiteName, overrides);
                }
            }
        }
        if (mainRows.isEmpty()) {
            throw new IllegalStateException("Excel 中未读取到任何站点配置: " + excelPath);
        }

        // 合并高级配置并转换
        List<SiteConfig> sites = new ArrayList<>(mainRows.size());
        Set<String> consumedAdvanced = new LinkedHashSet<>();
        for (int i = 0; i < mainRows.size(); i++) {
            Map<String, String> cells = mainRows.get(i);
            String siteName = cells.getOrDefault("siteName", "");
            Map<String, String> overrides = advancedBySite.get(siteName);
            if (overrides != null) {
                consumedAdvanced.add(siteName);
                // 高级配置非空值优先，主表值作为兜底（覆盖项通常只出现在其中一处）
                Map<String, String> merged = new LinkedHashMap<>(cells);
                for (Map.Entry<String, String> e : overrides.entrySet()) {
                    merged.put(e.getKey(), e.getValue());
                }
                sites.add(toSiteConfig(merged, i + 2));
            } else {
                sites.add(toSiteConfig(cells, i + 2));
            }
        }
        for (String name : advancedBySite.keySet()) {
            if (!consumedAdvanced.contains(name)) {
                log.warn("站点高级配置中的站点 [{}] 在 Sites 表中不存在，已忽略", name);
            }
        }
        log.info("已从 {} 加载 {} 个站点配置（启用 {} 个，高级配置覆盖 {} 个）", excelPath, sites.size(),
                sites.stream().filter(SiteConfig::isEnabled).count(), consumedAdvanced.size());
        return sites;
    }

    /**
     * 读取指定 sheet 的全部原始行（含表头行，headRowNumber=0，单元格以字符串返回）。
     * sheet 不存在 / 无法读取时：fallbackFirstSheet=true 回落第一个 sheet，否则返回空列表。
     */
    private static List<Map<Integer, String>> readSheetRows(Path excelPath, List<String> sheetNames,
                                                            boolean fallbackFirstSheet) {
        for (String name : sheetNames) {
            try {
                return EasyExcel.read(excelPath.toString())
                        .sheet(name)
                        .headRowNumber(0)
                        .doReadSync();
            } catch (Exception e) {
                // 指定名称的 sheet 不存在，尝试下一个候选名
            }
        }
        if (fallbackFirstSheet) {
            try {
                return EasyExcel.read(excelPath.toString())
                        .sheet(0)
                        .headRowNumber(0)
                        .doReadSync();
            } catch (Exception e) {
                log.warn("读取 Excel 第一个 sheet 失败: {}", e.getMessage());
            }
        }
        return List.of();
    }

    /** 解析表头行 -> canonical key 列映射（无法识别的列告警并忽略） */
    private static Map<Integer, String> resolveHeaderColumns(Map<Integer, String> headerRow) {
        Map<Integer, String> columnKeys = new LinkedHashMap<>();
        for (Map.Entry<Integer, String> e : headerRow.entrySet()) {
            String header = e.getValue();
            if (header == null || header.isBlank()) continue;
            String canonical = resolveCanonical(header.trim());
            if (canonical != null) {
                columnKeys.put(e.getKey(), canonical);
            } else {
                log.warn("忽略无法识别的表头列 [{}]（第 {} 列）", header, e.getKey() + 1);
            }
        }
        return columnKeys;
    }
    private SiteConfig toSiteConfig(Map<String, String> cells, int rowNo) {
        SiteConfig s = new SiteConfig();
        s.setSiteName(cells.getOrDefault("siteName", ""));
        s.setEntryUrl(cells.getOrDefault("entryUrl", ""));
        if (s.getSiteName().isBlank() || s.getEntryUrl().isBlank()) {
            throw new IllegalStateException("Excel 第 " + rowNo + " 行缺少 站点名称 或 入口URL");
        }

        String enabled = cells.getOrDefault("enabled", "true");
        s.setEnabled(!("false".equalsIgnoreCase(enabled) || "0".equals(enabled) || "否".equals(enabled)));

        s.setAuthType(cells.getOrDefault("authType", "NONE").toUpperCase());

        s.setUsername(emptyToNull(cells.get("username")));
        s.setPassword(emptyToNull(cells.get("password")));
        s.setLoginUrl(emptyToNull(cells.get("loginUrl")));
        s.setUsernameSelector(emptyToNull(cells.get("usernameSelector")));
        s.setPasswordSelector(emptyToNull(cells.get("passwordSelector")));
        s.setSubmitSelector(emptyToNull(cells.get("submitSelector")));
        s.setLoginSuccessText(emptyToNull(cells.get("loginSuccessText")));
        s.setLoginSuccessUrlContains(emptyToNull(cells.get("loginSuccessUrlContains")));
        s.setLoginSuccessCookie(emptyToNull(cells.get("loginSuccessCookie")));
        s.setReuseLoginState(boolOf(cells.get("reuseLoginState"), true));
        s.setManualLoginTimeoutSec(
                intOrNull(cells.get("manualLoginTimeoutSec")));
        s.setTokenHeader(emptyToNull(cells.get("tokenHeader")));
        s.setTokenValue(emptyToNull(cells.get("tokenValue")));
        s.setNotes(emptyToNull(cells.get("notes")));

        // 认证字段已赋值后再做校验
        validateAuth(s, rowNo);

        // 与全局默认值合并：留空回落 defaults
        PatrolProperties.Defaults d = properties.getDefaults();
        s.setMaxPages(intOf(cells.get("maxPages"), d.getMaxPages()));
        s.setMaxDepth(intOf(cells.get("maxDepth"), d.getMaxDepth()));
        s.setExtraEntryUrls(resolveExtraEntries(splitList(cells.get("extraEntryUrls")), s.getEntryUrl()));
        // 留空回落全局默认（与「站点高级配置全留空 = application.yml 全局默认」契约一致）
        s.setSitemapDiscovery(boolOf(cells.get("sitemapDiscovery"), d.isSitemapDiscovery()));
        s.setConsoleErrorsMax(intOf(cells.get("consoleErrorsMax"), d.getConsoleErrorsMax()));
        s.setJsErrorsMax(intOf(cells.get("jsErrorsMax"), d.getJsErrorsMax()));
        s.setFailedRequestsMax(intOf(cells.get("failedRequestsMax"), d.getFailedRequestsMax()));
        s.setLoadTimeoutMs(intOf(cells.get("loadTimeoutMs"), d.getLoadTimeoutMs()));
        s.setManualLoginTimeoutSec(
                s.getManualLoginTimeoutSec() == null ? d.getManualLoginTimeoutSec() : s.getManualLoginTimeoutSec());

        String kw = cells.get("errorKeywords");
        s.setErrorKeywords(kw == null || kw.isBlank()
                ? splitList(d.getErrorKeywords())
                : splitList(kw));

        // ---- 功能动作巡检 ----
        s.setEnableActions(boolOf(cells.get("enableActions"), d.isEnableActions()));
        String actionMode = cells.get("actionMode");
        s.setActionMode(actionMode == null || actionMode.isBlank()
                ? d.getActionMode() : actionMode.trim().toUpperCase());
        s.setMaxActionsPerPage(intOf(cells.get("maxActionsPerPage"), d.getMaxActionsPerPage()));
        s.setQueryButtonKeywords(cells.get("queryButtonKeywords") == null
                || cells.get("queryButtonKeywords").isBlank()
                ? splitList(d.getQueryButtonKeywords())
                : splitList(cells.get("queryButtonKeywords")));
        s.setExcludedButtonKeywords(cells.get("excludedButtonKeywords") == null
                || cells.get("excludedButtonKeywords").isBlank()
                ? splitList(d.getExcludedButtonKeywords())
                : splitList(cells.get("excludedButtonKeywords")));
        s.setDialogButtonKeywords(cells.get("dialogButtonKeywords") == null
                || cells.get("dialogButtonKeywords").isBlank()
                ? splitList(d.getDialogButtonKeywords())
                : splitList(cells.get("dialogButtonKeywords")));
        s.setDownloadButtonKeywords(cells.get("downloadButtonKeywords") == null
                || cells.get("downloadButtonKeywords").isBlank()
                ? splitList(d.getDownloadButtonKeywords())
                : splitList(cells.get("downloadButtonKeywords")));

        s.setPathIncludePrefixes(splitList(cells.get("pathIncludePrefixes")));
        s.setPathExcludePrefixes(splitList(cells.get("pathExcludePrefixes")));
        return s;
    }

    /**
     * 加载「页面动作」sheet（可选，不存在返回空列表）。
     * 列：站点名称、页面URL匹配、动作类型(CLICK)、元素选择器、填充值、说明、启用
     */
    public List<PageActionConfig> loadPageActions(Path excelPath) throws Exception {
        List<PageActionConfig> actions = new ArrayList<>();
        if (!Files.exists(excelPath)) return actions;
        List<Map<Integer, String>> rows = readSheetRows(excelPath, List.of("页面动作", "PageActions"), false);
        if (rows.size() < 2) return actions;

        Map<String, Integer> headers = new LinkedHashMap<>();
        rows.get(0).forEach((c, h) -> {
            if (h != null && !h.isBlank()) headers.put(h.trim(), c);
        });
        for (int r = 1; r < rows.size(); r++) {
            Map<Integer, String> raw = rows.get(r);
            if (raw == null) continue;
            PageActionConfig a = new PageActionConfig();
            a.setSiteName(cell(headers, raw, "站点名称", "siteName"));
            a.setUrlMatch(cell(headers, raw, "页面URL匹配", "urlMatch"));
            a.setActionType(cell(headers, raw, "动作类型", "actionType"));
            a.setSelector(cell(headers, raw, "元素选择器", "selector"));
            a.setFills(cell(headers, raw, "填充值", "fills"));
            a.setDescription(cell(headers, raw, "说明", "description"));
            String enabled = cell(headers, raw, "启用", "enabled");
            a.setEnabled(enabled == null || enabled.isBlank()
                    || "true".equalsIgnoreCase(enabled) || "1".equals(enabled));
            if (a.getSiteName() == null || a.getSiteName().isBlank()) continue;
            if (a.getActionType() == null || a.getActionType().isBlank()) a.setActionType("CLICK");
            if (!a.isClick()) {
                log.warn("忽略暂不支持的动作类型 [{}]（当前仅支持 CLICK）", a.getActionType());
                continue;
            }
            if (a.getSelector() == null || a.getSelector().isBlank()) {
                log.warn("忽略缺少元素选择器的动作行 {}", a);
                continue;
            }
            actions.add(a);
        }
        if (!actions.isEmpty()) {
            log.info("已加载 {} 条页面自定义动作", actions.size());
        }
        return actions;
    }

    private static String cell(Map<String, Integer> headers, Map<Integer, String> raw, String zh, String en) {
        Integer c = headers.get(zh);
        if (c == null) c = headers.get(en);
        if (c == null) return null;
        String v = raw.get(c);
        return v == null ? null : v.trim();
    }

    private void validateAuth(SiteConfig s, int rowNo) {
        String where = "Excel 第 " + rowNo + " 行 [" + s.getSiteName() + "] ";
        switch (s.getAuthType()) {
            case "BASIC" -> {
                if (isBlank(s.getUsername()) || isBlank(s.getPassword()))
                    throw new IllegalStateException(where + "BASIC 认证需要填写 用户名/密码");
            }
            case "FORM" -> {
                if (isBlank(s.getLoginUrl()) || isBlank(s.getUsernameSelector())
                        || isBlank(s.getPasswordSelector()) || isBlank(s.getSubmitSelector()))
                    throw new IllegalStateException(where + "FORM 认证需要填写 登录URL/用户名选择器/密码选择器/提交按钮选择器");
            }
            case "TOKEN" -> {
                if (isBlank(s.getTokenHeader()) || isBlank(s.getTokenValue()))
                    throw new IllegalStateException(where + "TOKEN 认证需要填写 Token请求头/Token值");
            }
            case "MANUAL", "SSO" -> {
                // 有头浏览器人工登录，登录页可选（默认打开入口URL）
                // 登录完成信号：登录成功标识文本 / 登录成功URL包含 / 登录成功Cookie，至少配置一项，否则只能等超时
                if (isBlank(s.getLoginSuccessText()) && isBlank(s.getLoginSuccessUrlContains())
                        && isBlank(s.getLoginSuccessCookie())) {
                    log.warn("{}MANUAL/SSO 认证建议配置 登录成功标识 / 登录成功URL包含 / 登录成功Cookie 之一，"
                            + "否则将等待手动登录超时({}s)后继续", where,
                            properties.getDefaults().getManualLoginTimeoutSec());
                }
            }
            case "NONE" -> { /* 无需校验 */ }
            default -> throw new IllegalStateException(where + "不支持的认证方式: " + s.getAuthType()
                    + "（支持 NONE/BASIC/FORM/TOKEN/MANUAL/SSO）");
        }
    }

    private static String resolveCanonical(String header) {
        for (Map.Entry<String, List<String>> e : ALIASES.entrySet()) {
            for (String alias : e.getValue()) {
                if (alias.equalsIgnoreCase(header)) return e.getKey();
            }
        }
        return null;
    }

    private static boolean isRowBlank(Map<Integer, String> row, Map<Integer, String> columnKeys) {
        return columnKeys.keySet().stream()
                .map(c -> row.get(c))
                .allMatch(v -> v == null || v.isBlank());
    }

    private static String emptyToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    private static int intOf(String s, int def) {
        if (isBlank(s)) return def;
        try {
            return (int) Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static Integer intOrNull(String s) {
        if (isBlank(s)) return null;
        try {
            return (int) Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static boolean boolOf(String s, boolean def) {
        if (isBlank(s)) return def;
        if ("true".equalsIgnoreCase(s) || "1".equals(s) || "是".equals(s)) return true;
        if ("false".equalsIgnoreCase(s) || "0".equals(s) || "否".equals(s)) return false;
        return def;
    }

    /**
     * 解析额外入口 URL 列表：绝对地址保持不变；相对路径（如 "/tools"、"menus/1"）
     * 基于入口 URL 解析为绝对地址，方便用户只填路径。
     */
    private static List<String> resolveExtraEntries(List<String> extras, String entryUrl) {
        if (extras == null || extras.isEmpty()) return List.of();
        URI base;
        try {
            base = URI.create(entryUrl);
        } catch (IllegalArgumentException e) {
            return extras;
        }
        List<String> out = new ArrayList<>();
        for (String raw : extras) {
            String t = raw == null ? "" : raw.trim();
            if (t.isEmpty()) continue;
            if (t.startsWith("http://") || t.startsWith("https://")) {
                out.add(t);
                continue;
            }
            try {
                String path = t.startsWith("/") ? t : "/" + t;
                out.add(base.resolve(path).toString());
            } catch (IllegalArgumentException e) {
                log.warn("忽略无法解析的额外入口URL [{}]（站点 [{}]）", t, entryUrl);
            }
        }
        return out;
    }

    private static List<String> splitList(String s) {
        if (isBlank(s)) return List.of();
        return Arrays.stream(s.split("[,，;；]"))
                .map(String::trim)
                .filter(x -> !x.isEmpty())
                .toList();
    }
}
