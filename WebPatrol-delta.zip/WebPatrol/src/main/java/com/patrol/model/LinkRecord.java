package com.patrol.model;

/**
 * 页面探索过程中发现的子页面链接记录。
 *
 * <p>记录当前页面上解析到的同源链接（含锚文本），并标注该链接
 * 在本次巡检中是否被实际访问（受深度/页数/前缀过滤限制），
 * 用于在报告中回放「页面 → 子页面」的探索过程。</p>
 */
public record LinkRecord(
        String url,            // 归一化后的链接地址
        String text,           // 锚文本（截断）
        boolean explored,      // 本次巡检是否实际访问了该子页面
        Verdict childVerdict   // 若已访问，子页面的巡检结论；未访问为 null
) {

    public LinkRecord withExplored(boolean explored, Verdict childVerdict) {
        return new LinkRecord(url, text, explored, childVerdict);
    }
}
