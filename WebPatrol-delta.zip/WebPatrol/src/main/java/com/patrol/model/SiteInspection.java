package com.patrol.model;

import java.util.List;

/** 单个站点的一次完整巡检结果 */
public record SiteInspection(
        String siteName,
        String entryUrl,
        String authType,
        String startedAt,
        String finishedAt,
        Verdict verdict,              // 站点级结论：所有页面中的最差结果
        List<PageInspection> pages,
        int linksFound,                // 站内探索发现的链接总数
        String errorMessage) {         // 站点级错误（如登录失败、浏览器异常）

    public int pagesVisited() {
        return pages == null ? 0 : pages.size();
    }

    public long passPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.PASS).count();
    }

    public long warnPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.WARN).count();
    }

    public long failPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.FAIL).count();
    }

    public int totalActions() {
        return pages == null ? 0 : pages.stream().mapToInt(PageInspection::actionCount).sum();
    }

    public long failedActions() {
        return pages == null ? 0 : pages.stream().mapToLong(PageInspection::failedActionCount).sum();
    }
}
