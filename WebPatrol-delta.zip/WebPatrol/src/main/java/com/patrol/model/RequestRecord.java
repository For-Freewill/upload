package com.patrol.model;

/** 单条后端请求记录（由嗅探器采集） */
public record RequestRecord(
        String url,
        String method,
        String resourceType,   // document / xhr / fetch / script / stylesheet / image ...
        int status,            // -1 表示请求失败未收到响应
        String failureText,    // 请求失败原因（net::ERR_xxx），成功时为 null
        long durationMs,       // 请求耗时，未知为 -1
        boolean isMainDoc) {   // 是否为当前页主文档

    /**
     * 该请求是否视为失败（HTTP >= 400 或网络层失败）。
     * <p>注意：net::ERR_ABORTED 是浏览器主动中止（SPA 框架如 Next.js 的 _rsc 预取在导航时会被中止），
     * 属正常行为，不计为失败。</p>
     */
    public boolean isFailed() {
        if (failureText != null && failureText.contains("ERR_ABORTED")) {
            return false;
        }
        return status >= 400 || status < 0;
    }

    /** 是否为被浏览器中止的预取类请求（SPA 正常行为，报告中单独标注） */
    public boolean isAborted() {
        return failureText != null && failureText.contains("ERR_ABORTED");
    }
}
