package com.patrol.model;

/** 整次巡检的汇总统计 */
public record PatrolSummary(
        int totalSites,
        int enabledSites,
        int passSites,
        int warnSites,
        int failSites,
        int totalPages,
        int passPages,
        int warnPages,
        int failPages,
        int totalConsoleErrors,
        int totalJsErrors,
        int totalFailedRequests,
        int totalActions,          // 执行的功能动作总数（按钮点击等）
        int failedActions,         // 结论为 FAIL 的动作数
        long durationMs) {
}
