package com.patrol.model;

import java.util.List;

/**
 * 单个页面动作（如点击查询按钮）的巡检结果。
 *
 * <p>动作期间触发的后端请求、console 日志、JS 异常独立采集，
 * 与页面自身的访问数据分开，用于精确归因「哪个按钮触发了哪些接口异常」。</p>
 */
public record ActionInspection(
        String siteName,
        String pageUrl,
        String actionType,        // AUTO_QUERY_CLICK / ALL_BUTTON_CLICK / CUSTOM_CLICK
        String description,      // 动作描述（如 "点击查询按钮[查询]"）
        String buttonCategory,    // 按钮类别：普通点击 / 弹窗类(不确认) / 下载类 / 自定义
        String selector,         // 点击的元素定位
        List<RequestRecord> requests,     // 动作触发的请求
        List<ConsoleRecord> consoleLogs,  // 动作期间 console 日志
        List<String> jsErrors,
        List<String> downloads,   // 动作触发的下载记录（文件名 <- URL）
        Verdict verdict,
        String screenshotPath,
        String contextPath,
        String errorMessage,     // 点击失败/导航跳转等异常信息
        boolean navigatedAway,   // 是否触发了页面跳转
        boolean skipped          // 是否因元素不可交互（不可见/被遮挡）而跳过，不计入失败
) {

    public long consoleErrorCount() {
        return consoleLogs == null ? 0 : consoleLogs.stream().filter(ConsoleRecord::isError).count();
    }

    public long failedRequestCount() {
        return requests == null ? 0 : requests.stream().filter(RequestRecord::isFailed).count();
    }

    public long jsErrorCount() {
        return jsErrors == null ? 0 : jsErrors.size();
    }
}
