package com.patrol.model;

import java.util.List;

/** 整次巡检报告（多站点聚合） */
public record PatrolReport(
        String startedAt,
        String finishedAt,
        String excelConfigPath,
        String browserInfo,
        List<SiteInspection> sites,
        PatrolSummary summary) {
}
