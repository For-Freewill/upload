package com.patrol.model;

/** 单条 console 日志 */
public record ConsoleRecord(
        String level,      // error / warning / log / info / debug / assert
        String text,
        String location,   // Playwright 返回的 "url:lineNumber" 形式定位
        long timestamp) {

    public boolean isError() {
        return "error".equalsIgnoreCase(level) || "assert".equalsIgnoreCase(level);
    }
}
