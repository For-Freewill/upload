package com.patrol.model;

/** 巡检发现的问题类型 */
public enum IssueType {
    MAIN_DOC_STATUS("主文档状态码异常"),
    EXPLORE_ERROR("页面访问失败"),
    JS_EXCEPTION("JS 运行时异常"),
    CONSOLE_ERROR("Console 错误"),
    BACKEND_FAILURE("后端请求失败"),
    LOAD_TIMEOUT("页面加载超时"),
    ERROR_KEYWORD("页面包含错误关键词"),
    ACTION_FAILURE("功能动作异常");

    private final String label;

    IssueType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
