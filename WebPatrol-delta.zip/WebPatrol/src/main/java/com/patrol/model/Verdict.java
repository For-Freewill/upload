package com.patrol.model;

/** 页面巡检结论 */
public enum Verdict {
    PASS, WARN, FAIL, SKIPPED;

    /** 取更严重的结论：FAIL > WARN > PASS > SKIPPED */
    public Verdict worseThan(Verdict other) {
        return this.ordinal() >= other.ordinal() ? this : other;
    }

    public static Verdict worstOf(Verdict a, Verdict b) {
        return a == null ? b : a.worseThan(b);
    }
}
