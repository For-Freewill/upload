package com.patrol.model;

/** 一条巡检发现的问题 */
public record IssueRecord(
        IssueType type,
        Verdict severity,     // WARN / FAIL
        String message) {
}
