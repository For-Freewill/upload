package com.patrol.model;

import java.util.List;

/** 单个页面的一次巡检结果（含页面访问 + 功能动作两阶段） */
public record PageInspection(
        String siteName,
        String url,               // 计划访问 URL
        String finalUrl,          // 重定向后的实际 URL
        String title,
        int depth,                // 距入口的链接深度
        int mainStatus,           // 主文档 HTTP 状态码，-1 = 导航失败
        long loadMs,              // 主文档加载耗时
        Verdict verdict,          // 页面级结论 = 访问结论与全部动作结论的最差值
        List<IssueRecord> issues,
        List<ConsoleRecord> consoleLogs,   // 页面加载阶段采集
        List<String> jsErrors,
        List<RequestRecord> requests,      // 页面加载阶段采集
        List<ActionInspection> actions,    // 功能动作阶段（查询按钮点击等）
        List<ElementDigest> elements,      // 页面解析出的可交互元素（含处理决策）
        String parentUrl,        // 该页面由哪个页面的链接发现（入口页为 null）
        List<LinkRecord> childLinks,   // 页面上发现的同源子页面链接（含巡检状态）
        String screenshotPath,    // 异常时保存的截图（相对报告目录）
        String contextPath,       // 异常时保存的上下文 JSON（相对报告目录）
        String errorMessage) {    // 访问/探索阶段的异常信息

    /** 探索阶段结束后回填父子关系与子页面链接（record 不可变，返回新实例） */
    public PageInspection withExploration(String parentUrl, List<LinkRecord> childLinks) {
        return new PageInspection(siteName, url, finalUrl, title, depth, mainStatus, loadMs,
                verdict, issues, consoleLogs, jsErrors, requests, actions, elements,
                parentUrl, childLinks, screenshotPath, contextPath, errorMessage);
    }

    /** 已实际巡检的子页面数量 */
    public long exploredChildCount() {
        return childLinks == null ? 0 : childLinks.stream().filter(LinkRecord::explored).count();
    }

    public long consoleErrorCount() {
        return consoleLogs == null ? 0 : consoleLogs.stream().filter(ConsoleRecord::isError).count();
    }

    public long failedRequestCount() {
        return requests == null ? 0 : requests.stream().filter(RequestRecord::isFailed).count();
    }

    public long jsErrorCount() {
        return jsErrors == null ? 0 : jsErrors.size();
    }

    public int actionCount() {
        return actions == null ? 0 : actions.size();
    }

    public long failedActionCount() {
        return actions == null ? 0 : actions.stream().filter(a -> a.verdict() == Verdict.FAIL).count();
    }
}
