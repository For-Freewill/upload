package com.patrol.engine;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitUntilState;
import com.patrol.config.PatrolProperties;
import com.patrol.excel.SiteConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Map;

/**
 * 认证支持：两阶段模型——「预认证（有头）」与「巡检加载（无头）」分离。
 *
 * <h3>阶段一：预认证（preAuthenticate，有头模式）</h3>
 * 巡检开始前统一执行，串行进行（MANUAL/SSO 需要人工在弹出的浏览器窗口中操作）：
 * <ul>
 *  <li>NONE / BASIC / TOKEN —— 无登录流程，直接跳过（凭据在巡检上下文创建时注入）</li>
 *  <li>FORM   —— 有头浏览器中自动填装表单登录，登录成功后导出 storageState</li>
 *  <li>MANUAL —— 弹出有头浏览器，人工手动完成登录（验证码/短信/任意方式）后导出 storageState</li>
 *  <li>SSO    —— 与 MANUAL 相同流程，适用于 SSO 统一认证跳转场景</li>
 * </ul>
 *
 * <h3>阶段二：巡检加载（createContext，无头模式）</h3>
 * 认证通过后，巡检过程全部使用无头浏览器；FORM/MANUAL/SSO 站点直接加载缓存的登录态，
 * 不再执行任何登录动作。
 *
 * <p>登录态缓存到 {@code login-state/<站点>.json}：TTL 有效期内直接复用，无需每次登录；
 * 过期或不存在才在预认证阶段重新登录。</p>
 */
public class AuthSupport {

    private static final Logger log = LoggerFactory.getLogger(AuthSupport.class);

    /**
     * 阶段一：预认证（有头模式，串行执行）。
     * 需要登录的站点（FORM/MANUAL/SSO）在巡检前统一完成登录并保存登录态；
     * 缓存 TTL 内的站点自动跳过。
     *
     * @param playwright    Playwright 实例（用于拉起有头浏览器）
     * @param properties    全局配置
     * @param site          站点配置
     * @param loginStateDir 登录态缓存目录
     */
    public static void preAuthenticate(Playwright playwright, PatrolProperties properties,
                                       SiteConfig site, Path loginStateDir) throws Exception {
        String authType = site.getAuthType() == null ? "NONE" : site.getAuthType().toUpperCase();
        switch (authType) {
            case "FORM", "MANUAL", "SSO" -> {
                Path statePath = statePathOf(site, loginStateDir);
                if (cacheUsable(site, statePath, properties)) {
                    log.info("[{}] 预认证跳过：复用缓存登录态 {}（TTL {} 分钟内）", site.getSiteName(),
                            statePath, properties.getDefaults().getLoginStateTtlMin());
                    return;
                }
                // 有头浏览器执行登录（认证阶段统一有头，便于人工介入与观察）
                BrowserType browserType = browserTypeOf(playwright, properties.getBrowser().getType());
                Browser headful = browserType.launch(new BrowserType.LaunchOptions()
                        .setHeadless(false).setSlowMo(properties.getBrowser().getSlowMoMs()));
                try {
                    if (site.isFormAuth()) {
                        formLogin(headful, properties, site, statePath);
                    } else {
                        manualLogin(headful, properties, site, statePath);
                    }
                } finally {
                    // 限时关闭：登录后浏览器状态复杂（跳转/下载/多窗口），楔死时不阻塞认证流程
                    PlaywrightFactory.closeQuietly("[" + site.getSiteName() + "] 认证浏览器",
                            PlaywrightFactory.INSTANCE_CLOSE_TIMEOUT_MS, headful::close);
                }
            }
            default -> log.info("[{}] 预认证跳过：认证方式 {} 无需登录流程", site.getSiteName(), authType);
        }
    }

    /**
     * 阶段二：为站点创建巡检用浏览器上下文（无头巡检）。
     * FORM/MANUAL/SSO 站点直接加载预认证阶段保存的登录态；缺失时抛出异常（站点判 FAIL）。
     *
     * @param patrolBrowser 巡检用（无头）浏览器实例
     * @param properties    全局配置
     * @param site          站点配置
     * @param loginStateDir 登录态缓存目录（固定目录，跨巡检复用）
     */
    /**
     * 所有浏览器上下文的公共选项：忽略 HTTPS 错误 + 统一 locale。
     * 固定 locale（默认 zh-CN）保证有头认证与无头巡检看到一致的界面语言，
     * 文本类选择器（如「登录」/「Sign in」）不随系统语言漂移。
     */
    private static Browser.NewContextOptions baseContextOptions(PatrolProperties properties) {
        Browser.NewContextOptions options = new Browser.NewContextOptions().setIgnoreHTTPSErrors(true);
        String locale = properties.getBrowser().getLocale();
        if (locale != null && !locale.isBlank()) {
            options.setLocale(locale);
        }
        return options;
    }

    public static BrowserContext createContext(Browser patrolBrowser, PatrolProperties properties,
                                                SiteConfig site, Path loginStateDir) throws Exception {
        Browser.NewContextOptions options = baseContextOptions(properties)
                .setAcceptDownloads(true);
        switch (site.getAuthType().toUpperCase()) {
            case "BASIC" -> options.setHttpCredentials(site.getUsername(), site.getPassword());
            case "TOKEN" -> options.setExtraHTTPHeaders(Map.of(
                    site.getTokenHeader(), site.getTokenValue()));
            case "FORM", "MANUAL", "SSO" -> {
                Path statePath = statePathOf(site, loginStateDir);
                if (!Files.exists(statePath)) {
                    throw new IllegalStateException("登录态缓存缺失（认证方式=" + site.getAuthType()
                            + "）：" + statePath + " —— 预认证阶段未完成或登录失败，请先完成登录认证");
                }
                options.setStorageStatePath(statePath);
                log.info("[{}] 巡检上下文加载缓存登录态: {}", site.getSiteName(), statePath);
            }
            default -> { /* NONE */ }
        }
        BrowserContext context = patrolBrowser.newContext(options);
        log.info("[{}] 已创建无头巡检上下文（认证方式={}）", site.getSiteName(), site.getAuthType());
        return context;
    }

    /** ---------------- 登录态缓存 ---------------- */

    private static Path statePathOf(SiteConfig site, Path loginStateDir) throws Exception {
        Files.createDirectories(loginStateDir);
        return loginStateDir.resolve(sanitize(site.getSiteName()) + ".json");
    }

    /** 登录态缓存是否可直接复用（reuse=false 时永不复用；TTL 过期返回 false） */
    private static boolean cacheUsable(SiteConfig site, Path statePath, PatrolProperties properties) {
        if (site.getReuseLoginState() != null && !site.getReuseLoginState()) {
            log.info("[{}] 配置为不复用登录态，每次重新登录", site.getSiteName());
            return false;
        }
        if (isCacheFresh(statePath, properties.getDefaults().getLoginStateTtlMin())) {
            return true;
        }
        if (Files.exists(statePath)) {
            log.info("[{}] 登录态缓存已过期，重新登录", site.getSiteName());
        }
        return false;
    }

    /** 缓存文件是否存在且未超过 TTL（0 = 永不过期） */
    private static boolean isCacheFresh(Path statePath, int ttlMin) {
        if (!Files.exists(statePath)) return false;
        if (ttlMin <= 0) return true;
        try {
            BasicFileAttributes attrs = Files.readAttributes(statePath, BasicFileAttributes.class);
            return System.currentTimeMillis() - attrs.lastModifiedTime().toMillis()
                    < ttlMin * 60_000L;
        } catch (Exception e) {
            return false;
        }
    }

    /** ---------------- 登录流程（均在有头浏览器中执行） ---------------- */

    /** 表单登录：有头浏览器中自动填装提交，导出 storageState */
    private static void formLogin(Browser browser, PatrolProperties properties,
                                  SiteConfig site, Path statePath) throws Exception {
        log.info("[{}] 执行表单登录（有头模式）: {}", site.getSiteName(), site.getLoginUrl());
        try (BrowserContext loginContext = browser.newContext(
                baseContextOptions(properties))) {
            Page loginPage = loginContext.newPage();
            loginPage.navigate(site.getLoginUrl(), new Page.NavigateOptions()
                    .setTimeout(Math.max(site.getLoadTimeoutMs() * 2L, 30_000L))
                    .setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
            loginPage.fill(site.getUsernameSelector(), site.getUsername());
            loginPage.fill(site.getPasswordSelector(), site.getPassword());
            loginPage.click(site.getSubmitSelector());

            // 等待登录生效：以"成功标识文本"为准，未配置则等待网络空闲
            if (site.getLoginSuccessText() != null && !site.getLoginSuccessText().isBlank()) {
                loginPage.waitForSelector("text=" + site.getLoginSuccessText(),
                        new Page.WaitForSelectorOptions()
                                .setTimeout(Math.max(site.getLoadTimeoutMs() * 2L, 30_000L)));
            } else {
                try {
                    loginPage.waitForLoadState(LoadState.NETWORKIDLE,
                            new Page.WaitForLoadStateOptions().setTimeout(10_000));
                } catch (PlaywrightException ignored) {
                    // 网络未完全空闲时继续，登录态以 cookie 导出为准
                }
            }
            loginContext.storageState(new BrowserContext.StorageStateOptions().setPath(statePath));
            log.info("[{}] 表单登录成功，登录态已缓存: {}", site.getSiteName(), statePath);
        }
    }

    /**
     * MANUAL / SSO 人工登录：弹出有头浏览器，等待人工完成登录（验证码/短信/SSO 跳转均可），
     * 检测到成功信号（登录成功标识文本 / 登录成功URL包含 / 登录成功Cookie）后保存登录态。
     */
    private static void manualLogin(Browser headful, PatrolProperties properties,
                                    SiteConfig site, Path statePath) throws Exception {
        int timeoutSec = site.getManualLoginTimeoutSec() != null
                ? site.getManualLoginTimeoutSec()
                : properties.getDefaults().getManualLoginTimeoutSec();
        String target = site.getLoginUrl() != null ? site.getLoginUrl() : site.getEntryUrl();

        log.info("=============================================================");
        log.info("[{}] MANUAL/SSO 人工登录", site.getSiteName());
        log.info("  >> 即将弹出浏览器窗口，请在其中手动完成登录: {}", target);
        log.info("  >> 登录成功信号：文本「{}」 / URL包含「{}」 / Cookie「{}」",
                site.getLoginSuccessText() == null ? "-" : site.getLoginSuccessText(),
                site.getLoginSuccessUrlContains() == null ? "-" : site.getLoginSuccessUrlContains(),
                site.getLoginSuccessCookie() == null ? "-" : site.getLoginSuccessCookie());
        log.info("  >> 等待最长时间 {} 秒（超时后按当时登录态继续）", timeoutSec);
        log.info("=============================================================");

        try (BrowserContext ctx = headful.newContext(baseContextOptions(properties))) {
            Page page = ctx.newPage();
            page.navigate(target, new Page.NavigateOptions()
                    .setTimeout(60_000L)
                    .setWaitUntil(WaitUntilState.DOMCONTENTLOADED));

            long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
            boolean signaled = false;
            String lastUrl = page.url();
            while (System.currentTimeMillis() < deadline) {
                lastUrl = page.url();
                // 信号 1：URL 包含指定串
                if (site.getLoginSuccessUrlContains() != null
                        && !site.getLoginSuccessUrlContains().isBlank()
                        && lastUrl.contains(site.getLoginSuccessUrlContains())) {
                    signaled = true;
                    break;
                }
                // 信号 2：出现指定 Cookie（如百度 BDUSS）——登录在页面弹窗内完成、URL 不变的站点适用
                if (site.getLoginSuccessCookie() != null && !site.getLoginSuccessCookie().isBlank()) {
                    String cookieName = site.getLoginSuccessCookie().trim();
                    boolean hasCookie = ctx.cookies().stream()
                            .anyMatch(c -> cookieName.equals(c.name));
                    if (hasCookie) {
                        signaled = true;
                        break;
                    }
                }
                // 信号 3：页面出现成功文本
                if (site.getLoginSuccessText() != null && !site.getLoginSuccessText().isBlank()) {
                    try {
                        page.waitForSelector("text=" + site.getLoginSuccessText(),
                                new Page.WaitForSelectorOptions().setTimeout(500));
                        signaled = true;
                        break;
                    } catch (PlaywrightException ignored) {
                        // 未出现，继续等待
                    }
                } else {
                    Thread.sleep(500);
                }
            }
            if (signaled) {
                log.info("[{}] 检测到登录成功信号（当前URL: {}）", site.getSiteName(), lastUrl);
            } else {
                log.warn("[{}] 未在 {} 秒内检测到登录成功信号，按当前登录态保存并继续（如未登录成功请配置 登录成功标识/登录成功URL包含）",
                        site.getSiteName(), timeoutSec);
            }
            ctx.storageState(new BrowserContext.StorageStateOptions().setPath(statePath));
            log.info("[{}] 人工登录态已缓存: {}（TTL {} 分钟内下次巡检免登录）", site.getSiteName(),
                    statePath, properties.getDefaults().getLoginStateTtlMin());
        }
    }

    private static BrowserType browserTypeOf(Playwright playwright, String type) {
        return switch (type == null ? "chromium" : type.toLowerCase()) {
            case "firefox" -> playwright.firefox();
            case "webkit" -> playwright.webkit();
            default -> playwright.chromium();
        };
    }

    static String sanitize(String name) {
        return name.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
    }
}
