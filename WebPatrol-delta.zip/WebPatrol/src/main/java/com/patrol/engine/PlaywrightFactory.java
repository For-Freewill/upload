package com.patrol.engine;

import com.microsoft.playwright.Playwright;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Playwright 实例工厂 + 生命周期工具。
 *
 * <p>新版 Playwright 在 create() 时会自动从官方 CDN 下载整套默认浏览器（速度慢且不必要）。
 * 巡检框架默认通过 {@code PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1} 跳过该行为，
 * 浏览器由用户显式安装（见 README：CLI install chromium）。
 * 若 {@code patrol.browser.auto-download=true} 则放行自动下载。</p>
 */
public final class PlaywrightFactory {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightFactory.class);

    private PlaywrightFactory() {
    }

    /** 页面关闭限时（毫秒） */
    public static final long PAGE_CLOSE_TIMEOUT_MS = 10_000;
    /** 浏览器 / Playwright 实例关闭限时（毫秒） */
    public static final long INSTANCE_CLOSE_TIMEOUT_MS = 15_000;

    /**
     * 关闭兜底线程池（守护线程）：关闭调用在其上执行，由调用方限时等待。
     * 超时后被放弃的关闭调用线程会残留为守护线程，随 JVM 退出，不影响主流程。
     */
    private static final ExecutorService CLOSE_POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "patrol-close-guard");
        t.setDaemon(true);
        return t;
    });

    public static Playwright create(boolean autoDownload) {
        Map<String, String> env = new HashMap<>();
        if (!autoDownload) {
            env.put("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        }
        // 若外部设置了镜像下载源，传递给 driver
        String host = System.getenv("PLAYWRIGHT_DOWNLOAD_HOST");
        if (host != null && !host.isBlank()) {
            env.put("PLAYWRIGHT_DOWNLOAD_HOST", host);
        }
        return Playwright.create(new Playwright.CreateOptions().setEnv(env));
    }

    /**
     * 限时关闭任意 Playwright 资源（page / browser / context / Playwright 实例）。
     *
     * <p><b>为什么必须限时</b>：Playwright 的关闭类调用（{@code page.close()} /
     * {@code browser.close()} / {@code Playwright.close()} 均为无超时的同步往返——
     * 当 driver 或浏览器楔死（悬挂外网 TCP、浏览器进程异常、会话失效重定向的怪异状态等）时，
     * 调用方会永久阻塞，巡检无法完成、报告无法产出。统一用独立守护线程限时兜底：
     * 超时放弃等待并记录 WARN（可能残留浏览器/驱动进程），绝不阻塞巡检主流程。</p>
     *
     * @param what        资源描述（用于日志）
     * @param timeoutMs   限时（毫秒）
     * @param closeAction 关闭动作（如 {@code page::close}）
     */
    public static void closeQuietly(String what, long timeoutMs, Runnable closeAction) {
        try {
            Future<?> future = CLOSE_POOL.submit(closeAction);
            future.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException te) {
            log.warn("[{}] 关闭未在 {}ms 内完成，放弃等待（可能残留浏览器/驱动进程）", what, timeoutMs);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.debug("[{}] 关闭异常: {}", what, e.getMessage());
        }
    }
}
