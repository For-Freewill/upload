package com.patrol.engine;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.LoadState;
import com.patrol.config.PatrolProperties;
import com.patrol.evidence.EvidenceManager;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.model.ActionInspection;
import com.patrol.model.ElementDigest;
import com.patrol.model.Verdict;
import com.patrol.sniffer.PageSniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 页面交互器：全面解析页面可点击元素（原生控件 / 导航链接 / 图片链接 / JS 伪链接 /
 * onclick 元素 / ARIA 可点击角色 / 疑似可点击组件），并对可安全点击的元素执行动作，
 * 采集动作触发的后端请求 / console 日志 / JS 异常并判定。
 *
 * <p>元素处理策略：</p>
 * <ul>
 *   <li>确认类（保存/提交/登录/退出…）：永不点击</li>
 *   <li>弹窗类（新增/编辑/删除…）：点击打开弹窗巡检，随后自动安全关闭、绝不确认</li>
 *   <li>下载类（导出/下载…）：真实执行并记录下载文件</li>
 *   <li>导航链接/图片链接（同源）：不点击——由 BFS 探索阶段统一巡检其目标页面</li>
 *   <li>外部链接：不点击（跨站跳转不可控）</li>
 *   <li>JS 伪链接（无 href / # / javascript:）：作为可点击控件巡检</li>
 *   <li>疑似可点击（cursor:pointer 无语义标记）：仅记录不点击</li>
 * </ul>
 *
 * <p>局限：通过 addEventListener 绑定且未设置 role/onclick/cursor:pointer 的元素无法静态识别。</p>
 */
public class PageInteractor {

    private static final Logger log = LoggerFactory.getLogger(PageInteractor.class);

    /**
     * 页面可点击元素识别 + 定位用的组合选择器（第一遍语义化扫描）。
     * 覆盖：原生控件（button/a/input/select/textarea/summary/label/area）、
     * ARIA 可点击角色（role=button/link/tab/menuitem/option/switch/checkbox/radio）、
     * 内联事件（[onclick]）、可聚焦元素（[tabindex]）。
     */
    static final String CLICKABLE_SELECTOR = String.join(",",
            "button", "a", "input", "select", "textarea", "summary", "label[for]", "area[href]",
            "[role=button]", "[role=link]", "[role=tab]", "[role=menuitem]", "[role=option]",
            "[role=switch]", "[role=checkbox]", "[role=radio]", "[role=menuitemradio]",
            "[role=menuitemcheckbox]",
            "[onclick]", "[tabindex]:not([tabindex='-1'])");

    /**
     * 两遍扫描识别可点击元素：
     * 第一遍按 {@link #CLICKABLE_SELECTOR} 语义化识别（原生控件/ARIA 角色/onclick/tabindex），
     * 第二遍扫描 cursor:pointer 且无语义标记的元素（框架 addEventListener 组件）标记为「疑似可点击·仅记录」。
     * 文本提取兜底链：innerText/value → aria-label → title → img[alt] → svg title。
     */
    private static final String JS_PARSE_ELEMENTS = """
            sel => {
              const out = [];
              const seen = new Set();
              const isVisible = el => typeof el.checkVisibility === 'function'
                  ? el.checkVisibility({checkVisibilityCSS: true})
                  : !!(el.offsetParent || el.getClientRects().length > 0);
              const clsOf = el => {
                const c = (el.className && el.className.baseVal !== undefined)
                    ? el.className.baseVal : el.className;
                return (c || '').toString().slice(0, 60);
              };
              const textOf = el => {
                // 无障碍名称优先：aria-label / title 高于可见文本（图标按钮依赖它们识别）
                let t = (el.getAttribute('aria-label') || '').trim();
                if (!t) t = (el.getAttribute('title') || '').trim();
                if (!t) t = (el.innerText || '').trim();
                if (!t && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) t = (el.value || '').trim();
                if (!t) {
                  const img = el.querySelector('img[alt], img[title]');
                  if (img) t = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
                }
                if (!t) {
                  const st = el.querySelector('svg title');
                  if (st) t = (st.textContent || '').trim();
                }
                return t.slice(0, 40);
              };
              let idx = 0;
              for (const el of document.querySelectorAll(sel)) {
                if (seen.has(el)) continue;
                seen.add(el);
                const tag = el.tagName.toLowerCase();
                const role = (el.getAttribute('role') || '').toLowerCase();
                const type = (el.getAttribute('type') || '').toLowerCase();
                const hrefAttr = el.getAttribute('href');
                const isAnchor = tag === 'a' || tag === 'area';
                let kind = 'OTHER';
                if (isAnchor) {
                  const h = (hrefAttr || '').trim().toLowerCase();
                  if (!hrefAttr || hrefAttr === '#' || h.startsWith('#') || h.startsWith('javascript:')) {
                    kind = 'PSEUDO_LINK';
                  } else {
                    const hasText = (el.innerText || '').trim().length > 0;
                    kind = (!hasText && el.querySelector('img, svg')) ? 'IMAGE_LINK' : 'LINK';
                  }
                } else if (tag === 'button' || role === 'button'
                    || (tag === 'input' && ['button','submit','reset','image'].includes(type))) {
                  kind = 'BUTTON';
                } else if (tag === 'summary') {
                  kind = 'SUMMARY';
                } else if (role === 'link' || role === 'tab' || role === 'menuitem' || role === 'option'
                    || role === 'switch' || role === 'checkbox' || role === 'radio'
                    || role.startsWith('menuitem')) {
                  kind = 'ARIA';
                } else if (el.hasAttribute('onclick')) {
                  kind = 'ONCLICK';
                } else if (tag === 'input') {
                  kind = 'INPUT';
                } else if (tag === 'select') {
                  kind = 'SELECT';
                } else if (tag === 'textarea') {
                  kind = 'TEXTAREA';
                } else if (tag === 'label') {
                  kind = 'LABEL';
                } else if (el.tabIndex >= 0) {
                  kind = 'TABINDEX';
                }
                out.push({
                  idx: idx,
                  tag: tag,
                  text: textOf(el),
                  id: el.id || '',
                  cls: clsOf(el),
                  type: el.getAttribute('type') || '',
                  kind: kind,
                  href: isAnchor ? (el.href || '') : '',
                  selector: sel + ' >> nth=' + idx,
                  visible: isVisible(el)
                });
                idx++;
              }
              // 第二遍：疑似可点击（cursor:pointer 但无语义标记），仅记录不点击
              let ptr = 0;
              for (const el of document.querySelectorAll('div, span, li, i, svg, td, p')) {
                if (seen.has(el) || ptr >= 80) continue;
                if (getComputedStyle(el).cursor !== 'pointer') continue;
                if (!isVisible(el)) continue;
                if ((el.innerText || '').trim().length > 30) continue;
                if (el.querySelector('button, a, [role=button], [onclick], input, select')) continue;
                seen.add(el);
                ptr++;
                out.push({
                  idx: -1,
                  tag: el.tagName.toLowerCase(),
                  text: textOf(el),
                  id: el.id || '',
                  cls: clsOf(el),
                  type: '',
                  kind: 'POINTER',
                  href: '',
                  selector: 'cursor-pointer#' + ptr,
                  visible: true
                });
              }
              return out;
            }
            """;

    private final SiteConfig site;
    private final PatrolProperties properties;
    private final Page page;
    private final PageSniffer sniffer;
    private final EvidenceManager evidence;
    /** 页面级下载采集日志（PatrolEngine 注册的 onDownload 监听写入，动作用下标切分归因） */
    private final List<String> downloadLog;

    public PageInteractor(SiteConfig site, PatrolProperties properties, Page page,
                          PageSniffer sniffer, EvidenceManager evidence, List<String> downloadLog) {
        this.site = site;
        this.properties = properties;
        this.page = page;
        this.sniffer = sniffer;
        this.evidence = evidence;
        this.downloadLog = downloadLog == null ? new ArrayList<>() : downloadLog;
    }

    public record InteractorResult(List<ElementDigest> elements, List<ActionInspection> actions) {
    }

    /**
     * 解析页面元素并执行动作（自定义动作优先，然后自动查询按钮点击）。
     *
     * @param pageUrl       当前页面 URL（用于自定义动作匹配）
     * @param pageIdx       页面序号（证据命名）
     * @param customActions 该站点的自定义动作配置
     */
    public InteractorResult runActions(String pageUrl, int pageIdx,
                                        List<PageActionConfig> customActions) {
        // 1. 元素解析
        List<ElementDigest> elements = parseElements();
        log.info("[{}] {} 解析到 {} 个可交互元素", site.getSiteName(), shortUrl(pageUrl), elements.size());

        // 2. 动作计划：自定义动作 + 自动点击（总数受上限控制）
        //    QUERY 模式：只点文本命中「查询按钮关键词」的可点击控件
        //    ALL 模式：遍历全部可点击控件，按策略执行：
        //      - 确认类（排除词命中）：永不点击（保存/提交/确认/登录/退出…）
        //      - 下载类（导出/下载…）：真实执行并记录下载（含下载链接）
        //      - 对话框类（新增/编辑/删除…）：点击打开弹窗巡检，随后自动关闭、绝不点确认
        //      - 导航链接（同源）：不点击，由探索阶段覆盖目标页面
        //      - 外部链接：不点击
        //      - 其余可点击控件：直接点击
        boolean allMode = site.isAllButtonMode();
        List<PlannedAction> planned = new ArrayList<>();
        if (customActions != null) {
            for (PageActionConfig c : customActions) {
                if (!c.isEnabled() || !c.matchesUrl(pageUrl)) continue;
                planned.add(PlannedAction.custom(c));
                if (planned.size() >= site.getMaxActionsPerPage()) break;
            }
        }
        for (ElementDigest el : elements) {
            if (planned.size() >= site.getMaxActionsPerPage()) break;
            // 只点击可见元素：隐藏在菜单/弹窗中的元素无法直接点击（会超时误报），
            // 它们仍会出现在元素清单中，只是不纳入点击计划
            if (!el.visible()) continue;
            if (matchesAny(el.text(), site.getExcludedButtonKeywords())) continue;
            // 链接型元素单独路由：导航链接由探索阶段覆盖（点击会跳转终止后续动作）；
            // 下载类链接真实点击执行下载；伪链接作为普通控件处理（见 isClickableControl）
            if (el.isLink()) {
                if (allMode && matchesAny(el.text(), site.getDownloadButtonKeywords())) {
                    planned.add(PlannedAction.autoClick(el, true, Category.DOWNLOAD));
                }
                continue;
            }
            if (!el.isClickableControl()) continue;
            Category cat = Category.PLAIN;
            if (allMode) {
                if (matchesAny(el.text(), site.getDownloadButtonKeywords())) {
                    cat = Category.DOWNLOAD;
                } else if (matchesAny(el.text(), site.getDialogButtonKeywords())) {
                    cat = Category.DIALOG;
                }
                planned.add(PlannedAction.autoClick(el, allMode, cat));
            } else if (matchesAny(el.text(), site.getQueryButtonKeywords())) {
                planned.add(PlannedAction.autoClick(el, false, Category.PLAIN));
            }
        }
        // 元素台账：标注每个按钮的处理决策（为什么点/为什么不点）
        elements = labelDecisions(elements, planned, allMode);
        if (planned.isEmpty()) {
            return new InteractorResult(elements, List.of());
        }

        // 3. 逐动作执行
        List<ActionInspection> results = new ArrayList<>();
        int actionIdx = 0;
        String urlBeforeAll = page.url();
        for (PlannedAction plan : planned) {
            // 点击若已导致导航离开，终止后续动作（页面上下文已变）
            if (results.stream().anyMatch(ActionInspection::navigatedAway)) {
                log.debug("[{}] 页面已跳转，终止剩余动作", site.getSiteName());
                break;
            }
            actionIdx++;
            ActionInspection result = execute(plan, pageUrl, pageIdx, actionIdx, urlBeforeAll);
            results.add(result);
            log.info("[{}] {} 动作 {}/{} {} -> {}（触发请求 {} 个，失败 {} 个，console错误 {} 条，下载 {} 个）",
                    site.getSiteName(), shortUrl(pageUrl), actionIdx, planned.size(),
                    plan.description(), result.verdict(),
                    result.requests() == null ? 0 : result.requests().size(),
                    result.failedRequestCount(), result.consoleErrorCount(),
                    result.downloads() == null ? 0 : result.downloads().size());
        }
        return new InteractorResult(elements, results);
    }

    /** ---------------- 元素解析 ---------------- */

    List<ElementDigest> parseElements() {
        try {
            Object result = page.evaluate(JS_PARSE_ELEMENTS, CLICKABLE_SELECTOR);
            if (!(result instanceof List<?> list)) return List.of();
            List<ElementDigest> out = new ArrayList<>();
            for (Object o : list) {
                if (!(o instanceof Map<?, ?> m)) continue;
                String tag = str(m.get("tag"));
                String text = str(m.get("text"));
                String id = str(m.get("id"));
                String cls = str(m.get("cls"));
                String type = str(m.get("type"));
                String kind = str(m.get("kind"));
                String href = str(m.get("href"));
                String selector = str(m.get("selector"));
                boolean visible = Boolean.TRUE.equals(m.get("visible"));
                out.add(new ElementDigest(tag, text, id, cls, type, kind, href,
                        selector, visible, ""));
            }
            // 按可操作性优先级稳定排序后再截断：保证链接较多时按钮类元素不被挤出台账
            out.sort(java.util.Comparator.comparingInt(e -> kindPriority(e.kind())));
            int limit = properties.getDefaults().getMaxElementsRecorded();
            return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
        } catch (PlaywrightException e) {
            log.debug("[{}] 元素解析失败: {}", site.getSiteName(), e.getMessage());
            return List.of();
        }
    }

    private static String str(Object o) {
        return o == null || "null".equals(o) ? "" : String.valueOf(o);
    }

    /** 可操作性优先级：按钮/伪链接 > ARIA/onclick > 折叠项 > 链接 > 疑似可点击 > 输入类 */
    private static int kindPriority(String kind) {
        return switch (kind == null ? "" : kind) {
            case ElementDigest.K_BUTTON, ElementDigest.K_PSEUDO_LINK -> 0;
            case ElementDigest.K_ARIA, ElementDigest.K_ONCLICK -> 1;
            case ElementDigest.K_SUMMARY -> 2;
            case ElementDigest.K_LINK, ElementDigest.K_IMAGE_LINK -> 3;
            case ElementDigest.K_POINTER, ElementDigest.K_TABINDEX -> 4;
            default -> 5;
        };
    }

    /** 元素处理决策标签（写入报告的按钮台账） */
    static final String DEC_CLICKED = "已点击";
    static final String DEC_DIALOG = "已点击·弹窗类(不确认)";
    static final String DEC_DOWNLOAD = "已点击·下载类";
    static final String DEC_EXCLUDED = "确认类·不点击";
    static final String DEC_INVISIBLE = "不可见·未点击";
    static final String DEC_NOT_BUTTON = "非按钮";
    static final String DEC_QUERY_MISS = "未命中查询词·未点击";
    static final String DEC_OVERFLOW = "超出每页上限·未点击";
    static final String DEC_LINK_EXPLORE = "导航链接·探索阶段覆盖";
    static final String DEC_LINK_EXTERNAL = "外部链接·不点击";
    static final String DEC_SUSPECT = "疑似可点击·仅记录";

    /**
     * 为页面元素标注巡检处理决策，形成完整按钮台账：
     * 每个可点击元素无论点击与否都有明确记录（为什么点/为什么不点），
     * 导航链接标注「探索阶段覆盖」——点击会跳转，由 BFS 探索统一巡检其目标页面。
     */
    private List<ElementDigest> labelDecisions(List<ElementDigest> elements,
                                                List<PlannedAction> planned,
                                                boolean allMode) {
        Map<String, String> plannedDecision = new LinkedHashMap<>();
        for (PlannedAction pa : planned) {
            if (!"CUSTOM_CLICK".equals(pa.actionType())) {
                plannedDecision.put(pa.selector(), switch (pa.category()) {
                    case DIALOG -> DEC_DIALOG;
                    case DOWNLOAD -> DEC_DOWNLOAD;
                    default -> DEC_CLICKED;
                });
            }
        }
        List<ElementDigest> labeled = new ArrayList<>(elements.size());
        for (ElementDigest el : elements) {
            String decision = plannedDecision.get(el.selectorHint());
            if (decision == null) {
                if (!el.visible()) {
                    decision = DEC_INVISIBLE;
                } else if (matchesAny(el.text(), site.getExcludedButtonKeywords())) {
                    decision = DEC_EXCLUDED;
                } else if (el.isLink()) {
                    decision = isSameOrigin(el.href()) ? DEC_LINK_EXPLORE : DEC_LINK_EXTERNAL;
                } else if (!el.isClickableControl()) {
                    decision = el.isSuspect() ? DEC_SUSPECT : DEC_NOT_BUTTON;
                } else if (!allMode && !matchesAny(el.text(), site.getQueryButtonKeywords())) {
                    decision = DEC_QUERY_MISS;
                } else {
                    decision = DEC_OVERFLOW;
                }
            }
            labeled.add(el.withDecision(decision));
        }
        return labeled;
    }

    /** 链接地址是否与站点入口同源（同 host + 端口）；非 http(s) 协议（mailto/tel/javascript）视为非同源 */
    private boolean isSameOrigin(String href) {
        if (href == null || href.isBlank()) return false;
        try {
            URI u = URI.create(href.trim());
            String scheme = u.getScheme();
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
            URI entry = URI.create(site.getEntryUrl());
            if (u.getHost() == null || !u.getHost().equalsIgnoreCase(entry.getHost())) return false;
            int p = u.getPort();
            int ep = entry.getPort();
            return p == ep
                    || (p == -1 && (ep == -1 || ep == defaultPort(scheme)))
                    || (ep == -1 && p == defaultPort(scheme));
        } catch (Exception e) {
            return false;
        }
    }

    private static int defaultPort(String scheme) {
        return "https".equalsIgnoreCase(scheme) ? 443 : 80;
    }

    /** ---------------- 单动作执行 ---------------- */

    /** 点击错误是否属于「元素不可交互」（不可见/被遮挡/未启用等待超时）——应跳过而非判失败 */
    private static boolean isActionabilityError(String msg) {
        if (msg == null) return false;
        return msg.contains("intercepts pointer events")
                || (msg.contains("Timeout") && (msg.contains("waiting for element to be visible")
                    || msg.contains("waiting for element to be stable")
                    || msg.contains("waiting for element to be enabled")));
    }

    /** 在打开的对话框内查找并点击「取消类」按钮（绝不点击确认/保存/删除类）。返回是否点到 */
    private boolean clickCancelButtonInDialog() {
        try {
            Object clicked = page.evaluate("""
                    () => {
                      const visible = el => el.getClientRects().length > 0;
                      const dialogs = Array.from(document.querySelectorAll(
                          '[role=dialog], [role=alertdialog], [class*=modal i], [class*=dialog i], [class*=drawer i]'))
                          .filter(visible);
                      for (const d of dialogs) {
                        const btns = Array.from(d.querySelectorAll('button, [role=button]')).filter(visible);
                        const isCancel = b => {
                          const t = (b.innerText || b.getAttribute('aria-label') || '').trim();
                          return /^(取消|关闭|close|cancel|×|x)$/i.test(t);
                        };
                        const cancel = btns.find(isCancel);
                        if (cancel) { cancel.click(); return true; }
                      }
                      return false;
                    }
                    """);
            return Boolean.TRUE.equals(clicked);
        } catch (PlaywrightException e) {
            return false;
        }
    }

    /**
     * 安全关闭点击后打开的对话框/下拉：Esc →（仍有弹窗时）点击取消按钮 → 再 Esc。
     * 绝不点击确认类按钮（保存/提交/确认/删除/创建…），保证新增/编辑/删除流程不被最终确认。
     */
    private void closeOverlaysSafely() {
        try {
            page.keyboard().press("Escape");
            page.waitForTimeout(400);
        } catch (PlaywrightException ignored) {
            return; // 点击导致跳转，页面不可用
        }
        if (clickCancelButtonInDialog()) {
            try {
                page.waitForTimeout(400);
            } catch (PlaywrightException ignored) {
            }
        }
        try {
            page.keyboard().press("Escape");
        } catch (PlaywrightException ignored) {
        }
    }

    private ActionInspection execute(PlannedAction plan, String pageUrl, int pageIdx,
                                      int actionIdx, String urlBeforeAll) {
        String desc = plan.description();
        String clickError = null;
        boolean navigatedAway = false;
        boolean skipped = false;

        sniffer.beginVisit();
        int downloadStart = downloadLog.size();
        try {
            // 点击前填充
            if (plan.fills != null && !plan.fills.isBlank()) {
                for (String fill : plan.fills.split("[;；]")) {
                    int eq = fill.indexOf('=');
                    if (eq <= 0) continue;
                    String sel = fill.substring(0, eq).trim();
                    String val = fill.substring(eq + 1);
                    try {
                        page.fill(sel, val, new Page.FillOptions()
                                .setTimeout(site.getLoadTimeoutMs()));
                    } catch (PlaywrightException e) {
                        log.debug("[{}] 动作填充失败 {}={}: {}", site.getSiteName(), sel, val, e.getMessage());
                    }
                }
            }
            // 点击（超时上限 5s：可见按钮的正常点击应立即完成，超时多为遮挡）
            Locator locator = page.locator(plan.selector());
            locator.click(new Locator.ClickOptions()
                    .setTimeout(Math.min(Math.max(site.getLoadTimeoutMs() / 2, 2000), 5000)));
        } catch (PlaywrightException e) {
            clickError = e.getMessage();
            // SPA 场景：按钮被 toast/浮层遮挡或瞬时不可交互，跳过而非判失败
            if (isActionabilityError(clickError)) {
                skipped = true;
                log.info("[{}] 动作 {} 元素不可交互，跳过（不判失败）", site.getSiteName(), desc);
            }
        }

        if (clickError == null) {
            // 宽限期：给 onclick 处理器时间发起请求，避免 NETWORKIDLE 判定早于请求发出而立即返回
            try {
                page.waitForTimeout(300);
            } catch (PlaywrightException ignored) {
                // 点击导致跳转后页面可能已不可用，以已采集数据继续
            }
            // 等待动作触发的请求完成（网络空闲或超时）；导出下载多在请求完成后触发，一并覆盖
            try {
                page.waitForLoadState(LoadState.NETWORKIDLE,
                        new Page.WaitForLoadStateOptions()
                                .setTimeout(properties.getDefaults().getActionNetworkIdleWaitMs()));
            } catch (PlaywrightException ignored) {
                // 网络未空闲（轮询/长连接），以已采集数据判定
            }
            // 对话框类（新增/编辑/删除/上传/导入…）：打开弹窗巡检后安全关闭，绝不点确认
            if (plan.category() == Category.DIALOG) {
                closeOverlaysSafely();
            } else {
                // 普通按钮也可能打开下拉/浮层，按一次 Esc 复位页面状态，避免遮挡后续动作
                try {
                    page.keyboard().press("Escape");
                } catch (PlaywrightException ignored) {
                }
            }
        }

        // 导航检测：URL 变化即视为跳转（终止后续动作）
        navigatedAway = clickError == null && !page.url().equals(urlBeforeAll);

        var requests = sniffer.finishVisit();
        var consoleLogs = sniffer.consoleLogs();
        var jsErrors = sniffer.jsErrors();
        List<String> downloads = downloadLog.size() > downloadStart
                ? new ArrayList<>(downloadLog.subList(downloadStart, downloadLog.size()))
                : List.of();

        // 动作级判定（阈值与站点阈值一致；被跳过的动作不因不可交互判失败）
        Verdict verdict = Verdict.PASS;
        if (clickError != null && !skipped) {
            verdict = Verdict.FAIL;
        } else if (jsErrors.size() > site.getJsErrorsMax()
                || consoleLogs.stream().filter(com.patrol.model.ConsoleRecord::isError).count()
                        > site.getConsoleErrorsMax()
                || requests.stream().filter(com.patrol.model.RequestRecord::isFailed).count()
                        > site.getFailedRequestsMax()) {
            verdict = Verdict.FAIL;
        }

        String screenshotRel = null;
        String contextRel = null;
        if (evidence != null && evidence.shouldSave(verdict)) {
            EvidenceManager.EvidencePaths paths = evidence.saveAction(
                    page, site, pageIdx, actionIdx, desc, plan.selector(), pageUrl,
                    verdict, requests, consoleLogs, jsErrors, sniffer.failureSnippets(),
                    clickError, navigatedAway);
            screenshotRel = paths.screenshot();
            contextRel = paths.contextJson();
        }

        String buttonCategory = switch (plan.category()) {
            case DIALOG -> "弹窗类(不确认)";
            case DOWNLOAD -> "下载类";
            default -> "CUSTOM_CLICK".equals(plan.actionType()) ? "自定义" : "普通点击";
        };
        return new ActionInspection(site.getSiteName(), pageUrl, plan.actionType(), desc,
                buttonCategory, plan.selector(), requests, consoleLogs, jsErrors, downloads, verdict,
                screenshotRel, contextRel, clickError, navigatedAway, skipped);
    }

    // ---------------- 动作计划 ----------------

    /** 按钮处理类别 */
    enum Category {
        /** 普通按钮：直接点击 */
        PLAIN,
        /** 对话框类（新增/编辑/删除/上传…）：点击后自动安全关闭弹窗，绝不点确认 */
        DIALOG,
        /** 下载类（导出/下载…）：真实执行下载并记录 */
        DOWNLOAD
    }

    private record PlannedAction(String actionType, String description, String selector,
                                  String fills, Category category) {

        static PlannedAction custom(PageActionConfig c) {
            String desc = c.getDescription() == null || c.getDescription().isBlank()
                    ? "自定义点击 " + c.getSelector()
                    : c.getDescription();
            return new PlannedAction("CUSTOM_CLICK", desc, c.getSelector(), c.getFills(), Category.PLAIN);
        }

        static PlannedAction autoClick(ElementDigest el, boolean allMode, Category cat) {
            String label = el.text() == null || el.text().isBlank()
                    ? "无文本按钮[" + shortHint(el) + "]" : el.text();
            String prefix = switch (cat) {
                case DIALOG -> "打开弹窗按钮[";      // 点击后自动关闭，不确认
                case DOWNLOAD -> "导出下载按钮[";    // 真实执行下载
                default -> allMode ? "全量遍历按钮[" : "点击查询按钮[";
            };
            String suffix = cat == Category.DIALOG ? "]（不确认）" : "]";
            return new PlannedAction(allMode ? "ALL_BUTTON_CLICK" : "AUTO_QUERY_CLICK",
                    prefix + label + suffix, el.selectorHint(), null, cat);
        }

        /** 无文本元素的简短定位提示：tag#id / tag.class / tag>>nth=N（避免超长选择器进入描述） */
        private static String shortHint(ElementDigest el) {
            if (el.id() != null && !el.id().isBlank()) return el.tag() + "#" + el.id();
            if (el.cssClass() != null && !el.cssClass().isBlank()) {
                String first = el.cssClass().trim().split("\\s+")[0];
                if (!first.isBlank()) return el.tag() + "." + first;
            }
            int p = el.selectorHint() == null ? -1 : el.selectorHint().lastIndexOf("nth=");
            return p >= 0 ? el.tag() + ">>" + el.selectorHint().substring(p) : el.tag();
        }
    }

    // ---------------- 工具 ----------------

    private static boolean matchesAny(String text, List<String> keywords) {
        if (text == null || text.isBlank() || keywords == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String kw : keywords) {
            if (kw == null || kw.isBlank()) continue;
            if (lower.contains(kw.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private static String shortUrl(String url) {
        if (url == null) return "";
        int p = url.indexOf('/', url.indexOf("//") + 2);
        return p < 0 ? url : url.substring(p);
    }
}
