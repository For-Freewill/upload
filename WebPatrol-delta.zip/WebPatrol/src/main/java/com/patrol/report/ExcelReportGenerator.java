package com.patrol.report;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.handler.context.CellWriteHandlerContext;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.patrol.model.ActionInspection;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.ElementDigest;
import com.patrol.model.IssueRecord;
import com.patrol.model.LinkRecord;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.RequestRecord;
import com.patrol.model.SiteInspection;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel 巡检汇总报告（基于 EasyExcel）：
 * 巡检总览 / 页面明细 / 动作明细 / 子页面链接 / 页面元素 / 失败请求 / Console错误 七个 sheet。
 * 「子页面链接」记录页面探索父子关系；「页面元素」记录每个按钮的处理决策台账。
 *
 * <p>结论列（PASS/WARN/FAIL）由 {@link VerdictColorHandler} 自动着色：
 * PASS=浅绿 / WARN=浅橙 / FAIL=玫红（加粗）。</p>
 */
@Component
public class ExcelReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(ExcelReportGenerator.class);

    private static final String[] OVERVIEW_HEADERS = {"站点", "入口URL", "认证方式", "巡检页面数", "PASS", "WARN",
            "FAIL", "执行动作", "失败动作", "发现链接数", "站点结论", "错误信息"};
    private static final String[] PAGE_HEADERS = {"站点", "URL", "标题", "父页面", "主文档状态码", "加载耗时(ms)",
            "console错误", "JS异常", "失败请求", "执行动作", "失败动作", "子页面链接", "已巡检子页面",
            "页面结论", "问题摘要", "截图", "上下文JSON"};
    private static final String[] ACTION_HEADERS = {"站点", "页面URL", "动作类型", "动作描述", "按钮类别",
            "触发请求数", "失败请求", "console错误", "JS异常", "是否跳转", "是否跳过", "动作结论",
            "下载文件", "异常信息", "动作截图", "动作上下文JSON"};
    private static final String[] LINK_HEADERS = {"站点", "来源页面", "子页面URL", "链接文本", "是否已巡检", "子页面结论"};
    private static final String[] ELEMENT_HEADERS = {"站点", "页面URL", "元素", "类别", "文本", "ID", "类型",
            "链接地址", "可见", "处理决策"};
    private static final String[] FAILED_REQUEST_HEADERS = {"站点", "页面URL", "请求URL", "方法", "资源类型",
            "状态码", "失败原因", "耗时(ms)"};
    private static final String[] CONSOLE_HEADERS = {"站点", "页面URL", "级别", "内容", "定位"};

    /** 巡检总览页元信息块行数（含标题行与空行分隔），其下一行是站点表头（需灰底加粗样式） */
    private static final int OVERVIEW_META_ROWS = 10;

    public void generate(PatrolReport report, Path file) {
        try {
            Files.createDirectories(file.getParent());
            ExcelWriter writer = null;
            try {
                writer = EasyExcel.write(file.toString()).build();
                overviewSheet(writer, report);
                pageSheet(writer, report);
                actionSheet(writer, report);
                linkSheet(writer, report);
                elementSheet(writer, report);
                failedRequestSheet(writer, report);
                consoleSheet(writer, report);
            } finally {
                if (writer != null) {
                    writer.finish();
                }
            }
            log.info("Excel 报告已生成: {}", file);
        } catch (Exception e) {
            log.error("Excel 报告生成失败: {}", e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------
    // Sheet 1：巡检总览（元信息块 + 站点汇总表；无 easyexcel head，表头行由样式处理器渲染）
    // ------------------------------------------------------------------
    private void overviewSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        data.add(row("巡检报告", ""));
        data.add(row("开始时间", nz(report.startedAt())));
        data.add(row("结束时间", nz(report.finishedAt())));
        data.add(row("配置文件", nz(report.excelConfigPath())));
        data.add(row("浏览器", nz(report.browserInfo())));
        data.add(row("站点总数", String.valueOf(report.summary().totalSites())));
        data.add(row("巡检页面总数", String.valueOf(report.summary().totalPages())));
        data.add(row("执行动作总数", String.valueOf(report.summary().totalActions())));
        data.add(row("失败动作数", String.valueOf(report.summary().failedActions())));
        data.add(row("", "")); // 空行分隔
        data.add(row((Object[]) OVERVIEW_HEADERS));
        for (SiteInspection s : report.sites()) {
            data.add(row(s.siteName(), nz(s.entryUrl()), nz(s.authType()),
                    s.pagesVisited(), s.passPages(), s.warnPages(), s.failPages(),
                    s.totalActions(), s.failedActions(), s.linksFound(),
                    s.verdict().name(), nz(s.errorMessage())));
        }
        WriteSheet sheet = EasyExcel.writerSheet(0, "巡检总览")
                .needHead(false)
                .registerWriteHandler(new VerdictColorHandler(OVERVIEW_META_ROWS))
                .build();
        writer.write(data, sheet);
    }

    private void pageSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                data.add(row(s.siteName(), p.url(), nz(p.title()),
                        p.parentUrl() == null ? "(入口页)" : p.parentUrl(),
                        p.mainStatus(), p.loadMs(), p.consoleErrorCount(), p.jsErrorCount(),
                        p.failedRequestCount(), p.actionCount(), p.failedActionCount(),
                        p.childLinks() == null ? 0 : p.childLinks().size(), p.exploredChildCount(),
                        p.verdict().name(), issueSummary(p),
                        nz(p.screenshotPath()), nz(p.contextPath())));
            }
        }
        writeTable(writer, 1, "页面明细", PAGE_HEADERS, data);
    }

    /** Sheet 3：功能动作明细（页面元素点击巡检的逐动作结果） */
    private void actionSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.actions() == null) continue;
                for (ActionInspection a : p.actions()) {
                    data.add(row(s.siteName(), p.url(), nz(a.actionType()), nz(a.description()),
                            nz(a.buttonCategory()),
                            a.requests() == null ? 0 : a.requests().size(),
                            a.failedRequestCount(), a.consoleErrorCount(), a.jsErrorCount(),
                            a.navigatedAway() ? "是" : "否", a.skipped() ? "是" : "否",
                            a.verdict().name(),
                            a.downloads() == null ? "" : String.join("; ", a.downloads()),
                            nz(a.errorMessage()), nz(a.screenshotPath()), nz(a.contextPath())));
                }
            }
        }
        writeTable(writer, 2, "动作明细", ACTION_HEADERS, data);
    }

    /** Sheet 4：子页面链接（页面探索过程发现的子页面链接及巡检状态） */
    private void linkSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.childLinks() == null) continue;
                for (LinkRecord l : p.childLinks()) {
                    data.add(row(s.siteName(), p.url(), l.url(), nz(l.text()),
                            l.explored() ? "是" : "否",
                            l.explored() && l.childVerdict() != null ? l.childVerdict().name() : ""));
                }
            }
        }
        writeTable(writer, 3, "子页面链接", LINK_HEADERS, data);
    }

    /** Sheet 5：页面元素台账（含类别、链接地址与处理决策） */
    private void elementSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                if (p.elements() == null) continue;
                for (ElementDigest el : p.elements()) {
                    data.add(row(s.siteName(), p.url(), nz(el.tag()), nz(el.kindLabel()),
                            nz(el.text()), nz(el.id()), nz(el.type()), nz(el.href()),
                            el.visible() ? "是" : "否", nz(el.decision())));
                }
            }
        }
        writeTable(writer, 4, "页面元素", ELEMENT_HEADERS, data);
    }

    /** Sheet 6：失败请求（页面访问 + 动作触发） */
    private void failedRequestSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                for (RequestRecord req : p.requests()) {
                    if (!req.isFailed()) continue;
                    data.add(failedRequestRow(s.siteName(), p.url(), req));
                }
                if (p.actions() == null) continue;
                for (ActionInspection a : p.actions()) {
                    if (a.requests() == null) continue;
                    for (RequestRecord req : a.requests()) {
                        if (!req.isFailed()) continue;
                        data.add(failedRequestRow(s.siteName(), p.url() + " ← " + a.description(), req));
                    }
                }
            }
        }
        writeTable(writer, 5, "失败请求", FAILED_REQUEST_HEADERS, data);
    }

    private static List<Object> failedRequestRow(String site, String pageUrl, RequestRecord req) {
        return row(site, pageUrl, nz(req.url()), nz(req.method()), nz(req.resourceType()),
                req.status(), nz(req.failureText()), req.durationMs());
    }

    /** Sheet 7：Console 错误（页面访问 + 动作期间） */
    private void consoleSheet(ExcelWriter writer, PatrolReport report) {
        List<List<Object>> data = new ArrayList<>();
        for (SiteInspection s : report.sites()) {
            for (PageInspection p : s.pages()) {
                for (ConsoleRecord c : p.consoleLogs()) {
                    if (!c.isError()) continue;
                    data.add(consoleRow(s.siteName(), p.url(), c));
                }
                if (p.actions() == null) continue;
                for (ActionInspection a : p.actions()) {
                    if (a.consoleLogs() == null) continue;
                    for (ConsoleRecord c : a.consoleLogs()) {
                        if (!c.isError()) continue;
                        data.add(consoleRow(s.siteName(), p.url() + " ← " + a.description(), c));
                    }
                }
            }
        }
        writeTable(writer, 6, "Console错误", CONSOLE_HEADERS, data);
    }

    private static List<Object> consoleRow(String site, String pageUrl, ConsoleRecord c) {
        return row(site, pageUrl, nz(c.level()), nz(c.text()), nz(c.location()));
    }

    // ------------------------------------------------------------------
    // 公共工具
    // ------------------------------------------------------------------

    /** 动态表头数据 sheet：easyexcel 自动渲染灰底加粗表头 + 结论列着色 + 自适应列宽 */
    private static void writeTable(ExcelWriter writer, int idx, String name,
                                    String[] headers, List<List<Object>> data) {
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        WriteSheet sheet = EasyExcel.writerSheet(idx, name)
                .head(head)
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .registerWriteHandler(new VerdictColorHandler())
                .build();
        writer.write(data, sheet);
    }

    /** 行构造（禁止 null，统一转空串/默认值） */
    private static List<Object> row(Object... values) {
        List<Object> line = new ArrayList<>();
        for (Object v : values) {
            line.add(v == null ? "" : v);
        }
        return line;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String issueSummary(PageInspection p) {
        if (p.issues() == null || p.issues().isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (IssueRecord ir : p.issues()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(ir.type().label()).append(": ").append(ir.message());
        }
        return sb.toString();
    }

    /**
     * 结论列着色处理器：PASS=浅绿 / WARN=浅橙 / FAIL=玫红（加粗）。
     * headerStyleRowIndex 非 null 时，将该相对行号整行渲染为灰底加粗表头样式
     * （用于「巡检总览」元信息块之后的站点表头行）。
     * 样式增强失败不影响报告产出（防御式降级）。
     */
    private static final class VerdictColorHandler implements CellWriteHandler {

        private final Integer headerStyleRowIndex;

        VerdictColorHandler() {
            this(null);
        }

        VerdictColorHandler(Integer headerStyleRowIndex) {
            this.headerStyleRowIndex = headerStyleRowIndex;
        }

        @Override
        public void afterCellDispose(CellWriteHandlerContext context) {
            try {
                if (Boolean.TRUE.equals(context.getHead())) {
                    return;
                }
                WriteCellData<?> cellData = context.getFirstCellData();
                if (cellData == null) {
                    return;
                }
                Integer r = context.getRelativeRowIndex();
                if (headerStyleRowIndex != null && r != null && r == headerStyleRowIndex) {
                    apply(cellData, IndexedColors.GREY_25_PERCENT, true);
                    return;
                }
                if (cellData.getType() != CellDataTypeEnum.STRING) {
                    return;
                }
                String v = cellData.getStringValue();
                if ("PASS".equals(v)) {
                    apply(cellData, IndexedColors.LIGHT_GREEN, true);
                } else if ("WARN".equals(v)) {
                    apply(cellData, IndexedColors.LIGHT_ORANGE, true);
                } else if ("FAIL".equals(v)) {
                    apply(cellData, IndexedColors.ROSE, true);
                }
            } catch (Exception ignore) {
                // 样式增强失败时降级为无着色，不影响报告数据
            }
        }

        private static void apply(WriteCellData<?> cellData, IndexedColors color, boolean bold) {
            WriteCellStyle style = cellData.getOrCreateStyle();
            style.setFillForegroundColor(color.getIndex());
            style.setFillPatternType(FillPatternType.SOLID_FOREGROUND);
            WriteFont font = new WriteFont();
            font.setBold(bold);
            style.setWriteFont(font);
        }
    }
}
