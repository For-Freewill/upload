package com.patrol.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.patrol.model.PatrolReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Path;

/** 巡检原始结果 JSON 落盘 */
@Component
public class JsonReportWriter {

    private static final Logger log = LoggerFactory.getLogger(JsonReportWriter.class);

    private final ObjectMapper mapper = new ObjectMapper();

    public void write(PatrolReport report, Path file) {
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(file.toFile(), report);
            log.info("JSON 报告已生成: {}", file);
        } catch (Exception e) {
            log.error("JSON 报告写入失败: {}", e.getMessage(), e);
        }
    }
}
