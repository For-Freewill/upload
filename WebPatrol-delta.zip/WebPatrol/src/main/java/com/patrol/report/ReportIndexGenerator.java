package com.patrol.report;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * 历次巡检索引页生成器：扫描报告根目录下所有 {@code patrol-<时间戳>/patrol-result.json}，
 * 生成/更新 {@code index.html} —— 卡片式展示历次巡检的时间、站点、页面/动作统计与结论，
 * 可一键打开对应报告，避免手动翻目录找报告。
 *
 * <p>对旧版本/损坏的 JSON 报告自动跳过（向后兼容），索引页自身不依赖报告 schema 的完整演进。</p>
 */
@Component
public class ReportIndexGenerator {

    private static final Logger log = LoggerFactory.getLogger(ReportIndexGenerator.class);
    private static final Pattern DIR_PATTERN = Pattern.compile("patrol-\\d{8}-\\d{6}");

    private final ObjectMapper mapper = new ObjectMapper();

    /** 一次巡检报告条目：目录名 + 解析后的 JSON */
    private record Entry(String dirName, JsonNode report) {
    }

    /** 生成/更新报告根目录下的 index.html，返回索引文件路径 */
    public Path generate(Path reportsRoot) {
        try {
            Files.createDirectories(reportsRoot);
            List<Entry> entries = new ArrayList<>();
            try (Stream<Path> dirs = Files.list(reportsRoot)) {
                dirs.filter(Files::isDirectory)
                        .filter(d -> DIR_PATTERN.matcher(d.getFileName().toString()).matches())
                        .filter(d -> Files.exists(d.resolve("patrol-result.json")))
                        .sorted((a, b) -> b.getFileName().toString().compareTo(a.getFileName().toString()))
                        .forEach(d -> {
                            try {
                                JsonNode root = mapper.readTree(d.resolve("patrol-result.json").toFile());
                                entries.add(new Entry(d.getFileName().toString(), root));
                            } catch (Exception e) {
                                log.debug("跳过无法解析的巡检报告目录 {}: {}", d.getFileName(), e.getMessage());
                            }
                        });
            }
            Path index = reportsRoot.resolve("index.html");
            Files.writeString(index, buildHtml(entries), StandardCharsets.UTF_8);
            log.info("历次巡检索引已生成: {}（{} 次巡检）", index.toAbsolutePath(), entries.size());
            return index;
        } catch (Exception e) {
            log.error("巡检索引页生成失败: {}", e.getMessage(), e);
            return null;
        }
    }

    private String buildHtml(List<Entry> entries) {
        StringBuilder html = new StringBuilder(16 * 1024);
        html.append("<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-\">")
            .append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
            .append("<title>巡检报告索引 · frontend-patrol</title><style>")
            .append(css())
            .append("</style></head><body>")
            .append("<div class=\"header\"><h1>📚 前端巡检报告索引</h1>")
            .append("<div class=\"meta\">共 ").append(entries.size())
            .append(" 次巡检 · frontend-patrol v1.0.0 · 点击卡片查看完整报告</div></div>");

        if (entries.isEmpty()) {
            html.append("<div class=\"empty\">暂无巡检记录 —— 运行一次巡检后此处会自动列出历次报告</div>");
        } else {
            html.append("<div class=\"grid\">");
            for (Entry entry : entries) {
                card(html, entry);
            }
            html.append("</div>");
        }
        html.append("<footer>frontend-patrol · Excel 驱动 · Spring Boot 4 / Java 17 / Playwright</footer>")
            .append("</body></html>");
        return html.toString();
    }

    private void card(StringBuilder html, Entry entry) {
        JsonNode e = entry.report();
        String dir = entry.dirName();
        String startedAt = text(e, "startedAt", "-");
        JsonNode sum = e.path("summary");
        String verdict = siteVerdict(e);
        String excel = text(e, "excelConfigPath", "-");

        html.append("<div class=\"card ").append(verdict.toLowerCase()).append("\">")
            .append("<div class=\"card-head\"><span class=\"badge ").append(verdict.toLowerCase()).append("\">")
            .append(verdict).append("</span><span class=\"time\">")
            .append(esc(startedAt)).append("</span></div>")
            .append("<div class=\"rows\">")
            .append("<div class=\"row\"><b>").append(intOf(sum, "enabledSites")).append("</b> 个站点")
            .append(" <span class=\"muted\">（PASS ").append(intOf(sum, "passSites"))
            .append(" / WARN ").append(intOf(sum, "warnSites"))
            .append(" / FAIL ").append(intOf(sum, "failSites")).append("）</span></div>")
            .append("<div class=\"row\">巡检页面 <b>").append(intOf(sum, "totalPages")).append("</b>")
            .append(" · 异常 <b class=\"red\">").append(intOf(sum, "failPages")).append("</b>")
            .append(" · 动作 <b>").append(intOf(sum, "totalActions")).append("</b>")
            .append("（失败 <b class=\"red\">").append(intOf(sum, "failedActions")).append("</b>）</div>")
            .append("<div class=\"row muted\">Console错误 ").append(intOf(sum, "totalConsoleErrors"))
            .append(" · JS异常 ").append(intOf(sum, "totalJsErrors"))
            .append(" · 失败请求 ").append(intOf(sum, "totalFailedRequests"))
            .append(" · 耗时 ").append(durationOf(sum)).append("</div>")
            .append("<div class=\"row muted\" title=\"").append(esc(siteNames(e))).append("\">站点: ")
            .append(esc(shorten(siteNames(e), 52))).append("</div>")
            .append("<div class=\"row muted\" title=\"").append(esc(excel)).append("\">配置: ")
            .append(esc(shorten(excel, 46))).append("</div>")
            .append("</div>")
            .append("<div class=\"links\">")
            .append("<a href=\"").append(dir).append("/report.html\" target=\"_blank\">📄 可视化报告</a> ")
            .append("<a href=\"").append(dir).append("/patrol-report.xlsx\">📊 Excel 明细</a> ")
            .append("<a href=\"").append(dir).append("/patrol-result.json\">🧾 原始 JSON</a>")
            .append("</div></div>");
    }

    /** 从站点结论推导整次巡检的总体结论（最差值） */
    private String siteVerdict(JsonNode e) {
        JsonNode sites = e.path("sites");
        String worst = "PASS";
        for (JsonNode s : sites) {
            String v = s.path("verdict").asText("PASS");
            if ("FAIL".equals(v)) return "FAIL";
            if ("WARN".equals(v)) worst = "WARN";
        }
        return worst;
    }

    /** 站点名称清单（顿号分隔） */
    private static String siteNames(JsonNode e) {
        StringBuilder sb = new StringBuilder();
        for (JsonNode s : e.path("sites")) {
            String n = s.path("siteName").asText("");
            if (n.isBlank()) continue;
            if (sb.length() > 0) sb.append("、");
            sb.append(n);
        }
        return sb.length() > 0 ? sb.toString() : "-";
    }

    private static String text(JsonNode node, String field, String def) {
        JsonNode v = node.path(field);
        return v.isTextual() && !v.asText().isBlank() ? v.asText() : def;
    }

    private static int intOf(JsonNode node, String field) {
        return node.path(field).asInt(0);
    }

    private static String durationOf(JsonNode sum) {
        long ms = sum.path("durationMs").asLong(0);
        if (ms <= 0) return "-";
        if (ms < 60_000) return ms + "ms";
        if (ms < 3_600_000) return ms / 60_000 + "分" + ms % 60_000 / 1000 + "秒";
        return ms / 3_600_000 + "时" + ms % 3_600_000 / 60_000 + "分";
    }

    private static String shorten(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private static String css() {
        return """
                body{font-family:"Segoe UI","Microsoft YaHei",sans-serif;background:#f5f7fa;color:#26333f;margin:0;padding:24px;}
                .header{background:linear-gradient(135deg,#1f6feb,#4f8ff7);color:#fff;padding:24px 28px;border-radius:12px;margin-bottom:20px;}
                .header h1{margin:0 0 6px;font-size:24px;}
                .meta{opacity:.92;font-size:13px;}
                .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:14px;}
                .card{background:#fff;border-radius:10px;padding:14px 18px;box-shadow:0 1px 4px rgba(0,0,0,.08);border-left:5px solid #22c55e;}
                .card.warn{border-left-color:#f59e0b;} .card.fail{border-left-color:#ef4444;}
                .card-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
                .badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;}
                .badge.pass{background:#dcfce7;color:#15803d;} .badge.warn{background:#fef3c7;color:#b45309;}
                .badge.fail{background:#fee2e2;color:#b91c1c;}
                .time{font-size:13px;color:#5a6b7b;font-weight:600;}
                .rows .row{font-size:13px;margin:3px 0;}
                .muted{color:#8a99a8;font-size:12px;}
                .red{color:#dc2626;font-weight:600;}
                .links{margin-top:10px;padding-top:8px;border-top:1px solid #eef2f7;font-size:13px;}
                .links a{margin-right:10px;color:#1f6feb;text-decoration:none;}
                .empty{background:#fff;border-radius:10px;padding:40px;text-align:center;color:#8a99a8;}
                footer{text-align:center;color:#8a99a8;font-size:12px;margin-top:16px;}
                """;
    }
}
