package com.patrol;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.patrol.config.PatrolProperties;
import com.patrol.excel.ExcelConfigLoader;
import com.patrol.excel.SiteConfig;
import com.patrol.support.TestWebServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

/**
 * <b>全局运行入口测试</b>：运行效果与直接运行 {@link PatrolApplication} 完全一致。
 *
 * <h2>全保真模式（默认）</h2>
 * <p>零参数调用 {@code SpringApplication.run(PatrolApplication.class)}，与
 * {@code PatrolApplication.main()} 无参运行<b>完全等价</b>（等价于 run.bat / java -jar）：</p>
 * <ul>
 *   <li>真实读取 {@code config/sites.xlsx}（含全部启用站点与认证方式）</li>
 *   <li>真实 {@code login-state/} 登录态缓存（TTL 内复用，过期自动走有头认证，MANUAL 站点会弹登录窗）</li>
 *   <li>报告输出到真实 {@code reports/patrol-&lt;时间戳&gt;/} 并更新历次索引页</li>
 *   <li>全部参数来自 {@code application.yml}（并行度 / locale / 阈值等），不做任何覆盖</li>
 * </ul>
 * <p>唯一差异：不调用 {@code System.exit}（改为捕获退出码断言），避免结束测试 JVM。
 * <b>在 IDE 中 Run/Debug 本用例，即可原样运行 / 断点调试整个真实巡检。</b></p>
 *
 * <h2>隔离模式（mvn test 回归）</h2>
 * <p>Maven surefire 自动注入 {@code patrol.runner.test.isolated=true}，切换到内置测试站点 +
 * {@code target/} 隔离目录（登录态/报告均隔离，并行度=2 验证 worker 池），保证回归套件确定性、
 * 不依赖外部站点、不弹登录窗。如需在 mvn 中强制全保真：
 * {@code PATROL_RUNNER_TEST_ISOLATED=false mvn test -Dtest=PatrolRunnerTest}。</p>
 */
public class PatrolRunnerTest {

    private static final Logger log = LoggerFactory.getLogger(PatrolRunnerTest.class);

    /** 仅隔离模式使用 */
    private TestWebServer webServer;

    @AfterClass
    public void tearDown() {
        if (webServer != null) {
            webServer.stop();
            webServer = null;
        }
    }

    /**
     * 全局端到端：Excel 配置 → SpringApplication 真实入口 → 两阶段并行巡检 → 报告/索引/退出码。
     * 全保真模式下与运行 PatrolApplication 完全一致；隔离模式下走确定性内置站点。
     */
    @Test
    public void globalRunThroughSpringBootEntry() throws Exception {
        boolean isolated = isolatedMode();

        Path excel;
        Path outDir;
        String[] args;
        if (isolated) {
            // ---- 隔离模式：内置测试站点 + target/ 隔离目录（回归确定性）----
            webServer = new TestWebServer();
            webServer.start();
            excel = Path.of("target", "runner-test-sites.xlsx");
            writeSitesExcel(excel);
            outDir = Path.of("target", "patrol-runner-test");
            Path loginStateDir = Path.of("target", "login-state-runner-test");
            cleanDir(loginStateDir);
            args = new String[]{
                    "--excel=" + excel,
                    "--patrol.output-dir=" + outDir,
                    "--patrol.login-state-dir=" + loginStateDir,
                    "--patrol.max-parallel-sites=2",              // 并行 worker 池
                    "--patrol.defaults.sitemap-discovery=false"   // 保证页面数确定性
            };
        } else {
            // ---- 全保真模式：零参数 = PatrolApplication.main() 无参运行，一切默认值来自 application.yml ----
            excel = Path.of("config", "sites.xlsx");
            outDir = Path.of("reports");
            args = new String[0];
        }
        Files.createDirectories(outDir);
        Set<Path> before = patrolDirs(outDir);
        log.info(">>> {}：SpringApplication 真实入口启动（配置={}, 输出={}, 参数={}）",
                isolated ? "隔离模式（回归）" : "全保真模式（等价运行 PatrolApplication）",
                excel, outDir, args.length == 0 ? "无（全部默认）" : String.join(" ", args));

        // 全局运行（不经过 PatrolApplication.main，避免 System.exit 结束测试 JVM）
        int exitCode = SpringApplication.exit(SpringApplication.run(PatrolApplication.class, args));

        // 1) 本次运行新增的报告目录：三件套 + 历次索引页
        Path reportDir = newPatrolDir(outDir, before);
        assertTrue("HTML 报告应生成: " + reportDir, Files.exists(reportDir.resolve("report.html")));
        assertTrue("Excel 报告应生成", Files.exists(reportDir.resolve("patrol-report.xlsx")));
        assertTrue("JSON 报告应生成", Files.exists(reportDir.resolve("patrol-result.json")));
        assertTrue("历次索引页应生成", Files.exists(outDir.resolve("index.html")));

        // 2) 结果断言：站点数 = Excel 中启用站点数
        JsonNode sites = new ObjectMapper()
                .readTree(reportDir.resolve("patrol-result.json").toFile()).get("sites");
        int enabled = enabledSiteCount(excel);
        assertTrue(excel + " 至少应有一个启用站点", enabled > 0);
        assertEquals("JSON 结果站点数应与 Excel 启用站点数一致", enabled, sites.size());

        if (isolated) {
            // 3a) 隔离模式：判定确定，严格断言（顺序 = Excel 配置顺序，验证并行下结果仍按配置汇总）
            assertEquals("结果顺序应与配置一致", "全局演示站", sites.get(0).get("siteName").asText());
            assertEquals("全局登录站", sites.get(1).get("siteName").asText());
            assertEquals("全局异常站", sites.get(2).get("siteName").asText());
            assertEquals("演示站应 PASS（查询动作成功、保存按钮排除）",
                    "PASS", sites.get(0).get("verdict").asText());
            assertEquals("登录站应 PASS（阶段一有头 FORM 自动登录 → 登录态缓存 → 阶段二无头巡检）",
                    "PASS", sites.get(1).get("verdict").asText());
            assertEquals("异常站应 FAIL（500 接口 + console 错误）",
                    "FAIL", sites.get(2).get("verdict").asText());
            assertEquals("存在 FAIL 站点时全局入口应返回退出码 1", 1, exitCode);
            assertTrue("阶段一应为 FORM 站点生成登录态缓存",
                    Files.exists(Path.of("target", "login-state-runner-test", "全局登录站.json")));
        } else {
            // 3b) 全保真模式：真实环境结论由站点状态决定，断言「退出码 ↔ 结果一致性」（strict-exit 语义）
            boolean anyFail = false;
            for (JsonNode site : sites) {
                String verdict = site.get("verdict").asText();
                JsonNode pagesNode = site.get("pages");
                int pageCount = pagesNode == null ? 0 : pagesNode.size();
                log.info("站点 [{}] 结论: {}（页面 {} 个）", site.get("siteName").asText(), verdict, pageCount);
                anyFail = anyFail || "FAIL".equals(verdict);
            }
            assertEquals("退出码应与结果一致（strict-exit：FAIL 站点→1，全部通过→0）",
                    anyFail ? 1 : 0, exitCode);
        }

        log.info("全局运行入口验证通过（模式={}，退出码={}），报告目录: {}",
                isolated ? "隔离" : "全保真", exitCode, reportDir.toAbsolutePath());
    }

    // ------------------------------------------------------------------
    // 模式判定：环境变量 PATROL_RUNNER_TEST_ISOLATED > 系统属性 patrol.runner.test.isolated > 默认 false
    // （surefire 注入系统属性 true → mvn test 走隔离模式；IDE 直接运行无此属性 → 全保真；
    //   环境变量最高优先，便于 CI / 命令行强制指定任一模式）
    // ------------------------------------------------------------------
    private static boolean isolatedMode() {
        String env = System.getenv("PATROL_RUNNER_TEST_ISOLATED");
        if (env != null && !env.isBlank()) {
            return Boolean.parseBoolean(env.trim());
        }
        return Boolean.getBoolean("patrol.runner.test.isolated");
    }

    /** Excel 中启用站点数（与 PatrolRunner 的过滤逻辑一致：filter isEnabled） */
    private static int enabledSiteCount(Path excel) throws Exception {
        ExcelConfigLoader loader = new ExcelConfigLoader(new PatrolProperties());
        return (int) loader.load(excel).stream().filter(SiteConfig::isEnabled).count();
    }

    /** Sites 主表（隔离模式专用；高级配置 sheet 可选，留空回落全局默认；EasyExcel 动态表头写出） */
    private void writeSitesExcel(Path excel) throws Exception {
        String[][] rows = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"全局演示站", webServer.baseUrl() + "/query-page", "true", "NONE", "", "",
                        "", "", "", "", "查询动作演示（PASS 预期）"},
                {"全局登录站", webServer.baseUrl() + "/home2", "true", "FORM", "admin", "admin123",
                        webServer.baseUrl() + "/login", "#username", "#password", "#loginBtn",
                        "两阶段 FORM 认证（PASS 预期）"},
                {"全局异常站", webServer.baseUrl() + "/broken-api", "true", "NONE", "", "",
                        "", "", "", "", "500 接口 + console 错误（FAIL 预期，驱动退出码 1）"}
        };
        String[] headers = rows[0];
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        List<List<Object>> data = new ArrayList<>();
        for (int r = 1; r < rows.length; r++) {
            List<Object> line = new ArrayList<>();
            for (int c = 0; c < headers.length; c++) {
                line.add(c < rows[r].length ? rows[r][c] : "");
            }
            data.add(line);
        }
        ExcelWriter writer = null;
        try {
            writer = EasyExcel.write(excel.toString()).build();
            WriteSheet sheet = EasyExcel.writerSheet(0, "Sites").head(head).build();
            writer.write(data, sheet);
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
    }

    /** 清空目录（隔离模式登录态缓存每次运行前清理，保证确定性） */
    private static void cleanDir(Path dir) throws Exception {
        if (Files.exists(dir)) {
            try (Stream<Path> walk = Files.walk(dir)) {
                walk.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
            }
        }
        Files.createDirectories(dir);
    }

    /** 输出根目录下现有 patrol-* 报告目录快照 */
    private static Set<Path> patrolDirs(Path outDir) throws Exception {
        try (Stream<Path> list = Files.list(outDir)) {
            Set<Path> dirs = new HashSet<>();
            list.filter(p -> Files.isDirectory(p)
                            && p.getFileName().toString().startsWith("patrol-"))
                    .forEach(dirs::add);
            return dirs;
        }
    }

    /** 本次运行新增的 patrol-* 报告目录（多于一个时取名称最大=最新） */
    private static Path newPatrolDir(Path outDir, Set<Path> before) throws Exception {
        Set<Path> after = patrolDirs(outDir);
        after.removeAll(before);
        return after.stream()
                .max(Comparator.comparing(p -> p.getFileName().toString()))
                .orElseThrow(() -> new AssertionError("本次运行未生成新的报告目录: " + outDir));
    }
}
