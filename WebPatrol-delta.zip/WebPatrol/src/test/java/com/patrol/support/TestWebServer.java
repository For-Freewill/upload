package com.patrol.support;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 本地巡检测试站点：一个进程内 HTTP 服务器，覆盖各类前端异常场景。
 *
 * <ul>
 *  <li>/              首页（正常 + 链接到其他页面）</li>
 *  <li>/ok-page       正常页面（PASS）</li>
 *  <li>/broken-api    页面发起 XHR 调用 /api/fail(500) → 后端失败 + console error（FAIL）</li>
 *  <li>/js-error      页面抛未捕获 JS 异常（FAIL）</li>
 *  <li>/slow          3 秒慢页面（阈值 1s → WARN）</li>
 *  <li>/error404      主文档 404（FAIL）</li>
 *  <li>/missing-js    引用不存在的 JS 文件（请求失败 → FAIL）</li>
 *  <li>/keyword-page   页面内容含错误关键词（FAIL）</li>
 *  <li>/query-page    正常查询页：查询按钮触发 /api/query(200)；同页「保存」按钮
 *                     触发 /api/danger —— 确认类排除词命中，永不应被点击</li>
 *  <li>/query-broken  查询按钮触发 /api/query-fail(500) + console error（动作 FAIL）</li>
 *  <li>/dialog-page   弹窗巡检演示页：新增/删除按钮打开弹窗（触发 /api/dialog-open），
 *                     弹窗内「确认创建/确认删除」→ /api/danger（巡检绝不点击）；
 *                     「导出数据」按钮触发 /api/export 下载</li>
 *  <li>/coverage-page 可点击元素覆盖演示页：图标按钮(aria-label)、role=button、role=tab、
 *                     无 href 伪链接、图片链接(img alt)、外部链接、下载链接、
 *                     cursor:pointer 疑似可点击、summary 折叠项、tabindex、input/select/textarea/label</li>
 *  <li>/isolated-home  孤立菜单演示首页：hash 路由菜单（#/hash-menu-a、#/hash-menu-b）
 *                     与 onclick 内联导航菜单（location.href='/onclick-menu'）</li>
 *  <li>/hidden-page    额外入口演示页：不被任何页面链接、不在 sitemap，仅能通过
 *                     「额外入口URL」配置探索到</li>
 *  <li>/isolated-menu1 /isolated-menu2  孤立菜单页：不被任何页面链接，仅在 /sitemap.xml 中登记，
 *                     仅能通过 sitemap 自动发现探索到</li>
 *  <li>/onclick-menu   onclick 导航演示页：仅能通过内联 JS 菜单（location.href）发现</li>
 *  <li>/sitemap.xml    站点地图：登记两个孤立菜单页（验证 sitemap 自动发现）</li>
 *  <li>/login /login-ok /home2   FORM 登录演示站点</li>
 *  <li>/manual-login  MANUAL 人工登录演示页：加载 1.5s 后 JS 种下 Cookie patrol_ok
 *                     （URL 不变化，验证「登录成功Cookie」信号检测）</li>
 * </ul>
 */
public class TestWebServer {

    private static final Logger log = LoggerFactory.getLogger(TestWebServer.class);
    private HttpServer server;
    private int port;
    /** /api/danger（确认类危险端点）被调用次数——巡检点击了确认按钮则 >0，用于断言 */
    private final AtomicInteger dangerCalls = new AtomicInteger();

    public int dangerCallCount() {
        return dangerCalls.get();
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setExecutor(Executors.newFixedThreadPool(8));

        server.createContext("/", this::dispatch);
        server.start();
        port = server.getAddress().getPort();
        log.info("测试站点已启动: http://127.0.0.1:{}/", port);
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
            log.info("测试站点已停止");
        }
    }

    public String baseUrl() {
        return "http://127.0.0.1:" + port;
    }

    private void dispatch(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        // 浏览器会自动请求 favicon，返回 204 避免污染“失败请求”判定
        if (path.equals("/favicon.ico")) {
            ex.sendResponseHeaders(204, -1);
            ex.close();
            return;
        }
        switch (path) {
            case "/", "/index.html" -> ok(ex, html("首页",
                    "<script>console.log('home ok')</script>"
                            + "<a href='/ok-page'>正常页</a>"
                            + "<a href='/broken-api'>接口异常页</a>"
                            + "<a href='/js-error'>JS异常页</a>"
                            + "<a href='/slow'>慢页面</a>"
                            + "<a href='/error404'>404页</a>"
                            + "<a href='/missing-js'>缺资源页</a>"
                            + "<a href='/keyword-page'>关键词页</a>"
                            + "<a href='/query-page'>正常查询页</a>"
                            + "<a href='/query-broken'>异常查询页</a>"
                            + "<a href='/dialog-page'>弹窗演示页</a>"
                            + "<script>fetch('/api/health').then(r=>console.log('health '+r.status))</script>"));
            case "/ok-page" -> ok(ex, html("正常页",
                    "<script>console.info('ok page')</script><a href='/'>返回首页</a>"));
            case "/broken-api" -> ok(ex, html("接口异常页",
                    "<script>fetch('/api/fail').then(r=>{"
                            + "console.error('API 调用失败: '+r.status);"
                            + "document.body.innerHTML+='<p>加载失败</p>'})</script>"));
            case "/js-error" -> ok(ex, html("JS异常页",
                    "<script>setTimeout(function(){throw new Error('模拟未捕获异常');},50)</script>"));
            case "/slow" -> {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                ok(ex, html("慢页面", "<p>slow but fine</p>"));
            }
            case "/error404" -> {
                byte[] body = "Not Found".getBytes(StandardCharsets.UTF_8);
                ex.getResponseHeaders().add("Content-Type", "text/plain; charset=utf-8");
                ex.sendResponseHeaders(404, body.length);
                ex.getResponseBody().write(body);
                ex.close();
            }
            case "/missing-js" -> ok(ex, html("缺资源页",
                    "<script src='/not-exists.js'></script><p>引用了不存在的 JS</p>"));
            case "/keyword-page" -> ok(ex, html("关键词页",
                    "<h1>系统异常</h1><p>出错了，请稍后重试</p>"));
            // ---- 动作巡检（查询按钮）演示 ----
            case "/query-page" -> ok(ex, html("正常查询页",
                    "<input id='kw' placeholder='关键词'>"
                            + "<button id='queryBtn' onclick=\"fetch('/api/query?kw='+encodeURIComponent(document.getElementById('kw').value))"
                            + ".then(r=>console.log('查询完成 '+r.status))\">查询</button>"
                            + "<button id='saveBtn' onclick=\"fetch('/api/danger')\">保存</button>"));
            case "/query-broken" -> ok(ex, html("异常查询页",
                    "<button id='badQueryBtn' onclick=\"fetch('/api/query-fail')"
                            + ".then(r=>{console.error('查询接口失败: '+r.status);})\">搜索</button>"));
            // ---- MANUAL 人工登录演示：登录在弹窗内完成、URL 不变；1.5s 后 JS 种下 Cookie patrol_ok
            //      （模拟人工点击「登录」完成登录，框架靠「登录成功Cookie=patrol_ok」信号检测） ----
            case "/manual-login" -> ok(ex, html("人工登录页",
                    "<button id='loginBtn' onclick=\"document.cookie='patrol_ok=1';"
                            + "document.getElementById('status').textContent='已登录'\">登录</button>"
                            + "<span id='status'></span>"
                            + "<script>setTimeout(function(){"
                            + "document.cookie='patrol_ok=1';"
                            + "var s=document.getElementById('status');"
                            + "if(s){s.textContent='已登录';}"
                            + "},1500)</script>"));
            // ---- 弹窗巡检演示：新增/删除点击后弹窗自动安全关闭，确认按钮绝不点击 ----
            case "/dialog-page" -> ok(ex, html("弹窗演示页",
                    "<button id='addBtn' onclick=\"fetch('/api/dialog-open')"
                            + ".then(r=>console.log('弹窗已打开 '+r.status));"
                            + "document.getElementById('dlg').style.display='block'\">新增用户</button>"
                            + "<button id='delBtn' onclick=\"document.getElementById('dlg2').style.display='block'\">删除用户</button>"
                            + "<button id='exportBtn' onclick=\"location.href='/api/export'\">导出数据</button>"
                            + "<div id='dlg' role='dialog' style='display:none'>"
                            + "<button id='confirmCreate' onclick=\"fetch('/api/danger')\">确认创建</button>"
                            + "<button id='cancel1' onclick=\"document.getElementById('dlg').style.display='none'\">取消</button></div>"
                            + "<div id='dlg2' role='dialog' style='display:none'>"
                            + "<button id='confirmDelete' onclick=\"fetch('/api/danger')\">确认删除</button>"
                            + "<button id='cancel2' onclick=\"document.getElementById('dlg2').style.display='none'\">取消</button></div>"));
            // ---- 可点击元素覆盖演示页：图标按钮/ARIA角色/伪链接/图片链接/外部链接/下载链接/疑似可点击 ----
            case "/coverage-page" -> ok(ex, html("覆盖演示页",
                    "<button id='iconBtn' aria-label='刷新数据' style='width:20px;height:20px'"
                            + " onclick=\"fetch('/api/refresh').then(r=>console.log('刷新 '+r.status))\">✻</button>"
                            + "<div id='cardBtn' role='button' tabindex='0'"
                            + " onclick=\"fetch('/api/aria-click').then(r=>console.log('aria '+r.status))\">卡片按钮</div>"
                            + "<span role='tab' onclick=\"fetch('/api/tab-click')\">标签页一</span>"
                            + "<a id='pseudoLink' onclick=\"fetch('/api/pseudo-click')\">展开更多</a>"
                            + "<a href='/ok-page'><img src='/favicon.ico' alt='图标链接说明'></a>"
                            + "<a href='https://example.com/help'>外部帮助文档</a>"
                            + "<a href='/api/export2'>下载报告</a>"
                            + "<div id='ptrEl' style='cursor:pointer'>纯指针区域</div>"
                            + "<div tabindex='0' id='focusEl'>可聚焦卡片</div>"
                            + "<details><summary id='sumEl'>折叠详情</summary><p>折叠内容</p></details>"
                            + "<label for='nameInput'>名称标签</label><input id='nameInput' type='text'>"
                            + "<select id='selEl'><option>选项一</option></select>"
                            + "<textarea id='memo'></textarea>"));
            case "/api/health" -> json(ex, 200, "{\"status\":\"ok\"}");
            case "/api/fail" -> json(ex, 500, "{\"error\":\"boom\"}");
            case "/api/query" -> json(ex, 200, "{\"list\":[1,2,3],\"total\":3}");
            case "/api/query-fail" -> json(ex, 500, "{\"error\":\"query boom\"}");
            case "/api/dialog-open" -> json(ex, 200, "{\"dialog\":\"create-user\"}");
            case "/api/refresh" -> json(ex, 200, "{\"refreshed\":true}");
            case "/api/aria-click" -> json(ex, 200, "{\"aria\":true}");
            case "/api/tab-click" -> json(ex, 200, "{\"tab\":1}");
            case "/api/pseudo-click" -> json(ex, 200, "{\"expanded\":true}");
            case "/api/danger" -> {
                dangerCalls.incrementAndGet();
                json(ex, 200, "{\"touched\":true}");
            }
            case "/api/export" -> {
                // 导出下载：Content-Disposition 触发浏览器下载事件（不导航）
                ex.getResponseHeaders().add("Content-Type", "application/octet-stream");
                ex.getResponseHeaders().add("Content-Disposition",
                        "attachment; filename=\"patrol-export.txt\"");
                byte[] body = "patrol export demo".getBytes(StandardCharsets.UTF_8);
                ex.sendResponseHeaders(200, body.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(body);
                }
            }
            case "/api/export2" -> {
                // 下载链接演示：<a href> 命中下载关键词被真实点击，触发浏览器下载事件
                ex.getResponseHeaders().add("Content-Type", "application/octet-stream");
                ex.getResponseHeaders().add("Content-Disposition",
                        "attachment; filename=\"patrol-export2.txt\"");
                byte[] body = "patrol export via link".getBytes(StandardCharsets.UTF_8);
                ex.sendResponseHeaders(200, body.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(body);
                }
            }
            case "/not-exists.js" -> {
                byte[] body = "not found".getBytes(StandardCharsets.UTF_8);
                ex.sendResponseHeaders(404, body.length);
                ex.getResponseBody().write(body);
                ex.close();
            }
            // ---- 孤立菜单页面探索演示 ----
            // 首页：hash 路由菜单 + onclick 内联导航菜单（模拟老系统/JS 动态菜单的常见写法）
            case "/isolated-home" -> ok(ex, html("孤立菜单首页",
                    "<a href='#/hash-menu-a'>hash菜单A</a>"
                            + "<a href='#/hash-menu-b'>hash菜单B</a>"
                            + "<button onclick=\"location.href='/onclick-menu'\">onclick菜单</button>"));
            // 仅能通过「额外入口URL」配置发现
            case "/hidden-page" -> ok(ex, html("隐藏页面", "<p>额外入口探索演示页</p>"));
            // 仅在 sitemap 中登记，不被任何页面链接
            case "/isolated-menu1" -> ok(ex, html("孤立菜单1", "<p>sitemap 发现演示页 1</p>"));
            case "/isolated-menu2" -> ok(ex, html("孤立菜单2", "<p>sitemap 发现演示页 2</p>"));
            // 仅能通过 onclick 内联导航发现
            case "/onclick-menu" -> ok(ex, html("onclick菜单页", "<p>onclick 导航演示页</p>"));
            case "/sitemap.xml" -> {
                String body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        + "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">"
                        + "<url><loc>" + baseUrl() + "/isolated-menu1</loc></url>"
                        + "<url><loc>" + baseUrl() + "/isolated-menu2</loc></url>"
                        + "<url><loc>https://external.example.com/other</loc></url>"
                        + "</urlset>";
                ex.getResponseHeaders().add("Content-Type", "application/xml; charset=utf-8");
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                ex.sendResponseHeaders(200, bytes.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(bytes);
                }
            }
            // ---- FORM 登录演示站 ----
            case "/login" -> ok(ex, html("登录",
                    "<form action='/login-ok' method='get'>"
                            + "<input id='username' name='username'>"
                            + "<input id='password' name='password' type='password'>"
                            + "<button id='loginBtn' type='submit'>登录</button></form>"));
            case "/login-ok" -> {
                // 登录成功设置会话 cookie，使登录态(storageState)有实际内容可缓存
                ex.getResponseHeaders().add("Set-Cookie",
                        "sid=session-" + System.currentTimeMillis() + "; Path=/; HttpOnly");
                ok(ex, html("登录成功",
                        "<p>欢迎回来 <a href='/home2'>进入系统</a> <a href='#'>退出登录</a></p>"));
            }
            case "/home2" -> ok(ex, html("系统首页",
                    "<script>console.log('home2 ready')</script><p>已登录系统</p>"));
            default -> {
                byte[] body = "Not Found".getBytes(StandardCharsets.UTF_8);
                ex.sendResponseHeaders(404, body.length);
                ex.getResponseBody().write(body);
                ex.close();
            }
        }
    }

    private void ok(HttpExchange ex, String html) throws IOException {
        byte[] body = html.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
        ex.sendResponseHeaders(200, body.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(body);
        }
    }

    private void json(HttpExchange ex, int status, String json) throws IOException {
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, body.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(body);
        }
    }

    private static String html(String title, String bodyContent) {
        return "<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-8\"><title>" + title
                + "</title></head><body><h1>" + title + "</h1>" + bodyContent + "</body></html>";
    }
}
