# frontend-patrol — Excel 驱动的前端巡检框架

基于 **Spring Boot 4.1.1 / Java 17 / Playwright 1.32.0** 的多站点 WEB 前端自动巡检框架
（Excel 读写基于 **EasyExcel 4.0.1**，报告 JSON 基于 **Jackson 2.21.1**，测试框架 **TestNG 7.7.1**）：
通过 Excel 配置多个站点的访问链接与认证信息，**先统一完成登录认证（有头模式），再以无头模式并行巡检**；
自动探索站内页面，对 **前端页面 + 后端请求 + console 日志** 进行嗅探与健康判定；
解析页面可交互元素，按三类安全策略**自动点击操作按钮**并对动作触发的接口/console/JS 异常独立校验；
异常页面自动保存 **全页截图 + 上下文 JSON 证据**，最终输出 HTML / Excel / JSON 三份详细报告，
并自动维护 **历次巡检索引页**。

## 核心能力

| 能力 | 说明 |
|---|---|
| Excel 多站点配置 | 一个 `sites.xlsx` 配置 N 个站点。双表结构：**Sites 主表（11 列核心字段）** + **站点高级配置 sheet（可选覆盖项，全留空=全局默认）**；中英文表头均可，旧版宽表向后兼容 |
| **两阶段认证** | 阶段一·预认证（**有头模式，串行**）：FORM 自动填表 / MANUAL / SSO 弹窗人工登录（验证码/短信均可），登录态保存 storageState 并缓存 `login-state/`（TTL 默认 480 分钟，跨巡检免登录）；阶段二·巡检（**无头模式**）只加载缓存登录态，缺失即站点 FAIL。六种认证：`NONE` / `BASIC` / `FORM` / `TOKEN` / `MANUAL` / `SSO` |
| **并行多实例巡检** | `patrol.max-parallel-sites` 配置最大并行度（默认 1 串行）；线程池+队列调度，每个 worker 持有**独立 Playwright 实例 + 无头浏览器**；认证失败站点不阻断其他站点；结果按 Excel 配置顺序汇总 |
| 自动探索 | 从入口页 BFS 探索同源链接，受 `最大页面数 / 最大深度 / 路径前缀过滤` 控制；报告记录**页面探索结构树**（父子关系）与**子页面链接台账**（锚文本 / 是否已巡检 / 子页面结论） |
| 三路嗅探 | 每页采集：① console 日志（含 error/warning 分级）② 未捕获 JS 异常 ③ 全部后端请求（状态码/耗时/资源类型/失败原因/响应片段） |
| **动作巡检·三类安全策略** | **全面解析页面可点击元素**（原生控件 / 导航链接 / 图片链接 / JS 伪链接 / onclick 元素 / ARIA 可点击角色 / cursor:pointer 疑似可点击组件），文本识别兜底链 `aria-label → title → innerText → img alt → svg title`；按策略处理：① 确认类（保存/提交/确认/登录/退出…）**永不点击**；② 弹窗类（新增/编辑/删除/上传/导入…）**点击打开弹窗后自动安全关闭，绝不点确认**；③ 下载类（导出/下载…，含下载链接）**真实执行下载并记录文件名与来源 URL**；④ 同源导航链接/图片链接**不点击**（由探索阶段巡检目标页面）；⑤ 外部链接**不点击**；⑥ JS 伪链接（无 href/#/javascript:）作为可点击控件巡检；⑦ 疑似可点击（cursor:pointer 无语义标记）**悬停探测**（ALL 模式，展开的菜单选项纳入巡检，见下「通用 DOM 增量探测」）；每个元素都有**类别 + 决策台账**（为什么点 / 为什么不点）；点击后独立采集该动作触发的请求与 console，动作级判定 |
| 统一 locale | `patrol.browser.locale`（默认 zh-CN）对认证与巡检所有上下文生效，保证有头认证与无头巡检界面语言一致，文本类选择器（如登录按钮「登录」/「Sign in」）不随系统语言漂移 |
| **通用 DOM 增量探测** | 凡可能引发 DOM 增量的操作都自动探测「新展现」元素（新插入 DOM 或由不可见变可见），按主流程同套路由纳入动作队列**继续点击巡检**。增量源全覆盖：① **点击**（table/td 菜单的下拉/弹窗/浮层，在浮层关闭前探测）；② **悬停探测**（cursor:pointer 疑似可点击元素 hover——老式系统悬停展开菜单的选项纳入巡检，选项点击时菜单已收起会自动用 hover 重展开）；③ **原生下拉框逐项选择**（逐个选 option 触发级联渲染，联动区域/子下拉纳入巡检）；④ **页面稳定期复扫**（初始扫描后等待异步渲染——懒加载/定时脚本/延迟组件，新展现元素并入初始计划）；⑤ **表单填充**（自定义动作 fills 触发的输入建议/自动补全下拉立即探测）。**QUERY 模式下操作引发的增量元素同样巡检**（主动操作的结果是巡检的直接延伸，仅初始元素受查询关键词过滤；增量元素仍走确认类排除词与下载/弹窗安全分类）。下拉重渲染的同结构选项按指纹去重只巡检一次；嵌套子层最多探测 2 层；弹窗内按钮同样适用（确认类仍被排除词挡住）。可配：`dom-stable-rescan-ms` / `max-hover-probes-per-page` / `max-select-options-probe`（0=禁用） |
| 自定义动作 | 「页面动作」sheet 可按 URL 匹配配置任意元素的显式点击（支持点击前填充表单），用于暂不自动化的复杂功能点 |
| 健康判定 | 页面访问 6 条规则（主文档状态码/JS 异常数/console 错误数/失败请求数/加载耗时/错误关键词）+ 动作结论聚合，页面结论 = 访问与全部动作的最差值 |
| 异常取证 | WARN/FAIL 页面与动作均保存全页 PNG 截图 + 上下文 JSON（问题清单、console、失败请求及响应片段、HTML 摘录） |
| 三份报告 + 历次索引 | `report.html`（可视化：探索结构树 / 子页面链接 / 按钮台账 / 动作卡片）+ `patrol-report.xlsx`（**七 sheet**：总览 / 页面明细 / 动作明细 / 子页面链接 / 页面元素 / 失败请求 / Console错误）+ `patrol-result.json`（原始数据）；每次巡检自动更新 `reports/index.html` **历次巡检索引页**（卡片式趋势总览，一键打开任意一次报告） |
| CI 友好 | 任一站点 FAIL 且 `patrol.strict-exit=true` 时进程退出码为 1；配置错误启动即 fail-fast（中文行号提示） |

## 快速开始

```bash
# 1. 安装 Chromium（首次使用执行一次）
mvn compile exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"

# 2. 生成巡检配置模板并填写（Sites 主表 + 站点高级配置 + 页面动作 + 字段说明）
run.bat template        # Windows（Linux/macOS: ./run.sh template）

# 3. 执行巡检
run.bat                 # Windows（Linux/macOS: ./run.sh）
```

> 上述为一键脚本方式；全部运行方式（**一键脚本 / Maven / IDE 直接调试 / java -jar / 测试**）见下文「运行方式」。

巡检完成后：

- **历次报告索引**：`reports/index.html`（推荐从这里进入）
- 本次报告：`reports/patrol-<时间戳>/`（report.html / patrol-report.xlsx / patrol-result.json）
- 截图与上下文：`reports/patrol-<时间戳>/evidence/<站点名>/`

## 运行方式

框架是标准 **Spring Boot 工程**，唯一入口类为 `com.patrol.PatrolApplication`（纯 CLI 应用，不启动 Web 容器）。
提供 5 种运行方式，按场景选用：

| # | 方式 | 适用场景 |
|---|---|---|
| 1 | 一键脚本 `run.bat` / `run.sh` | 日常巡检，双击即用（内置 Maven 路径自适应） |
| 2 | `mvn spring-boot:run` | 命令行 / CI 流水线 |
| 3 | **IDE 直接 Run / Debug**（开发推荐） | 断点调试巡检引擎与认证流程 |
| 4 | `mvn package` + `java -jar` | 部署到无 Maven 环境 / 定时任务 |
| 5 | `mvn test` | 全量回归测试（TestNG，不依赖外部站点） |

### 1) 一键脚本

```bash
run.bat              # Windows：执行巡检（双击亦可）
run.bat template     # Windows：生成配置模板后退出
./run.sh             # Linux / macOS：执行巡检
./run.sh template    # Linux / macOS：生成配置模板后退出
```

### 2) Maven 运行

```bash
mvn spring-boot:run                                              # 巡检（默认 config/sites.xlsx）
mvn spring-boot:run -Dspring-boot.run.arguments="--excel=config/my-sites.xlsx"   # 指定配置
mvn spring-boot:run -Dspring-boot.run.arguments=--gen-template   # 生成配置模板
```

### 3) IDE 直接运行 / 调试（开发推荐）

直接运行 `PatrolApplication` 的 main 方法即可，**无需任何参数**——默认读取 `config/sites.xlsx`，
全部默认值见 `application.yml`；需要换配置文件或生成模板时，把 `--excel=...` / `--gen-template`
作为 **Program arguments** 传入。断点建议：总编排 `PatrolRunner.run()`、认证 `AuthSupport`、
探索与动作 `PageExplorer` / `PageInteractor`。

- **IntelliJ IDEA**：工程已内置共享运行配置 `.run/`（`patrol-inspect` 巡检 / `patrol-gen-template` 生成模板），打开工程即可在运行配置下拉框选择 Run 或 **Debug**；也可直接右键 `PatrolApplication` → Debug。
- **VS Code**：工程已内置 `.vscode/launch.json`，按 F5 选择「frontend-patrol 巡检 (Run/Debug)」即可断点调试。
- 认证弹窗阶段想慢放观察，可在 `application.yml` 设 `patrol.browser.slow-mo-ms: 300`。

### 4) 打包运行（可执行 jar）

```bash
mvn package -DskipTests
java -jar target/frontend-patrol-1.0.0.jar                              # 默认 config/sites.xlsx
java -jar target/frontend-patrol-1.0.0.jar --excel=config/sites.xlsx    # 指定配置
java -jar target/frontend-patrol-1.0.0.jar --gen-template               # 生成配置模板
```

> jar 为 spring-boot repackage 的 fat jar；运行机器需先安装 Chromium
> （`mvn compile exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"`）。

### 5) 测试

```bash
mvn test          # 全量回归（TestNG；内置测试 Web 服务器，不依赖外部站点）
```

其中 `PatrolRunnerTest` 是**全局运行入口**用例（双模式）：

- **全保真模式（IDE 直接 Run/Debug，默认）**：与直接运行 `PatrolApplication` **效果完全一致**——
  零参数走真实链路：真实 `config/sites.xlsx` → 阶段一有头认证（登录态 TTL 内免弹窗）→
  阶段二无头并行巡检 → 报告输出真实 `reports/` 并更新索引 → strict-exit 退出码。
  **在 IDE 中 Debug 该用例，即可断点调试一次真实巡检**。
- **隔离模式（`mvn test` 自动切换）**：surefire 注入 `patrol.runner.test.isolated=true`，
  改用内置测试站点与 `target/` 隔离目录，保证回归确定性、不依赖外部站点、不弹登录窗；
  如需在 mvn 中强制全保真：`PATROL_RUNNER_TEST_ISOLATED=false mvn test -Dtest=PatrolRunnerTest`。

## 运行参数

| 参数 | 说明 | 默认 |
|---|---|---|
| `--excel=路径` | 巡检配置 Excel | `config/sites.xlsx` |
| `--gen-template` | 只生成配置模板后退出 | — |
| `patrol.max-parallel-sites` | 多站点并行巡检最大并行度（Playwright 实例数） | `1` |
| `patrol.browser.type` | chromium / firefox / webkit | `chromium` |
| `patrol.browser.slow-mo-ms` | 慢放调试（认证弹窗与无头巡检阶段均生效） | `0` |
| `patrol.login-state-dir` | 登录态缓存目录 | `login-state` |
| `patrol.defaults.*` | 全局默认阈值/探索/动作参数 | 见 `application.yml` |
| `patrol.strict-exit` | FAIL 时退出码 1 | `true` |

> 认证阶段固定「有头」、巡检阶段固定「无头」，无需也无法配置 headless 开关。

## 执行架构

```
sites.xlsx
    │
    ├─ 阶段一 · 预认证（有头模式 · 串行）
    │    ├─ FORM  → 有头浏览器自动填表登录
    │    ├─ MANUAL/SSO → 弹出浏览器窗口人工登录
    │    ├─ 登录态 storageState 缓存 login-state/<站点>.json（TTL 内复用）
    │    └─ 认证失败 → 记录错误，站点判 FAIL 不阻断其他站点
    │
    └─ 阶段二 · 并行巡检（无头模式 · Playwright 多实例）
         ├─ 线程池 max-parallel-sites 个 worker，队列调度
         ├─ 每 worker：独立 Playwright 实例 + 无头浏览器，循环领取站点
         └─ 每站点：四路页面发现（BFS 链接探索[含 onclick 导航] + hash 路由 + 额外入口 + sitemap）
              → 页面访问嗅探（console/JS/请求）
              → 按钮台账 + 三类策略动作点击
              → 规则判定 → 异常取证（截图+上下文）
                   ↓
         汇总（按配置顺序）→ JSON / Excel(7 sheet) / HTML 报告
              → reports/index.html 历次索引
```

## Excel 配置（双表结构，降低配置门槛）

配置文件为**双表结构**：日常巡检只填 `Sites` 主表（11 列核心字段）；需要个性化调优时才用 `站点高级配置` sheet。

**Sites 主表**（核心字段）：

| 列 | 必填性 | 说明 |
|---|---|---|
| `站点名称` / `入口URL` | 必填 | 站点唯一标识 / 巡检起始地址 |
| `启用` | 默认 true | false/否/0 时跳过该站点 |
| `认证方式` | 默认 NONE | NONE / BASIC / FORM / TOKEN / MANUAL / SSO |
| `用户名` / `密码` | BASIC/FORM 使用 | 认证凭据 |
| `登录URL` | FORM 必填，MANUAL 可选 | 登录页地址（MANUAL 不填则打开入口URL） |
| `用户名选择器` / `密码选择器` / `提交按钮选择器` | FORM 必填 | 登录页元素 CSS 选择器 |
| `备注` | 可选 | 任意说明 |

**站点高级配置 sheet**（可选，按 `站点名称` 关联主表行；**全部留空 = 使用 application.yml 全局默认值**）：

- **探索**：`最大页面数`、`最大深度`、`包含路径前缀`、`排除路径前缀`（建议排除 `/logout`；API 前缀如 `/api` 也可排除，避免下载/接口被当页面巡检）
  - **四路发现确保孤立菜单页面不遗漏**：① BFS 同源链接探索（`a[href]` / `area[href]` 图片地图 / `onclick` 内联 JS 导航 `location.href='…'`、`window.open`——老系统 JS 菜单常见写法）；② **hash 路由 SPA**（`#/menu`、`#!/menu`）每个 hash 菜单视为独立页面；③ **额外入口URL**：链接不可达的孤立页面在此登记（逗号分隔，支持相对路径如 `/tools`），作为 depth 0 种子直接探索；④ **Sitemap 自动发现**（默认开启）：探索前抓取同源 `/sitemap.xml` 自动补充孤立页面，无 sitemap 则静默跳过
- **动作巡检**：`启用动作巡检`、`动作模式`（QUERY=只点查询类；ALL=全量按钮遍历）、`动作数上限`、`查询按钮关键词`、`排除按钮关键词`、`对话框按钮关键词`、`下载按钮关键词`
  - 三类按钮策略（ALL 模式）：**确认类**（保存/提交/确认/登录/退出…）永不点击；**弹窗类**（新增/编辑/删除/上传/导入…）点击打开弹窗巡检后自动安全关闭，绝不点击弹窗内确认按钮；**下载类**（导出/下载…）真实执行并记录下载文件名/URL；原生 confirm/alert 自动 dismiss（同样不确认）
  - 只点击可见按钮（隐藏在下拉/弹窗中的按钮只入元素台账不点击）；被浮层遮挡/瞬时不可交互的点击标记「跳过」不判失败；点击导致页面跳转时自动终止该页剩余动作
- **健康阈值**：`Console错误上限`、`JS异常上限`、`失败请求上限`、`加载超时(ms)`、`错误关键词`
- **登录辅助**：`登录成功标识`、`登录成功URL包含`、`复用登录状态`（登录态缓存 TTL 默认 480 分钟）、`手动登录超时(秒)`
- **TOKEN 认证**：`Token请求头`、`Token值`

> **向后兼容**：旧版 33 列宽表格式无需迁移仍可正常加载（表头按别名解析、列序无关）。
> 完整字段说明见模板内的「字段说明」「高级配置说明」sheet。

**「页面动作」sheet**（可选）：`站点名称 / 页面URL匹配 / 动作类型 / 元素选择器 / 填充值 / 说明 / 启用`，
按 URL 匹配对指定元素执行显式点击（`填充值` 格式 `选择器=值`，分号分隔多项）。

## 工程结构

```
工程根目录
├── run.bat / run.sh                # 一键巡检脚本
├── .run/                           # IntelliJ IDEA 共享运行配置（IDE 打开工程即可 Run/Debug）
├── .vscode/launch.json             # VS Code 调试启动配置（F5 即可断点调试）
├── config/sites.xlsx               # 巡检配置（双表结构，含示例行）
├── login-state/                    # 登录态缓存（TTL 内复用免登录）
├── reports/                        # 报告输出根目录（index.html = 历次巡检索引）
└── src/main/java/com/patrol/
    ├── PatrolApplication.java      # Spring Boot 入口（IDE 直接 Run/Debug 本类）
    ├── runner/PatrolRunner.java      # 巡检总指挥：两阶段编排（认证→并行巡检）→汇总→报告+索引
    ├── excel/                        # Excel 配置加载（含认证字段校验）/ 站点与动作模型 / 模板生成
    ├── engine/                       # PatrolEngine(线程安全) / BFS 探索 / PageInteractor 动作巡检
    │                                 #   / AuthSupport(两阶段认证) / PlaywrightFactory
    ├── sniffer/PageSniffer.java      # console / pageError / 网络请求嗅探器（按访问窗口复位）
    ├── judge/HealthJudge.java        # 规则式健康判定（PASS/WARN/FAIL）
    ├── evidence/EvidenceManager.java # 页面级 + 动作级异常取证（截图 + 上下文 JSON）
    ├── report/                       # HTML / Excel(7 sheet) / JSON 报告 + 历次索引页生成
    └── model/                        # 巡检数据模型（record）
```

## 测试

```bash
mvn test
```

`PatrolRunnerTest`（**全局运行入口**，1 个用例，双模式）：
- **全保真模式（IDE 直接 Run/Debug，默认）**：零参数调用生产入口 `SpringApplication.run`，
  与直接运行 `PatrolApplication` 完全一致——真实 `config/sites.xlsx` / 真实登录态缓存 /
  报告输出 `reports/` 并更新索引 / strict-exit 退出码，断言「退出码 ↔ 站点结论一致性」。
- **隔离模式（`mvn test` 自动切换，surefire 注入 `patrol.runner.test.isolated=true`）**：
  内置测试站点 + `target/` 隔离目录（并行度=2 验证 worker 池），断言两阶段 FORM 认证、
  登录态缓存生成、结果按 Excel 配置顺序汇总、退出码 1；环境变量
  `PATROL_RUNNER_TEST_ISOLATED=false|true` 可强制指定任一模式。

`PatrolIntegrationTest`（**31 个用例**）会启动内置异常演练站点（500 接口 / JS 异常 / 404 / 缺失资源 /
慢页面 / 错误关键词 / 查询按钮成功与失败 / 确认类按钮排除 / 弹窗点击不确认 / 导出下载记录 /
FORM 登录与登录态缓存复用 / 可点击元素全面识别与路由 / **table 下拉菜单选项全量点击与重展开父菜单** /
**通用 DOM 增量探测（悬停菜单 / 原生下拉级联 / 异步渲染稳定复扫 / 填充联动输入建议，
及其开关禁用与选项上限截断的配置边界）** / 高级配置 sheet 合并语义 / 旧版宽表兼容 /
**孤立菜单页面四路全探索（链接 / hash 路由 / 额外入口 / sitemap）** /
**并行多站点两阶段端到端（认证失败站点不阻断）**），
执行完整巡检链路并断言判定结果、动作明细、证据文件、三份报告与索引页的产出。

## FAQ

- **Chromium 下载慢 / 卡住**：使用镜像 `PLAYWRIGHT_DOWNLOAD_HOST=https://npmmirror.com/mirrors/playwright mvn compile exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"`
- **MANUAL 登录窗口等待太久**：配置 `登录成功标识` 或 `登录成功URL包含` 可提前结束等待；也可调小 `手动登录超时(秒)`
- **登录态失效**：删除 `login-state/<站点>.json` 强制重登，或配置该站点 `复用登录状态=false`
- **误报 SPA 不可交互**：被浮层遮挡的点击自动标记「跳过」不判失败，可在报告「页面元素」sheet 查看决策原因
- **报告太多**：历次索引页按时间倒序排列；旧报告目录可按需归档（目录自包含，整体移动即可）
