package com.patrol.engine;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.LoadState;
import com.patrol.config.PatrolProperties;
import com.patrol.evidence.EvidenceManager;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.model.ActionInspection;
import com.patrol.model.ElementDigest;
import com.patrol.model.Verdict;
import com.patrol.sniffer.PageSniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 页面交互器：全面解析页面可点击元素（原生控件 / 导航链接 / 图片链接 / JS 伪链接 /
 * onclick 元素 / ARIA 可点击角色 / 疑似可点击组件），并对可安全点击的元素执行动作，
 * 采集动作触发的后端请求 / console 日志 / JS 异常并判定。
 *
 * <p>元素处理策略：</p>
 * <ul>
 *   <li>确认类（保存/提交/确认/登录/退出…）：永不点击</li>
 *   <li>弹窗类（新增/编辑/删除…）：点击打开弹窗巡检，随后自动安全关闭、绝不确认</li>
 *   <li>下载类（导出/下载…）：真实执行并记录下载文件</li>
 *   <li>导航链接/图片链接（同源）：不点击——由 BFS 探索阶段统一巡检其目标页面</li>
 *   <li>外部链接：不点击（跨站跳转不可控）</li>
 *   <li>JS 伪链接（无 href / # / javascript:）：作为可点击控件巡检</li>
 *   <li>疑似可点击（cursor:pointer 无语义标记）：悬停探测（ALL 模式）</li>
 * </ul>
 *
 * <p>通用 DOM 增量探测（队列驱动）：凡可能引发 DOM 增量的操作都自动探测「新展现」元素
 * （运行时新插入 DOM，或原本存在但由不可见变可见），按主流程同套路由纳入动作队列继续点击巡检。
 * 增量源五类：① 点击（table/td 菜单的下拉/弹窗/浮层，在浮层关闭前探测）；② 悬停探测
 * （cursor:pointer 疑似可点击元素 hover——老式系统悬停展开菜单，选项不可见时自动用 hover 重展开）；
 * ③ 原生下拉框逐项选择（逐个选 option 触发级联渲染，联动区域/子下拉纳入巡检）；
 * ④ 页面稳定期复扫（初始扫描后等待异步渲染——懒加载/定时脚本/延迟组件，新展现元素并入初始计划）；
 * ⑤ 表单填充（自定义动作 fills 触发的输入建议/自动补全下拉立即探测）。
 * 操作引发的增量元素不受 QUERY 关键词过滤（主动操作的结果是巡检的直接延伸，仅初始元素受过滤；
 * 增量元素仍走确认类排除词与下载/弹窗安全分类）。下拉重渲染的同结构选项按指纹去重只巡检一次；
 * 嵌套子层最多探测 2 层；弹窗内按钮同样适用（确认类仍被排除词挡住）。</p>
 *
 * <p>局限：通过 addEventListener 绑定且未设置 role/onclick/cursor:pointer 的元素无法静态识别。</p>
 */
public class PageInteractor {

    private static final Logger log = LoggerFactory.getLogger(PageInteractor.class);

    /** 元素可见性台账：pid → 上次扫描是否可见，用于识别操作后「新展现」元素（新插入 DOM 或由不可见变可见） */
    private final Map<String, Boolean> knownVisibility = new LinkedHashMap<>();
    /** 本页剩余悬停探测配额（每页上限见 PatrolProperties.maxHoverProbesPerPage，0=禁用） */
    private int remainingHoverProbes;
    /** 台账总量硬顶：下拉重渲染的重复元素可能持续膨胀台账，防止报告失控 */
    private static final int ELEMENT_LEDGER_CAP = 400;
    /** 增量探测嵌套深度上限：下拉的下拉最多再探 2 层 */
    private static final int MAX_EXPAND_DEPTH = 2;

    /**
     * 页面可点击元素识别 + 定位用的组合选择器（第一遍语义化扫描）。
     * 覆盖：原生控件（button/a/input/select/textarea/summary/label/area）、
     * ARIA 可点击角色（role=button/link/tab/menuitem/option/switch/checkbox/radio）、
     * 内联事件（[onclick]）、可聚焦元素（[tabindex]）。
     */
    static final String CLICKABLE_SELECTOR = String.join(",",
            "button", "a", "input", "select", "textarea", "summary", "label[for]", "area[href]",
            "[role=button]", "[role=link]", "[role=tab]", "[role=menuitem]", "[role=option]",
            "[role=switch]", "[role=checkbox]", "[role=radio]", "[role=menuitemradio]",
            "[role=menuitemcheckbox]",
            "[onclick]", "[tabindex]:not([tabindex='-1'])");

    /**
     * 两遍扫描识别可点击元素：
     * 第一遍按 {@link #CLICKABLE_SELECTOR} 语义化识别（原生控件/ARIA 角色/onclick/tabindex），
     * 第二遍扫描 cursor:pointer 且无语义标记的元素（框架 addEventListener 组件）标记为「疑似可点击」。
     * 文本提取兜底链：innerText/value → aria-label → title → img[alt] → svg title。
     * 每个元素分配运行时持久 ID（DOM expando，跨多次扫描识别同一元素）与稳定 CSS 路径。
     */
    private static final String JS_PARSE_ELEMENTS = """
            sel => {
              const out = [];
              const seen = new Set();
              const isVisible = el => typeof el.checkVisibility === 'function'
                  ? el.checkVisibility({checkVisibilityCSS: true})
                  : !!(el.offsetParent || el.getClientRects().length > 0);
              const clsOf = el => {
                const c = (el.className && el.className.baseVal !== undefined)
                    ? el.className.baseVal : el.className;
                return (c || '').toString().slice(0, 60);
              };
              const pidOf = el => {
                // 持久 expando ID：计数器必须挂在 window 上（局部计数器会在多次扫描间
                // 重复发号，导致新元素与旧元素 pid 冲突、增量探测漏报）
                if (!el.__patrolId) {
                  window.__patrolGpid = (window.__patrolGpid || 0) + 1;
                  el.__patrolId = 'p' + window.__patrolGpid;
                }
                return el.__patrolId;
              };
              const cssPathOf = el => {
                const parts = [];
                let n = el;
                while (n && n.nodeType === 1 && parts.length < 12) {
                  const seg = n.tagName.toLowerCase();
                  if (n.id) {
                    parts.unshift(seg + '#' + n.id.replace(/([^\\w-])/g, '\\\\$1'));
                    break;
                  }
                  const parent = n.parentElement;
                  let idx = 1, sib = n;
                  while ((sib = sib.previousElementSibling)) {
                    if (sib.tagName === n.tagName) idx++;
                  }
                  parts.unshift(seg + ':nth-of-type(' + idx + ')');
                  n = parent;
                }
                return parts.join(' > ');
              };
              const textOf = el => {
                // 无障碍名称优先：aria-label / title 高于可见文本（图标按钮依赖它们识别）
                let t = (el.getAttribute('aria-label') || '').trim();
                if (!t) t = (el.getAttribute('title') || '').trim();
                if (!t) t = (el.innerText || '').trim();
                // 原生下拉框：innerText 为全部选项拼接，取当前选中项文本更有意义
                if (!t && el.tagName === 'SELECT') {
                  t = (el.selectedOptions && el.selectedOptions[0]
                      ? el.selectedOptions[0].textContent : '').trim();
                }
                if (!t && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) t = (el.value || '').trim();
                if (!t) {
                  const img = el.querySelector('img[alt], img[title]');
                  if (img) t = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
                }
                if (!t) {
                  const st = el.querySelector('svg title');
                  if (st) t = (st.textContent || '').trim();
                }
                return t.slice(0, 40);
              };
              let idx = 0;
              for (const el of document.querySelectorAll(sel)) {
                if (seen.has(el)) continue;
                seen.add(el);
                const tag = el.tagName.toLowerCase();
                const role = (el.getAttribute('role') || '').toLowerCase();
                const type = (el.getAttribute('type') || '').toLowerCase();
                const hrefAttr = el.getAttribute('href');
                const isAnchor = tag === 'a' || tag === 'area';
                let kind = 'OTHER';
                if (isAnchor) {
                  const h = (hrefAttr || '').trim().toLowerCase();
                  if (!hrefAttr || hrefAttr === '#' || h.startsWith('#') || h.startsWith('javascript:')) {
                    kind = 'PSEUDO_LINK';
                  } else {
                    const hasText = (el.innerText || '').trim().length > 0;
                    kind = (!hasText && el.querySelector('img, svg')) ? 'IMAGE_LINK' : 'LINK';
                  }
                } else if (tag === 'button' || role === 'button'
                    || (tag === 'input' && ['button','submit','reset','image'].includes(type))) {
                  kind = 'BUTTON';
                } else if (tag === 'summary') {
                  kind = 'SUMMARY';
                } else if (role === 'link' || role === 'tab' || role === 'menuitem' || role === 'option'
                    || role === 'switch' || role === 'checkbox' || role === 'radio'
                    || role.startsWith('menuitem')) {
                  kind = 'ARIA';
                } else if (el.hasAttribute('onclick')) {
                  kind = 'ONCLICK';
                } else if (tag === 'input') {
                  kind = 'INPUT';
                } else if (tag === 'select') {
                  kind = 'SELECT';
                } else if (tag === 'textarea') {
                  kind = 'TEXTAREA';
                } else if (tag === 'label') {
                  kind = 'LABEL';
                } else if (el.tabIndex >= 0) {
                  kind = 'TABINDEX';
                }
                out.push({
                  idx: idx,
                  tag: tag,
                  text: textOf(el),
                  id: el.id || '',
                  cls: clsOf(el),
                  type: el.getAttribute('type') || '',
                  kind: kind,
                  href: isAnchor ? (el.href || '') : '',
                  selector: sel + ' >> nth=' + idx,
                  pid: pidOf(el),
                  path: cssPathOf(el),
                  visible: isVisible(el)
                });
                idx++;
              }
              // 第二遍：疑似可点击（cursor:pointer 但无语义标记）——悬停探测候选（ALL 模式）
              let ptr = 0;
              for (const el of document.querySelectorAll('div, span, li, i, svg, td, p')) {
                if (seen.has(el) || ptr >= 80) continue;
                if (getComputedStyle(el).cursor !== 'pointer') continue;
                if (!isVisible(el)) continue;
                if ((el.innerText || '').trim().length > 30) continue;
                if (el.querySelector('button, a, [role=button], [onclick], input, select')) continue;
                seen.add(el);
                ptr++;
                out.push({
                  idx: -1,
                  tag: el.tagName.toLowerCase(),
                  text: textOf(el),
                  id: el.id || '',
                  cls: clsOf(el),
                  type: '',
                  kind: 'POINTER',
                  href: '',
                  selector: 'cursor-pointer#' + ptr,
                  pid: pidOf(el),
                  path: cssPathOf(el),
                  visible: true
                });
              }
              return out;
            }
            """;

    private final SiteConfig site;
    private final PatrolProperties properties;
    private final Page page;
    private final PageSniffer sniffer;
    private final EvidenceManager evidence;
    /** 页面级下载采集日志（PatrolEngine 注册的 onDownload 监听写入，动作用下标切分归因） */
    private final List<String> downloadLog;

    public PageInteractor(SiteConfig site, PatrolProperties properties, Page page,
                          PageSniffer sniffer, EvidenceManager evidence, List<String> downloadLog) {
        this.site = site;
        this.properties = properties;
        this.page = page;
        this.sniffer = sniffer;
        this.evidence = evidence;
        this.downloadLog = downloadLog == null ? new ArrayList<>() : downloadLog;
    }

    public record InteractorResult(List<ElementDigest> elements, List<ActionInspection> actions) {
    }

    /** 单动作执行结果：动作巡检记录 + 该操作引发的「新展现」元素（供入队继续巡检） */
    private record ExecuteOutcome(ActionInspection action, List<ElementDigest> revealed) {
    }

    /**
     * 解析页面元素并执行动作（队列驱动：自定义动作 + 初始元素 + 操作引发的增量元素）。
     *
     * @param pageUrl       当前页面 URL（用于自定义动作匹配）
     * @param pageIdx       页面序号（证据命名）
     * @param customActions 该站点的自定义动作配置
     */
    public InteractorResult runActions(String pageUrl, int pageIdx,
                                        List<PageActionConfig> customActions) {
        knownVisibility.clear();
        remainingHoverProbes = properties.getDefaults().getMaxHoverProbesPerPage();

        // 1. 元素解析（初始）
        List<ElementDigest> elements = new ArrayList<>(parseElements());
        for (ElementDigest el : elements) {
            knownVisibility.put(el.patrolId(), el.visible());
        }

        // 1b. 页面稳定期复扫：等待异步渲染（懒加载/定时脚本/延迟组件）后复扫一次，
        //     「新展现」元素（新插入 DOM 或由不可见变可见）并入本轮巡检的初始计划
        int rescanMs = properties.getDefaults().getDomStableRescanMs();
        if (rescanMs > 0) {
            try {
                page.waitForTimeout(rescanMs);
                int before = elements.size();
                for (ElementDigest el : parseElements(false)) {
                    knownVisibility.put(el.patrolId(), el.visible());
                    elements.removeIf(prev -> prev.patrolId().equals(el.patrolId()));
                    elements.add(el);
                }
                // 排序截断语义与初始解析一致（按钮类优先保留）
                elements.sort(java.util.Comparator.comparingInt(e -> kindPriority(e.kind())));
                int limit = properties.getDefaults().getMaxElementsRecorded();
                if (elements.size() > limit) {
                    elements = new ArrayList<>(elements.subList(0, limit));
                }
                if (elements.size() > before) {
                    log.info("[{}] {} 稳定期复扫发现 {} 个新展现元素（异步渲染），并入巡检",
                            site.getSiteName(), shortUrl(pageUrl), elements.size() - before);
                }
            } catch (PlaywrightException e) {
                log.debug("[{}] 稳定期复扫失败: {}", site.getSiteName(), e.getMessage());
            }
        }
        log.info("[{}] {} 解析到 {} 个可交互元素", site.getSiteName(), shortUrl(pageUrl), elements.size());

        // 2. 动作计划（队列）：自定义动作 + 初始元素（QUERY 模式只点命中「查询按钮关键词」的控件）
        boolean allMode = site.isAllButtonMode();
        Deque<PlannedAction> queue = new ArrayDeque<>();
        Set<String> doneFps = new HashSet<>();     // 已执行动作的指纹（下拉重渲染去重）
        Set<String> queuedFps = new HashSet<>();  // 已入队未执行的指纹
        List<PlannedAction> executed = new ArrayList<>();
        List<ElementDigest> allElements = new ArrayList<>(elements);
        if (customActions != null) {
            for (PageActionConfig c : customActions) {
                if (queue.size() >= site.getMaxActionsPerPage()) break;
                if (!c.isEnabled() || !c.matchesUrl(pageUrl)) continue;
                queue.offer(PlannedAction.custom(c));
            }
        }
        for (ElementDigest el : elements) {
            if (queue.size() >= site.getMaxActionsPerPage()) break;
            // 只点击可见元素：隐藏在菜单/弹窗中的元素无法直接点击（会超时误报），
            // 它们仍会出现在元素清单中，只是不纳入点击计划
            if (!el.visible()) continue;
            PlannedAction pa = planCandidate(el, allMode, false, null);
            if (pa == null) continue;
            if (pa.fingerprint() != null) {
                if (doneFps.contains(pa.fingerprint()) || queuedFps.contains(pa.fingerprint())) continue;
                queuedFps.add(pa.fingerprint());
            }
            queue.offer(pa);
        }
        if (queue.isEmpty()) {
            return new InteractorResult(labelDecisions(allElements, executed, allMode), List.of());
        }

        // 3. 队列驱动执行：动作完成后其引发的「新展现」元素（下拉/浮层/级联/输入建议）入队续巡检
        List<ActionInspection> results = new ArrayList<>();
        int actionIdx = 0;
        String urlBeforeAll = page.url();
        while (!queue.isEmpty() && executed.size() < site.getMaxActionsPerPage()) {
            PlannedAction plan = queue.poll();
            // 指纹已被执行过（下拉重渲染的同结构选项）或已淘汰：跳过不重复点击
            if (plan.fingerprint() != null && !queuedFps.remove(plan.fingerprint())) {
                continue;
            }
            if (plan.fingerprint() != null) doneFps.add(plan.fingerprint());
            actionIdx++;
            ExecuteOutcome outcome = switch (plan.actionType()) {
                case "HOVER_PROBE" -> executeHoverProbe(plan, pageUrl, pageIdx, actionIdx, urlBeforeAll);
                case "SELECT_PROBE" -> executeSelectProbe(plan, pageUrl, pageIdx, actionIdx, urlBeforeAll);
                default -> execute(plan, pageUrl, pageIdx, actionIdx, urlBeforeAll);
            };
            executed.add(plan);
            results.add(outcome.action());
            log.info("[{}] {} 动作 {}/{} {} -> {}（触发请求 {} 个，失败 {} 个，console错误 {} 条，下载 {} 个）",
                    site.getSiteName(), shortUrl(pageUrl), actionIdx, executed.size() + queue.size(),
                    plan.description(), outcome.action().verdict(),
                    outcome.action().requests() == null ? 0 : outcome.action().requests().size(),
                    outcome.action().failedRequestCount(), outcome.action().consoleErrorCount(),
                    outcome.action().downloads() == null ? 0 : outcome.action().downloads().size());
            if (outcome.action().navigatedAway()) {
                log.debug("[{}] 页面已跳转，终止剩余动作", site.getSiteName());
                break;
            }
            if (!outcome.revealed().isEmpty()) {
                enqueueRevealed(outcome.revealed(), plan, allMode,
                        queue, doneFps, queuedFps, allElements, results.size());
            }
        }

        // 4. 元素台账：标注每个元素的处理决策（为什么点/为什么不点，含下拉选项与探测操作）
        return new InteractorResult(labelDecisions(allElements, executed, allMode), results);
    }

    /**
     * 单元素动作路由（初始元素与下拉/浮层选项统一规则）：
     * 确认类排除词命中 → 不点击；下载类真实执行；弹窗类点开自动关闭；
     * 导航链接由探索阶段覆盖；下拉/浮层上下文中 cursor:pointer 疑似可点击元素也点击
     * （老式 table 菜单的选项常仅有 cursor:pointer 标记）。
     *
     * @return 动作计划；null 表示不点击（决策由台账标注）
     */
    private PlannedAction planCandidate(ElementDigest el, boolean allMode,
                                         boolean revealedContext, PlannedAction parent) {
        if (matchesAny(el.text(), site.getExcludedButtonKeywords())) return null;
        if (el.isLink()) {
            if (allMode && matchesAny(el.text(), site.getDownloadButtonKeywords())) {
                return buildPlan(el, allMode, Category.DOWNLOAD, parent);
            }
            return null; // 导航链接（探索阶段覆盖）/ 外部链接：不点击
        }
        boolean clickable = el.isClickableControl()
                || (revealedContext && ElementDigest.K_POINTER.equals(el.kind()));
        if (!clickable) {
            // 通用 DOM 增量探测型操作（仅 ALL 模式）：非点击类元素也尝试触发 DOM 增量——
            // 原生下拉框逐项选择（级联渲染）、cursor:pointer 疑似可点击元素悬停（悬停展开菜单）
            if (allMode) {
                if (ElementDigest.K_SELECT.equals(el.kind())
                        && properties.getDefaults().getMaxSelectOptionsProbe() > 0) {
                    return buildSelectProbe(el, parent);
                }
                if (ElementDigest.K_POINTER.equals(el.kind())
                        && remainingHoverProbes > 0) {
                    remainingHoverProbes--;
                    return buildHoverProbe(el, parent);
                }
            }
            return null;
        }
        Category cat = Category.PLAIN;
        if (allMode || parent != null) {
            // 全量模式；或操作引发的增量元素（下拉/填充/悬停/级联选项）——
            // 主动操作的结果是巡检的直接延伸，不受 QUERY 关键词过滤，仍做下载/弹窗安全分类
            if (matchesAny(el.text(), site.getDownloadButtonKeywords())) {
                cat = Category.DOWNLOAD;
            } else if (matchesAny(el.text(), site.getDialogButtonKeywords())) {
                cat = Category.DIALOG;
            }
        } else if (!matchesAny(el.text(), site.getQueryButtonKeywords())) {
            return null;
        }
        return buildPlan(el, allMode, cat, parent);
    }

    /** 构建动作计划：初始元素（depth=0）或下拉选项（depth=父+1，携带父菜单选择器用于不可见时重新展开） */
    private PlannedAction buildPlan(ElementDigest el, boolean allMode, Category cat, PlannedAction parent) {
        String selector = clickSelectorOf(el);
        String fp = elementFingerprint(el);
        String label = el.text() == null || el.text().isBlank()
                ? "无文本按钮[" + PlannedAction.shortHint(el) + "]" : el.text();
        if (parent == null) {
            String prefix = switch (cat) {
                case DIALOG -> "打开弹窗按钮[";
                case DOWNLOAD -> "导出下载按钮[";
                default -> allMode ? "全量遍历按钮[" : "点击查询按钮[";
            };
            String suffix = cat == Category.DIALOG ? "]（不确认）" : "]";
            return new PlannedAction(allMode ? "ALL_BUTTON_CLICK" : "AUTO_QUERY_CLICK",
                    prefix + label + suffix, selector, null, cat,
                    0, "0|" + fp, null, label, false, false, el.patrolId());
        }
        // 下拉/浮层选项：描述与指纹都携带父链，同一下拉重渲染的同结构选项只巡检一次
        String chain = parent.chain() + " > " + label;
        String desc = "下拉选项[" + chain + "]" + (cat == Category.DIALOG ? "（不确认）" : "");
        return new PlannedAction("DROPDOWN_CLICK", desc, selector, null, cat,
                parent.depth() + 1, parentFp(parent) + ">" + fp,
                parent.selector(), chain, true, parent.expandByHover(), el.patrolId());
    }

    /** 悬停探测计划：cursor:pointer 疑似可点击元素执行 hover，探测其展开的菜单选项 */
    private PlannedAction buildHoverProbe(ElementDigest el, PlannedAction parent) {
        String label = el.text() == null || el.text().isBlank()
                ? "无文本悬停目标[" + PlannedAction.shortHint(el) + "]" : el.text();
        String chain = parent == null ? label : parent.chain() + " > " + label;
        return new PlannedAction("HOVER_PROBE", "悬停探测[" + chain + "]",
                clickSelectorOf(el), null, Category.PLAIN,
                parent == null ? 0 : parent.depth() + 1,
                parentFp(parent) + ">" + elementFingerprint(el),
                parent == null ? null : parent.selector(),
                chain, false, true, el.patrolId());
    }

    /** 原生下拉框逐项选择探测计划：逐个选择 option 触发 change 级联渲染，每项后增量探测 */
    private PlannedAction buildSelectProbe(ElementDigest el, PlannedAction parent) {
        String label = el.text() == null || el.text().isBlank()
                ? "无文本下拉框[" + PlannedAction.shortHint(el) + "]" : el.text();
        String chain = parent == null ? label : parent.chain() + " > " + label;
        return new PlannedAction("SELECT_PROBE", "下拉框逐项选择探测[" + chain + "]",
                clickSelectorOf(el), null, Category.PLAIN,
                parent == null ? 0 : parent.depth() + 1,
                parentFp(parent) + ">" + elementFingerprint(el),
                null, chain, false, false, el.patrolId());
    }

    /** 父动作指纹（无父动作时用固定前缀，保证子选项指纹稳定可去重） */
    private static String parentFp(PlannedAction parent) {
        return parent == null || parent.fingerprint() == null ? "p0" : parent.fingerprint();
    }

    /**
     * 操作引发的「新展现」元素纳入队列继续巡检：按主流程同套路由，
     * 指纹去重（下拉重渲染的同结构选项只巡检一次），台账同时登记（重复展现标注跳过）。
     */
    private void enqueueRevealed(List<ElementDigest> revealed, PlannedAction parent, boolean allMode,
                                 Deque<PlannedAction> queue, Set<String> doneFps, Set<String> queuedFps,
                                 List<ElementDigest> allElements, int executedSoFar) {
        int enqueued = 0;
        for (ElementDigest el : revealed) {
            if (executedSoFar + queue.size() >= site.getMaxActionsPerPage()) break;
            if (!el.visible()) continue;
            PlannedAction pa = planCandidate(el, allMode, true, parent);
            if (pa == null) continue;
            if (allElements.size() < ELEMENT_LEDGER_CAP) {
                allElements.add(pa.fingerprint() != null
                        && (doneFps.contains(pa.fingerprint()) || queuedFps.contains(pa.fingerprint()))
                        ? el.withDecision(DEC_REVEALED_DUP) : el);
            }
            if (pa.fingerprint() != null
                    && (doneFps.contains(pa.fingerprint()) || queuedFps.contains(pa.fingerprint()))) {
                log.debug("[{}] 下拉选项指纹重复，跳过: {} fp={}", site.getSiteName(),
                        el.text(), pa.fingerprint());
                continue;
            }
            if (pa.fingerprint() != null) queuedFps.add(pa.fingerprint());
            queue.offer(pa);
            enqueued++;
        }
        if (enqueued > 0) {
            log.info("[{}] 点击[{}]后新展现 {} 个可交互元素，纳入下拉/浮层巡检",
                    site.getSiteName(), parent.description(), enqueued);
        }
    }

    /**
     * 操作后增量探测：全量扫描并登记元素可见性，识别「新展现」元素——
     * 运行时新插入 DOM 的（动态渲染下拉），或原本存在但由不可见变可见的（display 切换式下拉）。
     */
    private List<ElementDigest> probeRevealed() {
        List<ElementDigest> all = parseElements(false);
        List<ElementDigest> revealed = new ArrayList<>();
        for (ElementDigest el : all) {
            Boolean prev = knownVisibility.put(el.patrolId(), el.visible());
            if (el.visible() && !Boolean.TRUE.equals(prev)) revealed.add(el);
        }
        log.debug("[{}] 增量探测：扫描 {} 个元素，新展现 {} 个: {}", site.getSiteName(), all.size(),
                revealed.size(), revealed.stream().map(e -> e.kind() + "|" + e.text() + "|" + e.cssPath()).toList());
        return revealed;
    }

    /** ---------------- 元素解析 ---------------- */

    List<ElementDigest> parseElements() {
        return parseElements(true);
    }

    /**
     * 解析页面可交互元素。
     *
     * @param applyLimit 是否按 maxElementsRecorded 截断（操作后增量探测需要全量结果登记可见性，不截断）
     */
    List<ElementDigest> parseElements(boolean applyLimit) {
        try {
            Object result = page.evaluate(JS_PARSE_ELEMENTS, CLICKABLE_SELECTOR);
            if (!(result instanceof List<?> list)) return List.of();
            List<ElementDigest> out = new ArrayList<>();
            for (Object o : list) {
                if (!(o instanceof Map<?, ?> m)) continue;
                String tag = str(m.get("tag"));
                String text = str(m.get("text"));
                String id = str(m.get("id"));
                String cls = str(m.get("cls"));
                String type = str(m.get("type"));
                String kind = str(m.get("kind"));
                String href = str(m.get("href"));
                String selector = str(m.get("selector"));
                String cssPath = str(m.get("path"));
                String patrolId = str(m.get("pid"));
                boolean visible = Boolean.TRUE.equals(m.get("visible"));
                out.add(new ElementDigest(tag, text, id, cls, type, kind, href,
                        selector, cssPath, patrolId, visible, ""));
            }
            if (applyLimit) {
                // 按可操作性优先级稳定排序后再截断：保证链接较多时按钮类元素不被挤出台账
                out.sort(java.util.Comparator.comparingInt(e -> kindPriority(e.kind())));
                int limit = properties.getDefaults().getMaxElementsRecorded();
                return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
            }
            return out;
        } catch (PlaywrightException e) {
            log.debug("[{}] 元素解析失败: {}", site.getSiteName(), e.getMessage());
            return List.of();
        }
    }

    private static String str(Object o) {
        return o == null || "null".equals(o) ? "" : String.valueOf(o);
    }

    /** 元素点击定位选择器：稳定 CSS 路径优先（nth= 全局序在 DOM 动态增删后会漂移） */
    private static String clickSelectorOf(ElementDigest el) {
        if (el.cssPath() != null && !el.cssPath().isBlank()) return el.cssPath();
        return el.selectorHint();
    }

    /** 元素指纹：tag|文本|链接|CSS 路径——用于下拉重渲染的同结构选项去重 */
    private static String elementFingerprint(ElementDigest el) {
        return (el.tag() == null ? "" : el.tag()) + "|"
                + (el.text() == null ? "" : el.text()) + "|"
                + (el.href() == null ? "" : el.href()) + "|"
                + (el.cssPath() == null ? "" : el.cssPath());
    }

    /** 可操作性优先级：按钮/伪链接 > ARIA/onclick > 折叠项 > 链接 > 疑似可点击 > 输入类 */
    private static int kindPriority(String kind) {
        return switch (kind == null ? "" : kind) {
            case ElementDigest.K_BUTTON, ElementDigest.K_PSEUDO_LINK -> 0;
            case ElementDigest.K_ARIA, ElementDigest.K_ONCLICK -> 1;
            case ElementDigest.K_SUMMARY -> 2;
            case ElementDigest.K_LINK, ElementDigest.K_IMAGE_LINK -> 3;
            case ElementDigest.K_POINTER, ElementDigest.K_TABINDEX -> 4;
            default -> 5;
        };
    }

    /** 元素处理决策标签（写入报告的按钮台账） */
    static final String DEC_CLICKED = "已点击";
    static final String DEC_DIALOG = "已点击·弹窗类(不确认)";
    static final String DEC_DOWNLOAD = "已点击·下载类";
    static final String DEC_REVEALED = "已点击·下拉/浮层选项";
    static final String DEC_REVEALED_DUP = "下拉/浮层重复展现·已巡检跳过";
    static final String DEC_HOVER_PROBED = "已悬停探测·展开选项已巡检";
    static final String DEC_SELECT_PROBED = "已逐项选择探测·联动已巡检";
    static final String DEC_EXCLUDED = "确认类·不点击";
    static final String DEC_INVISIBLE = "不可见·未点击";
    static final String DEC_NOT_BUTTON = "非按钮";
    static final String DEC_QUERY_MISS = "未命中查询词·未点击";
    static final String DEC_OVERFLOW = "超出每页上限·未点击";
    static final String DEC_LINK_EXPLORE = "导航链接·探索阶段覆盖";
    static final String DEC_LINK_EXTERNAL = "外部链接·不点击";
    static final String DEC_SUSPECT = "疑似可点击·仅记录";

    /**
     * 为页面元素标注巡检处理决策，形成完整按钮台账：
     * 每个元素无论点击与否都有明确记录（为什么点/为什么不点）；
     * 已执行的动作按元素持久 ID 关联标注（下拉选项/悬停探测/逐项选择探测各有专属标签）。
     */
    private List<ElementDigest> labelDecisions(List<ElementDigest> elements,
                                                List<PlannedAction> executed,
                                                boolean allMode) {
        Map<String, String> executedDecision = new LinkedHashMap<>();
        for (PlannedAction pa : executed) {
            if (pa.patrolId() == null || "CUSTOM_CLICK".equals(pa.actionType())) continue;
            executedDecision.put(pa.patrolId(), switch (pa.actionType()) {
                case "HOVER_PROBE" -> DEC_HOVER_PROBED;
                case "SELECT_PROBE" -> DEC_SELECT_PROBED;
                default -> pa.depth() > 0 ? DEC_REVEALED
                        : switch (pa.category()) {
                    case DIALOG -> DEC_DIALOG;
                    case DOWNLOAD -> DEC_DOWNLOAD;
                    default -> DEC_CLICKED;
                };
            });
        }
        List<ElementDigest> labeled = new ArrayList<>(elements.size());
        for (ElementDigest el : elements) {
            String decision = el.patrolId() == null || el.patrolId().isBlank()
                    ? null : executedDecision.get(el.patrolId());
            if (decision == null && el.decision() != null && !el.decision().isBlank()) {
                decision = el.decision(); // 入队时已标注（下拉/浮层重复展现跳过）
            }
            if (decision == null) {
                if (!el.visible()) {
                    decision = DEC_INVISIBLE;
                } else if (matchesAny(el.text(), site.getExcludedButtonKeywords())) {
                    decision = DEC_EXCLUDED;
                } else if (el.isLink()) {
                    decision = isSameOrigin(el.href()) ? DEC_LINK_EXPLORE : DEC_LINK_EXTERNAL;
                } else if (!el.isClickableControl()) {
                    decision = el.isSuspect() ? DEC_SUSPECT : DEC_NOT_BUTTON;
                } else if (!allMode && !matchesAny(el.text(), site.getQueryButtonKeywords())) {
                    decision = DEC_QUERY_MISS;
                } else {
                    decision = DEC_OVERFLOW;
                }
            }
            labeled.add(el.withDecision(decision));
        }
        return labeled;
    }

    /** 链接地址是否与站点入口同源（同 host + 端口）；非 http(s) 协议（mailto/tel/javascript）视为非同源 */
    private boolean isSameOrigin(String href) {
        if (href == null || href.isBlank()) return false;
        try {
            URI u = URI.create(href.trim());
            String scheme = u.getScheme();
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
            URI entry = URI.create(site.getEntryUrl());
            if (u.getHost() == null || !u.getHost().equalsIgnoreCase(entry.getHost())) return false;
            int p = u.getPort();
            int ep = entry.getPort();
            return p == ep
                    || (p == -1 && (ep == -1 || ep == defaultPort(scheme)))
                    || (ep == -1 && p == defaultPort(scheme));
        } catch (Exception e) {
            return false;
        }
    }

    private static int defaultPort(String scheme) {
        return "https".equalsIgnoreCase(scheme) ? 443 : 80;
    }

    /** ---------------- 单动作执行 ---------------- */

    /** 点击错误是否属于「元素不可交互」（不可见/被遮挡/未启用等待超时）——应跳过而非判失败 */
    private static boolean isActionabilityError(String msg) {
        if (msg == null) return false;
        return msg.contains("intercepts pointer events")
                || (msg.contains("Timeout") && (msg.contains("waiting for element to be visible")
                    || msg.contains("waiting for element to be stable")
                    || msg.contains("waiting for element to be enabled")));
    }

    /** 在打开的对话框内查找并点击「取消类」按钮（绝不点击确认/保存/删除类）。返回是否点到 */
    private boolean clickCancelButtonInDialog() {
        try {
            Object clicked = page.evaluate("""
                    () => {
                      const visible = el => el.getClientRects().length > 0;
                      const dialogs = Array.from(document.querySelectorAll(
                          '[role=dialog], [role=alertdialog], [class*=modal i], [class*=dialog i], [class*=drawer i]'))
                          .filter(visible);
                      for (const d of dialogs) {
                        const btns = Array.from(d.querySelectorAll('button, [role=button]')).filter(visible);
                        const isCancel = b => {
                          const t = (b.innerText || b.getAttribute('aria-label') || '').trim();
                          return /^(取消|关闭|close|cancel|×|x)$/i.test(t);
                        };
                        const cancel = btns.find(isCancel);
                        if (cancel) { cancel.click(); return true; }
                      }
                      return false;
                    }
                    """);
            return Boolean.TRUE.equals(clicked);
        } catch (PlaywrightException e) {
            return false;
        }
    }

    /**
     * 安全关闭点击后打开的对话框/下拉：Esc →（仍有弹窗时）点击取消按钮 → 再 Esc。
     * 绝不点击确认类按钮（保存/提交/确认/删除/创建…），保证新增/编辑/删除流程不被最终确认。
     */
    private void closeOverlaysSafely() {
        try {
            page.keyboard().press("Escape");
            page.waitForTimeout(400);
        } catch (PlaywrightException ignored) {
            return; // 点击导致跳转，页面不可用
        }
        if (clickCancelButtonInDialog()) {
            try {
                page.waitForTimeout(400);
            } catch (PlaywrightException ignored) {
            }
        }
        try {
            page.keyboard().press("Escape");
        } catch (PlaywrightException ignored) {
        }
    }

    /** 重新展开父菜单：点击展开的下拉用 click，悬停展开的菜单用 hover */
    private void reopenParentMenu(PlannedAction plan) {
        if (plan.expandByHover()) {
            page.locator(plan.expandSelector()).hover(new Locator.HoverOptions().setTimeout(2000));
        } else {
            page.locator(plan.expandSelector()).click(new Locator.ClickOptions().setTimeout(2000));
        }
    }

    private ExecuteOutcome execute(PlannedAction plan, String pageUrl, int pageIdx,
                                    int actionIdx, String urlBeforeAll) {
        String desc = plan.description();
        String clickError = null;
        boolean navigatedAway = false;
        boolean skipped = false;
        List<ElementDigest> revealed = new ArrayList<>();

        sniffer.beginVisit();
        int downloadStart = downloadLog.size();
        try {
            // 点击前填充；填充触发的联动（输入建议/级联表单/自动补全下拉）也是 DOM 增量源，立即探测
            if (plan.fills() != null && !plan.fills().isBlank()) {
                for (String fill : plan.fills().split("[;；]")) {
                    int eq = fill.indexOf('=');
                    if (eq <= 0) continue;
                    String sel = fill.substring(0, eq).trim();
                    String val = fill.substring(eq + 1);
                    try {
                        page.fill(sel, val, new Page.FillOptions()
                                .setTimeout(site.getLoadTimeoutMs()));
                    } catch (PlaywrightException e) {
                        log.debug("[{}] 动作填充失败 {}={}: {}", site.getSiteName(), sel, val, e.getMessage());
                    }
                }
                try {
                    page.waitForTimeout(300);
                    if (plan.depth() < MAX_EXPAND_DEPTH) {
                        revealed.addAll(probeRevealed());
                    }
                } catch (PlaywrightException e) {
                    log.debug("[{}] 填充后增量探测失败: {}", site.getSiteName(), e.getMessage());
                }
            }
            // 下拉选项：上一个选项的点击通常会使下拉收起——不可见时先重新展开父菜单再点击
            // （悬停展开的菜单须用 hover 重展开，点击展开的用 click）
            if (plan.expandSelector() != null) {
                try {
                    if (!page.locator(plan.selector()).isVisible()) {
                        reopenParentMenu(plan);
                        page.waitForTimeout(400);
                    }
                } catch (PlaywrightException e) {
                    log.debug("[{}] 重新展开父菜单失败 [{}]: {}", site.getSiteName(),
                            plan.expandSelector(), e.getMessage());
                }
            }
            // 点击（超时上限 5s：可见按钮的正常点击应立即完成，超时多为遮挡）
            Locator locator = page.locator(plan.selector());
            locator.click(new Locator.ClickOptions()
                    .setTimeout(Math.min(Math.max(site.getLoadTimeoutMs() / 2, 2000), 5000)));
        } catch (PlaywrightException e) {
            clickError = e.getMessage();
            // 下拉选项首次点击不可交互：可能父菜单展开时序错位，再展开一次重试
            if (plan.expandSelector() != null && isActionabilityError(clickError)) {
                try {
                    reopenParentMenu(plan);
                    page.waitForTimeout(400);
                    page.locator(plan.selector()).click(new Locator.ClickOptions()
                            .setTimeout(Math.min(Math.max(site.getLoadTimeoutMs() / 2, 2000), 5000)));
                    clickError = null;
                } catch (PlaywrightException e2) {
                    clickError = e2.getMessage();
                }
            }
        }
        // SPA 场景：按钮被 toast/浮层遮挡或瞬时不可交互，跳过而非判失败
        if (clickError != null && isActionabilityError(clickError)) {
            skipped = true;
            log.info("[{}] 动作 {} 元素不可交互，跳过（不判失败）", site.getSiteName(), desc);
        }

        if (clickError == null) {
            // 宽限期：给 onclick 处理器时间发起请求，避免 NETWORKIDLE 判定早于请求发出而立即返回
            try {
                page.waitForTimeout(300);
            } catch (PlaywrightException ignored) {
                // 点击导致跳转后页面可能已不可用，以已采集数据继续
            }
            // 等待动作触发的请求完成（网络空闲或超时）；导出下载多在请求完成后触发，一并覆盖
            try {
                page.waitForLoadState(LoadState.NETWORKIDLE,
                        new Page.WaitForLoadStateOptions()
                                .setTimeout(properties.getDefaults().getActionNetworkIdleWaitMs()));
            } catch (PlaywrightException ignored) {
                // 网络未空闲（轮询/长连接），以已采集数据判定
            }
            // 增量探测：下拉/浮层展开后「新展现」的可交互元素（必须在 Esc 关闭浮层前完成）
            if (plan.depth() < MAX_EXPAND_DEPTH) {
                try {
                    revealed.addAll(probeRevealed());
                } catch (PlaywrightException e) {
                    log.debug("[{}] 点击后探测新展现元素失败: {}", site.getSiteName(), e.getMessage());
                }
            }
            // 对话框类（新增/编辑/删除/上传/导入…）：打开弹窗巡检后安全关闭，绝不点确认
            if (plan.category() == Category.DIALOG) {
                closeOverlaysSafely();
            } else {
                // 普通按钮也可能打开下拉/浮层，按一次 Esc 复位页面状态，避免遮挡后续动作
                try {
                    page.keyboard().press("Escape");
                } catch (PlaywrightException ignored) {
                }
            }
        }

        // 导航检测：URL 变化即视为跳转（终止后续动作）
        navigatedAway = clickError == null && !page.url().equals(urlBeforeAll);
        return new ExecuteOutcome(finalizeOutcome(plan, pageUrl, pageIdx, actionIdx,
                clickError, skipped, navigatedAway, revealed, downloadStart), revealed);
    }

    /** 悬停探测执行器：hover 展开（老式系统悬停菜单/浮层）→ 增量探测 → 移开鼠标收起 */
    private ExecuteOutcome executeHoverProbe(PlannedAction plan, String pageUrl, int pageIdx,
                                              int actionIdx, String urlBeforeAll) {
        sniffer.beginVisit();
        int downloadStart = downloadLog.size();
        String clickError = null;
        boolean skipped = false;
        List<ElementDigest> revealed = new ArrayList<>();
        try {
            page.locator(plan.selector()).hover(new Locator.HoverOptions().setTimeout(3000));
            page.waitForTimeout(400); // 悬停展开渲染宽限
            if (plan.depth() < MAX_EXPAND_DEPTH) {
                try {
                    revealed.addAll(probeRevealed());
                } catch (PlaywrightException e) {
                    log.debug("[{}] 悬停后探测新展现元素失败: {}", site.getSiteName(), e.getMessage());
                }
            }
            // 移开鼠标收起悬停菜单，复位页面状态（展开的选项已入队，点击时会用 hover 重展开）
            try {
                page.mouse().move(0, 0);
                page.waitForTimeout(200);
            } catch (PlaywrightException ignored) {
            }
            try {
                page.waitForLoadState(LoadState.NETWORKIDLE,
                        new Page.WaitForLoadStateOptions()
                                .setTimeout(properties.getDefaults().getActionNetworkIdleWaitMs()));
            } catch (PlaywrightException ignored) {
            }
        } catch (PlaywrightException e) {
            clickError = e.getMessage();
            if (isActionabilityError(clickError)) {
                skipped = true;
                log.info("[{}] 动作 {} 元素不可交互，跳过（不判失败）", site.getSiteName(), plan.description());
            }
        }
        boolean navigatedAway = clickError == null && !page.url().equals(urlBeforeAll);
        return new ExecuteOutcome(finalizeOutcome(plan, pageUrl, pageIdx, actionIdx,
                clickError, skipped, navigatedAway, revealed, downloadStart), revealed);
    }

    /** 原生下拉框逐项选择探测执行器：逐个选择 option 触发 change 级联渲染，每项后增量探测 */
    private ExecuteOutcome executeSelectProbe(PlannedAction plan, String pageUrl, int pageIdx,
                                                int actionIdx, String urlBeforeAll) {
        sniffer.beginVisit();
        int downloadStart = downloadLog.size();
        String clickError = null;
        boolean skipped = false;
        List<ElementDigest> revealed = new ArrayList<>();
        try {
            Object opts = page.evaluate("""
                    sel => {
                      const el = document.querySelector(sel);
                      if (!el) return [];
                      return Array.from(el.options)
                          .map(o => ({value: o.value, text: (o.textContent || '').trim()}))
                          .filter(o => o.value);
                    }
                    """, plan.selector());
            List<String> values = new ArrayList<>();
            if (opts instanceof List<?> list) {
                for (Object o : list) {
                    if (o instanceof Map<?, ?> m && str(m.get("value")) != null
                            && !str(m.get("value")).isBlank()) {
                        values.add(str(m.get("value")));
                    }
                }
            }
            int limit = Math.min(values.size(), properties.getDefaults().getMaxSelectOptionsProbe());
            if (limit == 0) {
                skipped = true; // 无可选项：无 DOM 增量可探测，不判失败
                log.info("[{}] 动作 {} 无可选项，跳过", site.getSiteName(), plan.description());
            }
            for (int i = 0; i < limit; i++) {
                page.locator(plan.selector()).selectOption(values.get(i),
                        new Locator.SelectOptionOptions().setTimeout(3000));
                page.waitForTimeout(300); // change 级联渲染宽限
                if (plan.depth() < MAX_EXPAND_DEPTH) {
                    try {
                        revealed.addAll(probeRevealed());
                    } catch (PlaywrightException e) {
                        log.debug("[{}] 选项选择后探测新展现元素失败: {}", site.getSiteName(), e.getMessage());
                    }
                }
            }
            try {
                page.waitForLoadState(LoadState.NETWORKIDLE,
                        new Page.WaitForLoadStateOptions()
                                .setTimeout(properties.getDefaults().getActionNetworkIdleWaitMs()));
            } catch (PlaywrightException ignored) {
                // 网络未空闲（轮询/长连接），以已采集数据判定
            }
        } catch (PlaywrightException e) {
            clickError = e.getMessage();
            if (isActionabilityError(clickError)) {
                skipped = true;
                log.info("[{}] 动作 {} 元素不可交互，跳过（不判失败）", site.getSiteName(), plan.description());
            }
        }
        boolean navigatedAway = clickError == null && !page.url().equals(urlBeforeAll);
        return new ExecuteOutcome(finalizeOutcome(plan, pageUrl, pageIdx, actionIdx,
                clickError, skipped, navigatedAway, revealed, downloadStart), revealed);
    }

    /** 动作收尾（三类执行器共用）：嗅探快照、动作级判定、证据保存、动作记录构造 */
    private ActionInspection finalizeOutcome(PlannedAction plan, String pageUrl, int pageIdx, int actionIdx,
                                               String clickError, boolean skipped, boolean navigatedAway,
                                               List<ElementDigest> revealed, int downloadStart) {
        var requests = sniffer.finishVisit();
        var consoleLogs = sniffer.consoleLogs();
        var jsErrors = sniffer.jsErrors();
        List<String> downloads = downloadLog.size() > downloadStart
                ? new ArrayList<>(downloadLog.subList(downloadStart, downloadLog.size()))
                : List.of();

        // 动作级判定（阈值与站点阈值一致；被跳过的动作不因不可交互判失败）
        Verdict verdict = Verdict.PASS;
        if (clickError != null && !skipped) {
            verdict = Verdict.FAIL;
        } else if (jsErrors.size() > site.getJsErrorsMax()
                || consoleLogs.stream().filter(com.patrol.model.ConsoleRecord::isError).count()
                        > site.getConsoleErrorsMax()
                || requests.stream().filter(com.patrol.model.RequestRecord::isFailed).count()
                        > site.getFailedRequestsMax()) {
            verdict = Verdict.FAIL;
        }

        String screenshotRel = null;
        String contextRel = null;
        if (evidence != null && evidence.shouldSave(verdict)) {
            EvidenceManager.EvidencePaths paths = evidence.saveAction(
                    page, site, pageIdx, actionIdx, plan.description(), plan.selector(), pageUrl,
                    verdict, requests, consoleLogs, jsErrors, sniffer.failureSnippets(),
                    clickError, navigatedAway);
            screenshotRel = paths.screenshot();
            contextRel = paths.contextJson();
        }

        String buttonCategory = switch (plan.actionType()) {
            case "CUSTOM_CLICK" -> "自定义";
            case "DROPDOWN_CLICK" -> "下拉选项";
            case "HOVER_PROBE" -> "悬停探测";
            case "SELECT_PROBE" -> "下拉框逐项";
            default -> switch (plan.category()) {
                case DIALOG -> "弹窗类(不确认)";
                case DOWNLOAD -> "下载类";
                default -> "普通点击";
            };
        };
        return new ActionInspection(site.getSiteName(), pageUrl, plan.actionType(), plan.description(),
                buttonCategory, plan.selector(), requests, consoleLogs, jsErrors, downloads, verdict,
                screenshotRel, contextRel, clickError, navigatedAway, skipped);
    }

    // ---------------- 动作计划 ----------------

    /** 按钮处理类别 */
    enum Category {
        /** 普通按钮：直接点击 */
        PLAIN,
        /** 对话框类（新增/编辑/删除/上传…）：点击后自动安全关闭弹窗，绝不点确认 */
        DIALOG,
        /** 下载类（导出/下载…）：真实执行下载并记录 */
        DOWNLOAD
    }

    /**
     * 动作计划：depth=0 初始页面元素；depth&gt;0 为操作后新展现的下拉/浮层/级联选项
     * （expandSelector 指向父菜单——选项不可见时先重新展开再点击，expandByHover 区分 hover/click 展开）。
     */
    private record PlannedAction(String actionType, String description, String selector,
                                  String fills, Category category,
                                  int depth, String fingerprint, String expandSelector,
                                  String chain, boolean revealed, boolean expandByHover,
                                  String patrolId) {

        static PlannedAction custom(PageActionConfig c) {
            String desc = c.getDescription() == null || c.getDescription().isBlank()
                    ? "自定义点击 " + c.getSelector()
                    : c.getDescription();
            return new PlannedAction("CUSTOM_CLICK", desc, c.getSelector(), c.getFills(),
                    Category.PLAIN, 0, null, null, desc, false, false, null);
        }

        /** 无文本元素的简短定位提示：tag#id / tag.class / tag>>nth=N（避免超长选择器进入描述） */
        static String shortHint(ElementDigest el) {
            if (el.id() != null && !el.id().isBlank()) return el.tag() + "#" + el.id();
            if (el.cssClass() != null && !el.cssClass().isBlank()) {
                String first = el.cssClass().trim().split("\\s+")[0];
                if (!first.isBlank()) return el.tag() + "." + first;
            }
            int p = el.selectorHint() == null ? -1 : el.selectorHint().lastIndexOf("nth=");
            return p >= 0 ? el.tag() + ">>" + el.selectorHint().substring(p) : el.tag();
        }
    }

    // ---------------- 工具 ----------------

    private static boolean matchesAny(String text, List<String> keywords) {
        if (text == null || text.isBlank() || keywords == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String kw : keywords) {
            if (kw == null || kw.isBlank()) continue;
            if (lower.contains(kw.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private static String shortUrl(String url) {
        if (url == null) return "";
        int p = url.indexOf('/', url.indexOf("//") + 2);
        return p < 0 ? url : url.substring(p);
    }
}
