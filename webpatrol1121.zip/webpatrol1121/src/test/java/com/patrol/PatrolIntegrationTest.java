package com.patrol;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.patrol.config.PatrolProperties;
import com.patrol.engine.PatrolEngine;
import com.patrol.excel.ExcelConfigLoader;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.judge.HealthJudge;
import com.patrol.model.ActionInspection;
import com.patrol.model.ApiCallRecord;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.ElementDigest;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.PatrolSummary;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import com.patrol.report.ExcelReportGenerator;
import com.patrol.report.HtmlReportGenerator;
import com.patrol.report.JsonReportWriter;
import com.patrol.runner.PatrolRunner;
import com.patrol.support.TestWebServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import static org.testng.AssertJUnit.*;

/**
 * 端到端集成测试：本地测试站点 + 示例 Excel 配置 → 完整巡检 → 断言判定/证据/报告/动作巡检/登录态复用。
 */
public class PatrolIntegrationTest {

    private static final Logger log = LoggerFactory.getLogger(PatrolIntegrationTest.class);

    private TestWebServer webServer;
    private Path reportDir;
    private PatrolProperties properties;
    private ExcelConfigLoader loader;
    private List<SiteInspection> inspections;

    @BeforeClass
    public void setUp() throws Exception {
        webServer = new TestWebServer();
        webServer.start();

        // 输出目录（patrol- 前缀 + 时间戳，与正式巡检目录命名一致，可被索引页收录）
        reportDir = Path.of("target", "patrol-test-report",
                "patrol-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
        Files.createDirectories(reportDir);

        // 登录态缓存目录（隔离，便于断言；每次运行前清空，保证测试确定性）
        Path loginStateDir = Path.of("target", "login-state-test");
        if (Files.exists(loginStateDir)) {
            try (var walk = Files.walk(loginStateDir)) {
                walk.sorted(java.util.Comparator.reverseOrder())
                        .forEach(p -> p.toFile().delete());
            }
        }
        properties = new PatrolProperties();
        properties.setExcelPath(Path.of("target", "test-sites.xlsx").toString());
        properties.setOutputDir(reportDir.getParent().toString());
        properties.setLoginStateDir(loginStateDir.toString());
        properties.getDefaults().setLoadTimeoutMs(1000);   // 使 /slow 判 WARN
        properties.getDefaults().setMaxPages(10);
        properties.getDefaults().setMaxDepth(2);
        properties.getDefaults().setSitemapDiscovery(false); // 全局关闭，仅「孤立页面站」显式开启（保证其他站点页数确定性）

        // 构造测试 Excel 配置
        Path excel = Path.of("target", "test-sites.xlsx");
        writeTestExcel(excel);

        loader = new ExcelConfigLoader(properties);
        List<SiteConfig> sites = loader.load(excel).stream()
                .filter(SiteConfig::isEnabled).toList();
        List<PageActionConfig> pageActions = loader.loadPageActions(excel);

        PatrolEngine engine = new PatrolEngine(properties, new HealthJudge());

        // 阶段一：预认证（有头模式，串行）—— FORM 登录站弹出浏览器自动登录并保存登录态
        try (Playwright authPlaywright = com.patrol.engine.PlaywrightFactory.create(false)) {
            for (SiteConfig site : sites) {
                com.patrol.engine.AuthSupport.preAuthenticate(authPlaywright, properties, site,
                        Path.of(properties.getLoginStateDir()));
            }
        }

        // 阶段二：无头巡检（登录态已就绪，仅加载缓存）
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            inspections = sites.stream()
                    .map(site -> engine.inspect(site, browser, reportDir, pageActions))
                    .toList();
        }
        inspections.forEach(s -> log.info("站点 [{}] 结论: {} 页面数 {} 动作 {}",
                s.siteName(), s.verdict(), s.pagesVisited(), s.totalActions()));
    }

    /** 写入测试 Excel（新双表格式：Sites 主表 11 列 + 站点高级配置 sheet） */
    private void writeTestExcel(Path excel) throws Exception {
        String[][] sites = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"本地演示站", webServer.baseUrl() + "/", "true", "NONE", "", "",
                        "", "", "", "", "集成测试站点（ALL 全量按钮遍历）"},
                {"本地登录站", webServer.baseUrl() + "/home2", "true", "FORM", "admin", "admin123",
                        webServer.baseUrl() + "/login", "#username", "#password", "#loginBtn", "FORM 登录演示"},
                {"覆盖测试站", webServer.baseUrl() + "/coverage-page", "true", "NONE", "", "",
                        "", "", "", "",
                        "可点击元素覆盖演示（图标按钮/ARIA/伪链接/图片链接/下载链接/疑似可点击）"},
                {"孤立页面站", webServer.baseUrl() + "/isolated-home", "true", "NONE", "", "",
                        "", "", "", "",
                        "孤立菜单页面探索演示（hash 路由 / onclick 导航 / sitemap 发现 / 额外入口）"},
                {"DOM探测站", webServer.baseUrl() + "/dom-ops", "true", "NONE", "", "",
                        "", "", "", "",
                        "通用 DOM 增量探测演示（悬停菜单 / 原生下拉级联 / 异步渲染稳定复扫）"},
                {"弹窗关闭站", webServer.baseUrl() + "/modal-close", "true", "NONE", "", "",
                        "", "", "", "",
                        "弹窗关闭演示（关闭控件 addEventListener 绑定，扫描不可识别）"},
                {"迟到错误站", webServer.baseUrl() + "/console-gap", "true", "NONE", "", "",
                        "", "", "", "",
                        "窗口外迟到 console 错误捕获演示"},
                {"重定位站", webServer.baseUrl() + "/dom-rerender", "true", "NONE", "", "",
                        "", "", "", "",
                        "DOM 重渲染重定位演示（按钮销毁重建，原 cssPath 失效）"},
                {"API采集站", webServer.baseUrl() + "/api-calls", "true", "NONE", "", "",
                        "", "", "", "",
                        "前端 API 采集演示（xhr/fetch 过滤、请求响应体、curl 复现）"}
        };
        // 高级配置表头直接复用正式模板（列序一致）；列序：0站点 1页数 2深度 3额外入口 4包含
        //   5排除 6Sitemap 7动作开关 8动作模式 9动作上限 10-16关键词与阈值 17超时 18错误词
        //   19成功标识 20成功URL 21复用 22手动超时 23Token头 24Token值
        String[] advHead = com.patrol.excel.ExcelTemplateGenerator.ADVANCED_HEADERS;
        String[][] advanced = {
                advHead,
                // 演示站：排除 /api（防 onclick 提取的下载端点被当页面）；加载超时留空 → 回落全局默认
                {"本地演示站", "12", "2", "", "", "/logout,/api", "false",
                        "true", "ALL", "5", "", "", "", "", "", "", "", "1000", "",
                        "", "", "", "", "", ""},
                // 登录站：动作模式留空 → 回落全局默认 QUERY；登录成功标识从高级表合并
                {"本地登录站", "5", "1", "", "", "/logout", "false",
                        "true", "", "3", "", "", "", "", "", "", "", "", "",
                        "退出登录", "", "true", "", "", ""},
                {"覆盖测试站", "1", "0", "", "", "", "false",
                        "true", "ALL", "10", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // 孤立页面站：额外入口 /hidden-page（相对路径，加载时解析）；显式开启 sitemap 发现
                {"孤立页面站", "8", "2", "/hidden-page", "", "", "true",
                        "false", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // DOM 探测站：悬停菜单 + 原生下拉级联 + 异步渲染，ALL 模式验证通用 DOM 增量探测
                {"DOM探测站", "1", "0", "", "", "", "false",
                        "true", "ALL", "12", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // 弹窗关闭站：ALL 模式点击打开弹窗与弹窗后按钮，验证增强的浮层关闭逻辑
                {"弹窗关闭站", "1", "0", "", "", "", "false",
                        "true", "ALL", "10", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // 迟到错误站：无任何可点击元素，验证窗口间隙迟到 console 错误并入页面判定
                {"迟到错误站", "1", "0", "", "", "", "false",
                        "true", "ALL", "5", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // 重定位站：ALL 模式验证 DOM 重渲染后的元素指纹重定位
                {"重定位站", "1", "0", "", "", "", "false",
                        "true", "ALL", "10", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""},
                // API 采集站：ALL 模式点击按钮触发 POST/500 请求，验证业务 API 全链路采集
                {"API采集站", "1", "0", "", "", "", "false",
                        "true", "ALL", "5", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", ""}
        };
        writeSheets(excel, sites, advanced);
    }

    /** 双表写出：Sites 主表 + 站点高级配置（EasyExcel 动态表头） */
    private static void writeSheets(Path excel, String[][] sites, String[][] advanced) throws Exception {
        ExcelWriter writer = null;
        try {
            writer = EasyExcel.write(excel.toString()).build();
            writeMatrix(writer, 0, "Sites", sites);
            writeMatrix(writer, 1, "站点高级配置", advanced);
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
    }

    /** 单表写出：仅 Sites 主表（EasyExcel 动态表头） */
    private static void writeExcel(Path excel, String[][] rows) throws Exception {
        ExcelWriter writer = null;
        try {
            writer = EasyExcel.write(excel.toString()).build();
            writeMatrix(writer, 0, "Sites", rows);
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
    }

    /** 写出字符串矩阵：首行为表头，数据行不足列数补空串 */
    private static void writeMatrix(ExcelWriter writer, int idx, String name, String[][] rows) {
        String[] headers = rows[0];
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        List<List<Object>> data = new ArrayList<>();
        for (int r = 1; r < rows.length; r++) {
            List<Object> line = new ArrayList<>();
            for (int c = 0; c < headers.length; c++) {
                line.add(c < rows[r].length ? rows[r][c] : "");
            }
            data.add(line);
        }
        WriteSheet sheet = EasyExcel.writerSheet(idx, name).head(head).build();
        writer.write(data, sheet);
    }

    /** EasyExcel 读回生成的报告 sheet（headRowNumber=0，含表头行；sheet 不存在返回空列表） */
    private static List<Map<Integer, String>> readGeneratedSheet(Path excel, String sheetName) {
        try {
            return EasyExcel.read(excel.toString()).sheet(sheetName).headRowNumber(0).doReadSync();
        } catch (Exception e) {
            return List.of();
        }
    }

    /**
     * 旧版 31 列宽表头（保留用于验证向后兼容：旧格式单宽表文件仍可正常加载，
     * 新格式请使用 Sites 主表 + 站点高级配置双表结构）。
     */
    private static class ExcelTemplateHeaders {
        static String[] headRow() {
            return new String[]{"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码", "登录URL",
                    "用户名选择器", "密码选择器", "提交按钮选择器", "登录成功标识", "登录成功URL包含",
                    "复用登录状态", "手动登录超时(秒)", "Token请求头", "Token值",
                    "最大页面数", "最大深度", "包含路径前缀", "排除路径前缀",
                    "启用动作巡检", "动作模式", "动作数上限", "查询按钮关键词", "排除按钮关键词",
                    "Console错误上限", "JS异常上限", "失败请求上限", "加载超时(ms)", "错误关键词", "备注"};
        }
    }

    private SiteInspection demoSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("本地演示站"))
                .findFirst().orElseThrow();
    }

    private SiteInspection loginSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("本地登录站"))
                .findFirst().orElseThrow();
    }

    private PageInspection page(String path) {
        return demoSite().pages().stream()
                .filter(p -> p.url().endsWith(path))
                .findFirst().orElse(null);
    }

    @Test
    public void advancedSheetOverridesMerged() throws Exception {
        List<SiteConfig> sites = loader.load(Path.of(properties.getExcelPath()));

        // 演示站：高级配置覆盖项应生效
        SiteConfig demo = sites.stream().filter(s -> s.getSiteName().equals("本地演示站"))
                .findFirst().orElseThrow();
        assertEquals("高级配置应覆盖最大页面数", 12, demo.getMaxPages());
        assertTrue("高级配置动作模式 ALL 应生效", demo.isAllButtonMode());
        assertEquals("高级配置留空的加载超时应回落全局默认", 1000, demo.getLoadTimeoutMs());

        // 登录站：认证类字段（登录成功标识）与探索参数从高级表合并，动作模式留空回落默认
        SiteConfig login = sites.stream().filter(s -> s.getSiteName().equals("本地登录站"))
                .findFirst().orElseThrow();
        assertEquals("高级配置登录成功标识应合并", "退出登录", login.getLoginSuccessText());
        assertEquals("高级配置动作数上限应合并", 3, login.getMaxActionsPerPage().intValue());
        assertFalse("高级配置动作模式留空应回落全局默认 QUERY", login.isAllButtonMode());

        // 覆盖站：只填覆盖项，认证字段来自主表
        SiteConfig cov = sites.stream().filter(s -> s.getSiteName().equals("覆盖测试站"))
                .findFirst().orElseThrow();
        assertEquals("覆盖站最大页面数", 1, cov.getMaxPages());
        assertTrue("覆盖站动作模式 ALL", cov.isAllButtonMode());
        assertNull("覆盖站无 TOKEN 配置", cov.getTokenHeader());

        // 孤立页面站：额外入口（相对路径）应解析为绝对地址；sitemap 开关显式覆盖全局默认
        SiteConfig iso = sites.stream().filter(s -> s.getSiteName().equals("孤立页面站"))
                .findFirst().orElseThrow();
        assertEquals("额外入口相对路径应解析为绝对地址", 1, iso.getExtraEntryUrls().size());
        assertTrue("额外入口应指向隐藏页面: " + iso.getExtraEntryUrls(),
                iso.getExtraEntryUrls().get(0).endsWith("/hidden-page"));
        assertEquals("孤立页面站显式开启 sitemap 发现", Boolean.TRUE, iso.getSitemapDiscovery());
        assertEquals("演示站显式关闭 sitemap 发现", Boolean.FALSE, demo.getSitemapDiscovery());
    }

    /** Sitemap 自动发现留空回落全局默认：高级配置留空（或无高级配置表）时回落 application.yml 全局默认值 */
    @Test
    public void sitemapDiscoveryFallsBackToGlobalDefault() throws Exception {
        String[][] rows = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"回落站", "http://localhost:9/", "true", "NONE", "", "",
                        "", "", "", "", "无高级配置表 → Sitemap 留空回落全局默认"}
        };
        Path excel = Files.createTempFile("sitemap-fallback", ".xlsx");
        try {
            writeExcel(excel, rows);

            // 全局默认 true（代码默认值）→ 留空回落 true
            assertTrue("全局默认 true 时留空应回落 true",
                    new ExcelConfigLoader(new PatrolProperties()).load(excel)
                            .get(0).getSitemapDiscovery());

            // 全局默认 false → 留空回落 false（修复前空值被硬编码为 true，全局配置不生效）
            PatrolProperties p = new PatrolProperties();
            p.getDefaults().setSitemapDiscovery(false);
            assertFalse("全局默认 false 时留空应回落 false",
                    new ExcelConfigLoader(p).load(excel).get(0).getSitemapDiscovery());
        } finally {
            Files.deleteIfExists(excel);
        }
    }

    /**
     * 孤立菜单页面全探索：hash 路由菜单、onclick 内联导航菜单、sitemap 孤立页面、
     * 额外入口配置的隐藏页面——四种探索通道应全部覆盖，每个页面都被巡检到。
     */
    @Test
    public void isolatedPagesAllExplored() {
        SiteInspection iso = inspections.stream().filter(s -> s.siteName().equals("孤立页面站"))
                .findFirst().orElseThrow();
        List<String> urls = iso.pages().stream().map(PageInspection::url).toList();
        assertEquals("孤立页面站应探索 7 个页面（首页 + 2 hash 菜单 + onclick 菜单 + 额外入口 + 2 sitemap 页）: "
                + urls, 7, iso.pagesVisited());
        assertEquals("孤立页面站全部页面应 PASS", Verdict.PASS, iso.verdict());
        assertTrue("hash 路由菜单A应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("#/hash-menu-a")));
        assertTrue("hash 路由菜单B应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("#/hash-menu-b")));
        assertTrue("onclick 内联导航菜单应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/onclick-menu")));
        assertTrue("额外入口配置的隐藏页面应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/hidden-page")));
        assertTrue("sitemap 孤立菜单1应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/isolated-menu1")));
        assertTrue("sitemap 孤立菜单2应被探索: " + urls,
                urls.stream().anyMatch(u -> u.endsWith("/isolated-menu2")));
        assertFalse("sitemap 中的外部地址不应被探索",
                urls.stream().anyMatch(u -> u.contains("external.example.com")));
    }

    @Test
    public void demoSiteVisitedAllPages() {
        SiteInspection site = demoSite();
        assertEquals("应巡检 12 个页面（含下拉菜单演示页）", 12, site.pagesVisited());
        assertEquals(Verdict.FAIL, site.verdict());
    }

    @Test
    public void normalPagesPass() {
        PageInspection home = page("/");
        assertNotNull(home);
        assertEquals(Verdict.PASS, home.verdict());
        assertTrue(home.requests().stream().anyMatch(r -> r.url().endsWith("/api/health")
                && r.status() == 200 && r.durationMs() >= 0));

        PageInspection ok = page("/ok-page");
        assertNotNull(ok);
        assertEquals(Verdict.PASS, ok.verdict());
    }

    @Test
    public void brokenApiPageFails() {
        PageInspection p = page("/broken-api");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue("应捕获 /api/fail 失败请求",
                p.requests().stream().anyMatch(r -> r.url().endsWith("/api/fail") && r.status() == 500));
        assertTrue("应捕获 console error",
                p.consoleLogs().stream().anyMatch(c -> c.isError() && c.text().contains("API 调用失败")));
        assertTrue("应包含后端失败与 console 问题",
                p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.BACKEND_FAILURE)
                        && p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.CONSOLE_ERROR));
    }

    @Test
    public void jsErrorPageFails() {
        PageInspection p = page("/js-error");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue(p.jsErrorCount() > 0);
        assertTrue(p.jsErrors().get(0).contains("模拟未捕获异常"));
    }

    @Test
    public void slowPageWarns() {
        PageInspection p = page("/slow");
        assertNotNull(p);
        assertEquals(Verdict.WARN, p.verdict());
        assertTrue(p.loadMs() >= 2900);
        assertTrue(p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.LOAD_TIMEOUT));
    }

    @Test
    public void notFoundPageFails() {
        PageInspection p = page("/error404");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertEquals(404, p.mainStatus());
    }

    @Test
    public void missingResourcePageFails() {
        PageInspection p = page("/missing-js");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue("应捕获 /not-exists.js 失败请求",
                p.requests().stream().anyMatch(r -> r.url().endsWith("/not-exists.js") && r.isFailed()));
    }

    @Test
    public void keywordPageFails() {
        PageInspection p = page("/keyword-page");
        assertNotNull(p);
        assertEquals(Verdict.FAIL, p.verdict());
        assertTrue(p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.ERROR_KEYWORD));
    }

    // ================= 动作巡检（查询按钮点击） =================

    @Test
    public void queryButtonActionPasses() {
        PageInspection p = page("/query-page");
        assertNotNull(p);
        assertEquals("ALL 模式遍历后（确认类排除词生效）页面应仍为 PASS", Verdict.PASS, p.verdict());
        assertEquals("应执行 1 个按钮动作（「查询」被遍历，「保存」被排除）", 1, p.actionCount());
        ActionInspection action = p.actions().get(0);
        assertEquals(Verdict.PASS, action.verdict());
        assertEquals("ALL 模式动作类型应为 ALL_BUTTON_CLICK", "ALL_BUTTON_CLICK", action.actionType());
        assertTrue("动作描述应标注全量遍历", action.description().contains("全量遍历按钮"));
        assertTrue("动作应触发 /api/query 请求",
                action.requests().stream().anyMatch(r -> r.url().contains("/api/query") && r.status() == 200));
        assertFalse("不应触发导航跳转", action.navigatedAway());
        assertNull("动作不应有异常", action.errorMessage());
    }

    @Test
    public void excludedConfirmButtonNeverClicked() {
        for (SiteInspection s : inspections) {
            for (PageInspection p : s.pages()) {
                assertFalse("确认类按钮（保存）不应被点击（页面请求）: " + p.url(),
                        p.requests().stream().anyMatch(r -> r.url().contains("/api/danger")));
                if (p.actions() != null) {
                    for (ActionInspection a : p.actions()) {
                        assertFalse("确认类按钮/弹窗确认不应被点击（动作请求）: " + a.description(),
                                a.requests().stream().anyMatch(r -> r.url().contains("/api/danger")));
                    }
                }
            }
        }
        assertEquals("危险端点（确认创建/确认删除/保存触发）调用计数应为 0",
                0, webServer.dangerCallCount());
    }

    // ================= 弹窗巡检：新增/编辑/删除可点击但不确认 =================

    @Test
    public void dialogButtonsClickedWithoutConfirm() {
        PageInspection p = page("/dialog-page");
        assertNotNull("弹窗演示页应被巡检", p);
        assertEquals("弹窗按钮点击+自动关闭（不确认）后页面应为 PASS", Verdict.PASS, p.verdict());
        assertNotNull(p.actions());
        assertEquals("应执行 5 个动作（新增/删除/导出 + 点击后增量探测到的 2 个弹窗内取消按钮），实际: "
                + (p.actions().stream().map(ActionInspection::description).toList()),
                5, p.actionCount());

        ActionInspection add = p.actions().stream()
                .filter(a -> a.description().contains("新增用户")).findFirst().orElseThrow();
        assertEquals("新增动作应为 PASS", Verdict.PASS, add.verdict());
        assertTrue("新增按钮点击应触发 /api/dialog-open 请求",
                add.requests().stream().anyMatch(r -> r.url().contains("/api/dialog-open") && r.status() == 200));
        assertTrue("新增动作描述应标注不确认: " + add.description(),
                add.description().contains("不确认"));

        ActionInspection del = p.actions().stream()
                .filter(a -> a.description().contains("删除用户")).findFirst().orElseThrow();
        assertEquals("删除动作应为 PASS（弹窗被自动关闭，未确认）", Verdict.PASS, del.verdict());
        assertEquals("危险端点未被调用（弹窗确认按钮绝未点击）", 0, webServer.dangerCallCount());
    }

    @Test
    public void exportDownloadExecutedAndRecorded() {
        PageInspection p = page("/dialog-page");
        assertNotNull(p);
        ActionInspection export = p.actions().stream()
                .filter(a -> a.description().contains("导出数据")).findFirst().orElseThrow();
        assertEquals("导出动作应为 PASS", Verdict.PASS, export.verdict());
        assertTrue("导出动作描述应标注下载: " + export.description(),
                export.description().contains("导出下载"));
        assertNotNull("导出动作应记录下载列表", export.downloads());
        assertTrue("下载记录应包含 patrol-export.txt: " + export.downloads(),
                export.downloads().stream().anyMatch(d -> d.contains("patrol-export.txt")));
        assertFalse("下载不应导致页面跳转", export.navigatedAway());
    }

    @Test
    public void brokenQueryActionFails() {
        PageInspection p = page("/query-broken");
        assertNotNull(p);
        assertEquals("动作 FAIL 应拖累页面结论", Verdict.FAIL, p.verdict());
        assertEquals(1, p.actionCount());
        ActionInspection action = p.actions().get(0);
        assertEquals(Verdict.FAIL, action.verdict());
        assertTrue("动作应捕获 /api/query-fail 失败请求",
                action.requests().stream().anyMatch(r -> r.url().endsWith("/api/query-fail") && r.status() == 500));
        assertTrue("动作应捕获 console error",
                action.consoleLogs().stream().anyMatch(c -> c.isError() && c.text().contains("查询接口失败")));
        assertTrue("动作 FAIL 应补充页面级问题",
                p.issues().stream().anyMatch(i -> i.type() == com.patrol.model.IssueType.ACTION_FAILURE));
        assertNotNull("动作 FAIL 应保存截图", action.screenshotPath());
        assertNotNull("动作 FAIL 应保存上下文", action.contextPath());
    }

    @Test
    public void failingActionScreenshotAnnotated() throws Exception {
        // ---- 动作级：失败动作的截图应带红框标注异常元素 + 操作路径横幅 ----
        PageInspection p = page("/query-broken");
        ActionInspection action = p.actions().get(0);
        assertEquals(Verdict.FAIL, action.verdict());
        String json = Files.readString(reportDir.resolve(action.contextPath()));
        assertTrue("动作上下文应包含标注信息块", json.contains("\"annotation\""));
        assertTrue("标注应包含操作路径（站点→页面→动作）",
                json.contains("站点[") && json.contains("动作["));
        assertTrue("标注路径应包含动作所在页面", json.contains("/query-broken"));
        assertTrue("标注应包含异常原因", json.contains("异常["));
        assertTrue("异常元素应成功画上红框: " + json,
                json.contains("\"elementMarked\" : true"));

        Path shot = reportDir.resolve(action.screenshotPath());
        assertTrue("动作截图应存在", Files.exists(shot) && Files.size(shot) > 100);
        int red = countRedPixels(shot);
        assertTrue("截图应包含红色标注像素（红框+操作路径横幅），实际 " + red, red > 500);

        // ---- 页面级：访问异常页的截图应在动作开始前拍摄（正确的页面），带操作路径横幅 ----
        PageInspection broken = page("/broken-api");
        assertNotNull("访问异常页应有截图", broken.screenshotPath());
        String pageJson = Files.readString(reportDir.resolve(broken.contextPath()));
        assertTrue("页面上下文应包含操作路径标注",
                pageJson.contains("站点[") && pageJson.contains("页面["));
        int pageRed = countRedPixels(reportDir.resolve(broken.screenshotPath()));
        assertTrue("页面截图应包含红色横幅像素，实际 " + pageRed, pageRed > 500);
    }

    /** 统计截图中标注红（#d93026 系）像素数——红框边线与路径横幅底色 */
    private static int countRedPixels(Path png) throws Exception {
        BufferedImage img = ImageIO.read(png.toFile());
        assertNotNull("截图应可读取: " + png, img);
        int red = 0;
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                int c = img.getRGB(x, y);
                if (((c >> 16) & 0xff) > 170 && ((c >> 8) & 0xff) < 90 && (c & 0xff) < 90) red++;
            }
        }
        return red;
    }

    @Test
    public void elementsParsedOnPages() {
        PageInspection p = page("/query-page");
        assertNotNull(p);
        assertNotNull("页面应解析出元素清单", p.elements());
        assertTrue("应解析到查询/新增按钮等元素", p.elements().size() >= 2);
        assertTrue(p.elements().stream().anyMatch(e -> e.tag().equalsIgnoreCase("button")
                && e.text().contains("查询")));
    }

    // ================= 可点击元素全面覆盖：识别 + 分类路由 =================

    private SiteInspection coverageSite() {
        return inspections.stream()
                .filter(s -> s.siteName().equals("覆盖测试站"))
                .findFirst().orElseThrow();
    }

    /** 按文本在覆盖演示页元素台账中查找元素 */
    private ElementDigest covElement(String text) {
        return coverageSite().pages().get(0).elements().stream()
                .filter(e -> text.equals(e.text()))
                .findFirst().orElse(null);
    }

    @Test
    public void clickableElementCoverageRecognizedAndRouted() {
        SiteInspection site = coverageSite();
        assertEquals("覆盖演示页所有动作应 PASS，实际: " + site.pages().get(0).issues(),
                Verdict.PASS, site.verdict());
        PageInspection p = site.pages().get(0);
        List<ActionInspection> actions = p.actions();
        assertEquals("应执行 8 个动作（图标按钮/卡片按钮/伪链接/标签页/折叠项/下载链接"
                        + "+悬停探测+下拉框逐项探测），实际: "
                + (actions == null ? List.of() : actions.stream().map(ActionInspection::description).toList()),
                8, p.actionCount());

        // 图标按钮：无可见文本，通过 aria-label 识别并点击
        ElementDigest icon = covElement("刷新数据");
        assertNotNull("图标按钮应通过 aria-label 识别", icon);
        assertEquals("图标按钮应为按钮类别", ElementDigest.K_BUTTON, icon.kind());
        assertEquals("已点击", icon.decision());
        assertTrue("图标按钮点击应触发 /api/refresh",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/refresh") && r.status() == 200)));

        // role=button 的 div 与 role=tab 的 span（ARIA 可点击角色）
        ElementDigest card = covElement("卡片按钮");
        assertNotNull("role=button 元素应被识别", card);
        assertEquals(ElementDigest.K_BUTTON, card.kind());
        assertEquals("已点击", card.decision());
        assertTrue("卡片按钮点击应触发 /api/aria-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/aria-click"))));
        ElementDigest tab = covElement("标签页一");
        assertNotNull("role=tab 元素应被识别", tab);
        assertEquals(ElementDigest.K_ARIA, tab.kind());
        assertEquals("已点击", tab.decision());
        assertTrue("标签页点击应触发 /api/tab-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/tab-click"))));

        // 无 href 的 JS 伪链接：作为可点击控件点击
        ElementDigest pseudo = covElement("展开更多");
        assertNotNull("无 href 伪链接应被识别", pseudo);
        assertEquals(ElementDigest.K_PSEUDO_LINK, pseudo.kind());
        assertEquals("已点击", pseudo.decision());
        assertTrue("伪链接点击应触发 /api/pseudo-click",
                actions.stream().anyMatch(a -> a.requests().stream()
                        .anyMatch(r -> r.url().contains("/api/pseudo-click"))));

        // 图片链接：锚文本兜底取 img alt；同源导航链接不点击（探索阶段覆盖）
        ElementDigest imgLink = covElement("图标链接说明");
        assertNotNull("图片链接应被识别（img alt 作文本）", imgLink);
        assertEquals("图片链接类别", ElementDigest.K_IMAGE_LINK, imgLink.kind());
        assertEquals("同源图片链接不点击（探索覆盖）", "导航链接·探索阶段覆盖", imgLink.decision());
        assertFalse("导航链接未被点击（不产生跳转动作）",
                actions.stream().anyMatch(a -> a.description().contains("图标链接说明")));

        // 外部链接：不点击
        ElementDigest ext = covElement("外部帮助文档");
        assertNotNull("外部链接应被识别", ext);
        assertEquals(ElementDigest.K_LINK, ext.kind());
        assertEquals("外部链接·不点击", ext.decision());
        assertTrue("外部链接地址应记录", ext.href().contains("example.com"));

        // 下载链接：真实点击执行下载并记录
        ElementDigest dl = covElement("下载报告");
        assertNotNull("下载链接应被识别", dl);
        assertEquals(ElementDigest.K_LINK, dl.kind());
        assertEquals("已点击·下载类", dl.decision());
        ActionInspection dlAction = actions.stream()
                .filter(a -> a.description().contains("下载报告")).findFirst().orElseThrow();
        assertTrue("下载链接动作应记录下载文件: " + dlAction.downloads(),
                dlAction.downloads() != null && dlAction.downloads()
                        .stream().anyMatch(d -> d.contains("patrol-export2.txt")));

        // 疑似可点击（cursor:pointer 无语义标记）：悬停探测（hover 展开的选项自动纳入巡检）；
        // tabindex 可聚焦元素仍仅记录
        ElementDigest ptr = covElement("纯指针区域");
        assertNotNull("cursor:pointer 元素应被记录", ptr);
        assertEquals(ElementDigest.K_POINTER, ptr.kind());
        assertEquals("悬停探测后决策应标注", "已悬停探测·展开选项已巡检", ptr.decision());
        ElementDigest focus = covElement("可聚焦卡片");
        assertNotNull("tabindex 元素应被记录", focus);
        assertEquals(ElementDigest.K_TABINDEX, focus.kind());
        assertEquals("疑似可点击·仅记录", focus.decision());

        // 折叠项 summary：作为可点击控件点击
        ElementDigest sum = covElement("折叠详情");
        assertNotNull("summary 折叠项应被识别", sum);
        assertEquals(ElementDigest.K_SUMMARY, sum.kind());
        assertEquals("已点击", sum.decision());

        // 输入类/表单元素：记录但不点击
        assertEquals("非按钮", covElement("名称标签").decision());
        ElementDigest input = p.elements().stream()
                .filter(e -> ElementDigest.K_INPUT.equals(e.kind()) && "nameInput".equals(e.id()))
                .findFirst().orElse(null);
        assertNotNull("文本输入框应被记录", input);
        assertEquals("非按钮", input.decision());
        ElementDigest sel = p.elements().stream()
                .filter(e -> ElementDigest.K_SELECT.equals(e.kind()))
                .findFirst().orElse(null);
        assertNotNull("下拉框应被记录", sel);
        assertEquals("下拉框探测后决策应标注", "已逐项选择探测·联动已巡检", sel.decision());

        // 所有动作不应发生导航跳转（导航链接/外部链接均未点击）
        assertTrue("覆盖页动作不应跳转",
                actions.stream().noneMatch(ActionInspection::navigatedAway));
    }

    @Test
    public void summaryCountsActions() {
        assertEquals("演示站（ALL 模式）应有 11 个动作（查询+搜索+新增弹窗+删除弹窗+导出"
                        + "+弹窗内 2 个取消浮层选项+下拉菜单页 4 个[菜单项+3 下拉选项]）",
                11, demoSite().totalActions());
        assertEquals("其中 1 个失败（异常查询页）", 1, demoSite().failedActions());
    }

    // ================= 通用 DOM 增量探测：下拉菜单 / 悬停菜单 / 原生下拉级联 / 异步渲染 / 填充联动 =================

    /**
     * table/td 下拉菜单（table 下拉选项）全量点击巡检：
     * 菜单项点击展开 table 格式下拉选项（初始扫描时不存在于 DOM），
     * 增量探测应识别「新展现」的每个选项并逐个点击巡检；
     * 选项点击导致下拉收起后自动重展开父菜单再点击下一选项；
     * 下拉重建（模拟框架重渲染）后同结构选项按指纹去重只巡检一次。
     */
    @Test
    public void dropdownTableOptionsAllClicked() {
        PageInspection p = page("/dropdown-table");
        assertNotNull("下拉菜单演示页应被巡检", p);
        assertNotNull(p.actions());
        assertEquals("菜单项 + 3 个下拉选项都应被点击，实际: "
                        + (p.actions().stream().map(ActionInspection::description).toList()),
                4, p.actionCount());
        // 每个下拉选项端点恰好被触发 1 次（下拉重建后同结构路径的选项不重复点击）
        assertEquals("「用户管理」应被恰好点击 1 次", 1, webServer.dropCallCount("/api/drop-user"));
        assertEquals("「角色管理」应被恰好点击 1 次", 1, webServer.dropCallCount("/api/drop-role"));
        assertEquals("「菜单管理」应被恰好点击 1 次", 1, webServer.dropCallCount("/api/drop-menu"));

        // 每个下拉选项动作：类别=下拉选项、PASS、触发对应端点
        for (String opt : List.of("用户管理", "角色管理", "菜单管理")) {
            ActionInspection a = p.actions().stream()
                    .filter(x -> x.description().contains(opt)).findFirst().orElseThrow();
            assertEquals("下拉选项动作应为 PASS: " + a.description(), Verdict.PASS, a.verdict());
            assertEquals("动作类别应为下拉选项: " + a.description(), "下拉选项", a.buttonCategory());
            assertTrue("下拉选项动作应触发对应端点: " + a.requests(),
                    a.requests().stream().anyMatch(r -> r.url().contains("/api/drop-")
                            && r.status() == 200));
        }

        // 元素台账：下拉选项（探测到的展现实例）标注「已点击·下拉/浮层选项」
        List<ElementDigest> opts = p.elements().stream()
                .filter(e -> "用户管理".equals(e.text()) || "角色管理".equals(e.text())
                        || "菜单管理".equals(e.text()))
                .toList();
        assertTrue("下拉选项应出现在元素台账（初始不存在于 DOM + 增量探测展现）: " + opts.size(),
                opts.size() >= 3);
        assertTrue("下拉选项应标注已点击: " + opts.stream().map(ElementDigest::decision).toList(),
                opts.stream().anyMatch(e -> "已点击·下拉/浮层选项".equals(e.decision())));
        assertEquals("下拉菜单页应为 PASS", Verdict.PASS, p.verdict());
    }

    /**
     * 点击之外的 DOM 增量源也自动探测并巡检：
     * ① cursor:pointer 悬停菜单（无语义标记，mouseenter 展开）→ 悬停探测 → 展开选项被点击
     *   （选项点击前菜单已收起，验证 hover 重展开父菜单链路）；
     * ② 原生 select 级联（change 联动区域按钮）→ 逐项选择探测 → 联动按钮被点击；
     * ③ 定时脚本异步渲染按钮 → 页面稳定期复扫发现并入初始计划 → 被点击。
     */
    @Test
    public void domIncrementalProbeOpsCovered() {
        SiteInspection site = inspections.stream()
                .filter(s -> s.siteName().equals("DOM探测站"))
                .findFirst().orElseThrow();
        PageInspection p = site.pages().get(0);
        assertNotNull(p.actions());
        List<ActionInspection> actions = p.actions();

        // 悬停探测：悬停展开的菜单选项被点击（含 hover 重展开父菜单链路）
        assertEquals("悬停展开的选项应被点击 1 次", 1, webServer.probeCallCount("/api/hover-opt"));
        // 原生下拉逐项选择：级联联动按钮被点击
        assertEquals("select 级联「北京」联动按钮应被点击", 1, webServer.probeCallCount("/api/area-bj"));
        assertEquals("select 级联「上海」联动按钮应被点击", 1, webServer.probeCallCount("/api/area-sh"));
        // 异步渲染：稳定期复扫发现的延迟按钮被点击
        assertEquals("延迟渲染按钮应被稳定复扫发现并点击", 1, webServer.probeCallCount("/api/async-btn"));

        // 动作明细：悬停探测 / 下拉框逐项 / 下拉选项 / 全量遍历按钮
        assertTrue("应有悬停探测动作: " + actions.stream().map(ActionInspection::description).toList(),
                actions.stream().anyMatch(a -> "悬停探测".equals(a.buttonCategory())));
        assertTrue("应有下拉框逐项选择动作",
                actions.stream().anyMatch(a -> "下拉框逐项".equals(a.buttonCategory())));
        assertTrue("悬停展开的选项应作为下拉选项被巡检",
                actions.stream().anyMatch(a -> a.description().contains("悬浮菜单 > 悬浮选项A")));
        assertTrue("select 级联「北京」按钮应作为下拉选项被巡检",
                actions.stream().anyMatch(a -> a.description().contains("北京区域操作")));
        assertTrue("延迟渲染按钮应作为初始元素被巡检",
                actions.stream().anyMatch(a -> a.description().contains("延迟渲染按钮")));

        assertEquals("DOM 增量探测演示页应为 PASS: " + p.issues(), Verdict.PASS, site.verdict());

        // 元素台账决策标注
        ElementDigest hoverMenu = p.elements().stream()
                .filter(e -> "悬浮菜单".equals(e.text())).findFirst().orElse(null);
        assertNotNull("悬停菜单元素应被记录", hoverMenu);
        assertEquals("悬停探测后决策应标注", "已悬停探测·展开选项已巡检", hoverMenu.decision());
        ElementDigest city = p.elements().stream()
                .filter(e -> "city".equals(e.id())).findFirst().orElse(null);
        assertNotNull("原生下拉框应被记录", city);
        assertEquals("下拉框探测后决策应标注", "已逐项选择探测·联动已巡检", city.decision());
    }

    /**
     * 弹窗关闭增强：模态框的关闭控件用 addEventListener 绑定（元素扫描不可识别，
     * 也无 cursor:pointer 标记），旧逻辑（Esc + 只找 button 文本按钮）无法关闭——
     * 残留弹窗会遮挡后续按钮的点击。增强后的关闭逻辑应 JS click 命中关闭控件，
     * 弹窗关闭后的按钮照常被点击。
     */
    @Test
    public void modalWithUndetectableCloseGetsClosed() {
        SiteInspection site = inspections.stream()
                .filter(s -> s.siteName().equals("弹窗关闭站"))
                .findFirst().orElseThrow();
        assertEquals("弹窗关闭站应为单页", 1, site.pagesVisited());
        PageInspection p = site.pages().get(0);
        assertEquals("模态框关闭控件应被增强关闭逻辑点击 1 次",
                1, webServer.probeCallCount("/api/modal-closed"));
        assertEquals("弹窗关闭后的按钮应被正常点击（弹窗未残留遮挡）",
                1, webServer.probeCallCount("/api/after-modal"));
        assertEquals("弹窗关闭站页面应为 PASS: " + p.issues(), Verdict.PASS, p.verdict());
    }

    /**
     * 窗口外迟到错误捕获：页面加载 1s 后异步 console.error，发生在页面访问窗口
     * （finishVisit）之后、动作巡检收尾之前——窗口外缓冲 + 页面收尾 drain 机制
     * 应把它并入页面级结果并按阈值参与判定（不因窗口间隙而丢失）。
     */
    @Test
    public void strayConsoleErrorCapturedOutsideVisitWindow() {
        SiteInspection site = inspections.stream()
                .filter(s -> s.siteName().equals("迟到错误站"))
                .findFirst().orElseThrow();
        PageInspection p = site.pages().get(0);
        assertEquals("窗口间隙的迟到 console 错误应导致页面 FAIL", Verdict.FAIL, p.verdict());
        assertTrue("迟到错误文本应被捕获并入页面结果: " + p.consoleLogs(),
                p.consoleLogs().stream().filter(ConsoleRecord::isError)
                        .anyMatch(c -> c.text().contains("延迟脚本错误")));
    }

    /**
     * DOM 重渲染重定位：按钮A 点击后销毁并重建按钮B（父容器换 id，B 的原 cssPath
     * 彻底失效）——点击失败后应按指纹（tag|文本|href）重新扫描定位同元素，
     * 用最新选择器重试成功，不产生失败动作。
     */
    @Test
    public void reRenderedElementRelocatedByFingerprint() {
        SiteInspection site = inspections.stream()
                .filter(s -> s.siteName().equals("重定位站"))
                .findFirst().orElseThrow();
        PageInspection p = site.pages().get(0);
        assertEquals("重渲染按钮应被点击", 1, webServer.probeCallCount("/api/a-rerender"));
        assertTrue("按钮B 应在销毁重建后被指纹重定位点击（重定位或增量探测任一路径）",
                webServer.probeCallCount("/api/b-relocated") >= 1);
        assertEquals("重定位站不应有失败动作: "
                        + (p.actions() == null ? List.of() : p.actions().stream()
                                .map(a -> a.description() + "->" + a.verdict()).toList()),
                0, p.failedActionCount());
        assertEquals("重定位站页面应为 PASS: " + p.issues(), Verdict.PASS, p.verdict());
    }

    /**
     * 前端业务 API 请求全链路采集：站点级 apiCalls 应记录页面加载与动作点击触发的
     * xhr/fetch 请求（含 pageUrl/triggerUrl/触发源/方法/状态/请求头/请求体/响应体/耗时/失败信息），
     * 过滤图片等非业务资源请求；POST 请求应能生成含方法、URL、请求头、请求体的标准 curl 复现命令。
     */
    @Test
    public void apiCallsCapturedWithDetailsAndCurl() {
        SiteInspection site = inspections.stream()
                .filter(s -> s.siteName().equals("API采集站"))
                .findFirst().orElseThrow();
        List<ApiCallRecord> calls = site.apiCallList();
        assertFalse("API采集站应捕获到业务 API 请求", calls.isEmpty());

        // 1. 过滤规则：只保留业务请求（xhr/fetch），图片等资源请求不得混入
        for (ApiCallRecord c : calls) {
            assertTrue("应只保留 xhr/fetch 业务请求，混入了: " + c.resourceType() + " " + c.url(),
                    "xhr".equalsIgnoreCase(c.resourceType()) || "fetch".equalsIgnoreCase(c.resourceType()));
        }

        // 2. 页面加载触发的 GET 请求：pageUrl/triggerUrl/触发源/状态/响应体 全维度记录
        ApiCallRecord hello = calls.stream()
                .filter(c -> c.url().endsWith("/api/hello")).findFirst().orElseThrow();
        assertEquals("GET 方法应记录", "GET", hello.method());
        assertEquals("GET 请求应为 200", 200, hello.status());
        assertFalse("GET 请求不应判失败", hello.isFailed());
        assertTrue("响应体应被抓取并包含服务端返回内容: " + hello.responseBody(),
                hello.responseBody() != null && hello.responseBody().contains("hello patrol"));
        assertTrue("pageUrl 应归因到 API 采集页: " + hello.pageUrl(),
                hello.pageUrl() != null && hello.pageUrl().endsWith("/api-calls"));
        assertTrue("triggerUrl 应记录请求发起时的页面地址: " + hello.triggerUrl(),
                hello.triggerUrl() != null && hello.triggerUrl().endsWith("/api-calls"));
        assertEquals("页面加载触发的请求 source 应为 页面加载", "页面加载", hello.source());
        assertTrue("请求耗时应被记录", hello.durationMs() >= 0);

        // 3. 动作点击触发的 POST 请求：请求头 + 请求体记录，触发源归因到动作描述
        ApiCallRecord order = calls.stream()
                .filter(c -> c.url().endsWith("/api/order")).findFirst().orElseThrow();
        assertEquals("POST 方法应记录", "POST", order.method());
        assertTrue("触发源应归因到动作描述: " + order.source(),
                order.source() != null && order.source().startsWith("动作:"));
        assertTrue("请求体应记录 POST body: " + order.requestBody(),
                order.requestBody() != null && order.requestBody().contains("\"item\"")
                        && order.requestBody().contains("\"book\""));
        assertTrue("请求头应包含 Content-Type: " + order.requestHeaders(),
                order.requestHeaders() != null
                        && "application/json".equalsIgnoreCase(order.requestHeaders().get("content-type")));
        assertTrue("请求头应包含自定义头 X-Trace-Id",
                order.requestHeaders().containsKey("x-trace-id")
                        && "trace-123".equals(order.requestHeaders().get("x-trace-id")));
        assertTrue("POST 响应体应被抓取", order.responseBody() != null
                && order.responseBody().contains("\"orderId\""));

        // 4. curl 复现命令：标准格式（方法 + URL + 请求头 + 请求体）
        String curl = order.toCurl();
        assertTrue("curl 命令应以 curl 开头", curl.startsWith("curl -X POST"));
        assertTrue("curl 命令应包含请求 URL", curl.contains(order.url()));
        assertTrue("curl 命令应包含规范化大小写的 Content-Type 头",
                curl.contains("-H 'Content-Type: application/json'"));
        assertTrue("curl 命令应包含规范化大小写的自定义请求头",
                curl.contains("-H 'X-Trace-Id: trace-123'"));
        assertTrue("curl 命令应包含请求体", curl.contains("--data-raw"));
        assertTrue("curl 命令请求体应含业务数据", curl.contains("\"book\""));
        String curlOneLine = order.toCurlOneLine();
        assertTrue("单行版 curl 命令不应包含换行", curlOneLine.indexOf('\n') < 0);

        // 5. 失败请求（500）：状态与失败判定记录正确
        ApiCallRecord fail = calls.stream()
                .filter(c -> c.url().endsWith("/api/fail")).findFirst().orElseThrow();
        assertEquals("失败请求应记录 500 状态", 500, fail.status());
        assertTrue("500 响应应判失败", fail.isFailed());
        assertTrue("失败请求的响应体也应被抓取: " + fail.responseBody(),
                fail.responseBody() != null && fail.responseBody().contains("boom"));
        assertEquals("失败 API 数量统计", 1, site.failedApiCalls());

        // 6. 图片资源请求（/favicon.ico，resourceType=image）不得出现在业务 API 列表
        assertTrue("图片资源请求应被过滤",
                calls.stream().noneMatch(c -> c.url().contains("favicon")));
    }

    /**
     * 自定义动作 fill 填充也是 DOM 增量源：填充 input 后 oninput 渲染的输入建议
     * （display:none → block 的「新展现」按钮）应被立即探测并纳入动作队列点击巡检，
     * 随后自定义动作本身的目标按钮照常点击（QUERY 模式下不受查询词过滤——主动操作的结果）。
     */
    @Test
    public void fillProbeRendersSuggestionsInspected() throws Exception {
        // 独立 Excel：填充站（QUERY 模式——「触发按钮」不命中查询词，仅由页面动作点击）+ 页面动作（fills）
        Path excel = Path.of("target", "fill-probe-sites.xlsx");
        String[][] sites = {
                {"站点名称", "入口URL", "启用", "认证方式", "用户名", "密码",
                        "登录URL", "用户名选择器", "密码选择器", "提交按钮选择器", "备注"},
                {"填充站", webServer.baseUrl() + "/fill-probe", "true", "NONE", "", "",
                        "", "", "", "", "填充联动增量探测演示（输入建议自动补全）"}
        };
        String[] advHead = com.patrol.excel.ExcelTemplateGenerator.ADVANCED_HEADERS;
        String[] adv = new String[advHead.length];
        adv[0] = "填充站";
        adv[1] = "1";   // 页数
        adv[2] = "0";   // 深度
        adv[6] = "false"; // sitemap
        adv[7] = "true";  // 动作开关
        adv[8] = "QUERY"; // 动作模式
        adv[9] = "5";     // 动作上限
        String[][] actions = {
                {"站点名称", "页面URL匹配", "动作类型", "元素选择器", "填充值", "说明", "启用"},
                {"填充站", "", "CLICK", "#searchBtn", "#kw=巡检关键字", "填充关键字后点击触发按钮", "true"}
        };
        ExcelWriter writer = null;
        try {
            writer = EasyExcel.write(excel.toString()).build();
            writeMatrix(writer, 0, "Sites", sites);
            writeMatrix(writer, 1, "站点高级配置", new String[][]{advHead, adv});
            writeMatrix(writer, 2, "页面动作", actions);
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        int search0 = webServer.probeCallCount("/api/search");
        int sugA0 = webServer.probeCallCount("/api/sug-a");
        int sugB0 = webServer.probeCallCount("/api/sug-b");

        PatrolProperties props = new PatrolProperties();
        props.setExcelPath(excel.toString());
        props.setOutputDir(Path.of("target", "fill-probe-report").toString());
        props.setLoginStateDir(Path.of("target", "login-state-fill").toString());
        ExcelConfigLoader testLoader = new ExcelConfigLoader(props);
        SiteConfig fillSite = testLoader.load(excel).stream()
                .filter(s -> s.getSiteName().equals("填充站")).findFirst().orElseThrow();
        List<PageActionConfig> pageActions = testLoader.loadPageActions(excel);
        assertEquals("页面动作应加载 1 条", 1, pageActions.size());

        PatrolEngine engine = new PatrolEngine(props, new HealthJudge());
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            SiteInspection result = engine.inspect(fillSite, browser,
                    Path.of("target", "fill-probe-report", "patrol-fill"), pageActions);
            PageInspection p = result.pages().get(0);
            assertNotNull(p.actions());
            assertEquals("填充站应为 PASS: " + p.issues(), Verdict.PASS, result.verdict());

            // 自定义动作链路：fills 填充 → 点击目标按钮
            assertEquals("填充后应点击触发按钮 1 次", 1,
                    webServer.probeCallCount("/api/search") - search0);
            assertTrue("应有自定义动作: "
                            + p.actions().stream().map(ActionInspection::description).toList(),
                    p.actions().stream().anyMatch(a -> "自定义".equals(a.buttonCategory())));

            // 填充联动探测：输入建议按钮（新展现）被纳入队列点击巡检
            assertEquals("输入建议「建议词A」应被点击 1 次", 1,
                    webServer.probeCallCount("/api/sug-a") - sugA0);
            assertEquals("输入建议「建议词B」应被点击 1 次", 1,
                    webServer.probeCallCount("/api/sug-b") - sugB0);
            assertTrue("建议词A 应作为下拉选项动作被巡检（描述含父链）: "
                            + p.actions().stream().map(ActionInspection::description).toList(),
                    p.actions().stream().anyMatch(a -> a.description().contains("建议词A")
                            && "下拉选项".equals(a.buttonCategory())));
            assertTrue("建议词B 应作为下拉选项动作被巡检",
                    p.actions().stream().anyMatch(a -> a.description().contains("建议词B")
                            && "下拉选项".equals(a.buttonCategory())));
        }
    }

    /**
     * 三个增量探测开关全部关闭（=0）时行为回落：
     * 悬停探测禁用 → cursor:pointer 悬浮菜单仅记录不点击；
     * 下拉框逐项探测禁用 → 原生 select 仅记录不选择；
     * 稳定期复扫禁用 → 异步渲染的延迟按钮既不进台账也不被点击。
     */
    @Test
    public void probeSwitchesCanBeDisabled() throws Exception {
        int hover0 = webServer.probeCallCount("/api/hover-opt");
        int bj0 = webServer.probeCallCount("/api/area-bj");
        int sh0 = webServer.probeCallCount("/api/area-sh");
        int async0 = webServer.probeCallCount("/api/async-btn");

        PatrolProperties props = new PatrolProperties();
        props.setOutputDir(Path.of("target", "probe-boundary-report").toString());
        props.setLoginStateDir(Path.of("target", "login-state-boundary").toString());
        props.getDefaults().setMaxHoverProbesPerPage(0);
        props.getDefaults().setMaxSelectOptionsProbe(0);
        props.getDefaults().setDomStableRescanMs(0);

        SiteInspection result = inspectDomOps(props);
        PageInspection p = result.pages().get(0);

        assertEquals("悬停探测禁用后 hover 选项不应被点击", hover0,
                webServer.probeCallCount("/api/hover-opt"));
        assertEquals("select 探测禁用后「北京」联动不应被点击", bj0,
                webServer.probeCallCount("/api/area-bj"));
        assertEquals("select 探测禁用后「上海」联动不应被点击", sh0,
                webServer.probeCallCount("/api/area-sh"));
        assertEquals("稳定期复扫禁用后延迟渲染按钮不应被点击", async0,
                webServer.probeCallCount("/api/async-btn"));

        // 决策台账回落为仅记录语义
        ElementDigest hoverMenu = p.elements().stream()
                .filter(e -> "悬浮菜单".equals(e.text())).findFirst().orElse(null);
        assertNotNull("悬停菜单元素仍应被记录", hoverMenu);
        assertEquals("禁用悬停探测后决策应回落仅记录",
                "疑似可点击·仅记录", hoverMenu.decision());
        ElementDigest city = p.elements().stream()
                .filter(e -> "city".equals(e.id())).findFirst().orElse(null);
        assertNotNull("原生下拉框仍应被记录", city);
        assertEquals("禁用下拉框探测后决策应回落非按钮", "非按钮", city.decision());
        assertEquals("开关禁用是正常巡检行为，页面不应判失败: " + p.issues(),
                Verdict.PASS, result.verdict());
    }

    /**
     * max-select-options-probe 选项上限截断：dom-ops 的城市下拉有两个非空选项
     * （北京/上海），上限设 1 时只逐项选择第一个（北京），上海不被选择、其联动按钮不巡检。
     */
    @Test
    public void selectProbeOptionLimitTruncates() throws Exception {
        int bj0 = webServer.probeCallCount("/api/area-bj");
        int sh0 = webServer.probeCallCount("/api/area-sh");

        PatrolProperties props = new PatrolProperties();
        props.setOutputDir(Path.of("target", "probe-boundary-report").toString());
        props.setLoginStateDir(Path.of("target", "login-state-boundary").toString());
        props.getDefaults().setMaxSelectOptionsProbe(1);

        SiteInspection result = inspectDomOps(props);

        assertEquals("上限 1：第一个选项「北京」级联按钮应被点击", 1,
                webServer.probeCallCount("/api/area-bj") - bj0);
        assertEquals("上限 1：第二个选项「上海」不应被选择探测", 0,
                webServer.probeCallCount("/api/area-sh") - sh0);
        assertEquals("截断是正常巡检行为，页面不应判失败: " + result.pages().get(0).issues(),
                Verdict.PASS, result.verdict());
    }

    /** dom-ops 演示页的单站点配置（ALL 模式，全部按钮型元素 + 增量探测操作） */
    private SiteConfig domOpsSite() {
        SiteConfig site = new SiteConfig();
        site.setSiteName("DOM探测边界站");
        site.setEntryUrl(webServer.baseUrl() + "/dom-ops");
        site.setMaxPages(1);
        site.setMaxDepth(0);
        site.setActionMode("ALL");
        site.setMaxActionsPerPage(12);
        site.setLoadTimeoutMs(5000);
        return site;
    }

    /** 用给定属性对 dom-ops 页执行一次独立无头巡检 */
    private SiteInspection inspectDomOps(PatrolProperties props) throws Exception {
        PatrolEngine engine = new PatrolEngine(props, new HealthJudge());
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            return engine.inspect(domOpsSite(), browser,
                    Path.of("target", "probe-boundary-report", "patrol-boundary"), List.of());
        }
    }

    // ================= 认证与登录态复用 =================

    @Test
    public void formAuthSitePasses() {
        SiteInspection login = loginSite();
        assertNull("不应有站点级错误: " + login.errorMessage(), login.errorMessage());
        assertEquals(Verdict.PASS, login.verdict());
        assertTrue(login.pagesVisited() >= 1);
    }

    @Test
    public void loginStateCachedAndReused() throws Exception {
        Path stateFile = Path.of(properties.getLoginStateDir(), "本地登录站.json");
        assertTrue("FORM 登录后应缓存登录态: " + stateFile,
                Files.exists(stateFile) && Files.size(stateFile) > 50);
        long mtimeBefore = Files.getLastModifiedTime(stateFile).toMillis();

        // 第二次巡检同一站点：应复用缓存登录态（不再重新登录 → 状态文件不被更新）
        SiteConfig site = loader.load(Path.of(properties.getExcelPath())).stream()
                .filter(s -> s.getSiteName().equals("本地登录站"))
                .findFirst().orElseThrow();
        PatrolEngine engine = new PatrolEngine(properties, new HealthJudge());
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false);
             Browser browser = playwright.chromium().launch(
                     new BrowserType.LaunchOptions().setHeadless(true))) {
            SiteInspection second = engine.inspect(site, browser, reportDir, List.of());
            assertEquals("复用登录态后的巡检也应通过", Verdict.PASS, second.verdict());
        }
        assertEquals("应复用缓存登录态（状态文件未重新生成）",
                mtimeBefore, Files.getLastModifiedTime(stateFile).toMillis());
    }

    /**
     * MANUAL 人工登录第三种成功信号「登录成功Cookie」：
     * 登录在页面弹窗内完成、URL 不变化的站点（如百度 BDUSS）适用。
     * /manual-login 页加载 1.5s 后由 JS 种下 Cookie patrol_ok，框架应立即检测到并保存登录态，
     * 而不是等满手动登录超时。
     */
    @Test
    public void manualLoginCookieSignalDetected() throws Exception {
        SiteConfig site = new SiteConfig();
        site.setSiteName("手动登录站");
        site.setEntryUrl(webServer.baseUrl() + "/manual-login");
        site.setAuthType("MANUAL");
        site.setLoginSuccessCookie("patrol_ok");
        site.setManualLoginTimeoutSec(20);

        Path stateDir = Path.of("target", "login-state-manual-test");
        if (Files.exists(stateDir)) {
            try (var walk = Files.walk(stateDir)) {
                walk.sorted(java.util.Comparator.reverseOrder())
                        .forEach(p -> p.toFile().delete());
            }
        }

        long t0 = System.currentTimeMillis();
        try (Playwright playwright = com.patrol.engine.PlaywrightFactory.create(false)) {
            com.patrol.engine.AuthSupport.preAuthenticate(playwright, properties, site, stateDir);
        }
        long elapsed = System.currentTimeMillis() - t0;

        Path state = stateDir.resolve("手动登录站.json");
        assertTrue("MANUAL 登录成功后应缓存登录态: " + state,
                Files.exists(state) && Files.size(state) > 50);
        String json = Files.readString(state);
        assertTrue("storageState 应包含登录 Cookie patrol_ok", json.contains("patrol_ok"));
        assertTrue("Cookie 信号应远早于超时被检测到（实际耗时 " + elapsed + "ms，超时 20s）",
                elapsed < 15_000);
    }

    // ================= 并行多站点巡检（PatrolRunner 两阶段端到端） =================

    /**
     * 验证执行编排：阶段一预认证（有头、串行）→ 阶段二并行无头巡检（Playwright 多实例）。
     * 4 个站点、并行度 2：3 个 NONE 站点正常巡检，1 个 FORM 站点登录地址不可达应判 FAIL 且不阻断其他站点。
     * 同时验证向后兼容：本用例刻意使用旧版 31 列宽表格式，旧配置文件无需迁移即可继续使用。
     */
    @Test
    public void parallelMultiSitePatrolWithTwoPhaseAuth() throws Exception {
        Path excel = Path.of("target", "parallel-sites.xlsx");
        String[][] rows = {
                ExcelTemplateHeaders.headRow(),
                parallelRow("并行站1", webServer.baseUrl() + "/ok-page", "NONE"),
                parallelRow("并行站2", webServer.baseUrl() + "/query-page", "NONE"),
                parallelRow("并行站3", webServer.baseUrl() + "/dialog-page", "NONE"),
                parallelRow("认证失败站", webServer.baseUrl() + "/ok-page", "FORM"),
        };
        // 认证失败站：登录地址端口不可达 → 阶段一有头认证快速失败
        rows[4][4] = "user";
        rows[4][5] = "pass";
        rows[4][6] = "http://127.0.0.1:1/login";
        rows[4][7] = "#u";
        rows[4][8] = "#p";
        rows[4][9] = "#s";
        writeExcel(excel, rows);

        PatrolProperties props = new PatrolProperties();
        props.setExcelPath(excel.toString());
        props.setOutputDir(Path.of("target", "parallel-report").toString());
        props.setLoginStateDir(Path.of("target", "login-state-parallel").toString());
        props.setMaxParallelSites(2);
        props.setStrictExit(false);
        props.getDefaults().setLoadTimeoutMs(2000);

        PatrolRunner runner = new PatrolRunner(props,
                new ExcelConfigLoader(props),
                new PatrolEngine(props, new HealthJudge()),
                new JsonReportWriter(), new ExcelReportGenerator(), new HtmlReportGenerator(),
                new com.patrol.report.ReportIndexGenerator());
        runner.run();

        // 读取最新报告目录中的 JSON 结果
        Path outRoot = Path.of("target", "parallel-report");
        Path latest;
        try (var stream = Files.list(outRoot)) {
            latest = stream.filter(Files::isDirectory)
                    .max(java.util.Comparator.comparing(p -> p.getFileName().toString()))
                    .orElseThrow(() -> new AssertionError("应生成报告目录"));
        }
        com.fasterxml.jackson.databind.JsonNode sites = new com.fasterxml.jackson.databind.ObjectMapper()
                .readTree(latest.resolve("patrol-result.json").toFile()).get("sites");

        assertEquals("4 个站点均应有结果（按配置顺序）", 4, sites.size());
        assertEquals("结果顺序应与配置一致: " + sites.get(0).get("siteName").asText(),
                "并行站1", sites.get(0).get("siteName").asText());
        assertEquals("并行站2", sites.get(1).get("siteName").asText());
        assertEquals("并行站3", sites.get(2).get("siteName").asText());
        assertEquals("认证失败站", sites.get(3).get("siteName").asText());

        for (int i = 0; i < 3; i++) {
            assertEquals("NONE 站点应巡检通过: " + sites.get(i).get("siteName").asText(),
                    "PASS", sites.get(i).get("verdict").asText());
            assertTrue("站点应巡检到页面: " + sites.get(i).get("siteName").asText(),
                    sites.get(i).get("pages").size() >= 1);
        }
        assertEquals("认证失败站点应判 FAIL", "FAIL", sites.get(3).get("verdict").asText());
        assertTrue("应记录认证失败原因: " + sites.get(3).get("errorMessage").asText(),
                sites.get(3).get("errorMessage").asText().contains("登录认证失败"));
        assertEquals("认证失败站点不应有页面", 0, sites.get(3).get("pages").size());

        // 三份报告文件应存在
        assertTrue(Files.exists(latest.resolve("report.html")));
        assertTrue(Files.exists(latest.resolve("patrol-report.xlsx")));

        // 历次巡检索引页应自动生成并包含本次巡检
        Path index = outRoot.resolve("index.html");
        assertTrue("应生成历次报告索引页", Files.exists(index));
        String indexHtml = Files.readString(index);
        assertTrue("索引页应链接本次报告目录", indexHtml.contains(latest.getFileName().toString()));
        assertTrue("索引页应展示站点统计", indexHtml.contains("并行站1"));
    }

    /** 并行测试行：单页、零深度、禁用动作 */
    private static String[] parallelRow(String name, String url, String auth) {
        String[] r = new String[31];
        r[0] = name;
        r[1] = url;
        r[2] = "true";
        r[3] = auth;
        r[16] = "1";       // 最大页面数
        r[17] = "0";       // 最大深度
        r[20] = "false";   // 禁用动作巡检（保持测试精简）
        r[22] = "0";       // 动作上限
        r[28] = "2000";    // 加载超时
        r[30] = "并行巡检测试站点";
        return r;
    }

    // ================= 证据与报告 =================

    @Test
    public void evidenceSavedForAbnormalPages() throws Exception {
        for (PageInspection p : demoSite().pages()) {
            if (p.verdict() == Verdict.FAIL || p.verdict() == Verdict.WARN) {
                assertNotNull("异常页应保存截图: " + p.url(), p.screenshotPath());
                assertNotNull("异常页应保存上下文 JSON: " + p.url(), p.contextPath());
                Path shot = reportDir.resolve(p.screenshotPath().replace('/', '\\').replace('\\', '/'));
                assertTrue("截图文件应存在: " + shot, Files.exists(shot) && Files.size(shot) > 100);
                Path ctx = reportDir.resolve(p.contextPath().replace('/', '\\').replace('\\', '/'));
                assertTrue("上下文 JSON 应存在: " + ctx, Files.exists(ctx) && Files.size(ctx) > 50);
            }
        }
    }

    @Test
    public void evidenceContextContainsDetails() throws Exception {
        PageInspection p = page("/broken-api");
        Path ctx = reportDir.resolve(p.contextPath());
        String json = Files.readString(ctx);
        assertTrue(json.contains("/api/fail"));
        assertTrue(json.contains("API 调用失败"));
        assertTrue(json.contains("responseSnippet"));
        assertTrue(json.contains("pageHtmlExcerpt"));
    }

    @Test
    public void reportsGenerated() throws Exception {
        int totalActions = inspections.stream().mapToInt(SiteInspection::totalActions).sum();
        int failedActions = inspections.stream().mapToInt(s -> (int) s.failedActions()).sum();
        PatrolSummary summary = new PatrolSummary(
                inspections.size(), inspections.size(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.PASS).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.WARN).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.FAIL).count(),
                inspections.stream().mapToInt(SiteInspection::pagesVisited).sum(),
                inspections.stream().mapToInt(s -> (int) s.passPages()).sum(),
                inspections.stream().mapToInt(s -> (int) s.warnPages()).sum(),
                inspections.stream().mapToInt(s -> (int) s.failPages()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.consoleErrorCount()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.jsErrorCount()).sum(),
                inspections.stream().flatMap(s -> s.pages().stream())
                        .mapToInt(p -> (int) p.failedRequestCount()).sum(),
                totalActions, failedActions, 0);
        PatrolReport report = new PatrolReport(
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                "target/test-sites.xlsx", "chromium (test)", inspections, summary);

        Path json = reportDir.resolve("patrol-result.json");
        new JsonReportWriter().write(report, json);
        Path xlsx = reportDir.resolve("patrol-report.xlsx");
        new ExcelReportGenerator().generate(report, xlsx);
        Path html = reportDir.resolve("report.html");
        new HtmlReportGenerator().generate(report, html);

        assertTrue(Files.exists(json) && Files.size(json) > 1000);
        assertTrue(Files.exists(xlsx) && Files.size(xlsx) > 5000);
        assertTrue(Files.exists(html) && Files.size(html) > 3000);

        // JSON 应包含动作明细字段
        String jsonText = Files.readString(json);
        assertTrue("JSON 应包含动作明细", jsonText.contains("\"actions\""));
        assertTrue("JSON 应包含元素解析", jsonText.contains("\"elements\""));
        assertTrue("JSON 应包含动作统计", jsonText.contains("\"totalActions\""));

        // Excel 应包含动作明细 sheet（EasyExcel 读回验证，含表头行）
        List<Map<Integer, String>> actionRows = readGeneratedSheet(xlsx, "动作明细");
        assertTrue("Excel 应有动作明细 sheet", actionRows.size() >= 1);
        assertTrue("动作明细应有表头 + 至少 2 条数据行: " + actionRows.size(),
                actionRows.size() >= 3);
        List<Map<Integer, String>> pageRows = readGeneratedSheet(xlsx, "页面明细");
        assertFalse("Excel 应有页面明细 sheet", pageRows.isEmpty());

        // HTML 应包含动作区块
        String htmlText = Files.readString(html);
        assertTrue("HTML 应展示功能动作", htmlText.contains("功能动作"));
        assertTrue("HTML 应展示执行动作汇总", htmlText.contains("执行动作"));

        // 前端 API 请求明细：JSON 字段 + HTML 尾部章节与 curl 按钮 + Excel sheet
        assertTrue("JSON 应包含业务 API 请求明细字段", jsonText.contains("\"apiCalls\""));
        assertTrue("JSON 应包含 API 请求体字段", jsonText.contains("\"requestBody\""));
        assertTrue("JSON 应包含 API 响应体字段", jsonText.contains("\"responseBody\""));
        assertTrue("HTML 应展示 API 请求明细章节（报告尾部）", htmlText.contains("前端 API 请求明细"));
        assertTrue("HTML 应提供 curl 复现按钮", htmlText.contains("data-curl"));
        assertTrue("HTML 应包含 curl 复制脚本", htmlText.contains("copyCurl"));
        List<Map<Integer, String>> apiRows = readGeneratedSheet(xlsx, "API请求明细");
        assertTrue("Excel 应有 API 请求明细 sheet（表头 + 至少 2 条数据行）: " + apiRows.size(),
                apiRows.size() >= 3);
        assertTrue("Excel API sheet 应包含 curl 复现命令",
                apiRows.stream().anyMatch(r -> String.valueOf(r.get(12)).contains("curl")));

        // 历次巡检索引页应可生成且包含本报告目录
        Path index = new com.patrol.report.ReportIndexGenerator().generate(reportDir.getParent());
        assertNotNull("索引页应生成", index);
        String indexHtml = Files.readString(index);
        assertTrue("索引页应链接本报告目录", indexHtml.contains(reportDir.getFileName().toString()));
        assertTrue("索引页应展示站点名称", indexHtml.contains("本地演示站"));
    }

    @AfterClass
    public void tearDown() {
        if (webServer != null) {
            webServer.stop();
        }
    }
}
