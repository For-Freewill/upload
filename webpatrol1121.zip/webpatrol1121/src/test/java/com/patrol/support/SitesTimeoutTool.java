package com.patrol.support;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 临时工具（非测试用例）：把 sites.xlsx 中指定站点的「手动登录超时(秒)」改为目标值。
 * 表格 MCP 工具对本地 xlsx 写入不落盘，须用 EasyExcel 全量读改写直写磁盘
 * （写新文件后 mv -f 原子替换）。
 * 运行：mvn exec:java -Dexec.mainClass=com.patrol.support.SitesTimeoutTool \
 *       -Dexec.classpathScope=test -Dexec.args="config/sites.xlsx Dify本地站 120"
 */
public class SitesTimeoutTool {

    public static void main(String[] args) throws Exception {
        Path excel = Paths.get(args[0]);
        String siteName = args[1];
        String timeoutSec = args[2];
        if (!Files.exists(excel)) {
            throw new IllegalArgumentException("文件不存在: " + excel);
        }

        List<List<String>> sites = readMatrix(excel, 0);
        List<List<String>> advanced = readMatrix(excel, 1);
        if (sites.isEmpty() || advanced.isEmpty()) {
            throw new IllegalStateException("两个 sheet 均须有数据");
        }

        // 高级配置表头定位「手动登录超时(秒)」列（0 基）
        List<String> head = advanced.get(0);
        int timeoutCol = -1;
        int nameCol = -1;
        for (int c = 0; c < head.size(); c++) {
            String h = head.get(c);
            if (h == null) continue;
            if (h.contains("手动登录超时")) timeoutCol = c;
            if (h.contains("站点名称")) nameCol = c;
        }
        if (timeoutCol < 0 || nameCol < 0) {
            throw new IllegalStateException("未找到「站点名称/手动登录超时(秒)」表头: " + head);
        }

        int changed = 0;
        for (List<String> row : advanced) {
            String name = nameCol < row.size() ? row.get(nameCol) : null;
            if (siteName.equals(name)) {
                while (row.size() <= timeoutCol) {
                    row.add("");
                }
                row.set(timeoutCol, timeoutSec);
                changed++;
            }
        }
        if (changed == 0) {
            throw new IllegalStateException("高级配置表未找到站点: " + siteName);
        }

        // 写新文件后原子替换
        Path out = excel.resolveSibling(excel.getFileName() + ".new.xlsx");
        ExcelWriter writer = null;
        try {
            writer = EasyExcel.write(out.toString()).build();
            writeMatrix(writer, 0, "Sites", sites);
            writeMatrix(writer, 1, "站点高级配置", advanced);
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
        Files.move(out, excel, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("OK: " + siteName + " 手动登录超时(秒) -> " + timeoutSec
                + "（共改 " + changed + " 行），已落盘 " + excel);
    }

    /** 读指定 sheet 为字符串矩阵（headRowNumber=0 全量动态读，EasyExcel doReadSync 自管资源） */
    @SuppressWarnings("unchecked")
    private static List<List<String>> readMatrix(Path excel, int sheetIdx) {
        List<Map<Integer, String>> rows = EasyExcel.read(excel.toString())
                .sheet(sheetIdx)
                .headRowNumber(0)
                .doReadSync();
        List<List<String>> matrix = new ArrayList<>();
        for (Map<Integer, String> m : rows) {
            int max = m.keySet().stream().filter(Integer.class::isInstance)
                    .mapToInt(k -> (Integer) k).max().orElse(-1);
            List<String> line = new ArrayList<>();
            for (int c = 0; c <= max; c++) {
                String v = m.get(c);
                line.add(v == null ? "" : v);
            }
            matrix.add(line);
        }
        return matrix;
    }

    /** 写字符串矩阵到 sheet（首行作动态表头 + 列宽自适应） */
    private static void writeMatrix(ExcelWriter writer, int idx, String name, List<List<String>> rows) {
        List<List<String>> head = new ArrayList<>();
        for (String h : rows.get(0)) {
            head.add(List.of(h));
        }
        List<List<Object>> data = new ArrayList<>();
        for (int r = 1; r < rows.size(); r++) {
            List<Object> line = new ArrayList<>();
            line.addAll(rows.get(r));
            data.add(line);
        }
        writer.write(data, EasyExcel.writerSheet(idx, name)
                .head(head)
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .build());
    }
}
