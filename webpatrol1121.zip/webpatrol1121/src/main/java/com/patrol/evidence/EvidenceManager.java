package com.patrol.evidence;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.Page;
import com.patrol.config.PatrolProperties;
import com.patrol.excel.SiteConfig;
import com.patrol.judge.HealthJudge;
import com.patrol.model.ActionInspection;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.IssueRecord;
import com.patrol.model.RequestRecord;
import com.patrol.model.Verdict;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 异常证据管理：为 WARN / FAIL 页面保存全页截图 + 上下文 JSON
 * （页面元信息、问题清单、console 日志尾部、JS 异常、失败请求及响应片段、HTML 摘录）。
 */
public class EvidenceManager {

    private static final Logger log = LoggerFactory.getLogger(EvidenceManager.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final Path evidenceRoot;
    private final PatrolProperties properties;
    private final ObjectMapper mapper = new ObjectMapper();

    public EvidenceManager(Path reportDir, PatrolProperties properties) {
        this.evidenceRoot = reportDir.resolve("evidence");
        this.properties = properties;
        try {
            Files.createDirectories(evidenceRoot);
        } catch (Exception e) {
            log.warn("创建证据目录失败: {}", e.getMessage());
        }
    }

    public record EvidencePaths(String screenshot, String contextJson) {
    }

    /** 判定是否需要保存证据 */
    public boolean shouldSave(Verdict verdict) {
        return verdict == Verdict.FAIL
                || (verdict == Verdict.WARN && properties.getEvidence().isIncludeWarn());
    }

    /**
     * 保存截图与上下文 JSON，返回相对报告根目录的路径。
     *
     * @param shot       调用方在正确时机（页面动作开始前 / 浮层清理前）拍摄的<b>已标注</b>截图；
     *                   为 null 或 png 为 null 时回落为当前页面无标注截图（截图优先，标注尽力而为）
     * @param annotation 截图标注信息（操作路径 / 异常元素），写入上下文 JSON 的 annotation 块
     */
    public EvidencePaths save(Page page, SiteConfig site, int pageIdx,
                              HealthJudge.VisitFacts facts, List<IssueRecord> issues,
                              Verdict verdict, Map<String, String> failureSnippets,
                              String pageContent, ScreenshotAnnotator.CapturedShot shot,
                              ScreenshotAnnotator.Annotation annotation) {
        String siteDir = sanitize(site.getSiteName());
        String base = String.format("page-%02d", pageIdx);
        Path dir = evidenceRoot.resolve(siteDir);
        String screenshotRel = null;
        String contextRel = null;
        try {
            Files.createDirectories(dir);
        } catch (Exception e) {
            log.warn("创建站点证据目录失败: {}", e.getMessage());
            return new EvidencePaths(null, null);
        }

        // 1. 截图：优先使用调用方在「正确时机」拍摄的已标注截图
        try {
            Path png = dir.resolve(base + ".png");
            byte[] pngBytes = shot != null ? shot.png() : null;
            if (pngBytes == null || pngBytes.length == 0) {
                pngBytes = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
            }
            Files.write(png, pngBytes);
            screenshotRel = "evidence/" + siteDir + "/" + base + ".png";
        } catch (Exception e) {
            log.warn("[{}] 截图失败: {}", site.getSiteName(), e.getMessage());
        }

        // 2. 上下文 JSON
        try {
            Path json = dir.resolve(base + ".context.json");
            Map<String, Object> ctx = new LinkedHashMap<>();
            ctx.put("capturedAt", LocalDateTime.now().format(TS));
            ctx.put("site", site.getSiteName());
            ctx.put("plannedUrl", facts.url);
            ctx.put("finalUrl", facts.url);
            ctx.put("mainStatus", facts.mainStatus);
            ctx.put("loadMs", facts.loadMs);
            ctx.put("verdict", verdict.name());
            ctx.put("navigateError", facts.navigateError);

            List<Map<String, Object>> issueList = new ArrayList<>();
            for (IssueRecord ir : issues) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("type", ir.type().name());
                m.put("label", ir.type().label());
                m.put("severity", ir.severity().name());
                m.put("message", ir.message());
                issueList.add(m);
            }
            ctx.put("issues", issueList);
            ctx.put("jsErrors", facts.jsErrors);

            // console 尾部
            int tail = properties.getEvidence().getConsoleTail();
            List<Map<String, Object>> console = new ArrayList<>();
            List<?> logs = facts.consoleLogs;
            int from = Math.max(0, logs.size() - tail);
            for (int i = from; i < logs.size(); i++) {
                com.patrol.model.ConsoleRecord cr = (com.patrol.model.ConsoleRecord) logs.get(i);
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("level", cr.level());
                m.put("text", cr.text());
                m.put("location", cr.location());
                m.put("timestamp", cr.timestamp());
                console.add(m);
            }
            ctx.put("consoleLog", console);

            // 失败请求明细 + 响应片段
            List<Map<String, Object>> failed = new ArrayList<>();
            int snippetBytes = properties.getEvidence().getResponseSnippetBytes();
            for (com.patrol.model.RequestRecord r : facts.requests) {
                if (!r.isFailed()) continue;
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("url", r.url());
                m.put("method", r.method());
                m.put("resourceType", r.resourceType());
                m.put("status", r.status());
                m.put("failureText", r.failureText());
                m.put("durationMs", r.durationMs());
                m.put("isMainDoc", r.isMainDoc());
                String snippet = failureSnippets.get(r.url() + "#" + r.method());
                if (snippet != null) {
                    m.put("responseSnippet", truncateUtf8(snippet, snippetBytes));
                }
                failed.add(m);
            }
            ctx.put("failedRequests", failed);
            ctx.put("screenshot", screenshotRel);
            putAnnotation(ctx, annotation, shot);

            if (pageContent != null) {
                ctx.put("pageHtmlExcerpt", truncateUtf8(pageContent, 20000));
            }

            mapper.writerWithDefaultPrettyPrinter().writeValue(json.toFile(), ctx);
            contextRel = "evidence/" + siteDir + "/" + base + ".context.json";
        } catch (Exception e) {
            log.warn("[{}] 上下文保存失败: {}", site.getSiteName(), e.getMessage());
        }

        log.info("[{}] 已保存异常证据: {}（verdict={}）", site.getSiteName(), screenshotRel, verdict);
        return new EvidencePaths(screenshotRel, contextRel);
    }

    /**
     * 保存动作级证据（点击查询按钮等动作异常时）：动作后截图 + 上下文 JSON。
     *
     * @param shot       调用方在<b>浮层清理前</b>拍摄的已标注截图（红框异常元素 + 操作路径横幅，
     *                   保留弹窗打开/元素原位的第一现场）；为 null 或 png 为 null 时回落当前页面无标注截图
     * @param annotation 截图标注信息（操作路径 / 异常元素），写入上下文 JSON 的 annotation 块
     */
    public EvidencePaths saveAction(Page page, SiteConfig site, int pageIdx, int actionIdx,
                                     String description, String selector, String pageUrl,
                                     Verdict verdict,
                                     List<RequestRecord> requests,
                                     List<ConsoleRecord> consoleLogs,
                                     List<String> jsErrors,
                                     Map<String, String> failureSnippets,
                                     String clickError, boolean navigatedAway,
                                     ScreenshotAnnotator.CapturedShot shot,
                                     ScreenshotAnnotator.Annotation annotation) {
        String siteDir = sanitize(site.getSiteName());
        String base = String.format("page-%02d-action-%02d", pageIdx, actionIdx);
        Path dir = evidenceRoot.resolve(siteDir);
        String screenshotRel = null;
        String contextRel = null;
        try {
            Files.createDirectories(dir);
        } catch (Exception e) {
            log.warn("创建站点证据目录失败: {}", e.getMessage());
            return new EvidencePaths(null, null);
        }

        try {
            Path png = dir.resolve(base + ".png");
            byte[] pngBytes = shot != null ? shot.png() : null;
            if (pngBytes == null || pngBytes.length == 0) {
                pngBytes = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
            }
            Files.write(png, pngBytes);
            screenshotRel = "evidence/" + siteDir + "/" + base + ".png";
        } catch (Exception e) {
            log.warn("[{}] 动作截图失败: {}", site.getSiteName(), e.getMessage());
        }

        try {
            Path json = dir.resolve(base + ".context.json");
            Map<String, Object> ctx = new LinkedHashMap<>();
            ctx.put("capturedAt", LocalDateTime.now().format(TS));
            ctx.put("site", site.getSiteName());
            ctx.put("pageUrl", pageUrl);
            ctx.put("action", description);
            ctx.put("selector", selector);
            ctx.put("verdict", verdict.name());
            ctx.put("clickError", clickError);
            ctx.put("navigatedAway", navigatedAway);
            ctx.put("jsErrors", jsErrors);

            List<Map<String, Object>> console = new ArrayList<>();
            if (consoleLogs != null) {
                for (ConsoleRecord cr : consoleLogs) {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("level", cr.level());
                    m.put("text", cr.text());
                    m.put("location", cr.location());
                    m.put("timestamp", cr.timestamp());
                    console.add(m);
                }
            }
            ctx.put("consoleLog", console);

            List<Map<String, Object>> failed = new ArrayList<>();
            int snippetBytes = properties.getEvidence().getResponseSnippetBytes();
            if (requests != null) {
                for (RequestRecord r : requests) {
                    if (!r.isFailed()) continue;
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("url", r.url());
                    m.put("method", r.method());
                    m.put("resourceType", r.resourceType());
                    m.put("status", r.status());
                    m.put("failureText", r.failureText());
                    m.put("durationMs", r.durationMs());
                    String snippet = failureSnippets.get(r.url() + "#" + r.method());
                    if (snippet != null) {
                        m.put("responseSnippet", truncateUtf8(snippet, snippetBytes));
                    }
                    failed.add(m);
                }
            }
            ctx.put("failedRequests", failed);
            ctx.put("screenshot", screenshotRel);
            ctx.put("totalRequests", requests == null ? 0 : requests.size());
            putAnnotation(ctx, annotation, shot);

            mapper.writerWithDefaultPrettyPrinter().writeValue(json.toFile(), ctx);
            contextRel = "evidence/" + siteDir + "/" + base + ".context.json";
        } catch (Exception e) {
            log.warn("[{}] 动作上下文保存失败: {}", site.getSiteName(), e.getMessage());
        }

        log.info("[{}] 已保存动作证据: {}（verdict={}）", site.getSiteName(), base, verdict);
        return new EvidencePaths(screenshotRel, contextRel);
    }

    /** 上下文 JSON 写入标注信息块：操作路径、异常元素选择器/描述、红框是否成功画上 */
    private static void putAnnotation(Map<String, Object> ctx,
                                      ScreenshotAnnotator.Annotation annotation,
                                      ScreenshotAnnotator.CapturedShot shot) {
        if (annotation == null) return;
        Map<String, Object> anno = new LinkedHashMap<>();
        anno.put("pathText", annotation.pathText());
        anno.put("elementSelector", annotation.elementSelector());
        anno.put("elementLabel", annotation.elementLabel());
        anno.put("elementMarked", shot != null && Boolean.TRUE.equals(shot.elementMarked()));
        ctx.put("annotation", anno);
    }

    private static String truncateUtf8(String s, int maxBytes) {
        if (s == null) return null;
        if (s.getBytes(StandardCharsets.UTF_8).length <= maxBytes) return s;
        StringBuilder sb = new StringBuilder();
        int used = 0;
        for (int i = 0; i < s.length(); i++) {
            String ch;
            if (Character.isHighSurrogate(s.charAt(i)) && i + 1 < s.length()) {
                ch = s.substring(i, i + 2);   // 代理对整体处理，避免截断多字节字符
                i++;
            } else {
                ch = s.substring(i, i + 1);
            }
            int b = ch.getBytes(StandardCharsets.UTF_8).length;
            if (used + b > maxBytes) break;
            sb.append(ch);
            used += b;
        }
        return sb + "\n...[truncated]";
    }

    static String sanitize(String name) {
        return name.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
    }
}
