package com.patrol.evidence;

import com.microsoft.playwright.Page;

import java.util.HashMap;
import java.util.Map;

/**
 * 截图标注器：截图前向页面注入 DOM 覆盖层，使证据截图「自解释」——
 * <ul>
 *   <li><b>红色边框</b>（3px #d93026）框住<b>操作异常的元素</b>，附红色标签显示元素描述，
 *       元素不在视口时先滚动到可视区；元素已消失（跳转/重渲染）时只在横幅中说明。</li>
 *   <li><b>操作路径文字横幅</b>（fixed 顶部红底白字）：站点 → 页面 → 动作（→ 异常原因），
 *       让截图脱离报告也能看懂「这是哪个站点的哪条路径上的哪一步出了什么问题」。</li>
 * </ul>
 *
 * <p>所有注入节点带 {@code data-patrol-anno} 属性、{@code pointer-events:none}、
 * 无 class/role——既不干扰点击，也不会被弹窗检测启发式
 * （{@code [class*=modal]} + fixed/absolute、{@code [role=dialog]}）误判为浮层。</p>
 *
 * <p>标注是「截图瞬态」：注入 → 截图 → 清理，绝不残留到下一动作的元素扫描与点击。</p>
 */
public final class ScreenshotAnnotator {

    private ScreenshotAnnotator() {
    }

    /**
     * 标注内容：
     * pathText      操作路径文字（横幅主体，如 站点[X] → 页面[/a] → 动作[点击: 查询] → 异常[失败请求1个]）
     * elementSelector 异常元素的 CSS 选择器（null=仅横幅，不画红框）
     * elementLabel  元素描述标签（红框旁的 ❗ 文本）
     */
    public record Annotation(String pathText, String elementSelector, String elementLabel) {
    }

    /**
     * 一次已标注的截图结果：png 为截图字节（null=截图失败），elementMarked 表示
     * 异常元素是否成功画上了红框（false 可能因元素已消失——跳转/重渲染）。
     */
    public record CapturedShot(byte[] png, Boolean elementMarked) {
    }

    private static final String APPLY_JS = """
            a => {
              const MARK = 'data-patrol-anno';
              // 幂等：先清理上次残留
              document.querySelectorAll('[' + MARK + ']').forEach(n => n.remove());
              let marked = false;
              // 1. 红框框住异常元素（文档坐标，fullPage 截图下与元素精确对位）
              if (a.sel) {
                let el = null;
                try { el = document.querySelector(a.sel); } catch (e) { el = null; }
                if (el) {
                  try { el.scrollIntoView({block: 'center'}); } catch (e) {}
                  const r = el.getBoundingClientRect();
                  if (document.body && (r.width > 0 || r.height > 0)) {
                    const sx = window.scrollX || 0, sy = window.scrollY || 0;
                    const box = document.createElement('div');
                    box.setAttribute(MARK, '1');
                    box.style.cssText = 'position:absolute;pointer-events:none;z-index:2147483647;'
                      + 'border:3px solid #d93026;background:rgba(217,48,38,.10);border-radius:2px;'
                      + 'left:' + (r.left + sx - 5) + 'px;top:' + (r.top + sy - 5) + 'px;'
                      + 'width:' + (r.width + 10) + 'px;height:' + (r.height + 10) + 'px;';
                    document.body.appendChild(box);
                    const tag = document.createElement('div');
                    tag.setAttribute(MARK, '1');
                    tag.style.cssText = 'position:absolute;pointer-events:none;z-index:2147483647;'
                      + 'background:#d93026;color:#fff;font:700 12px/1.5 system-ui,sans-serif;'
                      + 'padding:2px 8px;border-radius:3px;white-space:nowrap;'
                      + 'left:' + Math.max(0, r.left + sx - 5) + 'px;'
                      + 'top:' + Math.max(2, r.top + sy - 24) + 'px;';
                    tag.textContent = '\\u2757 ' + (a.label || '异常元素');
                    document.body.appendChild(tag);
                    marked = true;
                  }
                }
              }
              // 2. 操作路径文字横幅（fixed 顶部红底白字，始终可见）
              const bar = document.createElement('div');
              bar.setAttribute(MARK, '1');
              bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;'
                + 'background:#d93026;color:#fff;font:700 13px/1.8 system-ui,sans-serif;'
                + 'padding:5px 12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'
                + 'box-shadow:0 2px 8px rgba(0,0,0,.4);';
              bar.textContent = '\\uD83D\\uDCCD ' + (a.path || '');
              document.documentElement.appendChild(bar);
              return {marked: marked};
            }
            """;

    private static final String CLEAR_JS =
            "() => document.querySelectorAll('[data-patrol-anno]').forEach(n => n.remove())";

    /** 注入标注，返回异常元素是否成功画上红框（evaluate 失败/元素消失返回 false，不抛异常） */
    public static boolean apply(Page page, Annotation annotation) {
        if (page == null || annotation == null) return false;
        try {
            Map<String, String> arg = new HashMap<>();
            arg.put("path", nz(annotation.pathText()));
            arg.put("sel", nz(annotation.elementSelector()));
            arg.put("label", nz(annotation.elementLabel()));
            Object result = page.evaluate(APPLY_JS, arg);
            return result instanceof Map<?, ?> m && Boolean.TRUE.equals(m.get("marked"));
        } catch (Exception e) {
            return false;
        }
    }

    /** 清理所有注入的标注节点（页面关闭/跳转后 evaluate 可能失败，静默处理） */
    public static void clearQuietly(Page page) {
        if (page == null) return;
        try {
            page.evaluate(CLEAR_JS);
        } catch (Exception ignored) {
            // 页面已导航/关闭时无法清理，新页面导航本身会丢弃这些瞬态节点
        }
    }

    /**
     * 注入标注 → 整页截图 → 清理标注，一气呵成。
     * 标注注入失败时仍返回未标注截图（证据优先，标注尽力而为）；
     * 截图失败返回 png=null（调用方决定是否兜底）。
     */
    public static CapturedShot capture(Page page, Annotation annotation) {
        if (page == null) return new CapturedShot(null, false);
        boolean marked = false;
        try {
            if (annotation != null) {
                marked = apply(page, annotation);
            }
        } catch (Exception ignored) {
            // 注入失败不阻断截图
        }
        try {
            byte[] png = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
            return new CapturedShot(png, marked);
        } catch (Exception e) {
            return new CapturedShot(null, marked);
        } finally {
            clearQuietly(page);
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
