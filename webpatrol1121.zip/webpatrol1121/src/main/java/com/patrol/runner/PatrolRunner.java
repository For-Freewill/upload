package com.patrol.runner;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import com.patrol.config.PatrolProperties;
import com.patrol.engine.AuthSupport;
import com.patrol.engine.PatrolEngine;
import com.patrol.engine.PlaywrightFactory;
import com.patrol.excel.ExcelConfigLoader;
import com.patrol.excel.ExcelTemplateGenerator;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.model.PatrolReport;
import com.patrol.model.PatrolSummary;
import com.patrol.model.ReportComparison;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import com.patrol.report.ExcelReportGenerator;
import com.patrol.report.HtmlReportGenerator;
import com.patrol.report.JsonReportWriter;
import com.patrol.report.ReportComparator;
import com.patrol.report.ReportIndexGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 巡检总指挥：加载 Excel 配置 → 逐站点巡检 → 汇总 → 生成三份报告（JSON / Excel / HTML）。
 *
 * <p>用法：java -jar frontend-patrol.jar [--excel=config/sites.xlsx] [--out=reports] [--gen-template]</p>
 */
@Component
public class PatrolRunner implements CommandLineRunner, ExitCodeGenerator {

    private static final Logger log = LoggerFactory.getLogger(PatrolRunner.class);
    private static final DateTimeFormatter DIR_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final PatrolProperties properties;
    private final ExcelConfigLoader configLoader;
    private final PatrolEngine engine;
    private final JsonReportWriter jsonReportWriter;
    private final ExcelReportGenerator excelReportGenerator;
    private final HtmlReportGenerator htmlReportGenerator;
    private final ReportIndexGenerator reportIndexGenerator;

    private final AtomicInteger exitCode = new AtomicInteger(0);

    public PatrolRunner(PatrolProperties properties, ExcelConfigLoader configLoader,
                        PatrolEngine engine, JsonReportWriter jsonReportWriter,
                        ExcelReportGenerator excelReportGenerator,
                        HtmlReportGenerator htmlReportGenerator,
                        ReportIndexGenerator reportIndexGenerator) {
        this.properties = properties;
        this.configLoader = configLoader;
        this.engine = engine;
        this.jsonReportWriter = jsonReportWriter;
        this.excelReportGenerator = excelReportGenerator;
        this.htmlReportGenerator = htmlReportGenerator;
        this.reportIndexGenerator = reportIndexGenerator;
    }

    @Override
    public void run(String... args) {
        String startedAt = LocalDateTime.now().format(ISO);
        long t0 = System.currentTimeMillis();
        Path excelPath = resolveExcelPath(args);

        // --gen-template：生成配置模板后退出
        if (hasFlag(args, "--gen-template")) {
            try {
                ExcelTemplateGenerator.generate(excelPath);
                log.info("模板已生成: {}，请填写后重新运行巡检", excelPath.toAbsolutePath());
            } catch (Exception e) {
                log.error("模板生成失败: {}", e.getMessage());
                exitCode.set(2);
            }
            return;
        }

        try {
            // 1. 加载配置（不存在时自动生成模板并提示）
            if (!Files.exists(excelPath)) {
                log.warn("巡检配置不存在: {} —— 自动生成模板（含示例行），请填写后重跑", excelPath.toAbsolutePath());
                ExcelTemplateGenerator.generate(excelPath);
                exitCode.set(0);
                return;
            }
            List<SiteConfig> allSites = configLoader.load(excelPath);
            List<SiteConfig> sites = allSites.stream().filter(SiteConfig::isEnabled).toList();
            if (sites.isEmpty()) {
                log.warn("Excel 中没有「启用」状态的站点，巡检结束");
                return;
            }
            List<PageActionConfig> allActions = configLoader.loadPageActions(excelPath);
            log.info("本次巡检 {} 个启用站点: {}（自定义页面动作 {} 条）", sites.size(),
                    sites.stream().map(SiteConfig::getSiteName).toList(), allActions.size());

            // 2. 巡检报告目录
            Path reportDir = Path.of(properties.getOutputDir())
                    .resolve("patrol-" + LocalDateTime.now().format(DIR_TS));
            Files.createDirectories(reportDir);

            // 3. 阶段一：登录认证（有头模式、串行执行；MANUAL/SSO 需人工在弹出窗口中操作）
            Map<String, String> authFailures = new LinkedHashMap<>();
            long needAuth = sites.stream().filter(s -> {
                String t = s.getAuthType() == null ? "" : s.getAuthType().toUpperCase();
                return t.equals("FORM") || t.equals("MANUAL") || t.equals("SSO");
            }).count();
            log.info("========== 阶段一：登录认证（有头模式）—— {} 个站点需登录，共 {} 个站点 ==========",
                    needAuth, sites.size());
            Playwright authPlaywright = PlaywrightFactory.create(properties.getBrowser().isAutoDownload());
            try {
                for (SiteConfig site : sites) {
                    try {
                        AuthSupport.preAuthenticate(authPlaywright, properties, site,
                                Path.of(properties.getLoginStateDir()));
                    } catch (Exception e) {
                        log.error("站点 [{}] 登录认证失败: {}", site.getSiteName(), e.getMessage());
                        authFailures.put(site.getSiteName(), "登录认证失败: " + e.getMessage());
                    }
                }
            } finally {
                PlaywrightFactory.closeQuietly("认证 Playwright 实例",
                        PlaywrightFactory.INSTANCE_CLOSE_TIMEOUT_MS, authPlaywright::close);
            }
            if (!authFailures.isEmpty()) {
                log.warn("认证失败站点（巡检将跳过并判 FAIL）: {}", authFailures.keySet());
            }

            // 4. 阶段二：并行无头巡检（Playwright 多实例，结果按配置顺序汇总）
            String browserInfo = properties.getBrowser().getType()
                    + " (playwright-java · 无头并行 x" + Math.max(1, properties.getMaxParallelSites()) + ")";
            List<SiteInspection> inspections =
                    patrolConcurrently(sites, allActions, reportDir, authFailures);

            // 4. 汇总 + 报告（站点数按本次实际运行的启用站点数统计，不含 Excel 中禁用的站点）
            String finishedAt = LocalDateTime.now().format(ISO);
            PatrolReport report = new PatrolReport(startedAt, finishedAt,
                    excelPath.toString(), browserInfo, inspections,
                    buildSummary(inspections, t0, sites.size()));

            // 5. 与上次巡检报告对比：定位 output-dir 下最近一次（排除本次）的报告并逐项对比
            //    （对比失败不影响本次报告产出）
            ReportComparison comparison = null;
            try {
                PatrolReport previous = ReportComparator.loadLatestPrevious(
                        Path.of(properties.getOutputDir()), reportDir);
                if (previous != null) {
                    comparison = ReportComparator.compare(report, previous);
                    log.info("上次对比分析完成：新增问题类 {} 项，恢复改善类 {} 项",
                            comparison.newIssueCount(), comparison.recoveredCount());
                }
            } catch (Exception e) {
                log.warn("上次报告对比分析失败（不影响本次报告）: {}", e.getMessage());
            }

            jsonReportWriter.write(report, reportDir.resolve("patrol-result.json"));
            excelReportGenerator.generate(report, comparison, reportDir.resolve("patrol-report.xlsx"));
            htmlReportGenerator.generate(report, comparison, reportDir.resolve("report.html"));
            // 更新历次巡检索引页（reports/index.html），一键回看任意一次报告
            reportIndexGenerator.generate(Path.of(properties.getOutputDir()));

            printSummary(report, reportDir);

            boolean anyFail = inspections.stream().anyMatch(s -> s.verdict() == Verdict.FAIL);
            if (anyFail && properties.isStrictExit()) {
                exitCode.set(1);
            }
        } catch (Exception e) {
            log.error("巡检执行失败: {}", e.getMessage(), e);
            exitCode.set(2);
        }
    }

    /**
     * 阶段二：并行无头巡检。
     *
     * <p>线程池 + 队列调度：每个 worker 持有独立的 Playwright 实例与无头浏览器，
     * 从公共队列取站点任务，直到队列清空。认证失败的站点直接构造 FAIL 结果不再巡检。
     * 巡检阶段强制无头（认证已在阶段一有头完成）。</p>
     *
     * @return 按配置文件中的站点顺序返回巡检结果
     */
    private List<SiteInspection> patrolConcurrently(List<SiteConfig> sites,
                                                    List<PageActionConfig> allActions,
                                                    Path reportDir,
                                                    Map<String, String> authFailures) throws Exception {
        int parallel = Math.max(1, Math.min(properties.getMaxParallelSites(), sites.size()));
        log.info("========== 阶段二：并行无头巡检 —— {} 个站点，最大并行度 {}（Playwright 多实例） ==========",
                sites.size(), parallel);

        record SiteTask(int index, SiteConfig site, List<PageActionConfig> actions) {
        }
        BlockingQueue<SiteTask> queue = new LinkedBlockingQueue<>();
        for (int i = 0; i < sites.size(); i++) {
            SiteConfig site = sites.get(i);
            List<PageActionConfig> siteActions = allActions.stream()
                    .filter(a -> site.getSiteName().equals(a.getSiteName()))
                    .filter(PageActionConfig::isEnabled)
                    .toList();
            queue.add(new SiteTask(i, site, siteActions));
        }

        SiteInspection[] results = new SiteInspection[sites.size()];
        AtomicInteger workerSeq = new AtomicInteger(0);
        ExecutorService pool = Executors.newFixedThreadPool(parallel, task -> new Thread(task,
                "patrol-worker-" + workerSeq.incrementAndGet()));
        try {
            for (int w = 0; w < parallel; w++) {
            pool.submit(() -> {
                String worker = Thread.currentThread().getName();
                // 每个 worker 独立的 Playwright 实例 + 无头浏览器（关闭统一限时兜底，防止 driver 楔死阻塞 worker）
                Playwright playwright = PlaywrightFactory.create(properties.getBrowser().isAutoDownload());
                try {
                    BrowserType browserType = switch (properties.getBrowser().getType().toLowerCase()) {
                        case "firefox" -> playwright.firefox();
                        case "webkit" -> playwright.webkit();
                        default -> playwright.chromium();
                    };
                    Browser browser = browserType.launch(new BrowserType.LaunchOptions()
                            // 巡检阶段强制无头（登录认证已在阶段一有头完成）
                            .setHeadless(true)
                            .setSlowMo(properties.getBrowser().getSlowMoMs()));
                    try {
                        SiteTask task;
                        while ((task = queue.poll()) != null) {
                            SiteConfig site = task.site();
                            log.info("[worker-{}] 领取站点任务: [{}]", worker, site.getSiteName());
                            String authError = authFailures.get(site.getSiteName());
                            SiteInspection result = authError != null
                                    ? failedSite(site, authError)
                                    : engine.inspect(site, browser, reportDir, task.actions());
                            synchronized (results) {
                                results[task.index()] = result;
                            }
                        }
                    } finally {
                        PlaywrightFactory.closeQuietly("[" + worker + "] 浏览器",
                                PlaywrightFactory.INSTANCE_CLOSE_TIMEOUT_MS, browser::close);
                    }
                } catch (Exception e) {
                    log.error("巡检 worker 异常退出: {}", e.getMessage(), e);
                } finally {
                    PlaywrightFactory.closeQuietly("[" + worker + "] Playwright 实例",
                            PlaywrightFactory.INSTANCE_CLOSE_TIMEOUT_MS, playwright::close);
                }
            });
            }
            pool.shutdown();
            if (!pool.awaitTermination(24, TimeUnit.HOURS)) {
                pool.shutdownNow();
                throw new IllegalStateException("巡检线程池 24 小时未完成，已强制终止");
            }
        } finally {
            pool.shutdownNow();
        }

        List<SiteInspection> inspections = new ArrayList<>(sites.size());
        for (int i = 0; i < sites.size(); i++) {
            SiteInspection r = results[i];
            inspections.add(r != null ? r
                    : failedSite(sites.get(i), "巡检 worker 异常终止，站点未被巡检"));
        }
        return inspections;
    }

    private static SiteInspection failedSite(SiteConfig site, String message) {
        String now = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        return new SiteInspection(site.getSiteName(), site.getEntryUrl(), site.getAuthType(),
                now, now, Verdict.FAIL, List.of(), 0, message, List.of());
    }

    /**
     * @param totalSites 本次实际运行的启用站点数（= inspections.size()，不含 Excel 中禁用的站点）
     */
    private PatrolSummary buildSummary(List<SiteInspection> inspections, long t0, int totalSites) {
        int totalPages = inspections.stream().mapToInt(SiteInspection::pagesVisited).sum();
        int passPages = inspections.stream().mapToInt(s -> (int) s.passPages()).sum();
        int warnPages = inspections.stream().mapToInt(s -> (int) s.warnPages()).sum();
        int failPages = inspections.stream().mapToInt(s -> (int) s.failPages()).sum();
        int consoleErrors = inspections.stream().flatMap(s -> s.pages().stream())
                .mapToInt(p -> (int) p.consoleErrorCount()).sum();
        int jsErrors = inspections.stream().flatMap(s -> s.pages().stream())
                .mapToInt(p -> (int) p.jsErrorCount()).sum();
        int failedRequests = inspections.stream().flatMap(s -> s.pages().stream())
                .mapToInt(p -> (int) p.failedRequestCount()).sum();
        int totalActions = inspections.stream().flatMap(s -> s.pages().stream())
                .mapToInt(com.patrol.model.PageInspection::actionCount).sum();
        int failedActions = inspections.stream().flatMap(s -> s.pages().stream())
                .mapToInt(p -> (int) p.failedActionCount()).sum();
        return new PatrolSummary(
                totalSites,
                inspections.size(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.PASS).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.WARN).count(),
                (int) inspections.stream().filter(s -> s.verdict() == Verdict.FAIL).count(),
                totalPages, passPages, warnPages, failPages,
                consoleErrors, jsErrors, failedRequests,
                totalActions, failedActions,
                System.currentTimeMillis() - t0);
    }

    private void printSummary(PatrolReport report, Path reportDir) {
        PatrolSummary s = report.summary();
        log.info("");
        log.info("╔══════════════════════ 巡检结果汇总 ══════════════════════╗");
        log.info("  站点: {} 个（PASS {} / WARN {} / FAIL {}）",
                s.enabledSites(), s.passSites(), s.warnSites(), s.failSites());
        log.info("  页面: {} 个（PASS {} / WARN {} / FAIL {}）",
                s.totalPages(), s.passPages(), s.warnPages(), s.failPages());
        log.info("  功能动作: {} 个（失败 {} 个）", s.totalActions(), s.failedActions());
        log.info("  Console错误 {} 条 | JS异常 {} 处 | 失败请求 {} 个",
                s.totalConsoleErrors(), s.totalJsErrors(), s.totalFailedRequests());
        long apiTotal = report.sites().stream().mapToLong(site -> site.apiCallList().size()).sum();
        long apiFailed = report.sites().stream().mapToLong(com.patrol.model.SiteInspection::failedApiCalls).sum();
        log.info("  前端业务API请求: {} 条（失败 {} 个）—— 详见报告尾部「前端 API 请求明细」",
                apiTotal, apiFailed);
        log.info("  报告目录: {}", reportDir.toAbsolutePath());
        log.info("    - report.html        (可视化报告)");
        log.info("    - patrol-report.xlsx (Excel 汇总)");
        log.info("    - patrol-result.json (原始数据)");
        log.info("    - evidence/          (截图与上下文)");
        log.info("  历次报告索引: {}", Path.of(properties.getOutputDir())
                .resolve("index.html").toAbsolutePath());
        log.info("╚═════════════════════════════════════════════════════════╝");
    }

    private Path resolveExcelPath(String... args) {
        for (String a : args) {
            if (a.startsWith("--excel=")) {
                return Path.of(a.substring("--excel=".length()));
            }
        }
        return Path.of(properties.getExcelPath());
    }

    private static boolean hasFlag(String[] args, String flag) {
        for (String a : args) {
            if (a.equals(flag)) return true;
        }
        return false;
    }

    @Override
    public int getExitCode() {
        return exitCode.get();
    }
}
