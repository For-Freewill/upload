package com.patrol.engine;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.patrol.config.PatrolProperties;
import com.patrol.evidence.EvidenceManager;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.judge.HealthJudge;
import com.patrol.model.PageInspection;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import com.patrol.sniffer.PageSniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 巡检引擎：对单个站点执行「认证 → 自动探索（+元素解析/功能动作）→ 嗅探 → 判定 → 取证」全流程。
 */
@Component
public class PatrolEngine {

    private static final Logger log = LoggerFactory.getLogger(PatrolEngine.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final PatrolProperties properties;
    private final HealthJudge judge;

    public PatrolEngine(PatrolProperties properties, HealthJudge judge) {
        this.properties = properties;
        this.judge = judge;
    }

    /**
     * 巡检一个站点（无头模式）。登录认证已在预认证阶段完成（有头），
     * 本阶段仅加载缓存登录态。站点级异常（登录态缺失、浏览器崩溃等）不会中断整体流程，
     * 而是返回带 errorMessage 的 FAIL 结果。线程安全：无共享可变状态，可并行调用。
     *
     * @param browser     巡检用（无头）浏览器实例
     * @param reportDir   本轮巡检报告目录
     * @param pageActions 该站点的自定义页面动作配置（可为空）
     */
    public SiteInspection inspect(SiteConfig site, Browser browser,
                                  Path reportDir, List<PageActionConfig> pageActions) {
        String startedAt = LocalDateTime.now().format(TS);
        log.info("========== 开始巡检站点 [{}] {} (auth={}) ==========",
                site.getSiteName(), site.getEntryUrl(), site.getAuthType());

        try (BrowserContext context = AuthSupport.createContext(browser,
                properties, site, Path.of(properties.getLoginStateDir()))) {
            EvidenceManager evidence = new EvidenceManager(reportDir, properties);
            // 下载采集：导出/下载类动作真实执行，记录文件名与来源 URL（动作用下标切分归因）
            List<String> downloadLog = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
            Page page = context.newPage();
            // 动作点击可能触发 alert/confirm 等，自动关闭避免卡死（confirm 一律 dismiss = 不最终确认）
            registerPageHandlers(page, site, downloadLog);
            // 伪链接 window.open 等新开页面同样纳入嗅探与保护：弹窗页面里的 console 错误/请求
            // 不再漏采，弹窗页触发的对话框同样自动关闭、下载同样记录
            PageSniffer sniffer = new PageSniffer(page);
            context.onPage(p -> {
                if (p == null || p == page) return;
                registerPageHandlers(p, site, downloadLog);
                sniffer.addPage(p);
            });
            try {
                PageExplorer explorer = new PageExplorer(site, properties, page,
                        sniffer, judge, evidence, pageActions, downloadLog);
                PageExplorer.ExploreOutcome outcome = explorer.explore();
                List<PageInspection> pages = outcome.pages();

                Verdict verdict = pages.stream()
                        .map(PageInspection::verdict)
                        .reduce(Verdict.PASS, Verdict::worstOf);

                String finishedAt = LocalDateTime.now().format(TS);
                int totalActions = pages.stream().mapToInt(PageInspection::actionCount).sum();
                log.info("========== 站点 [{}] 巡检完成: {} 个页面, {} 个动作, 业务API请求 {} 条, 结论 {} ==========",
                        site.getSiteName(), pages.size(), totalActions, sniffer.apiCalls().size(), verdict);
                return new SiteInspection(site.getSiteName(), site.getEntryUrl(),
                        site.getAuthType(), startedAt, finishedAt, verdict,
                        pages, outcome.linksFound(), null, sniffer.apiCalls());
            } finally {
                sniffer.stop();
                // 限时关闭：driver/浏览器楔死时 page.close() 会永久阻塞，绝不影响巡检完成
                PlaywrightFactory.closeQuietly("页面 " + page.url(),
                        PlaywrightFactory.PAGE_CLOSE_TIMEOUT_MS, page::close);
            }
        } catch (Exception e) {
            log.error("站点 [{}] 巡检失败: {}", site.getSiteName(), e.getMessage(), e);
            return new SiteInspection(site.getSiteName(), site.getEntryUrl(),
                    site.getAuthType(), startedAt, LocalDateTime.now().format(TS),
                    Verdict.FAIL, List.of(), 0, e.getMessage(), List.of());
        }
    }

    /** 页面级保护与采集注册：对话框自动 dismiss（confirm=不确认）、下载记录+清理 */
    private void registerPageHandlers(Page p, SiteConfig site, List<String> downloadLog) {
        p.onDialog(dialog -> {
            log.debug("[{}] 动作触发对话框[{}]，自动关闭", site.getSiteName(), dialog.type());
            try {
                dialog.dismiss();
            } catch (Exception ignored) {
            }
        });
        p.onDownload(download -> {
            String entry = download.suggestedFilename() + " <- " + download.url()
                    + (download.failure() != null ? " [失败: " + download.failure() + "]" : "");
            downloadLog.add(entry);
            log.info("[{}] 触发下载: {}", site.getSiteName(), entry);
            try {
                download.delete();   // 清理临时文件（下载未完成时忽略）
            } catch (Exception ignored) {
            }
        });
    }
}
