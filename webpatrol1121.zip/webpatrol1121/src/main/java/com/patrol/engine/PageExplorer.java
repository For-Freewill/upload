package com.patrol.engine;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitUntilState;
import com.patrol.config.PatrolProperties;
import com.patrol.evidence.EvidenceManager;
import com.patrol.evidence.ScreenshotAnnotator;
import com.patrol.excel.PageActionConfig;
import com.patrol.excel.SiteConfig;
import com.patrol.judge.HealthJudge;
import com.patrol.model.ActionInspection;
import com.patrol.model.ElementDigest;
import com.patrol.model.IssueRecord;
import com.patrol.model.IssueType;
import com.patrol.model.LinkRecord;
import com.patrol.model.PageInspection;
import com.patrol.model.Verdict;
import com.patrol.sniffer.PageSniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * 站内页面自动探索器：从入口 URL 出发，同源链接 BFS 探索（深度/页数受配置限制），
 * 逐页完成「嗅探采集 → 健康判定 → 异常取证」。
 */
public class PageExplorer {

    private static final Logger log = LoggerFactory.getLogger(PageExplorer.class);

    /** 不作为页面巡检的资源扩展名 */
    private static final Set<String> SKIP_EXTENSIONS = Set.of(
            ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp", ".bmp",
            ".css", ".js", ".json", ".map", ".xml", ".txt",
            ".pdf", ".zip", ".rar", ".7z", ".gz", ".tar",
            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".csv",
            ".mp4", ".webm", ".avi", ".mov", ".mp3", ".wav",
            ".woff", ".woff2", ".ttf", ".eot", ".exe", ".apk", ".dmg");

    private final SiteConfig site;
    private final PatrolProperties properties;
    private final Page page;
    private final PageSniffer sniffer;
    private final HealthJudge judge;
    private final EvidenceManager evidence;
    private final List<PageActionConfig> customActions;
    /** 页面级下载采集日志（PatrolEngine 注册的 onDownload 监听写入） */
    private final List<String> downloadLog;
    private final URI entry;

    public PageExplorer(SiteConfig site, PatrolProperties properties, Page page,
                        PageSniffer sniffer, HealthJudge judge, EvidenceManager evidence,
                        List<PageActionConfig> customActions, List<String> downloadLog) {
        this.site = site;
        this.properties = properties;
        this.page = page;
        this.sniffer = sniffer;
        this.judge = judge;
        this.evidence = evidence;
        this.customActions = customActions == null ? List.of() : customActions;
        this.downloadLog = downloadLog == null ? new ArrayList<>() : downloadLog;
        this.entry = URI.create(site.getEntryUrl());
    }

    private record QueueItem(String url, int depth, String parentUrl) {
    }

    /**
     * 执行 BFS 探索，返回逐页巡检结果。
     */
    public record ExploreOutcome(List<PageInspection> pages, int linksFound) {
    }

    /** collectLinks 采集到的原始链接（href + 锚文本） */
    private record RawLink(String href, String text) {
    }

    /**
     * 执行 BFS 探索，返回逐页巡检结果。
     *
     * <p>探索过程记录每个页面发现的子页面链接与页面间的父子关系，
     * 结束后统一回填到 {@link PageInspection#childLinks()}，
     * 供报告完整回放「页面 → 子页面」的探索路径。</p>
     */
    public ExploreOutcome explore() {
        List<PageInspection> pages = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Map<String, Verdict> verdictByPage = new HashMap<>();
        Map<String, List<LinkRecord>> childLinksByPage = new HashMap<>();
        ArrayDeque<QueueItem> queue = new ArrayDeque<>();
        int linksFound = 0;

        queue.add(new QueueItem(site.getEntryUrl(), 0, null));
        // 额外探索入口：孤立菜单页面等链接不可达的页面（depth 0 种子；相对路径已在加载时解析为绝对地址）
        for (String extra : site.getExtraEntryUrls()) {
            if (extra != null && !extra.isBlank()) {
                queue.add(new QueueItem(extra, 0, null));
            }
        }
        // Sitemap 自动发现：抓取同源 /sitemap.xml 补充孤立页面（无 sitemap 则静默跳过）
        if (site.getSitemapDiscovery() == null || site.getSitemapDiscovery()) {
            List<String> sitemapUrls = fetchSitemapUrls();
            for (String u : sitemapUrls) {
                queue.add(new QueueItem(u, 0, null));
            }
        }
        int pageIdx = 0;

        while (!queue.isEmpty() && pages.size() < site.getMaxPages()) {
            QueueItem item = queue.poll();
            String normalized = normalize(item.url());
            if (normalized == null || !visited.add(normalized)) continue;
            if (!allowedByPrefixes(normalized)) continue;

            pageIdx++;
            PageInspection inspection = visit(normalized, item.depth(), pageIdx, item.parentUrl());
            pages.add(inspection);
            verdictByPage.put(normalized, inspection.verdict());
            log.info("[{}] {}/{} {} depth={} -> {} (consoleErr={} jsErr={} failedReq={} actions={}/{}失败 load={}ms)",
                    site.getSiteName(), pages.size(), site.getMaxPages(), normalized,
                    item.depth(), inspection.verdict(), inspection.consoleErrorCount(),
                    inspection.jsErrorCount(), inspection.failedRequestCount(),
                    inspection.actionCount(), inspection.failedActionCount(), inspection.loadMs());

            // 从当前页采集同源链接继续探索（同时记录子页面链接台账）
            if (inspection.errorMessage() == null) {
                int nextDepth = item.depth() + 1;
                List<LinkRecord> pageLinks = new ArrayList<>();
                Set<String> seenOnPage = new HashSet<>();
                for (RawLink raw : collectLinks()) {
                    String n = normalize(raw.href());
                    if (n == null || !seenOnPage.add(n)) continue;
                    pageLinks.add(new LinkRecord(n, raw.text(), false, null));
                    if (nextDepth <= site.getMaxDepth() && !visited.contains(n)) {
                        queue.add(new QueueItem(n, nextDepth, normalized));
                    }
                }
                linksFound += pageLinks.size();
                childLinksByPage.put(normalized, pageLinks);
            }
        }

        // 探索结束后回填：每个子页面链接标注「是否已巡检 + 巡检结论」
        List<PageInspection> enriched = new ArrayList<>(pages.size());
        for (PageInspection p : pages) {
            List<LinkRecord> filled = childLinksByPage.getOrDefault(p.url(), List.of()).stream()
                    .map(l -> l.withExplored(verdictByPage.containsKey(l.url()), verdictByPage.get(l.url())))
                    .toList();
            enriched.add(p.withExploration(p.parentUrl(), filled));
        }
        return new ExploreOutcome(enriched, linksFound);
    }

    /** ---------------- 单页访问：嗅探 → 判定 → 取证 ---------------- */

    private PageInspection visit(String url, int depth, int pageIdx, String parentUrl) {
        long pageStart = System.nanoTime();
        HealthJudge.VisitFacts facts = new HealthJudge.VisitFacts();
        facts.url = url;

        // 窗口上下文：页面加载窗口（业务 API 记录按此归因 pageUrl/source）
        sniffer.beginVisit(url, "页面加载");
        long t0 = System.nanoTime();
        Response resp = null;
        String navError = null;
        try {
            // hash 路由页面：若当前页与目标仅 fragment 不同，浏览器会做「同文档导航」（不重新加载、
            // navigate 返回 null），嗅探窗口采集不到主文档请求。先回落空白页强制完整文档加载。
            if (url.contains("#")) {
                try {
                    page.navigate("about:blank");
                } catch (PlaywrightException ignored) {
                    // 回落失败不影响后续导航
                }
            }
            resp = page.navigate(url, new Page.NavigateOptions()
                    // 导航硬超时取「阈值 4 倍且不低于 30s」，避免慢页面被误判为访问失败
                    .setTimeout(Math.max(site.getLoadTimeoutMs() * 4L, 30_000L))
                    .setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
        } catch (PlaywrightException e) {
            navError = e.getMessage();
        }
        facts.loadMs = (System.nanoTime() - t0) / 1_000_000;
        facts.mainStatus = resp != null ? resp.status() : -1;
        facts.navigateError = navError;

        String title = null;
        String content = null;
        String finalUrl = url;
        if (navError == null) {
            // 等待网络空闲（尽量收齐 XHR/fetch 结果），超时则继续以已采集数据判定
            try {
                page.waitForLoadState(LoadState.NETWORKIDLE,
                        new Page.WaitForLoadStateOptions()
                                .setTimeout(properties.getDefaults().getNetworkIdleWaitMs()));
            } catch (PlaywrightException ignored) {
                // 网络未空闲（轮询/长连接等），不视为异常
            }
            try {
                finalUrl = page.url();
                title = page.title();
                content = page.content();
            } catch (PlaywrightException e) {
                log.debug("[{}] 读取页面信息失败: {}", site.getSiteName(), e.getMessage());
            }
        }

        facts.consoleLogs = sniffer.consoleLogs();
        facts.jsErrors = sniffer.jsErrors();
        facts.requests = sniffer.finishVisit();
        facts.pageContent = content;
        Map<String, String> failureSnippets = sniffer.failureSnippets();

        HealthJudge.JudgeResult judged = judge.judge(site, facts);

        // 页面访问异常的「第一现场」预截：动作巡检会改变页面状态（点击/跳转/关闭弹窗），
        // 访问级异常（加载失败/console/JS/失败请求）必须在动作开始前截图——
        // 那才是「正确的页面」；横幅标注操作路径（站点 → 页面 → 来源）
        ScreenshotAnnotator.CapturedShot postVisitShot = null;
        if (navError == null && evidence.shouldSave(judged.verdict())) {
            postVisitShot = ScreenshotAnnotator.capture(page,
                    pageAnnotation(site.getSiteName(), url, parentUrl, judged.verdict()));
        }

        String screenshotRel = null;
        String contextRel = null;

        // ---- 功能动作阶段：元素解析 + 查询按钮点击（仅页面访问正常的页面执行） ----
        List<ElementDigest> elements = List.of();
        List<ActionInspection> actions = List.of();
        if (navError == null && facts.mainStatus > 0 && facts.mainStatus < 400
                && (site.getEnableActions() == null || site.getEnableActions())) {
            try {
                PageInteractor interactor = new PageInteractor(site, properties, page,
                        sniffer, evidence, downloadLog);
                PageInteractor.InteractorResult r = interactor.runActions(finalUrl, pageIdx, customActions);
                elements = r.elements();
                actions = r.actions();
            } catch (Exception e) {
                log.warn("[{}] 动作巡检阶段异常: {}", site.getSiteName(), e.getMessage());
            }
        }

        // 聚合页面结论 = 访问结论与全部动作结论的最差值；动作 FAIL 时补充页面级问题摘要
        Verdict verdict = judged.verdict();
        List<IssueRecord> issues = new ArrayList<>(judged.issues());
        long failedActions = actions.stream()
                .filter(a -> a.verdict() == Verdict.FAIL).count();
        if (failedActions > 0) {
            verdict = Verdict.FAIL;
            StringBuilder sb = new StringBuilder("功能动作异常 " + failedActions + " 个：");
            for (ActionInspection a : actions) {
                if (a.verdict() != Verdict.FAIL) continue;
                sb.append("[").append(a.description());
                if (a.errorMessage() != null) sb.append(" 点击失败");
                if (a.failedRequestCount() > 0) sb.append(" 失败请求").append(a.failedRequestCount()).append("个");
                if (a.consoleErrorCount() > 0) sb.append(" console错误").append(a.consoleErrorCount()).append("条");
                if (a.jsErrorCount() > 0) sb.append(" JS异常").append(a.jsErrorCount()).append("处");
                sb.append("] ");
            }
            issues.add(new IssueRecord(IssueType.ACTION_FAILURE, Verdict.FAIL,
                    sb.toString().trim()));
        }
        for (ActionInspection a : actions) {
            verdict = Verdict.worstOf(verdict, a.verdict());
        }

        // 窗口间隙迟到的 console/JS 错误并入页面级结果：visit 窗口结束与动作窗口开始之间存在间隙，
        // 间隙期 SPA 的异步错误（延迟脚本、定时轮询、上个动作的尾包）进入嗅探器的窗口外缓冲，
        // 页面收尾时统一取出并入——迟到错误绝不丢失，并按站点阈值参与页面判定
        List<com.patrol.model.ConsoleRecord> pageConsole = new ArrayList<>(facts.consoleLogs);
        List<String> pageJs = new ArrayList<>(facts.jsErrors);
        List<com.patrol.model.ConsoleRecord> strayConsole = sniffer.drainStrayConsole();
        List<String> strayJs = sniffer.drainStrayJsErrors();
        pageConsole.addAll(strayConsole);
        pageJs.addAll(strayJs);
        boolean strayHasError = strayConsole.stream().anyMatch(com.patrol.model.ConsoleRecord::isError)
                || !strayJs.isEmpty();
        if (strayHasError) {
            long consoleErr = pageConsole.stream()
                    .filter(com.patrol.model.ConsoleRecord::isError).count();
            if (consoleErr > site.getConsoleErrorsMax() || pageJs.size() > site.getJsErrorsMax()) {
                verdict = Verdict.worstOf(verdict, Verdict.FAIL);
                issues.add(new IssueRecord(IssueType.CONSOLE_ERROR, Verdict.FAIL,
                        "窗口间隙采集到迟到错误：console error " + consoleErr + " 条 / JS 异常 "
                                + pageJs.size() + " 处"));
            }
            log.debug("[{}] {} 窗口间隙捕获迟到错误并入页面结果: console {} 条, JS {} 处",
                    site.getSiteName(), shortUrlOf(url), strayConsole.size(), strayJs.size());
        }

        // 证据保存：按最终聚合结论保存一次（访问异常、或动作拖累为 WARN/FAIL 的页面均有截图+上下文）。
        // 访问级异常用动作开始前的「第一现场」预截；动作拖累的页面现场补截（终态 + 操作路径横幅）
        if (evidence.shouldSave(verdict)) {
            ScreenshotAnnotator.Annotation annotation =
                    pageAnnotation(site.getSiteName(), url, parentUrl, verdict);
            ScreenshotAnnotator.CapturedShot shot = postVisitShot != null ? postVisitShot
                    : ScreenshotAnnotator.capture(page, annotation);
            EvidenceManager.EvidencePaths paths = evidence.save(page, site, pageIdx,
                    facts, issues, verdict, failureSnippets, content, shot, annotation);
            screenshotRel = paths.screenshot();
            contextRel = paths.contextJson();
        }

        long patrolMs = (System.nanoTime() - pageStart) / 1_000_000;
        return new PageInspection(
                site.getSiteName(), url, finalUrl, title, depth,
                facts.mainStatus, facts.loadMs, patrolMs, verdict,
                issues, pageConsole, pageJs, facts.requests,
                actions, elements,
                parentUrl, List.of(),
                screenshotRel, contextRel, navError);
    }

    private static String shortUrlOf(String url) {
        if (url == null) return "";
        int p = url.indexOf('/', url.indexOf("//") + 2);
        return p < 0 ? url : url.substring(p);
    }

    /** 页面级操作路径标注：站点 → 页面 ← 来源（入口/父页面）→ 结论；页面级异常无单一元素，不画红框只显示横幅 */
    private static ScreenshotAnnotator.Annotation pageAnnotation(String siteName, String url,
                                                                 String parentUrl, Verdict verdict) {
        String path = "站点[" + siteName + "] → 页面[" + url + "] ← "
                + (parentUrl == null || parentUrl.isBlank() ? "入口" : "来源[" + parentUrl + "]")
                + " → 结论[" + verdict + "]";
        return new ScreenshotAnnotator.Annotation(path, null, null);
    }

    /**
     * 采集当前页面中的可探索链接：
     * <ul>
     *   <li>{@code a[href]} 导航链接（锚文本兜底取 img alt/title）</li>
     *   <li>{@code area[href]} 图片地图区域</li>
     *   <li>{@code [onclick]} 内联 JS 导航（location.href='…' / window.open('…')，JS 菜单项常见写法）</li>
     * </ul>
     */
    @SuppressWarnings("unchecked")
    private List<RawLink> collectLinks() {
        try {
            Object result = page.evaluate("""
                    (() => {
                      const out = [];
                      const push = (href, text) => out.push({ href, text: (text || '').trim().slice(0, 60) });
                      for (const a of document.querySelectorAll('a[href]')) {
                        let t = (a.innerText || a.textContent || '').trim();
                        if (!t) {
                          const img = a.querySelector('img[alt], img[title]');
                          if (img) t = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
                        }
                        push(a.href, t);
                      }
                      for (const ar of document.querySelectorAll('area[href]')) {
                        push(ar.href, ar.getAttribute('alt') || '');
                      }
                      for (const el of document.querySelectorAll('[onclick]')) {
                        const code = el.getAttribute('onclick') || '';
                        const m = code.match(/(?:location(?:\\.href)?\\s*=\\s*|window\\.open\\(\\s*)['"]([^'"]+)['"]/);
                        if (m && m[1]) {
                          let u;
                          try { u = new URL(m[1], location.href).href; } catch (e) { continue; }
                          push(u, (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim());
                        }
                      }
                      return out;
                    })()
                    """);
            if (!(result instanceof List<?> list)) return List.of();
            List<RawLink> out = new ArrayList<>();
            for (Object o : list) {
                if (!(o instanceof Map<?, ?> m)) continue;
                String href = String.valueOf(m.get("href"));
                String text = String.valueOf(m.get("text"));
                if ("null".equals(href) || href.isBlank()) continue;
                out.add(new RawLink(href, "null".equals(text) ? "" : text));
            }
            return out;
        } catch (PlaywrightException e) {
            log.debug("[{}] 链接采集失败: {}", site.getSiteName(), e.getMessage());
            return List.of();
        }
    }

    /**
     * 归一化 URL：同源则返回规范形式，非同源/非页面返回 null。
     *
     * <p>路由型 hash（{@code #/menu}、{@code #!/menu}）会被保留——hash 路由 SPA 的
     * 各菜单页面视为不同页面参与探索，不再折叠为同一 URL；普通页内锚点（如 {@code #top}）忽略。</p>
     */
    String normalize(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String t = raw.trim();
        String lower = t.toLowerCase(Locale.ROOT);
        if (lower.startsWith("javascript:") || lower.startsWith("mailto:")
                || lower.startsWith("tel:") || lower.startsWith("data:")) {
            return null;
        }
        URI uri;
        try {
            uri = URI.create(t);
        } catch (IllegalArgumentException e) {
            return null;
        }
        String scheme = uri.getScheme();
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return null;

        String host = uri.getHost();
        if (host == null || !host.equalsIgnoreCase(entry.getHost())) return null;
        int port = uri.getPort();
        int entryPort = entry.getPort();
        boolean samePort = (port == -1 && entryPort == -1) || port == entryPort
                || (port == -1 && defaultPort(scheme) == entryPort)
                || (entryPort == -1 && port == defaultPort(scheme));
        if (!samePort) return null;

        String path = uri.getPath() == null ? "/" : uri.getPath();
        String lowerPath = path.toLowerCase(Locale.ROOT);
        for (String ext : SKIP_EXTENSIONS) {
            if (lowerPath.endsWith(ext)) return null;
        }
        String query = uri.getQuery();
        String fragment = uri.getFragment();
        // 路由型 hash 保留（#/、#!/ 开头），hash 路由 SPA 的每个菜单页面是独立页面
        boolean routeFragment = fragment != null && !fragment.isBlank()
                && (fragment.startsWith("/") || fragment.startsWith("!"));
        return scheme.toLowerCase(Locale.ROOT) + "://" + host.toLowerCase(Locale.ROOT)
                + (port >= 0 ? ":" + port : "")
                + path
                + (query != null && !query.isBlank() ? "?" + query : "")
                + (routeFragment ? "#" + fragment : "");
    }

    private static int defaultPort(String scheme) {
        return "https".equalsIgnoreCase(scheme) ? 443 : 80;
    }

    /**
     * 抓取同源 /sitemap.xml 并解析其中的候选 URL（孤立页面自动发现的来源之一）。
     * 404/超时/解析失败均静默跳过（多数站点没有 sitemap，属正常情况）。
     */
    private List<String> fetchSitemapUrls() {
        String sitemapUrl = entry.getScheme() + "://" + entry.getHost()
                + (entry.getPort() >= 0 ? ":" + entry.getPort() : "") + "/sitemap.xml";
        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(5))
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build();
            HttpResponse<String> resp = client.send(
                    HttpRequest.newBuilder(URI.create(sitemapUrl))
                            .timeout(Duration.ofSeconds(5)).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) {
                log.debug("[{}] sitemap 不可用（{}），跳过自动发现", site.getSiteName(), resp.statusCode());
                return List.of();
            }
            String body = resp.body();
            if (body == null || !body.contains("<loc")) {
                log.debug("[{}] sitemap 响应中无 <loc> 条目，跳过", site.getSiteName());
                return List.of();
            }
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            Document doc = factory.newDocumentBuilder()
                    .parse(new InputSource(new StringReader(body)));
            NodeList locs = doc.getElementsByTagName("loc");
            List<String> out = new ArrayList<>(locs.getLength());
            for (int i = 0; i < locs.getLength(); i++) {
                String u = locs.item(i).getTextContent() == null ? "" : locs.item(i).getTextContent().trim();
                if (!u.isEmpty()) out.add(u);
            }
            log.info("[{}] sitemap 自动发现 {} 个候选页面: {}", site.getSiteName(), out.size(), sitemapUrl);
            return out;
        } catch (Exception e) {
            log.debug("[{}] sitemap 未发现或抓取失败（可忽略）: {}", site.getSiteName(), e.getMessage());
            return List.of();
        }
    }

    /** 按站点配置的包含/排除前缀过滤 */
    private boolean allowedByPrefixes(String normalizedUrl) {
        String rawPath;
        try {
            rawPath = URI.create(normalizedUrl).getPath();
        } catch (IllegalArgumentException e) {
            return false;
        }
        final String path = rawPath == null ? "/" : rawPath;
        List<String> includes = site.getPathIncludePrefixes();
        if (includes != null && !includes.isEmpty()) {
            boolean matched = includes.stream().anyMatch(p -> path.startsWith(ensureSlash(p)));
            if (!matched) return false;
        }
        List<String> excludes = site.getPathExcludePrefixes();
        if (excludes != null) {
            for (String p : excludes) {
                if (path.startsWith(ensureSlash(p))) return false;
            }
        }
        return true;
    }

    private static String ensureSlash(String p) {
        String t = p.trim();
        return t.startsWith("/") ? t : "/" + t;
    }
}
