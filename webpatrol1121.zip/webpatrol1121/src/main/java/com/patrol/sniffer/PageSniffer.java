package com.patrol.sniffer;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Request;
import com.microsoft.playwright.Response;
import com.patrol.model.ApiCallRecord;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.RequestRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 页面嗅探器：在单个 Page 上一次性挂载 console / pageError / 网络事件监听，
 * 按访问（visit）维度复位与汇总采集结果。
 *
 * <p>事件监听器只注册一次，跨多次导航复用；每次导航前调用 {@link #beginVisit(String)}，
 * 导航完成后调用 {@link #finishVisit()} 得到该次访问的完整采集数据。</p>
 */
public class PageSniffer {

    private static final Logger log = LoggerFactory.getLogger(PageSniffer.class);

    /**
     * 响应体抓取线程池（守护线程）。{@code Response.body()} 没有超时语义——
     * 外网半断时 4xx 响应的 body 可能永远悬挂，直接调用会拖死巡检 worker，
     * 因此外层用 {@link Future#get(long, TimeUnit)} 限时兜底，超时放弃该片段（证据为尽力而为）。
     */
    private static final ExecutorService SNIPPET_EXECUTOR = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "patrol-snippet-reader");
        t.setDaemon(true);
        return t;
    });
    /** 单个失败响应体片段的抓取超时（毫秒） */
    private static final long SNIPPET_TIMEOUT_MS = 3_000;

    private final Page page;

    // 当前访问的采集容器
    private volatile boolean active = false;
    private final List<ConsoleRecord> consoleLogs = new ArrayList<>();
    private final List<String> jsErrors = new ArrayList<>();
    private final List<RequestRecord> requests = new ArrayList<>();

    // ---------------------- 业务 API 请求（xhr / fetch）站点级采集 ----------------------
    /** 当前窗口内进行中的 API 请求草稿: key = url#method -> FIFO 草稿队列（同 URL 并发时按发出顺序配对响应） */
    private final Map<String, ArrayDeque<ApiDraft>> apiPending = new LinkedHashMap<>();
    /** 当前窗口已完成（收到响应/失败）的 API 草稿，finishVisit 时抓响应体并固化 */
    private final List<ApiDraft> apiDrafts = new ArrayList<>();
    /** 站点级累积的业务 API 调用记录（跨窗口累积，PatrolEngine 站点收尾时取走） */
    private final List<ApiCallRecord> siteApiCalls = new ArrayList<>();
    /** 站点级 API 记录上限（防止异常页面轮询刷爆内存） */
    private static final int SITE_API_CAP = 3_000;
    /** 单窗口响应体抓取上限：超出后新响应不再抓 body（记录仍保留，防慢页面拖死巡检） */
    private static final int API_BODY_FETCH_CAP = 100;
    /** 响应体内容长度上限（字节）：超过视为大响应，跳过 body 抓取 */
    private static final long API_BODY_MAX_BYTES = 512 * 1024;
    /** 响应体存储截断长度（字符） */
    private static final int API_BODY_SNIPPET_LEN = 4_000;
    /** 请求头 / 请求体存储截断长度（字符） */
    private static final int API_REQ_SNIPPET_LEN = 4_000;
    /** 当前窗口上下文：所属巡检页面 + 触发源（beginVisit 时设置，报告归因用） */
    private volatile String windowPageUrl;
    private volatile String windowSource;
    /** 本地维护的当前文档地址（由导航请求 URL 推进，事件载荷本地可得，供 API 记录 triggerUrl 归因） */
    private volatile String docUrl = "about:blank";

    /**
     * API 请求草稿（可变中间态）：事件回调内只登记本地字段与对象句柄，
     * headers / postData / body 等需要 driver 往返的属性统一延迟到 finishVisit 读取
     * （与 body() 同理，避免监听器内嵌套远程调用阻塞分发循环）。
     */
    private static final class ApiDraft {
        final String pageUrl;
        final String triggerUrl;    // 请求发起瞬间的浏览器地址（onRequest 时捕获）
        final String source;
        final String method;
        final String url;
        final String resourceType;
        final long startNano;
        Request request;           // 请求对象句柄（延迟读 headers/postData）
        Response response;          // 响应句柄（延迟读 body / content-type）
        int status = -1;
        String failureText;
        long durationMs = -1;

        ApiDraft(String pageUrl, String triggerUrl, String source, Request req, long startNano) {
            this.pageUrl = pageUrl;
            this.triggerUrl = triggerUrl;
            this.source = source;
            this.method = req.method();
            this.url = req.url();
            this.resourceType = req.resourceType();
            this.startNano = startNano;
            this.request = req;
        }
    }

    /**
     * 访问窗口外（上一窗口结束与下一窗口开始之间的间隙）到达的 console / JS 错误缓冲。
     *
     * <p>窗口切换存在间隙（页面访问结算后进入动作巡检、两个动作之间），间隙期 SPA 的
     * 异步错误（延迟脚本、定时轮询、上个动作的尾包）如果直接丢弃会造成<b>console 错误漏采</b>。
     * 缓冲后并入下一个窗口（页面访问或动作），宁可归因稍有偏移也绝不丢失。</p>
     */
    private final List<ConsoleRecord> strayConsole = new ArrayList<>();
    private final List<String> strayJsErrors = new ArrayList<>();
    /** 窗口外缓冲上限（防止异常页面无限刷错误日志撑爆内存） */
    private static final int STRAY_CAP = 300;
    /** 进行中的请求: key = url#method -> 发出时刻(nano) */
    private final Map<String, Long> pending = new LinkedHashMap<>();
    /** 失败请求的响应体片段: key = url#method */
    private final Map<String, String> failureSnippets = new LinkedHashMap<>();
    /**
     * 失败响应句柄: key = url#method。
     *
     * <p><b>事件回调内绝不调用 {@code Response.body()}</b>——Playwright 事件监听器运行在
     * 连接的消息分发循环里，嵌套发起 body() 请求会在无后续消息到达时永久阻塞（典型死锁：
     * 外网请求悬挂时首次导航即卡死）。因此监听器只登记句柄，
     * 统一延迟到 {@link #finishVisit()}（分发循环之外）再抓取响应体。</p>
     */
    private final Map<String, Response> failedResponses = new LinkedHashMap<>();

    public PageSniffer(Page page) {
        this.page = page;
        attachTo(page);
    }

    /**
     * 为新出现的页面（伪链接 window.open 弹出的新页签等）追加挂载监听，
     * 采集结果并入同一容器——弹窗页面里的 console 错误 / 请求同样计入巡检结果。
     */
    public void addPage(Page extra) {
        if (extra == null || extra == page) return;
        try {
            attachTo(extra);
        } catch (Exception e) {
            // 页面可能已关闭（竞态），挂载失败不影响巡检
        }
    }

    private void attachTo(Page p) {
        // 注意：页面导航/销毁竞态时 Playwright 可能向监听器传入 null 载荷
        // （如事件排队期间对象已被 dispose），所有载荷必须先做空检查，绝不让监听器异常炸掉巡检。
        p.onConsoleMessage(msg -> {
            if (msg == null) return;
            ConsoleRecord rec = new ConsoleRecord(
                    msg.type(), msg.text(), msg.location(), System.currentTimeMillis());
            synchronized (consoleLogs) {
                if (active) {
                    consoleLogs.add(rec);
                } else if (strayConsole.size() < STRAY_CAP) {
                    strayConsole.add(rec);   // 窗口外缓冲，并入下一窗口（见字段注释）
                }
            }
        });
        p.onPageError(err -> {
            if (err == null) return;
            synchronized (jsErrors) {
                if (active) {
                    jsErrors.add(err);
                } else if (strayJsErrors.size() < STRAY_CAP) {
                    strayJsErrors.add(err);
                }
            }
        });
        page.onRequest(req -> {
            if (req == null) return;
            // 本地维护「当前文档地址」：导航请求的 URL 即文档 URL，事件载荷本地可得，
            // 供 API 记录的 triggerUrl 归因（请求发起时浏览器所在页面），无需在监听器内做 driver 往返
            try {
                if (req.isNavigationRequest()) docUrl = req.url();
            } catch (Exception ignored) {
            }
            if (!active) return;
            String key = keyOf(req);
            synchronized (pending) {
                pending.put(key, System.nanoTime());
            }
            // 业务 API 请求（xhr/fetch，不含图片/脚本/样式等资源）：登记草稿，
            // 响应/失败时补全状态与耗时，headers/postData/body 统一延迟到 finishVisit 读取
            if (isApiRequest(req)) {
                synchronized (apiPending) {
                    apiPending.computeIfAbsent(key, k -> new ArrayDeque<>())
                            .addLast(new ApiDraft(windowPageUrl, docUrl, windowSource, req,
                                    System.nanoTime()));
                }
            }
        });
        page.onResponse(resp -> {
            if (!active || resp == null) return;
            Request req = resp.request();
            if (req == null) return;
            String key = keyOf(req);
            Long start;
            synchronized (pending) {
                start = pending.remove(key);
            }
            long dur = start == null ? -1 : (System.nanoTime() - start) / 1_000_000;
            synchronized (requests) {
                requests.add(new RequestRecord(req.url(), req.method(), req.resourceType(),
                        resp.status(), null, dur, isMainDoc(req)));
            }
            if (resp.status() >= 400) {
                // 只登记句柄，响应体延迟到 finishVisit() 再抓取（见字段注释）
                synchronized (failedResponses) {
                    failedResponses.putIfAbsent(key, resp);
                }
            }
            // 业务 API 请求：补全草稿（响应句柄登记，body 延迟抓取）
            if (isApiRequest(req)) {
                synchronized (apiPending) {
                    ArrayDeque<ApiDraft> queue = apiPending.get(key);
                    ApiDraft d = queue == null ? null : queue.pollFirst();
                    if (d != null) {
                        d.response = resp;
                        d.status = resp.status();
                        d.durationMs = (System.nanoTime() - d.startNano) / 1_000_000;
                        synchronized (apiDrafts) {
                            apiDrafts.add(d);
                        }
                    }
                }
            }
        });
        page.onRequestFailed(req -> {
            if (!active || req == null) return;
            String key = keyOf(req);
            Long start;
            synchronized (pending) {
                start = pending.remove(key);
            }
            long dur = start == null ? -1 : (System.nanoTime() - start) / 1_000_000;
            synchronized (requests) {
                requests.add(new RequestRecord(req.url(), req.method(), req.resourceType(),
                        -1, req.failure(), dur, isMainDoc(req)));
            }
            // 业务 API 请求：网络层失败（net::ERR_xxx）同样补全草稿
            if (isApiRequest(req)) {
                synchronized (apiPending) {
                    ArrayDeque<ApiDraft> queue = apiPending.get(key);
                    ApiDraft d = queue == null ? null : queue.pollFirst();
                    if (d != null) {
                        d.response = null;
                        d.status = -1;
                        d.failureText = req.failure();
                        d.durationMs = (System.nanoTime() - d.startNano) / 1_000_000;
                        synchronized (apiDrafts) {
                            apiDrafts.add(d);
                        }
                    }
                }
            }
        });
    }

    /** 是否为业务 API 请求（xhr / fetch；图片、视频、脚本、样式等资源请求被过滤） */
    private static boolean isApiRequest(Request req) {
        try {
            String t = req.resourceType();
            return "xhr".equalsIgnoreCase(t) || "fetch".equalsIgnoreCase(t);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isMainDoc(Request req) {
        try {
            return req.isNavigationRequest() && req.frame() == page.mainFrame();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 抓取本次访问中失败响应（状态码 ≥ 400）的响应体片段。
     *
     * <p>只能在 {@link #finishVisit()}（事件分发循环之外）调用；每个片段限时
     * {@link #SNIPPET_TIMEOUT_MS}，超时 / 重定向 / 无 body / 页面已跳转均静默降级，
     * 绝不阻塞巡检主流程。</p>
     */
    private void drainFailedResponses() {
        synchronized (failedResponses) {
            for (Map.Entry<String, Response> e : failedResponses.entrySet()) {
                Response resp = e.getValue();
                byte[] body;
                try {
                    Future<byte[]> future = SNIPPET_EXECUTOR.submit(resp::body);
                    body = future.get(SNIPPET_TIMEOUT_MS, TimeUnit.MILLISECONDS);
                } catch (TimeoutException te) {
                    log.debug("抓取失败响应体超时放弃: {}", resp.url());
                    continue;
                } catch (Exception ex) {
                    // 重定向 / 无 body 的响应会抛异常，属正常情况
                    log.debug("读取失败响应体失败 {} : {}", resp.url(), ex.getMessage());
                    continue;
                }
                if (body == null || body.length == 0) continue;
                synchronized (failureSnippets) {
                    failureSnippets.putIfAbsent(e.getKey(),
                            new String(body, java.nio.charset.StandardCharsets.UTF_8));
                }
            }
            failedResponses.clear();
        }
    }

    private static String keyOf(Request req) {
        return req.url() + "#" + req.method();
    }

    /** 开始一次新的页面访问（无窗口上下文，等价于 beginVisit(null, null)） */
    public void beginVisit() {
        beginVisit(null, null);
    }

    /**
     * 开始一次新的访问窗口，并登记窗口上下文供业务 API 记录归因。
     *
     * @param pageUrl 本窗口所属的巡检页面（报告归组用）
     * @param source  触发源描述（如 "页面加载"、"动作: 点击查询按钮[查询]"）
     */
    public void beginVisit(String pageUrl, String source) {
        windowPageUrl = pageUrl;
        windowSource = source;
        synchronized (consoleLogs) {
            consoleLogs.clear();
            consoleLogs.addAll(strayConsole);
            strayConsole.clear();
        }
        synchronized (jsErrors) {
            jsErrors.clear();
            jsErrors.addAll(strayJsErrors);
            strayJsErrors.clear();
        }
        synchronized (requests) { requests.clear(); }
        synchronized (pending) { pending.clear(); }
        synchronized (failureSnippets) { failureSnippets.clear(); }
        synchronized (failedResponses) { failedResponses.clear(); }
        // 窗口切换时清空上一窗口残留的 API 草稿（未完成的随 finishVisit 已固化）
        synchronized (apiPending) { apiPending.clear(); }
        synchronized (apiDrafts) { apiDrafts.clear(); }
        active = true;
    }

    /** 停止采集（页面关闭前调用），同时丢弃未归并的窗口外缓冲与未完成的 API 草稿 */
    public void stop() {
        active = false;
        synchronized (consoleLogs) {
            strayConsole.clear();
        }
        synchronized (jsErrors) {
            strayJsErrors.clear();
        }
        synchronized (apiPending) { apiPending.clear(); }
        synchronized (apiDrafts) { apiDrafts.clear(); }
    }

    public List<ConsoleRecord> consoleLogs() {
        synchronized (consoleLogs) { return new ArrayList<>(consoleLogs); }
    }

    public List<String> jsErrors() {
        synchronized (jsErrors) { return new ArrayList<>(jsErrors); }
    }

    /** 当前窗口内已登记的请求快照（动作收尾前的异常预判用；未响应请求不计入） */
    public List<RequestRecord> requests() {
        synchronized (requests) { return new ArrayList<>(requests); }
    }

    public Map<String, String> failureSnippets() {
        synchronized (failureSnippets) { return new LinkedHashMap<>(failureSnippets); }
    }

    /** 取出并清空窗口间隙缓冲的 console 记录（页面收尾时并入页面级结果，不丢弃迟到错误） */
    public List<ConsoleRecord> drainStrayConsole() {
        synchronized (consoleLogs) {
            List<ConsoleRecord> out = new ArrayList<>(strayConsole);
            strayConsole.clear();
            return out;
        }
    }

    /** 取出并清空窗口间隙缓冲的 JS 异常 */
    public List<String> drainStrayJsErrors() {
        synchronized (jsErrors) {
            List<String> out = new ArrayList<>(strayJsErrors);
            strayJsErrors.clear();
            return out;
        }
    }

    /** 结束一次访问：抓取失败响应体片段、挂起未响应的请求以 -1 状态补录，返回完整请求列表 */
    public List<RequestRecord> finishVisit() {
        active = false;
        // 响应体片段在事件分发循环之外抓取（调用方线程），避免监听器内嵌套 body() 死锁
        drainFailedResponses();
        synchronized (pending) {
            for (Map.Entry<String, Long> e : pending.entrySet()) {
                long dur = (System.nanoTime() - e.getValue()) / 1_000_000;
                String key = e.getKey();
                String url = key.substring(0, key.lastIndexOf('#'));
                String method = key.substring(key.lastIndexOf('#') + 1);
                synchronized (requests) {
                    requests.add(new RequestRecord(url, method, "other",
                            -1, "no-response(pending)", dur, false));
                }
            }
            pending.clear();
        }
        // 业务 API 草稿固化：挂起请求补录 + 响应体限时抓取，并入站点级累积列表
        drainApiCalls();
        synchronized (requests) { return new ArrayList<>(requests); }
    }

    // ---------------------- 业务 API 请求固化与读取 ----------------------

    /**
     * 固化本窗口的 API 草稿：未响应的按挂起补录；响应体在事件分发循环之外限时抓取
     * （文本类响应、大小上限、单窗口抓取上限，二进制/大响应/超时均静默降级），
     * 转成不可变 {@link ApiCallRecord} 并入站点级累积列表。
     */
    private void drainApiCalls() {
        List<ApiDraft> windowDrafts = new ArrayList<>();
        synchronized (apiPending) {
            for (ArrayDeque<ApiDraft> queue : apiPending.values()) {
                for (ApiDraft d : queue) {
                    // 窗口结束时仍未收到响应：按挂起补录（-1 / no-response）
                    if (d.failureText == null) {
                        d.failureText = "no-response(pending)";
                    }
                    windowDrafts.add(d);
                }
            }
            apiPending.clear();
        }
        synchronized (apiDrafts) {
            windowDrafts.addAll(apiDrafts);
            apiDrafts.clear();
        }
        int bodyFetched = 0;
        for (ApiDraft d : windowDrafts) {
            String responseBody = null;
            if (d.response != null) {
                if (bodyFetched < API_BODY_FETCH_CAP) {
                    bodyFetched++;
                    responseBody = fetchApiBody(d.response);
                } else {
                    responseBody = "(响应体未采集：超出单窗口抓取上限)";
                }
            }
            Map<String, String> requestHeaders = null;
            String requestBody = null;
            if (d.request != null) {
                // headers()/postData() 需要 driver 往返，统一在此（分发循环之外）读取；
                // 页面已关闭等竞态会抛异常，静默降级为空
                try {
                    requestHeaders = d.request.headers();
                } catch (Exception e) {
                    log.debug("读取 API 请求头失败 {} : {}", d.url, e.getMessage());
                }
                try {
                    requestBody = d.request.postData();
                } catch (Exception e) {
                    log.debug("读取 API 请求体失败 {} : {}", d.url, e.getMessage());
                }
            }
            String pageUrl = d.pageUrl != null ? d.pageUrl : d.triggerUrl;
            String source = d.source != null ? d.source : "页面加载";
            synchronized (siteApiCalls) {
                if (siteApiCalls.size() < SITE_API_CAP) {
                    siteApiCalls.add(new ApiCallRecord(
                            pageUrl, d.triggerUrl, source, d.method, d.url, d.resourceType,
                            d.status, requestHeaders, clip(requestBody, API_REQ_SNIPPET_LEN),
                            responseBody, d.durationMs, d.failureText));
                }
            }
        }
        if (!windowDrafts.isEmpty()) {
            log.debug("本窗口采集业务 API 请求 {} 条（累计 {} 条）",
                    windowDrafts.size(), Math.min(siteApiCalls.size(), SITE_API_CAP));
        }
    }

    /**
     * 抓取文本类 API 响应体片段。只能在事件分发循环之外调用（finishVisit 链路）；
     * 二进制（图片/视频/字体/附件等）与超大响应直接跳过，抓取限时
     * {@link #SNIPPET_TIMEOUT_MS}，超时/无 body/异常均静默降级返回 null。
     */
    private String fetchApiBody(Response resp) {
        try {
            Map<String, String> headers = resp.headers();
            String contentType = headers == null ? "" : headers.getOrDefault("content-type", "");
            if (!isTextLike(contentType)) return null;
            String len = headers.get("content-length");
            if (len != null) {
                try {
                    if (Long.parseLong(len.trim()) > API_BODY_MAX_BYTES) {
                        return "(响应体未采集: 响应超过 " + API_BODY_MAX_BYTES / 1024 + "KB)";
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            byte[] body;
            Future<byte[]> future = SNIPPET_EXECUTOR.submit(resp::body);
            body = future.get(SNIPPET_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (body == null || body.length == 0) return null;
            String text = new String(body, java.nio.charset.StandardCharsets.UTF_8);
            return clip(text, API_BODY_SNIPPET_LEN);
        } catch (TimeoutException te) {
            log.debug("抓取 API 响应体超时放弃: {}", resp.url());
            return null;
        } catch (Exception ex) {
            log.debug("读取 API 响应体失败 {} : {}", resp.url(), ex.getMessage());
            return null;
        }
    }

    /** content-type 是否为文本类（JSON/文本/HTML/表单等；二进制媒体/字体/附件返回 false，空视为文本） */
    private static boolean isTextLike(String contentType) {
        if (contentType == null || contentType.isBlank()) return true;
        String lower = contentType.toLowerCase(java.util.Locale.ROOT);
        if (lower.contains("image/") || lower.contains("video/") || lower.contains("audio/")
                || lower.contains("font/") || lower.contains("octet-stream") || lower.contains("pdf")
                || lower.contains("zip") || lower.contains("gzip") || lower.contains("wasm")
                || lower.contains("binary")) {
            return false;
        }
        return true;
    }

    private static String clip(String s, int max) {
        if (s == null || s.length() <= max) return s;
        return s.substring(0, max) + "…(截断)";
    }

    /** 站点级业务 API 调用记录（页面加载 + 全部动作窗口跨窗口累积；站点收尾时由引擎取走） */
    public List<ApiCallRecord> apiCalls() {
        synchronized (siteApiCalls) {
            return new ArrayList<>(siteApiCalls);
        }
    }
}
