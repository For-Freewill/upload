package com.patrol.model;

/** 页面解析出的可交互元素摘要（含元素类别、链接地址与巡检处理决策） */
public record ElementDigest(
        String tag,           // button / a / input / select / div / span / summary ...
        String text,          // 可见文本 / value / aria-label / title / img alt（截断）
        String id,
        String cssClass,
        String type,          // input 的 type 属性
        String kind,          // 元素类别（BUTTON / LINK / IMAGE_LINK / PSEUDO_LINK / ONCLICK / ARIA / ...）
        String href,          // 链接元素的绝对地址（非链接为空）
        String selectorHint,  // 定位提示（如 button, a, input >> nth=3）
        String cssPath,       // 稳定 CSS 路径（tag:nth-of-type 链，遇 id 终止）——点击定位优先用它
        String patrolId,      // 运行时持久元素 ID（DOM expando，跨多次扫描识别同一元素）
        boolean visible,       // 解析时是否可见（display/visibility/尺寸检查）
        String decision        // 巡检处理决策（已点击/确认类不点击/不可见未点击/导航链接探索覆盖/外部链接不点击等）
) {

    public static final String K_BUTTON = "BUTTON";              // 原生按钮 / role=button / input 按钮型
    public static final String K_LINK = "LINK";                 // 导航链接（a[href]）
    public static final String K_IMAGE_LINK = "IMAGE_LINK";      // 图片链接（无文本、内含 img/svg，alt 作文本）
    public static final String K_PSEUDO_LINK = "PSEUDO_LINK";   // JS 伪链接（无 href / # / javascript:）
    public static final String K_ONCLICK = "ONCLICK";           // 带 onclick 的非原生元素
    public static final String K_ARIA = "ARIA";                 // ARIA 可点击角色（tab/menuitem/option/switch...）
    public static final String K_SUMMARY = "SUMMARY";           // details 折叠项
    public static final String K_POINTER = "POINTER";           // 疑似可点击（cursor:pointer，悬停探测候选）
    public static final String K_TABINDEX = "TABINDEX";          // 可聚焦元素（tabindex，仅记录）
    public static final String K_INPUT = "INPUT";                // 文本类输入框
    public static final String K_SELECT = "SELECT";              // 下拉框
    public static final String K_TEXTAREA = "TEXTAREA";          // 文本域
    public static final String K_LABEL = "LABEL";                // 表单标签
    public static final String K_OTHER = "OTHER";

    public ElementDigest withDecision(String decision) {
        return new ElementDigest(tag, text, id, cssClass, type, kind, href,
                selectorHint, cssPath, patrolId, visible, decision);
    }

    /** 可自动点击的控制类元素（按钮/伪链接/onclick元素/ARIA可点击角色/折叠项） */
    public boolean isClickableControl() {
        return K_BUTTON.equals(kind) || K_PSEUDO_LINK.equals(kind)
                || K_ONCLICK.equals(kind) || K_ARIA.equals(kind) || K_SUMMARY.equals(kind);
    }

    /** 导航型链接（含图片链接）：点击会跳转页面，由 BFS 探索阶段统一巡检 */
    public boolean isLink() {
        return K_LINK.equals(kind) || K_IMAGE_LINK.equals(kind);
    }

    /** 仅记录、不自动点击的疑似可点击元素 */
    public boolean isSuspect() {
        return K_POINTER.equals(kind) || K_TABINDEX.equals(kind);
    }

    /** 元素类别的中文标签（报告展示用） */
    public String kindLabel() {
        return switch (kind == null ? "" : kind) {
            case K_BUTTON -> "按钮";
            case K_LINK -> "链接";
            case K_IMAGE_LINK -> "图片链接";
            case K_PSEUDO_LINK -> "JS伪链接";
            case K_ONCLICK -> "onclick元素";
            case K_ARIA -> "ARIA可点击";
            case K_SUMMARY -> "折叠项";
            case K_POINTER -> "疑似可点击";
            case K_TABINDEX -> "可聚焦元素";
            case K_INPUT -> "输入框";
            case K_SELECT -> "下拉框";
            case K_TEXTAREA -> "文本域";
            case K_LABEL -> "表单标签";
            default -> "其他";
        };
    }
}
