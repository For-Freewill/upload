package com.patrol.model;

import java.util.List;

/**
 * 与上一次巡检报告的对比分析结果。
 *
 * <p>对比相同站点的页面/动作/错误变化，帮助快速识别「这次比上次多了什么问题、恢复了什么问题」：</p>
 * <ul>
 *   <li>站点级：结论变化、站点耗时变化</li>
 *   <li>页面级：新增/消失页面、页面结论变化、巡检耗时变化</li>
 *   <li>动作级：新增失败动作、已恢复动作</li>
 *   <li>错误级：console / JS / 失败请求的数量变化</li>
 * </ul>
 */
public record ReportComparison(
        boolean available,          // 是否找到了可对比的上次报告
        String previousReport,      // 上次报告目录名（如 patrol-20261120-183000）
        String previousStartedAt,   // 上次巡检开始时间
        List<ChangeRow> rows) {     // 变化明细

    /** 单条变化：category=站点/页面/动作/错误，previous/current 为对比前后的值 */
    public record ChangeRow(
            String category,
            String site,
            String page,
            String item,
            String previous,
            String current,
            String change) {
    }

    /** 新增问题类变化的数量（新增失败动作 / 新增页面 / 结论恶化 / 错误增多） */
    public long newIssueCount() {
        return rows == null ? 0 : rows.stream()
                .filter(r -> r.change() != null && r.change().startsWith("新增")).count();
    }

    /** 恢复类变化的数量（已恢复动作 / 消失页面 / 结论好转 / 错误减少） */
    public long recoveredCount() {
        return rows == null ? 0 : rows.stream()
                .filter(r -> r.change() != null && r.change().startsWith("恢复")).count();
    }
}
