package com.patrol.model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 单条前端业务 API 调用记录（xhr / fetch，已过滤图片、脚本、样式等资源请求）。
 *
 * <p>记录「哪个页面、什么触发源、发起了什么请求、拿到了什么响应」的完整链路，
 * 供站点级请求明细统计与 curl 一键复现：</p>
 * <ul>
 *   <li>{@code pageUrl} —— 该请求所属的巡检页面（窗口上下文，报告归组用）</li>
 *   <li>{@code triggerUrl} —— 请求实际发起时浏览器所在页面地址（跳转/SPA 路由后可能与 pageUrl 不同）</li>
 *   <li>{@code source} —— 触发源描述（页面加载 / 功能动作描述）</li>
 *   <li>{@code requestHeaders} / {@code requestBody} —— 请求侧信息（含 Cookie，供 curl 复现）</li>
 *   <li>{@code responseBody} —— 响应体片段（文本类响应、限时抓取、超长截断；未采集时为 null 或说明文字）</li>
 * </ul>
 */
public record ApiCallRecord(
        String pageUrl,
        String triggerUrl,
        String source,
        String method,
        String url,
        String resourceType,          // xhr / fetch
        int status,                   // -1 = 未收到响应（网络失败或挂起）
        Map<String, String> requestHeaders,
        String requestBody,
        String responseBody,
        long durationMs,              // 请求耗时，未知为 -1
        String failureText             // 网络层失败原因（net::ERR_xxx），成功为 null
) {

    /** 该请求是否失败（HTTP >= 400 或网络层失败；ERR_ABORTED 属浏览器正常中止不计） */
    public boolean isFailed() {
        if (failureText != null && failureText.contains("ERR_ABORTED")) {
            return false;
        }
        return status >= 400 || status < 0;
    }

    /** 生成标准 curl 复现命令（多行反斜杠续行，可读性好，适合报告展示） */
    public String toCurl() {
        return buildCurl(" \\\n  ");
    }

    /** 单行版 curl 命令（适合 HTML 属性内嵌与 Excel 单元格） */
    public String toCurlOneLine() {
        return buildCurl(" ");
    }

    /**
     * curl 命令构造：method + URL + 全量请求头（剔除 curl 自行计算的 content-length）+
     * 请求体（--data-raw）。单引号内的单引号按 shell 规则 {@code '\''} 转义；
     * 请求头键规范化为标准 HTTP 大小写（Playwright 采集为小写，如 content-type → Content-Type）。
     */
    private String buildCurl(String sep) {
        StringBuilder sb = new StringBuilder("curl -X ").append(nz(method)).append(" '")
                .append(shellQuote(nz(url))).append("'");
        if (requestHeaders != null) {
            Map<String, String> ordered = new LinkedHashMap<>(requestHeaders);
            for (Map.Entry<String, String> e : ordered.entrySet()) {
                String key = e.getKey();
                if (key == null || key.equalsIgnoreCase("content-length")) continue;
                sb.append(sep).append("-H '").append(shellQuote(headerTitle(key))).append(": ")
                        .append(shellQuote(nz(e.getValue()))).append("'");
            }
        }
        if (requestBody != null && !requestBody.isBlank()) {
            sb.append(sep).append("--data-raw '").append(shellQuote(requestBody)).append("'");
        }
        return sb.toString();
    }

    /** 请求头键规范化：按 '-' 分段首字母大写（content-type → Content-Type，x-trace-id → X-Trace-Id） */
    private static String headerTitle(String key) {
        StringBuilder sb = new StringBuilder(key.length());
        boolean upperNext = true;
        for (char ch : key.toCharArray()) {
            if (upperNext) {
                sb.append(Character.toUpperCase(ch));
                upperNext = false;
            } else {
                sb.append(ch);
            }
            if (ch == '-') {
                upperNext = true;
            }
        }
        return sb.toString();
    }

    /** shell 单引号字符串内嵌转义：' → '\'' */
    private static String shellQuote(String s) {
        return s.replace("'", "'\\''");
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
