package com.patrol.model;

import java.util.List;

/** 单个站点的一次完整巡检结果 */
public record SiteInspection(
        String siteName,
        String entryUrl,
        String authType,
        String startedAt,
        String finishedAt,
        Verdict verdict,              // 站点级结论：所有页面中的最差结果
        List<PageInspection> pages,
        int linksFound,                // 站内探索发现的链接总数
        String errorMessage,           // 站点级错误（如登录失败、浏览器异常）
        List<ApiCallRecord> apiCalls)  // 站点级前端业务 API 请求明细（xhr/fetch，跨页面+动作累积）
{
    /** apiCalls 的空安全视图（旧版报告 JSON 反序列化时该字段可能为 null） */
    public List<ApiCallRecord> apiCallList() {
        return apiCalls == null ? List.of() : apiCalls;
    }

    /** 失败的业务 API 请求数（HTTP >= 400 或网络层失败，ERR_ABORTED 不计） */
    public long failedApiCalls() {
        return apiCallList().stream().filter(ApiCallRecord::isFailed).count();
    }


    public int pagesVisited() {
        return pages == null ? 0 : pages.size();
    }

    public long passPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.PASS).count();
    }

    public long warnPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.WARN).count();
    }

    public long failPages() {
        return pages == null ? 0 : pages.stream().filter(p -> p.verdict() == Verdict.FAIL).count();
    }

    public int totalActions() {
        return pages == null ? 0 : pages.stream().mapToInt(PageInspection::actionCount).sum();
    }

    public long failedActions() {
        return pages == null ? 0 : pages.stream().mapToLong(PageInspection::failedActionCount).sum();
    }

    /** 站点巡检总耗时（毫秒）：由开始/结束时间戳计算；解析失败返回 -1 */
    public long durationMs() {
        try {
            java.time.LocalDateTime s = java.time.LocalDateTime.parse(startedAt);
            java.time.LocalDateTime f = java.time.LocalDateTime.parse(finishedAt);
            return java.time.Duration.between(s, f).toMillis();
        } catch (Exception e) {
            return -1;
        }
    }

    /** 站点下全部子页面的巡检耗时合计（毫秒），站点级错误页无页面时返回 0 */
    public long pagePatrolMs() {
        return pages == null ? 0 : pages.stream().mapToLong(PageInspection::patrolMs).sum();
    }
}
