package com.patrol.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** 巡检框架全局配置（application.yml 中 patrol.* 前缀） */
@ConfigurationProperties(prefix = "patrol")
public class PatrolProperties {

    /** Excel 巡检配置文件路径 */
    private String excelPath = "config/sites.xlsx";

    /** 报告输出根目录 */
    private String outputDir = "reports";

    /** 登录状态缓存目录（MANUAL/SSO/FORM 登录态文件，跨巡检复用） */
    private String loginStateDir = "login-state";

    /** 任一站点 FAIL 时以非 0 退出码结束（便于 CI 集成） */
    private boolean strictExit = true;

    /**
     * 多站点并行巡检的最大并行度（Playwright 实例数）。
     * 1 = 串行（默认）；N = 最多 N 个站点同时巡检，每个 worker 独立 Playwright + 无头浏览器实例。
     * 登录认证阶段始终串行（MANUAL/SSO 需人工交互）。
     */
    private int maxParallelSites = 1;

    private final Browser browser = new Browser();
    private final Defaults defaults = new Defaults();
    private final Evidence evidence = new Evidence();

    public static class Browser {
        /** 浏览器类型：chromium / firefox / webkit */
        private String type = "chromium";
        /**
         * 所有浏览器上下文（认证+巡检）统一使用的 locale（如 zh-CN / en-US）。
         * 固定 locale 保证有头认证与无头巡检看到一致的界面语言，
         * 文本类选择器（如登录按钮）不随系统语言漂移；留空则使用浏览器默认。
         */
        private String locale = "zh-CN";
        /** 慢放（调试用，ms） */
        private int slowMoMs = 0;
        /** create() 时是否允许 Playwright 自动下载整套浏览器（默认 false，需先 CLI install） */
        private boolean autoDownload = false;

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public String getLocale() { return locale; }
        public void setLocale(String locale) { this.locale = locale; }
        public int getSlowMoMs() { return slowMoMs; }
        public void setSlowMoMs(int slowMoMs) { this.slowMoMs = slowMoMs; }
        public boolean isAutoDownload() { return autoDownload; }
        public void setAutoDownload(boolean autoDownload) { this.autoDownload = autoDownload; }
    }

    public static class Defaults {
        private int maxPages = 10;
        private int maxDepth = 2;
        /** 探索开始前尝试抓取同源 /sitemap.xml 补充孤立页面（无 sitemap 则跳过） */
        private boolean sitemapDiscovery = true;
        private int consoleErrorsMax = 0;
        private int jsErrorsMax = 0;
        private int failedRequestsMax = 0;
        private int loadTimeoutMs = 15000;
        private int networkIdleWaitMs = 5000;
        /** 页面内容中的错误关键词（逗号分隔），命中即判 FAIL */
        private String errorKeywords =
                "Whitelabel Error,404 Not Found,500 Internal Server Error,出错了,系统异常,页面不存在,Service Unavailable";

        // ---- 功能动作巡检（查询按钮点击等） ----
        /** 是否启用动作巡检（解析页面元素并对查询类按钮自动点击） */
        private boolean enableActions = true;
        /** 动作模式：QUERY = 只点查询关键词按钮；ALL = 遍历全部按钮型元素（排除词仍生效） */
        private String actionMode = "QUERY";
        /** 单页最大动作数（自定义动作 + 自动查询按钮点击总数上限） */
        private int maxActionsPerPage = 5;
        /** 动作点击后等待网络空闲的毫秒数 */
        private int actionNetworkIdleWaitMs = 5000;
        /** 查询类按钮文本关键词（逗号分隔，忽略大小写） */
        private String queryButtonKeywords = "查询,搜索,检索,筛选,search,query,find,重置,reset";
        /**
         * 永不点击的按钮文本关键词（逗号分隔）——确认类按钮：
         * 保存/提交/确认/登录/退出等，点击会造成数据落库、误登出等不可逆影响。
         * 新增/编辑/删除类按钮允许点击（打开对话框），但绝不点击对话框内的确认按钮。
         */
        private String excludedButtonKeywords =
                "保存,提交,确认,确定,登录,退出,注销,登出,save,submit,confirm,login,logout,signout";
        /**
         * 对话框类按钮文本关键词（逗号分隔）——新增/编辑/删除/上传/导入等：
         * 允许点击（巡检其打开的弹窗与触发的请求），随后自动安全关闭对话框（Esc→取消按钮，
         * 绝不点击确认/保存/删除等最终确认）。
         */
        private String dialogButtonKeywords =
                "新增,添加,新建,创建,删除,移除,编辑,修改,更新,重命名,上传,导入,add,create,delete,remove,edit,update,upload,import,rename";
        /**
         * 下载类按钮文本关键词（逗号分隔）——导出/下载等：
         * 真实执行下载并记录下载文件名与来源 URL。
         */
        private String downloadButtonKeywords = "导出,下载,export,download";
        /** 页面元素解析结果保存上限（超出截断；按钮类元素优先保留，链接/疑似可点击靠后） */
        private int maxElementsRecorded = 150;

        // ---- 通用 DOM 增量探测 ----
        /**
         * 页面稳定期复扫等待毫秒数：初始扫描后等待异步渲染（懒加载/定时脚本/延迟组件）
         * 再复扫一次，「新展现」元素并入本轮巡检的初始计划；0 = 禁用稳定期复扫。
         */
        private int domStableRescanMs = 800;
        /**
         * 每页悬停探测配额：ALL 模式下对 cursor:pointer 疑似可点击元素执行 hover
         * 探测（悬停展开菜单）的上限；0 = 禁用悬停探测。
         */
        private int maxHoverProbesPerPage = 10;
        /**
         * 原生下拉框逐项选择探测的选项上限：逐个选择 option 触发 change 级联渲染探测；
         * 0 = 禁用下拉框逐项探测。
         */
        private int maxSelectOptionsProbe = 8;

        // ---- 认证 ----
        /** MANUAL/SSO 手动登录最长等待秒数 */
        private int manualLoginTimeoutSec = 300;
        /** 登录状态缓存有效时长（分钟），过期后重新登录；0 = 永不过期（文件存在即复用） */
        private int loginStateTtlMin = 480;

        public int getMaxPages() { return maxPages; }
        public void setMaxPages(int maxPages) { this.maxPages = maxPages; }
        public int getMaxDepth() { return maxDepth; }
        public void setMaxDepth(int maxDepth) { this.maxDepth = maxDepth; }
        public boolean isSitemapDiscovery() { return sitemapDiscovery; }
        public void setSitemapDiscovery(boolean sitemapDiscovery) { this.sitemapDiscovery = sitemapDiscovery; }
        public int getConsoleErrorsMax() { return consoleErrorsMax; }
        public void setConsoleErrorsMax(int consoleErrorsMax) { this.consoleErrorsMax = consoleErrorsMax; }
        public int getJsErrorsMax() { return jsErrorsMax; }
        public void setJsErrorsMax(int jsErrorsMax) { this.jsErrorsMax = jsErrorsMax; }
        public int getFailedRequestsMax() { return failedRequestsMax; }
        public void setFailedRequestsMax(int failedRequestsMax) { this.failedRequestsMax = failedRequestsMax; }
        public int getLoadTimeoutMs() { return loadTimeoutMs; }
        public void setLoadTimeoutMs(int loadTimeoutMs) { this.loadTimeoutMs = loadTimeoutMs; }
        public int getNetworkIdleWaitMs() { return networkIdleWaitMs; }
        public void setNetworkIdleWaitMs(int networkIdleWaitMs) { this.networkIdleWaitMs = networkIdleWaitMs; }
        public String getErrorKeywords() { return errorKeywords; }
        public void setErrorKeywords(String errorKeywords) { this.errorKeywords = errorKeywords; }
        public boolean isEnableActions() { return enableActions; }
        public void setEnableActions(boolean enableActions) { this.enableActions = enableActions; }
        public String getActionMode() { return actionMode; }
        public void setActionMode(String actionMode) { this.actionMode = actionMode; }
        public int getMaxActionsPerPage() { return maxActionsPerPage; }
        public void setMaxActionsPerPage(int maxActionsPerPage) { this.maxActionsPerPage = maxActionsPerPage; }
        public int getActionNetworkIdleWaitMs() { return actionNetworkIdleWaitMs; }
        public void setActionNetworkIdleWaitMs(int actionNetworkIdleWaitMs) { this.actionNetworkIdleWaitMs = actionNetworkIdleWaitMs; }
        public String getQueryButtonKeywords() { return queryButtonKeywords; }
        public void setQueryButtonKeywords(String queryButtonKeywords) { this.queryButtonKeywords = queryButtonKeywords; }
        public String getExcludedButtonKeywords() { return excludedButtonKeywords; }
        public void setExcludedButtonKeywords(String excludedButtonKeywords) { this.excludedButtonKeywords = excludedButtonKeywords; }
        public String getDialogButtonKeywords() { return dialogButtonKeywords; }
        public void setDialogButtonKeywords(String dialogButtonKeywords) { this.dialogButtonKeywords = dialogButtonKeywords; }
        public String getDownloadButtonKeywords() { return downloadButtonKeywords; }
        public void setDownloadButtonKeywords(String downloadButtonKeywords) { this.downloadButtonKeywords = downloadButtonKeywords; }
        public int getMaxElementsRecorded() { return maxElementsRecorded; }
        public void setMaxElementsRecorded(int maxElementsRecorded) { this.maxElementsRecorded = maxElementsRecorded; }
        public int getDomStableRescanMs() { return domStableRescanMs; }
        public void setDomStableRescanMs(int domStableRescanMs) { this.domStableRescanMs = domStableRescanMs; }
        public int getMaxHoverProbesPerPage() { return maxHoverProbesPerPage; }
        public void setMaxHoverProbesPerPage(int maxHoverProbesPerPage) { this.maxHoverProbesPerPage = maxHoverProbesPerPage; }
        public int getMaxSelectOptionsProbe() { return maxSelectOptionsProbe; }
        public void setMaxSelectOptionsProbe(int maxSelectOptionsProbe) { this.maxSelectOptionsProbe = maxSelectOptionsProbe; }
        public int getManualLoginTimeoutSec() { return manualLoginTimeoutSec; }
        public void setManualLoginTimeoutSec(int manualLoginTimeoutSec) { this.manualLoginTimeoutSec = manualLoginTimeoutSec; }
        public int getLoginStateTtlMin() { return loginStateTtlMin; }
        public void setLoginStateTtlMin(int loginStateTtlMin) { this.loginStateTtlMin = loginStateTtlMin; }
    }

    public static class Evidence {
        /** WARN 页面是否也保存截图与上下文 */
        private boolean includeWarn = true;
        /** 上下文 JSON 中保留的 console 日志条数 */
        private int consoleTail = 50;
        /** 失败请求响应体截取字节数 */
        private int responseSnippetBytes = 2048;

        public boolean isIncludeWarn() { return includeWarn; }
        public void setIncludeWarn(boolean includeWarn) { this.includeWarn = includeWarn; }
        public int getConsoleTail() { return consoleTail; }
        public void setConsoleTail(int consoleTail) { this.consoleTail = consoleTail; }
        public int getResponseSnippetBytes() { return responseSnippetBytes; }
        public void setResponseSnippetBytes(int responseSnippetBytes) { this.responseSnippetBytes = responseSnippetBytes; }
    }

    public String getExcelPath() { return excelPath; }
    public void setExcelPath(String excelPath) { this.excelPath = excelPath; }
    public String getOutputDir() { return outputDir; }
    public void setOutputDir(String outputDir) { this.outputDir = outputDir; }
    public String getLoginStateDir() { return loginStateDir; }
    public void setLoginStateDir(String loginStateDir) { this.loginStateDir = loginStateDir; }
    public boolean isStrictExit() { return strictExit; }
    public void setStrictExit(boolean strictExit) { this.strictExit = strictExit; }
    public int getMaxParallelSites() { return maxParallelSites; }
    public void setMaxParallelSites(int maxParallelSites) { this.maxParallelSites = maxParallelSites; }
    public Browser getBrowser() { return browser; }
    public Defaults getDefaults() { return defaults; }
    public Evidence getEvidence() { return evidence; }
}
