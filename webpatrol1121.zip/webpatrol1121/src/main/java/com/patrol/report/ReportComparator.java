package com.patrol.report;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.patrol.model.ActionInspection;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.ReportComparison;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * 上次巡检报告对比分析器：在 output-dir 下定位最近一次（排除本次）的 patrol-result.json，
 * 对相同站点/页面/动作/错误逐项对比，产出变化明细，供报告展示「与上次的差异」。
 */
public class ReportComparator {

    private static final Logger log = LoggerFactory.getLogger(ReportComparator.class);
    private static final Pattern DIR_TS = Pattern.compile("patrol-(\\d{8}-\\d{6})");
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    /** 巡检耗时变化超过该阈值（毫秒）才单独成行，避免大报告刷屏 */
    private static final long PATROL_MS_REPORT_THRESHOLD = 1000;

    /**
     * 定位最近一次巡检报告（排除本次目录），读取为 PatrolReport；无可用历史报告返回 null。
     */
    public static PatrolReport loadLatestPrevious(Path outputDir, Path currentDir) {
        if (outputDir == null || !Files.isDirectory(outputDir)) return null;
        try (Stream<Path> children = Files.list(outputDir)) {
            Optional<Path> latest = children
                    .filter(Files::isDirectory)
                    .filter(d -> d.getFileName() != null
                            && DIR_TS.matcher(d.getFileName().toString()).find()
                            && !d.equals(currentDir)
                            && Files.exists(d.resolve("patrol-result.json")))
                    .max(Comparator.comparing(d -> dirTimestamp(d)));
            if (latest.isEmpty()) {
                log.debug("没有可对比的历史报告（目录 {}）", outputDir);
                return null;
            }
            PatrolReport previous = MAPPER.readValue(
                    latest.get().resolve("patrol-result.json").toFile(), PatrolReport.class);
            log.info("已定位上次巡检报告用于对比: {}", latest.get().getFileName());
            return previous;
        } catch (Exception e) {
            log.warn("读取上次报告失败，跳过对比: {}", e.getMessage());
            return null;
        }
    }

    private static String dirTimestamp(Path dir) {
        Matcher m = DIR_TS.matcher(dir.getFileName().toString());
        return m.find() ? m.group(1) : "";
    }

    /** 对比本次与上次报告，产出变化明细 */
    public static ReportComparison compare(PatrolReport current, PatrolReport previous) {
        List<ReportComparison.ChangeRow> rows = new ArrayList<>();
        Map<String, SiteInspection> prevSites = bySite(previous);
        Set<String> prevNames = prevSites.keySet();
        Set<String> curNames = new LinkedHashSet<>();
        for (SiteInspection s : current.sites()) curNames.add(s.siteName());

        // 新增 / 消失站点
        for (String name : curNames) {
            if (!prevNames.contains(name)) {
                rows.add(row("站点", name, "", "站点", "无", "本次新增", "新增站点"));
            }
        }
        for (String name : prevNames) {
            if (!curNames.contains(name)) {
                rows.add(row("站点", name, "", "站点", "上次存在", "本次未巡检", "恢复站点"));
            }
        }

        for (SiteInspection cur : current.sites()) {
            SiteInspection prev = prevSites.get(cur.siteName());
            if (prev == null) continue;
            compareSite(prev, cur, rows);
        }
        return new ReportComparison(true, previous.startedAt() + " ~ " + previous.finishedAt(),
                previous.startedAt(), rows);
    }

    private static void compareSite(SiteInspection prev, SiteInspection cur,
                                    List<ReportComparison.ChangeRow> rows) {
        String name = cur.siteName();
        // 站点结论变化
        if (prev.verdict() != cur.verdict()) {
            rows.add(row("站点", name, "", "站点结论", prev.verdict().name(), cur.verdict().name(),
                    worse(cur.verdict(), prev.verdict()) ? "新增问题" : "恢复改善"));
        }
        // 站点耗时变化
        long dPrev = prev.durationMs();
        long dCur = cur.durationMs();
        if (dPrev >= 0 && dCur >= 0 && Math.abs(dCur - dPrev) >= PATROL_MS_REPORT_THRESHOLD) {
            rows.add(row("站点", name, "", "站点总耗时", ms(dPrev), ms(dCur), "耗时变化"));
        }

        Map<String, PageInspection> prevPages = byUrl(prev.pages());
        Map<String, PageInspection> curPages = byUrl(cur.pages());
        // 新增 / 消失页面
        for (Map.Entry<String, PageInspection> e : curPages.entrySet()) {
            if (!prevPages.containsKey(e.getKey())) {
                rows.add(row("页面", name, e.getKey(), "页面", "无", e.getValue().verdict().name(),
                        "新增页面"));
            }
        }
        for (Map.Entry<String, PageInspection> e : prevPages.entrySet()) {
            if (!curPages.containsKey(e.getKey())) {
                rows.add(row("页面", name, e.getKey(), "页面", e.getValue().verdict().name(),
                        "本次未巡检到", "恢复页面"));
            }
        }
        // 同页面对比
        Map<String, ActionInspection> prevFailedActions = failedActions(prev.pages());
        Map<String, ActionInspection> curFailedActions = failedActions(cur.pages());
        for (Map.Entry<String, PageInspection> e : curPages.entrySet()) {
            PageInspection pp = prevPages.get(e.getKey());
            if (pp == null) continue;
            comparePage(name, pp, e.getValue(), rows);
        }
        // 失败动作变化（以 页面URL#动作描述 为键）
        for (String key : curFailedActions.keySet()) {
            if (!prevFailedActions.containsKey(key)) {
                ActionInspection a = curFailedActions.get(key);
                int sharp = key.indexOf('#');
                rows.add(row("动作", name, key.substring(0, sharp), "失败动作", "上次未失败",
                        a.description() + " [" + a.verdict().name() + "]", "新增失败动作"));
            }
        }
        for (String key : prevFailedActions.keySet()) {
            if (!curFailedActions.containsKey(key)) {
                ActionInspection a = prevFailedActions.get(key);
                int sharp = key.indexOf('#');
                rows.add(row("动作", name, key.substring(0, sharp), "失败动作",
                        a.description() + " [" + a.verdict().name() + "]",
                        curPages.containsKey(key.substring(0, sharp)) ? "本次通过/未执行" : "页面本次未巡检",
                        "恢复动作"));
            }
        }
    }

    private static void comparePage(String site, PageInspection prev, PageInspection cur,
                                    List<ReportComparison.ChangeRow> rows) {
        String url = cur.url();
        // 页面结论变化
        if (prev.verdict() != cur.verdict()) {
            rows.add(row("页面", site, url, "页面结论", prev.verdict().name(), cur.verdict().name(),
                    worse(cur.verdict(), prev.verdict()) ? "新增问题" : "恢复改善"));
        }
        // 错误数量变化（console / JS / 失败请求）
        errorChange("console错误", prev.consoleErrorCount(), cur.consoleErrorCount(), site, url, rows);
        errorChange("JS异常", prev.jsErrorCount(), cur.jsErrorCount(), site, url, rows);
        errorChange("失败请求", prev.failedRequestCount(), cur.failedRequestCount(), site, url, rows);
        // 巡检耗时变化
        if (Math.abs(cur.patrolMs() - prev.patrolMs()) >= PATROL_MS_REPORT_THRESHOLD) {
            rows.add(row("页面", site, url, "巡检耗时", ms(prev.patrolMs()), ms(cur.patrolMs()), "耗时变化"));
        }
    }

    private static void errorChange(String label, long prevCount, long curCount,
                                    String site, String url, List<ReportComparison.ChangeRow> rows) {
        if (prevCount == curCount) return;
        String change = curCount > prevCount ? "新增问题" : "恢复改善";
        rows.add(row("错误", site, url, label,
                String.valueOf(prevCount), String.valueOf(curCount), change));
    }

    private static boolean worse(Verdict cur, Verdict prev) {
        return cur.ordinal() > prev.ordinal();
    }

    private static Map<String, SiteInspection> bySite(PatrolReport report) {
        Map<String, SiteInspection> out = new LinkedHashMap<>();
        for (SiteInspection s : report.sites()) out.put(s.siteName(), s);
        return out;
    }

    private static Map<String, PageInspection> byUrl(List<PageInspection> pages) {
        Map<String, PageInspection> out = new LinkedHashMap<>();
        if (pages == null) return out;
        for (PageInspection p : pages) out.put(p.url(), p);
        return out;
    }

    private static Map<String, ActionInspection> failedActions(List<PageInspection> pages) {
        Map<String, ActionInspection> out = new LinkedHashMap<>();
        if (pages == null) return out;
        for (PageInspection p : pages) {
            if (p.actions() == null) continue;
            for (ActionInspection a : p.actions()) {
                if (a.verdict() == Verdict.FAIL) {
                    out.put(p.url() + "#" + a.description(), a);
                }
            }
        }
        return out;
    }

    private static ReportComparison.ChangeRow row(String category, String site, String page,
                                                 String item, String previous, String current,
                                                 String change) {
        return new ReportComparison.ChangeRow(category, site, page == null ? "" : page,
                item, previous, current, change);
    }

    private static String ms(long v) {
        return v < 0 ? "-" : (v / 1000.0) + "s";
    }
}
