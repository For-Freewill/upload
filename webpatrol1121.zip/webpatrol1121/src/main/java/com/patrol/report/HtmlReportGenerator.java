package com.patrol.report;

import com.patrol.model.ApiCallRecord;
import com.patrol.model.ConsoleRecord;
import com.patrol.model.IssueRecord;
import com.patrol.model.PageInspection;
import com.patrol.model.PatrolReport;
import com.patrol.model.ReportComparison;
import com.patrol.model.RequestRecord;
import com.patrol.model.SiteInspection;
import com.patrol.model.Verdict;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * HTML 可视化巡检报告：总览卡片 + 站点章节 + 页面明细表 + 问题详情 + 截图证据链接。
 */
@Component
public class HtmlReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(HtmlReportGenerator.class);

    public void generate(PatrolReport report, Path file) {
        generate(report, null, file);
    }

    /** @param comparison 与上次报告的对比分析（可为 null：无历史报告时不渲染对比章节） */
    public void generate(PatrolReport report, ReportComparison comparison, Path file) {
        StringBuilder html = new StringBuilder(64 * 1024);
        html.append("<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-8\">")
            .append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
            .append("<title>前端巡检报告</title><style>")
            .append(css())
            .append("</style></head><body>");

        html.append("<div class=\"header\"><h1>🔍 前端巡检报告</h1>")
            .append("<div class=\"meta\">巡检窗口: ").append(esc(report.startedAt())).append(" ~ ")
            .append(esc(report.finishedAt()))
            .append(" &nbsp;|&nbsp; 配置: ").append(esc(report.excelConfigPath()))
            .append(" &nbsp;|&nbsp; 浏览器: ").append(esc(report.browserInfo())).append("</div></div>");

        // 总览卡片
        var sum = report.summary();
        html.append("<div class=\"cards\">");
        card(html, String.valueOf(sum.totalSites()), "站点", "blue");
        card(html, String.valueOf(sum.passSites()), "通过站点", "green");
        card(html, String.valueOf(sum.warnSites()), "警告站点", "orange");
        card(html, String.valueOf(sum.failSites()), "失败站点", "red");
        card(html, String.valueOf(sum.totalPages()), "巡检页面", "blue");
        card(html, String.valueOf(sum.failPages()), "异常页面", "red");
        card(html, String.valueOf(sum.totalConsoleErrors()), "Console错误", "red");
        card(html, String.valueOf(sum.totalJsErrors()), "JS异常", "red");
        card(html, String.valueOf(sum.totalFailedRequests()), "失败请求", "red");
        card(html, String.valueOf(sum.totalActions()), "执行动作", "blue");
        card(html, String.valueOf(sum.failedActions()), "失败动作", "red");
        long apiTotal = report.sites().stream().mapToLong(s -> s.apiCallList().size()).sum();
        long apiFailed = report.sites().stream().mapToLong(com.patrol.model.SiteInspection::failedApiCalls).sum();
        card(html, String.valueOf(apiTotal), "业务API请求", "blue");
        card(html, String.valueOf(apiFailed), "API失败", "red");
        html.append("</div>");

        // 站点导航
        html.append("<nav class=\"toc\"><b>站点目录：</b> ");
        int idx = 1;
        for (SiteInspection s : report.sites()) {
            html.append("<a href=\"#site-").append(idx).append("\">")
                .append(idx).append(". ").append(esc(s.siteName()))
                .append(" <span class=\"badge ").append(badgeClass(s.verdict())).append("\">")
                .append(s.verdict().name()).append("</span></a> ");
            idx++;
        }
        html.append(" <a href=\"#api-section\">🌐 API 请求明细</a>");
        html.append("</nav>");

        // 站点章节
        idx = 1;
        for (SiteInspection s : report.sites()) {
            siteSection(html, s, idx++);
        }

        // 与上次巡检对比
        if (comparison != null && comparison.available()) {
            comparisonSection(html, comparison);
        }

        // 前端 API 请求明细（报告最尾部单独展示：站点级业务请求统计 + curl 一键复现）
        apiSection(html, report);

        html.append("<footer>frontend-patrol v1.0.0 · Excel 驱动 · Spring Boot 4 / Java 17 / Playwright")
            .append(" &nbsp;·&nbsp; <a href=\"../index.html\">📚 历次巡检索引</a></footer>");
        html.append(curlScript());
        html.append("</body></html>");

        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                out.write(html.toString().getBytes(StandardCharsets.UTF_8));
            }
            log.info("HTML 报告已生成: {}", file);
        } catch (Exception e) {
            log.error("HTML 报告写入失败: {}", e.getMessage(), e);
        }
    }

    private void siteSection(StringBuilder html, SiteInspection s, int idx) {
        html.append("<section id=\"site-").append(idx).append("\">")
            .append("<h2>").append(idx).append(". ").append(esc(s.siteName()))
            .append(" <span class=\"badge ").append(badgeClass(s.verdict())).append("\">")
            .append(s.verdict().name()).append("</span></h2>")
            .append("<div class=\"site-meta\">入口: <code>").append(esc(s.entryUrl())).append("</code>")
            .append(" &nbsp;|&nbsp; 认证: ").append(esc(s.authType()))
            .append(" &nbsp;|&nbsp; 页面: ").append(s.pagesVisited())
            .append("（PASS ").append(s.passPages()).append(" / WARN ").append(s.warnPages())
            .append(" / FAIL ").append(s.failPages()).append("）")
            .append(" &nbsp;|&nbsp; 发现链接: ").append(s.linksFound())
            .append(" &nbsp;|&nbsp; 动作: ").append(s.totalActions())
            .append("（失败 ").append(s.failedActions()).append("）")
            .append(" &nbsp;|&nbsp; 站点耗时: <b>").append(fmtMs(s.durationMs())).append("</b>")
            .append("</div>");
        if (s.errorMessage() != null) {
            html.append("<div class=\"site-error\">站点级错误: ").append(esc(s.errorMessage())).append("</div>");
        }
        // 站点与子页面耗时列表
        html.append("<details class=\"tree\"><summary>⏱️ 巡检耗时（站点总耗时 ")
            .append(fmtMs(s.durationMs())).append("，子页面合计 ")
            .append(fmtMs(s.pagePatrolMs())).append("）</summary>")
            .append("<table><tr><th>页面</th><th>深度</th><th>加载耗时</th><th>巡检耗时</th><th>动作数</th><th>结论</th></tr>");
        for (PageInspection p : s.pages()) {
            html.append("<tr><td class=\"wrap\"><code>").append(esc(shortUrl(p.url()))).append("</code></td>")
                .append("<td>").append(p.depth()).append("</td>")
                .append("<td>").append(fmtMs(p.loadMs())).append("</td>")
                .append("<td><b>").append(fmtMs(p.patrolMs())).append("</b></td>")
                .append("<td>").append(p.actionCount()).append("</td>")
                .append("<td><span class=\"badge ").append(badgeClass(p.verdict())).append("\">")
                .append(p.verdict().name()).append("</span></td></tr>");
        }
        html.append("</table></details>");
        // 页面探索结构树（父子关系 + 巡检结论）
        html.append("<details class=\"tree\"><summary>🗺️ 页面探索结构（")
            .append(s.pagesVisited()).append(" 页，按深度缩放展示父子关系）</summary><ul class=\"tree-list\">");
        for (PageInspection p : s.pages()) {
            html.append("<li style=\"margin-left:").append(Math.min(p.depth(), 6) * 22).append("px\">");
            if (p.depth() > 0) html.append("<span class=\"muted\">└─</span> ");
            html.append("<span class=\"badge ").append(badgeClass(p.verdict())).append("\">")
                .append(p.verdict().name()).append("</span> <code>").append(esc(shortUrl(p.url())))
                .append("</code>");
            if (p.parentUrl() != null) {
                html.append(" <span class=\"muted\">← 来自 ").append(esc(shortUrl(p.parentUrl()))).append("</span>");
            }
            html.append("</li>");
        }
        html.append("</ul></details>");
        for (PageInspection p : s.pages()) {
            pageBlock(html, p);
        }
        html.append("</section>");
    }

    private static String shortUrl(String url) {
        if (url == null) return "";
        int p = url.indexOf('/', url.indexOf("//") + 2);
        return p < 0 ? url : url.substring(p);
    }

    private void pageBlock(StringBuilder html, PageInspection p) {
        html.append("<details class=\"page ").append(detailsOpen(p)).append("\">")
            .append("<summary>")
            .append("<span class=\"badge ").append(badgeClass(p.verdict())).append("\">")
            .append(p.verdict().name()).append("</span> ")
            .append("<code>").append(esc(p.url())).append("</code>")
            .append(p.title() != null ? " — " + esc(truncate(p.title(), 60)) : "")
            .append(" <span class=\"muted\">[").append(p.mainStatus()).append(" · ")
            .append(p.loadMs()).append("ms · depth ").append(p.depth());
        if (p.parentUrl() != null) {
            html.append(" · ← ").append(esc(shortUrl(p.parentUrl())));
        }
        html.append("]</span>")
            .append("</summary><div class=\"page-body\">");

        // 问题清单
        if (!p.issues().isEmpty()) {
            html.append("<table class=\"kv\"><tr><th>问题</th></tr>");
            for (IssueRecord ir : p.issues()) {
                html.append("<tr><td class=\"").append(badgeClass(ir.severity())).append("-text\">")
                    .append("[<b>").append(ir.severity().name()).append("</b>] ")
                    .append(esc(ir.type().label())).append(" — ").append(esc(ir.message()))
                    .append("</td></tr>");
            }
            html.append("</table>");
        }

        // 失败请求
        var failed = p.requests().stream().filter(RequestRecord::isFailed).toList();
        if (!failed.isEmpty()) {
            html.append("<h4>失败请求（").append(failed.size()).append("）</h4><table>")
                .append("<tr><th>URL</th><th>方法</th><th>类型</th><th>状态</th><th>原因</th><th>耗时</th></tr>");
            for (RequestRecord r : failed) {
                html.append("<tr><td class=\"wrap\"><code>").append(esc(truncate(r.url(), 120))).append("</code></td>")
                    .append("<td>").append(r.method()).append("</td><td>").append(esc(r.resourceType())).append("</td>")
                    .append("<td class=\"red-text\">").append(r.status()).append("</td>")
                    .append("<td>").append(esc(r.failureText() == null ? "-" : r.failureText())).append("</td>")
                    .append("<td>").append(r.durationMs()).append("ms</td></tr>");
            }
            html.append("</table>");
        }

        // JS 异常
        if (!p.jsErrors().isEmpty()) {
            html.append("<h4>JS 未捕获异常（").append(p.jsErrors().size()).append("）</h4><ul class=\"mono\">");
            for (String e : p.jsErrors()) {
                html.append("<li>").append(esc(e)).append("</li>");
            }
            html.append("</ul>");
        }

        // Console 错误
        var consoleErr = p.consoleLogs().stream().filter(ConsoleRecord::isError).toList();
        if (!consoleErr.isEmpty()) {
            html.append("<h4>Console 错误（").append(consoleErr.size()).append("）</h4><ul class=\"mono\">");
            for (ConsoleRecord c : consoleErr) {
                html.append("<li>").append(esc(truncate(c.text(), 300)))
                    .append(" <span class=\"muted\">").append(esc(c.location() == null ? "" : c.location()))
                    .append("</span></li>");
            }
            html.append("</ul>");
        }

        // 功能动作明细
        if (p.actions() != null && !p.actions().isEmpty()) {
            html.append("<h4>功能动作（").append(p.actions().size())
                .append("，失败 ").append(p.failedActionCount()).append("）</h4>");
            for (var a : p.actions()) {
                html.append("<details class=\"action ").append(a.verdict() == Verdict.PASS ? "" : "open").append("\">")
                    .append("<summary><span class=\"badge ").append(badgeClass(a.verdict())).append("\">")
                    .append(a.verdict().name()).append("</span> ")
                    .append(esc(a.description()))
                    .append(" <span class=\"cat-badge\">").append(esc(a.buttonCategory() == null ? "" : a.buttonCategory())).append("</span>")
                    .append(" <span class=\"muted\">[触发请求 ").append(a.requests() == null ? 0 : a.requests().size())
                    .append(" · 失败 ").append(a.failedRequestCount())
                    .append(" · console错误 ").append(a.consoleErrorCount())
                    .append(" · JS异常 ").append(a.jsErrorCount())
                    .append(a.navigatedAway() ? " · 已跳转页面" : "")
                    .append(a.skipped() ? " · 已跳过(不可交互)" : "")
                    .append(a.downloads() == null || a.downloads().isEmpty() ? ""
                            : " · 下载 " + a.downloads().size())
                    .append("]</span></summary><div class=\"page-body\">");
                if (a.errorMessage() != null) {
                    html.append("<div class=\"site-error\">动作异常: ").append(esc(truncate(a.errorMessage(), 300))).append("</div>");
                }
                if (a.downloads() != null && !a.downloads().isEmpty()) {
                    html.append("<ul class=\"evidence\">");
                    for (String dl : a.downloads()) {
                        html.append("<li>下载: ").append(esc(truncate(dl, 300))).append("</li>");
                    }
                    html.append("</ul>");
                }
                var actionFailed = a.requests() == null ? List.<RequestRecord>of()
                        : a.requests().stream().filter(RequestRecord::isFailed).toList();
                if (!actionFailed.isEmpty()) {
                    html.append("<table><tr><th>URL</th><th>方法</th><th>状态</th><th>原因</th><th>耗时</th></tr>");
                    for (RequestRecord r : actionFailed) {
                        html.append("<tr><td class=\"wrap\"><code>").append(esc(truncate(r.url(), 120))).append("</code></td>")
                            .append("<td>").append(r.method()).append("</td>")
                            .append("<td class=\"red-text\">").append(r.status()).append("</td>")
                            .append("<td>").append(esc(r.failureText() == null ? "-" : r.failureText())).append("</td>")
                            .append("<td>").append(r.durationMs()).append("ms</td></tr>");
                    }
                    html.append("</table>");
                }
                var actionConsoleErr = a.consoleLogs() == null ? List.<ConsoleRecord>of()
                        : a.consoleLogs().stream().filter(ConsoleRecord::isError).toList();
                if (!actionConsoleErr.isEmpty() || !a.jsErrors().isEmpty()) {
                    html.append("<ul class=\"mono\">");
                    for (String e : a.jsErrors()) {
                        html.append("<li class=\"red-text\">JS异常: ").append(esc(truncate(e, 300))).append("</li>");
                    }
                    for (ConsoleRecord c : actionConsoleErr) {
                        html.append("<li>").append(esc(truncate(c.text(), 300)))
                            .append(" <span class=\"muted\">").append(esc(c.location() == null ? "" : c.location()))
                            .append("</span></li>");
                    }
                    html.append("</ul>");
                }
                if (a.screenshotPath() != null) {
                    html.append("<div class=\"evidence\">📷 动作截图: <a href=\"").append(esc(a.screenshotPath()))
                        .append("\" target=\"_blank\">").append(esc(a.screenshotPath())).append("</a></div>");
                }
                html.append("</div></details>");
            }
        }

        // 页面解析元素（可点击元素台账：含类别、链接地址与处理决策）
        if (p.elements() != null && !p.elements().isEmpty()) {
            html.append("<details class=\"elements\"><summary><span class=\"muted\">解析到 ")
                .append(p.elements().size()).append(" 个可点击元素（含按钮/链接/图片链接/onclick/疑似可点击，点击展开）</span></summary><ul class=\"mono\">");
            for (var el : p.elements()) {
                html.append("<li>&lt;").append(esc(el.tag())).append("&gt; ")
                    .append("<span class=\"kind-badge\">").append(esc(el.kindLabel())).append("</span> ")
                    .append(esc(el.text().isBlank() ? "(无文本)" : el.text()));
                if (!el.id().isBlank()) html.append(" <span class=\"muted\">#").append(esc(el.id())).append("</span>");
                if (!el.type().isBlank()) html.append(" <span class=\"muted\">type=").append(esc(el.type())).append("</span>");
                if (!el.href().isBlank()) html.append(" <span class=\"muted\">").append(esc(truncate(el.href(), 70))).append("</span>");
                html.append(" <span class=\"dec-badge ").append(decisionClass(el.decision())).append("\">")
                    .append(esc(el.decision() == null || el.decision().isBlank() ? "未记录" : el.decision()))
                    .append("</span></li>");
            }
            html.append("</ul></details>");
        }

        // 子页面链接（页面探索过程记录）
        if (p.childLinks() != null && !p.childLinks().isEmpty()) {
            html.append("<details class=\"elements\"><summary><span class=\"muted\">子页面链接 ")
                .append(p.childLinks().size()).append(" 个（其中 ")
                .append(p.exploredChildCount()).append(" 个已巡检，点击展开）</span></summary><ul class=\"mono\">");
            for (var l : p.childLinks()) {
                html.append("<li>");
                if (l.explored()) {
                    html.append("<span class=\"badge ").append(badgeClass(l.childVerdict())).append("\">")
                        .append(l.childVerdict() == null ? "已巡检" : l.childVerdict().name()).append("</span> ");
                } else {
                    html.append("<span class=\"dec-badge dec-muted\">未巡检</span> ");
                }
                html.append(esc(l.text().isBlank() ? "(无锚文本)" : l.text()))
                    .append(" → <code>").append(esc(shortUrl(l.url()))).append("</code></li>");
            }
            html.append("</ul></details>");
        }

        // 证据链接
        if (p.screenshotPath() != null) {
            html.append("<div class=\"evidence\">📷 截图: <a href=\"").append(esc(p.screenshotPath()))
                .append("\" target=\"_blank\">").append(esc(p.screenshotPath())).append("</a>")
                .append(" &nbsp; 📄 上下文: <a href=\"").append(esc(p.contextPath() == null ? "" : p.contextPath()))
                .append("\" target=\"_blank\">").append(esc(p.contextPath() == null ? "-" : p.contextPath()))
                .append("</a></div>");
        }
        html.append("</div></details>");
    }

    private static String detailsOpen(PageInspection p) {
        return p.verdict() == Verdict.PASS ? "" : "open";
    }

    /** 毫秒人性化（<1s 显示 ms，≥1s 显示 x.x s） */
    private static String fmtMs(long ms) {
        if (ms < 0) return "-";
        return ms < 1000 ? ms + "ms" : String.format("%.1fs", ms / 1000.0);
    }

    /** 与上次巡检对比章节：变化类型徽标配色 */
    private static String comparisonChangeClass(String change) {
        if (change == null) return "dec-muted";
        if (change.startsWith("新增")) return "dec-excluded";   // 新增问题类（红系）
        if (change.startsWith("恢复")) return "dec-clicked";     // 恢复改善类（绿系）
        return "dec-muted";                                       // 耗时变化/站点变化等中性
    }

    private void comparisonSection(StringBuilder html, ReportComparison comparison) {
        html.append("<section id=\"comparison\"><h2>📊 与上次巡检对比</h2>")
            .append("<div class=\"site-meta\">对比基线: ")
            .append(esc(comparison.previousReport() == null ? "-" : comparison.previousReport()))
            .append(" &nbsp;|&nbsp; 新增问题类变化 <b class=\"fail-text\">").append(comparison.newIssueCount())
            .append("</b> 项 &nbsp;|&nbsp; 恢复改善类变化 <b class=\"pass-text\" style=\"color:#15803d\">")
            .append(comparison.recoveredCount()).append("</b> 项");
        if (comparison.rows().isEmpty()) {
            html.append("<div class=\"site-meta\" style=\"margin-top:8px\">✔ 与上次巡检相比无站点/页面/动作/错误变化</div></section>");
            return;
        }
        html.append("</div><table><tr><th>变化</th><th>类别</th><th>站点</th><th>页面</th><th>对比项</th>")
            .append("<th>上次</th><th>本次</th></tr>");
        for (ReportComparison.ChangeRow r : comparison.rows()) {
            html.append("<tr><td><span class=\"dec-badge ").append(comparisonChangeClass(r.change()))
                .append("\">").append(esc(nz(r.change()))).append("</span></td>")
                .append("<td>").append(esc(nz(r.category()))).append("</td>")
                .append("<td>").append(esc(nz(r.site()))).append("</td>")
                .append("<td class=\"wrap\"><code>").append(esc(shortUrl(nz(r.page())))).append("</code></td>")
                .append("<td>").append(esc(nz(r.item()))).append("</td>")
                .append("<td>").append(esc(nz(r.previous()))).append("</td>")
                .append("<td><b>").append(esc(nz(r.current()))).append("</b></td></tr>");
        }
        html.append("</table></section>");
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    // ---------------------- 前端 API 请求明细（报告尾部章节） ----------------------

    /**
     * 报告尾部章节：站点级前端业务请求（xhr/fetch）明细统计。
     * <p>每条记录展示「所在页面 / 触发源 / 方法 / URL / 状态 / 耗时」，
     * 展开后含请求头、请求体、响应体与标准 curl 复现命令；
     * 「⚡ 复现 curl」按钮一键展开并复制 curl，可直接复现该请求。</p>
     */
    private void apiSection(StringBuilder html, PatrolReport report) {
        long apiTotal = report.sites().stream().mapToLong(s -> s.apiCallList().size()).sum();
        html.append("<section id=\"api-section\"><h2>🌐 前端 API 请求明细</h2>")
            .append("<div class=\"site-meta\">仅统计前端发起的业务请求（xhr / fetch），")
            .append("已过滤图片、视频、脚本、样式等非业务资源请求，共 <b>").append(apiTotal)
            .append("</b> 条。记录维度：所在页面(pageUrl) / 发起页面(triggerUrl) / 触发源 / ")
            .append("方法 / 请求URL / 资源类型 / 状态 / 响应体 / 耗时 / 请求头与请求体 / 失败信息。</div>");
        for (SiteInspection s : report.sites()) {
            apiSiteBlock(html, s);
        }
        html.append("</section>");
    }

    /** 站点级 API 统计块：总数 / 失败 / 慢请求 / 平均耗时 + 逐条明细（默认折叠） */
    private void apiSiteBlock(StringBuilder html, SiteInspection s) {
        List<ApiCallRecord> calls = s.apiCallList();
        if (calls.isEmpty()) return;
        long failed = s.failedApiCalls();
        long slow = calls.stream().filter(c -> c.durationMs() > 1_000).count();
        long known = calls.stream().filter(c -> c.durationMs() >= 0).count();
        long avg = known == 0 ? 0
                : calls.stream().filter(c -> c.durationMs() >= 0).mapToLong(ApiCallRecord::durationMs).sum() / known;
        html.append("<h3 style=\"margin:14px 0 6px;font-size:15px\">").append(esc(s.siteName()))
            .append(" <span class=\"badge ").append(badgeClass(s.verdict())).append("\">")
            .append(s.verdict().name()).append("</span>")
            .append(" <span class=\"muted\">API ").append(calls.size())
            .append(" 条 · 失败 ").append(failed)
            .append(" · 慢请求(&gt;1s) ").append(slow)
            .append(" · 平均耗时 ").append(avg).append("ms</span></h3>")
            .append("<details class=\"api-tree\"><summary>点击展开 ")
            .append(calls.size()).append(" 条 API 请求明细</summary>");
        for (ApiCallRecord c : calls) {
            apiCallBlock(html, c);
        }
        html.append("</details>");
    }

    /** 单条 API 记录：概要行（方法徽标 + URL + 状态 + 耗时 + curl 按钮），展开显示请求/响应详情 */
    private void apiCallBlock(StringBuilder html, ApiCallRecord c) {
        String statusText = c.status() < 0 ? "无响应(" + c.status() + ")" : String.valueOf(c.status());
        String statusClass = c.isFailed() ? "red-text" : "pass-text";
        html.append("<details class=\"api-item\"><summary>")
            .append("<span class=\"m-badge ").append(methodClass(c.method())).append("\">")
            .append(esc(nz(c.method()))).append("</span> ")
            .append("<code>").append(esc(truncate(nz(c.url()), 110))).append("</code> ")
            .append("<span class=\"").append(statusClass).append("\">[").append(statusText).append("]</span> ")
            .append("<span class=\"muted\">").append(c.durationMs()).append("ms · ")
            .append(esc(shortUrl(nz(c.pageUrl())))).append(" · ").append(esc(nz(c.source())));
        if (c.failureText() != null) {
            html.append(" · <span class=\"red-text\">").append(esc(truncate(c.failureText(), 80))).append("</span>");
        }
        html.append("</span> ")
            .append("<button class=\"curl-btn\" type=\"button\" data-curl=\"")
            .append(esc(c.toCurlOneLine())).append("\" onclick=\"event.preventDefault();event.stopPropagation();copyCurl(this)\">⚡ 复现 curl</button>")
            .append("</summary><div class=\"api-body\">");
        // 归因信息
        html.append("<table class=\"kv\"><tr><td><b>发起页面(triggerUrl)</b>: <code>")
            .append(esc(nz(c.triggerUrl())))
            .append("</code></td></tr>");
        if (c.failureText() != null) {
            html.append("<tr><td class=\"red-text\"><b>失败信息</b>: ").append(esc(c.failureText())).append("</td></tr>");
        }
        html.append("</table>");
        // 请求头
        if (c.requestHeaders() != null && !c.requestHeaders().isEmpty()) {
            html.append("<h4>请求头（").append(c.requestHeaders().size()).append("）</h4><ul class=\"mono\">");
            for (var e : c.requestHeaders().entrySet()) {
                html.append("<li>").append(esc(e.getKey())).append(": ")
                        .append(esc(truncate(nz(e.getValue()), 200))).append("</li>");
            }
            html.append("</ul>");
        }
        // 请求体
        if (c.requestBody() != null && !c.requestBody().isBlank()) {
            html.append("<h4>请求体</h4><pre class=\"api-pre\">").append(esc(c.requestBody())).append("</pre>");
        }
        // 响应体
        if (c.responseBody() != null && !c.responseBody().isBlank()) {
            html.append("<h4>响应体</h4><pre class=\"api-pre\">").append(esc(c.responseBody())).append("</pre>");
        }
        // curl 复现命令（点击按钮展开显示 + 复制）
        html.append("<div class=\"curl-wrap\"><button class=\"curl-btn\" type=\"button\" data-curl=\"")
            .append(esc(c.toCurlOneLine())).append("\" onclick=\"copyCurl(this)\">⚡ 展开并复制 curl 命令</button>")
            .append("<pre class=\"api-pre curl-out\">").append(esc(c.toCurl())).append("</pre></div>")
            .append("</div></details>");
    }

    private static String methodClass(String method) {
        if (method == null) return "m-get";
        return switch (method.toUpperCase(java.util.Locale.ROOT)) {
            case "POST" -> "m-post";
            case "PUT", "PATCH" -> "m-put";
            case "DELETE" -> "m-delete";
            default -> "m-get";
        };
    }

    /** curl 复现按钮的交互脚本：展开命令 + 复制到剪贴板（file:// 打开时回落 execCommand） */
    private static String curlScript() {
        return """
                <script>
                function copyCurl(btn){
                  var curl = btn.getAttribute('data-curl');
                  var box = btn.closest('details') || btn.parentElement;
                  var out = box ? box.querySelector('.curl-out') : null;
                  if (out) out.style.display = 'block';
                  var ok = false;
                  try {
                    if (navigator.clipboard && window.isSecureContext) {
                      navigator.clipboard.writeText(curl); ok = true;
                    }
                  } catch (e) {}
                  if (!ok) {
                    try {
                      var ta = document.createElement('textarea');
                      ta.value = curl; ta.style.position='fixed'; ta.style.opacity='0';
                      document.body.appendChild(ta); ta.select();
                      ok = document.execCommand('copy');
                      document.body.removeChild(ta);
                    } catch (e) {}
                  }
                  var old = btn.textContent;
                  btn.textContent = ok ? '✓ 已复制到剪贴板' : '已展开（请手动复制）';
                  setTimeout(function(){ btn.textContent = old; }, 2000);
                }
                </script>
                """;
    }

    private static void card(StringBuilder html, String value, String label, String color) {
        html.append("<div class=\"card ").append(color).append("\"><div class=\"num\">")
            .append(value).append("</div><div class=\"lbl\">").append(label).append("</div></div>");
    }

    private static String badgeClass(Verdict v) {
        return switch (v) {
            case FAIL -> "fail";
            case WARN -> "warn";
            default -> "pass";
        };
    }

    /** 按钮处理决策徽标的配色 */
    private static String decisionClass(String decision) {
        if (decision == null) return "dec-muted";
        if (decision.startsWith("已点击·弹窗")) return "dec-dialog";
        if (decision.startsWith("已点击·下载")) return "dec-download";
        if (decision.startsWith("已点击")) return "dec-clicked";
        if (decision.startsWith("确认类")) return "dec-excluded";
        return "dec-muted";
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private static String css() {
        return """
                body{font-family:"Segoe UI","Microsoft YaHei",sans-serif;background:#f5f7fa;color:#26333f;margin:0;padding:24px;}
                .header{background:linear-gradient(135deg,#1f6feb,#4f8ff7);color:#fff;padding:24px 28px;border-radius:12px;}
                .header h1{margin:0 0 6px;font-size:24px;}
                .meta{opacity:.92;font-size:13px;}
                .cards{display:flex;flex-wrap:wrap;gap:12px;margin:20px 0;}
                .card{background:#fff;border-radius:10px;padding:14px 20px;min-width:110px;box-shadow:0 1px 4px rgba(0,0,0,.08);border-top:4px solid #ccc;}
                .card .num{font-size:26px;font-weight:700;}
                .card .lbl{font-size:12px;color:#5a6b7b;}
                .card.blue{border-top-color:#3b82f6;} .card.green{border-top-color:#22c55e;}
                .card.orange{border-top-color:#f59e0b;} .card.red{border-top-color:#ef4444;}
                .toc{background:#fff;border-radius:10px;padding:10px 16px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.06);}
                .toc a{margin-right:12px;text-decoration:none;color:#1f6feb;}
                section{background:#fff;border-radius:12px;padding:18px 22px;margin-bottom:18px;box-shadow:0 1px 4px rgba(0,0,0,.07);}
                h2{margin:0 0 8px;font-size:19px;color:#1f2937;}
                .site-meta{font-size:13px;color:#5a6b7b;margin-bottom:12px;}
                .site-error{background:#fef2f2;border-left:4px solid #ef4444;color:#b91c1c;padding:8px 12px;border-radius:6px;font-size:13px;}
                .badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;}
                .badge.pass{background:#dcfce7;color:#15803d;} .badge.warn{background:#fef3c7;color:#b45309;}
                .badge.fail{background:#fee2e2;color:#b91c1c;}
                details.page{border:1px solid #e5e9f0;border-radius:8px;margin:10px 0;background:#fafbfd;}
                details.page[open]{border-color:#c8d4e0;}
                details.page summary{padding:9px 12px;cursor:pointer;font-size:13px;}
                .page-body{padding:4px 14px 12px;}
                table{border-collapse:collapse;width:100%;font-size:12.5px;margin:6px 0;}
                th,td{border:1px solid #e2e8f0;padding:5px 8px;text-align:left;vertical-align:top;}
                th{background:#eef2f7;font-weight:600;}
                td.wrap{word-break:break-all;max-width:480px;}
                .kv td{border:none;padding:3px 6px;}
                .kv{border:1px solid #e2e8f0;border-radius:6px;}
                h4{margin:10px 0 4px;font-size:13px;color:#374151;}
                ul.mono{margin:4px 0;padding-left:18px;font-size:12px;max-height:200px;overflow:auto;background:#f8fafc;border-radius:6px;padding:8px 8px 8px 24px;}
                ul.mono li{font-family:Consolas,monospace;margin-bottom:3px;word-break:break-all;}
                .muted{color:#8a99a8;font-size:11.5px;}
                .red-text{color:#dc2626;font-weight:600;}
                .fail-text{color:#b91c1c;} .warn-text{color:#b45309;}
                .evidence{margin-top:8px;font-size:13px;}
                .evidence a{color:#1f6feb;}
                details.action{border:1px solid #dbe4ee;border-radius:6px;margin:6px 0;background:#fff;}
                details.action summary{padding:6px 10px;cursor:pointer;font-size:12.5px;}
                .cat-badge{display:inline-block;background:#e0e7ff;color:#3730a3;border-radius:4px;padding:1px 6px;font-size:11px;margin-left:4px;}
                .dec-badge{display:inline-block;border-radius:4px;padding:1px 6px;font-size:11px;margin-left:6px;}
                .kind-badge{display:inline-block;border-radius:3px;padding:0 5px;font-size:10.5px;background:#e0eaff;color:#3b5b9c;margin-right:2px;}
                .dec-clicked{background:#dcfce7;color:#15803d;} .dec-dialog{background:#ede9fe;color:#6d28d9;}
                .dec-download{background:#cffafe;color:#0e7490;} .dec-excluded{background:#fee2e2;color:#b91c1c;}
                .dec-muted{background:#f1f5f9;color:#64748b;}
                details.tree{border:1px dashed #c8d4e0;border-radius:8px;margin:8px 0 12px;padding:6px 12px;background:#f8fafc;}
                details.tree summary{cursor:pointer;font-size:13px;color:#374151;}
                ul.tree-list{margin:6px 0 4px;padding-left:8px;list-style:none;font-size:12.5px;}
                ul.tree-list li{margin:3px 0;word-break:break-all;}
                details.elements{margin:8px 0 0;font-size:12px;}
                details.elements summary{cursor:pointer;color:#5a6b7b;}
                .pass-text{color:#15803d;font-weight:600;}
                .m-badge{display:inline-block;border-radius:4px;padding:1px 8px;font-size:11px;font-weight:700;
                    font-family:Consolas,monospace;margin-right:2px;}
                .m-get{background:#dbeafe;color:#1d4ed8;} .m-post{background:#dcfce7;color:#15803d;}
                .m-put{background:#fef3c7;color:#b45309;} .m-delete{background:#fee2e2;color:#b91c1c;}
                details.api-tree{border:1px dashed #c8d4e0;border-radius:8px;margin:8px 0 12px;padding:6px 12px;background:#f8fafc;}
                details.api-tree summary{cursor:pointer;font-size:13px;color:#374151;}
                details.api-item{border:1px solid #e2e8f0;border-radius:6px;margin:6px 0;background:#fff;}
                details.api-item summary{padding:6px 10px;cursor:pointer;font-size:12px;word-break:break-all;list-style:none;}
                details.api-item summary::before{content:"▸";color:#8a99a8;margin-right:5px;}
                details.api-item[open] summary::before{content:"▾";}
                .api-body{padding:4px 12px 12px;}
                .api-pre{background:#0f172a;color:#e2e8f0;border-radius:6px;padding:10px 12px;font-family:Consolas,monospace;
                    font-size:12px;overflow:auto;max-height:260px;white-space:pre-wrap;word-break:break-all;margin:6px 0;}
                .curl-btn{background:#1f6feb;color:#fff;border:none;border-radius:5px;padding:3px 10px;font-size:11.5px;
                    cursor:pointer;margin-left:8px;}
                .curl-btn:hover{background:#3b82f6;}
                .curl-out{display:none;}
                .curl-wrap{margin-top:6px;}
                footer{text-align:center;color:#8a99a8;font-size:12px;margin-top:8px;}
                """;
    }
}
