package com.e2e.framework.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * 文件路径解析器 —— 统一处理工程根目录相对路径与绝对路径。
 *
 * <p>解析规则：
 * <ul>
 *   <li>绝对路径（如 {@code C:/Users/xxx/test.txt} 或 {@code /usr/local/test.txt}）→ 原样使用</li>
 *   <li>相对路径（如 {@code test-output/test.txt}）→ 基于工程根目录（user.dir）解析</li>
 *   <li>支持正则文件名批量匹配（{@code pattern} 字段）</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public final class FilePathResolver {

    private static final Logger log = LoggerFactory.getLogger(FilePathResolver.class);

    private FilePathResolver() {
    }

    /**
     * 解析文件路径。
     * <p>绝对路径原样返回；相对路径基于工程根目录（user.dir）解析。
     */
    public static Path resolve(String pathStr) {
        if (pathStr == null || pathStr.isBlank()) {
            throw new IllegalArgumentException("文件路径不能为空");
        }
        Path path = Paths.get(pathStr);
        if (path.isAbsolute()) {
            log.debug("文件路径(绝对): {}", path.toAbsolutePath());
            return path;
        }
        // 相对路径 → 基于工程根目录解析
        Path resolved = Paths.get(System.getProperty("user.dir")).resolve(path);
        log.debug("文件路径(相对→工程根): {} → {}", pathStr, resolved.toAbsolutePath());
        return resolved;
    }

    /**
     * 按正则模式匹配目录下的文件。
     *
     * @param dirPath 目录路径（相对或绝对）
     * @param pattern 文件名正则表达式（如 "e2e-.*\\.txt"）
     * @param recursive 是否递归子目录
     * @return 匹配的文件列表
     */
    public static List<Path> matchFiles(String dirPath, String pattern, boolean recursive) {
        Path dir = resolve(dirPath);
        if (!Files.isDirectory(dir)) {
            log.warn("目录不存在: {}", dir.toAbsolutePath());
            return List.of();
        }
        Pattern regex = Pattern.compile(pattern);
        List<Path> matched = new ArrayList<>();
        try (Stream<Path> stream = recursive ? Files.walk(dir) : Files.list(dir)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> regex.matcher(p.getFileName().toString()).matches())
                    .forEach(matched::add);
        } catch (IOException e) {
            log.warn("文件匹配异常: {} - {}", dirPath, e.getMessage());
        }
        return matched;
    }

    /**
     * 判断路径是否为绝对路径。
     */
    public static boolean isAbsolute(String pathStr) {
        return pathStr != null && Paths.get(pathStr).isAbsolute();
    }

    /**
     * 获取工程根目录。
     */
    public static String projectRoot() {
        return System.getProperty("user.dir");
    }
}
