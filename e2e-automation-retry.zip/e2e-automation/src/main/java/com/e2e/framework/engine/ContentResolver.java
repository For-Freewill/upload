package com.e2e.framework.engine;

import com.alibaba.fastjson2.JSON;
import com.e2e.framework.core.FilePathResolver;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.protocol.DbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 断言内容解析器 —— 从各数据源加载「实际值」（AssertionEngine 的内容加载职责拆分）。
 *
 * <p>职责边界：只负责<b>取数与路径求值</b>，不做操作符评估（见 {@link OperatorEvaluator}）。
 *
 * <p>支持的来源（source）与取数逻辑：
 * <ul>
 *   <li>{@code DB} —— 按 target SQL 直查（FIELD 列选择 / ROW 整行 JSON），回写 DB/DB_ROWS 输出</li>
 *   <li>{@code FILE} —— 按 FIELD 提取 content/lineCount/size/exists</li>
 *   <li>{@code JSONPATH} / {@code XPATH} / {@code XML} —— 显式路径断言
 *       （FROM 输出变量 / FILE 文件 / 常见默认键）</li>
 *   <li>其他 source —— outputs 取值（大小写不敏感）+ target 前缀自动路由：
 *       {@code $.} 走 JSONPath、{@code //} 走 XPath</li>
 * </ul>
 *
 * <p>Map 模式行加载：{@link #loadActualRows}（DB 多行 / outputs List&lt;Map&gt;）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class ContentResolver {

    private static final Logger log = LoggerFactory.getLogger(ContentResolver.class);

    /** 常见内容输出键（显式路径断言缺省 FROM 时依次尝试） */
    private static final String[] COMMON_CONTENT_KEYS = {"body", "HTTP_BODY", "firstMessage", "STDOUT"};

    // ===================== 字符串模式：加载实际值 =====================

    public List<String> loadActual(AssertionRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        if ("DB".equalsIgnoreCase(rule.getSource())) {
            DbClient db = ctx.clients().db();
            List<Map<String, Object>> rows = db.query(rule.getTarget());
            List<String> actual = new ArrayList<>();
            String field = rule.getField();
            boolean isRowMode = field != null && (field.equals("*") || field.equalsIgnoreCase("ROW"));
            for (Map<String, Object> row : rows) {
                if (row.isEmpty()) continue;
                if (isRowMode) {
                    actual.add(JSON.toJSONString(row));
                } else if (field != null && !field.isBlank()) {
                    Object val = getCaseInsensitive(row, field);
                    actual.add(val == null ? null : String.valueOf(val));
                } else {
                    Object first = row.values().iterator().next();
                    actual.add(first == null ? null : String.valueOf(first));
                }
            }
            outputs.putIfAbsent("DB", rows);
            outputs.putIfAbsent("DB_ROWS", rows);
            return actual;
        }
        // FILE 断言：读取文件内容/行数/大小/存在性
        if ("FILE".equalsIgnoreCase(rule.getSource())) {
            return loadFileActual(rule, outputs);
        }
        // 显式 JSONPath 断言：{"JSONPATH":"$.data.status","FROM":"body","OP":"EQ",...}
        if ("JSONPATH".equalsIgnoreCase(rule.getSource())) {
            String content = resolvePathContent(rule, outputs);
            return content == null ? new ArrayList<>() : evalJsonPath(rule.getTarget(), content);
        }
        // 显式 XPath 断言：{"XPATH":"//Order/Status","FROM":"firstMessage","OP":"EQ",...}（XML 为别名）
        if ("XPATH".equalsIgnoreCase(rule.getSource()) || "XML".equalsIgnoreCase(rule.getSource())) {
            String content = resolvePathContent(rule, outputs);
            return content == null ? new ArrayList<>() : evalXPath(rule.getTarget(), content);
        }
        Object value = getOutputCaseInsensitive(outputs, rule.getSource());

        // JSONPath 自动路由：target 以 $. 开头
        String target = rule.getTarget();
        if (value != null && target != null && target.startsWith("$.")) {
            return evalJsonPath(target, String.valueOf(value));
        }
        // XPath 自动路由：target 以 / 或 // 开头
        if (value != null && target != null && (target.startsWith("//") || target.startsWith("/"))
                && !target.startsWith("/\\") && target.length() > 1) {
            return evalXPath(target, String.valueOf(value));
        }

        List<String> actual = new ArrayList<>();
        if (value == null) return actual;
        if (value instanceof List<?> list) {
            for (Object o : list) {
                actual.add(o == null ? null : String.valueOf(o));
            }
        } else {
            actual.add(String.valueOf(value));
        }
        return actual;
    }

    // ===================== Map 模式：加载实际行 =====================

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> loadActualRows(AssertionRule rule, Map<String, Object> outputs,
                                                     ScenarioExecutionContext ctx) {
        if ("DB".equalsIgnoreCase(rule.getSource())) {
            DbClient db = ctx.clients().db();
            List<Map<String, Object>> rows = db.query(rule.getTarget());
            outputs.putIfAbsent("DB", rows);
            outputs.putIfAbsent("DB_ROWS", rows);
            return rows;
        }
        // 非 DB 来源：尝试从 outputs 获取 List<Map>
        Object value = getOutputCaseInsensitive(outputs, rule.getSource());
        if (value instanceof List<?> list) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object o : list) {
                if (o instanceof Map<?, ?> map) {
                    result.add((Map<String, Object>) map);
                }
            }
            return result;
        }
        return List.of();
    }

    // ===================== FILE 断言 =====================

    /**
     * FILE 断言 —— 读取文件并提取指定字段。
     * <p>target = 文件路径，field = 提取字段（content/lineCount/size/exists/lines）。
     */
    private List<String> loadFileActual(AssertionRule rule, Map<String, Object> outputs) {
        String filePath = rule.getTarget();
        String field = rule.getField() == null || rule.getField().isBlank()
                ? "content" : rule.getField().toLowerCase();
        List<String> actual = new ArrayList<>();

        if (filePath == null || filePath.isBlank()) {
            log.warn("    FILE 断言缺少文件路径");
            return actual;
        }

        try {
            Path path = FilePathResolver.resolve(filePath);
            log.debug("    FILE 断言路径: {} -> {}", filePath, path.toAbsolutePath());
            switch (field) {
                case "exists" -> {
                    actual.add(String.valueOf(Files.exists(path)));
                    outputs.put("FILE_EXISTS", Files.exists(path));
                }
                case "linecount", "lines" -> {
                    if (Files.exists(path)) {
                        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
                        actual.add(String.valueOf(lines.size()));
                        outputs.put("FILE_LINES", lines);
                        outputs.put("FILE_LINE_COUNT", lines.size());
                    } else {
                        actual.add("0");
                    }
                }
                case "size" -> {
                    if (Files.exists(path)) {
                        long size = Files.size(path);
                        actual.add(String.valueOf(size));
                        outputs.put("FILE_SIZE", size);
                    } else {
                        actual.add("0");
                    }
                }
                case "content", "" -> {
                    if (Files.exists(path)) {
                        String content = Files.readString(path, StandardCharsets.UTF_8);
                        List<String> lines = content.isBlank() ? List.of() : content.lines().toList();
                        // 默认：每行作为一个 actual 值（支持 CONTAINS/EQ 按行匹配）
                        for (String line : lines) {
                            actual.add(line);
                        }
                        // 如果文件只有一行无换行，也要加入
                        if (actual.isEmpty() && !content.isEmpty()) {
                            actual.add(content);
                        }
                        outputs.put("FILE_CONTENT", content);
                        outputs.put("FILE_LINES", lines);
                        outputs.put("FILE_LINE_COUNT", lines.size());
                    }
                }
                default -> {
                    // field 被当作关键词搜索：检查文件内容是否包含该关键词
                    if (Files.exists(path)) {
                        String content = Files.readString(path, StandardCharsets.UTF_8);
                        actual.add(content);
                        outputs.put("FILE_CONTENT", content);
                    }
                }
            }
        } catch (IOException e) {
            log.warn("    FILE 断言读取异常: {} - {}", filePath, e.getMessage());
        }
        return actual;
    }

    // ===================== 显式路径断言：内容定位 =====================

    /**
     * 解析路径断言的内容来源（JSONPATH/XPATH/XML 显式模式使用）。
     * <p>内容定位符（解析层 FROM/FILE，经 field 传递）解析顺序：
     * <ol>
     *   <li>field 匹配输出变量（大小写不敏感）→ 使用该输出值</li>
     *   <li>field 非空但非输出变量 → 按文件路径读取（FilePathResolver）</li>
     *   <li>field 为空 → 依次尝试常见输出键：body / HTTP_BODY / firstMessage / STDOUT</li>
     * </ol>
     */
    private String resolvePathContent(AssertionRule rule, Map<String, Object> outputs) {
        String locator = rule.getField();
        // ① 定位符匹配输出变量
        if (locator != null && !locator.isBlank()) {
            Object v = getOutputCaseInsensitive(outputs, locator);
            if (v != null && !String.valueOf(v).isBlank()) {
                return String.valueOf(v);
            }
            // ② 按文件路径读取
            try {
                Path path = FilePathResolver.resolve(locator);
                if (Files.exists(path)) {
                    return Files.readString(path, StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                log.warn("    路径断言内容文件读取失败: {} - {}", locator, e.getMessage());
            }
            log.warn("    路径断言内容来源未找到: {}（既非输出变量也非文件）", locator);
            return null;
        }
        // ③ 常见输出键依次尝试
        for (String key : COMMON_CONTENT_KEYS) {
            Object v = getOutputCaseInsensitive(outputs, key);
            if (v != null && !String.valueOf(v).isBlank()) {
                return String.valueOf(v);
            }
        }
        return null;
    }

    // ===================== 路径求值引擎 =====================

    /**
     * JSONPath 求值（com.jayway.jsonpath）。
     * <p>路径如 {@code $.data.status} / {@code $.items[0].name} / {@code $..orderId}。
     */
    private List<String> evalJsonPath(String jsonPath, String json) {
        List<String> actual = new ArrayList<>();
        try {
            Object result = com.jayway.jsonpath.JsonPath.read(json, jsonPath);
            if (result instanceof List<?> list) {
                for (Object o : list) {
                    actual.add(o == null ? null : String.valueOf(o));
                }
            } else if (result != null) {
                actual.add(String.valueOf(result));
            }
            log.debug("    JSONPath {} -> {}", jsonPath, actual);
        } catch (Exception e) {
            log.warn("    JSONPath 求值失败: {} - {}", jsonPath, e.getMessage());
        }
        return actual;
    }

    /**
     * XPath 求值（JDK 内置 javax.xml.xpath，适用于 XML 报文/HTML，防 XXE 安全配置）。
     * <p>路径如 {@code //Order/Status} / {@code /Order/Items/Item[1]/Sku}。
     */
    private List<String> evalXPath(String xpathExpr, String xml) {
        List<String> actual = new ArrayList<>();
        try {
            var xpathFactory = javax.xml.xpath.XPathFactory.newInstance();
            var xpath = xpathFactory.newXPath();
            var dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            var docBuilder = dbf.newDocumentBuilder();
            var doc = docBuilder.parse(new java.io.ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
            var nodes = (org.w3c.dom.NodeList) xpath.evaluate(xpathExpr, doc, javax.xml.xpath.XPathConstants.NODESET);
            for (int i = 0; i < nodes.getLength(); i++) {
                String text = nodes.item(i).getTextContent();
                actual.add(text == null ? "" : text.trim());
            }
            log.debug("    XPath {} -> {} nodes", xpathExpr, actual.size());
        } catch (Exception e) {
            log.warn("    XPath 求值失败: {} - {}", xpathExpr, e.getMessage());
        }
        return actual;
    }

    // ===================== 工具 =====================

    /** 大小写不敏感的 outputs 取值 */
    Object getOutputCaseInsensitive(Map<String, Object> outputs, String key) {
        Object v = outputs.get(key);
        if (v != null) return v;
        for (var entry : outputs.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue();
        }
        return null;
    }

    /** 大小写不敏感的 Map 取值 */
    Object getCaseInsensitive(Map<String, Object> map, String key) {
        Object val = map.get(key);
        if (val != null) return val;
        for (var entry : map.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue();
        }
        return null;
    }
}
