package com.e2e.framework.bootstrap;

import com.e2e.framework.model.results.ScenarioResult;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 场景执行结果暂存（Runner 写入，套件监听器读取生成报告）。
 *
 * <p>线程安全：使用 Collections.synchronizedMap 包装 LinkedHashMap，
 * 保证 parallel="instances" 场景级并行时并发写入安全，同时保持插入序（= 完成序）。
 * 报告生成时由 E2ESuiteLifecycleListener 按模版定义顺序重新排序。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public final class ResultStore {

    private static final Map<String, ScenarioResult> RESULTS =
            Collections.synchronizedMap(new LinkedHashMap<>());

    private ResultStore() {
    }

    public static void put(ScenarioResult result) {
        RESULTS.put(result.getScenario().getScenarioId(), result);
    }

    public static Collection<ScenarioResult> all() {
        synchronized (RESULTS) {
            return new java.util.ArrayList<>(RESULTS.values());
        }
    }

    public static void clear() {
        RESULTS.clear();
    }
}
