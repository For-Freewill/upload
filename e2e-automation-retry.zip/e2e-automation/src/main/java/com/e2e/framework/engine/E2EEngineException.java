package com.e2e.framework.engine;

/**
 * 执行引擎异常（依赖环、场景编排错误等）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class E2EEngineException extends RuntimeException {
    public E2EEngineException(String message) { super(message); }
}
