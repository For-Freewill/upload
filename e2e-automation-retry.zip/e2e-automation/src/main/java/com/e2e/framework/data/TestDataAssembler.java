package com.e2e.framework.data;

import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.OnFailure;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.TestDataBundle;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 通用装配器：将 Excel / YAML 两种来源统一解析出的「行数据」装配为领域模型。
 *
 * <p>所有数据源共用同一套校验与容错规则，保证行为一致。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class TestDataAssembler {

    private final String source;
    private final boolean strict;

    public TestDataAssembler(String source, boolean strict) {
        this.source = source;
        this.strict = strict;
    }

    /**
     * @param scenarioRows  场景行（键为归一化大写表头，值为字符串）
     * @param stepRows      步骤行
     * @param globalConfig  全局配置键值对
     */
    public TestDataBundle assemble(List<Map<String, String>> scenarioRows,
                                    List<Map<String, String>> stepRows,
                                    Map<String, String> globalConfig) {
        TestDataBundle bundle = new TestDataBundle();

        // 1. 全局配置
        globalConfig.forEach((k, v) -> {
            if (k != null && !k.isBlank()) {
                bundle.getGlobalConfig().put(k.trim(), v == null ? "" : v.trim());
            }
        });

        // 2. 场景
        for (Map<String, String> row : scenarioRows) {
            String scenarioId = value(row, "SCENARIOID", "SCENARIO_ID", "ID");
            if (blank(scenarioId)) {
                recordIssue(bundle, new DataQualityIssue(source, null, null, "Scenario_ID",
                        "Scenarios 表存在空的 Scenario_ID 行: " + row, "跳过该行"));
                continue;
            }
            ScenarioDefinition scenario = new ScenarioDefinition(
                    parseInt(value(row, "SEQ", "SEQNO", "序号"), 0),
                    scenarioId.trim(),
                    value(row, "SCENARIONAME", "NAME"),
                    parseBool(value(row, "ENABLED", "ENBALED"), true),
                    splitList(value(row, "TAGS")),
                    value(row, "ENV"),
                    parseInt(value(row, "TIMEOUT"), 1800),
                    value(row, "DESCRIPTION"),
                    value(row, "OWNER"));
            bundle.getScenarios().put(scenario.getScenarioId(), scenario);
        }

        // 3. 步骤
        for (Map<String, String> row : stepRows) {
            String scenarioId = value(row, "SCENARIOID", "SCENARIO_ID");
            String stepId = value(row, "STEPID", "STEP_ID");
            if (blank(scenarioId) || blank(stepId)) {
                recordIssue(bundle, new DataQualityIssue(source, scenarioId, stepId, "Steps",
                        "步骤行缺少 Scenario_ID 或 STEP_ID: " + row, "跳过该行"));
                continue;
            }
            ScenarioDefinition owner = bundle.getScenarios().get(scenarioId.trim());
            if (owner == null) {
                recordIssue(bundle, new DataQualityIssue(source, scenarioId, stepId, "Scenario_ID",
                        "步骤引用的场景不存在（孤儿步骤）", "跳过该行"));
                continue;
            }
            StepDefinition step = new StepDefinition(
                    owner.getScenarioId(),
                    parseInt(value(row, "SEQNO", "SEQ_NO"), owner.getSteps().size() + 1),
                    stepId.trim(),
                    upper(value(row, "APP")),
                    upper(value(row, "ACTION")),
                    splitList(value(row, "DEPENDSON", "DEPENDS_ON")),
                    value(row, "INPUT"),
                    value(row, "ASSERT"),
                    value(row, "EXTRACT"),
                    parseInt(value(row, "TIMEOUT"), 180),
                    parseInt(value(row, "RETRY"), 0),
                    OnFailure.parse(value(row, "ONFAILURE", "ON_FAILURE")),
                    parseBool(value(row, "ENABLED", "ENBALED"), true));

            List<DataQualityIssue> stepIssues = new ArrayList<>();
            step.setInputPayloads(JsonPayloadSanitizer.parseInputPayloads(step.getInputRaw(),
                    scenarioId, stepId, stepIssues));
            step.setAssertRules(JsonPayloadSanitizer.parseAssertRules(step.getAssertRaw(),
                    scenarioId, stepId, stepIssues));
            step.setExtractRules(JsonPayloadSanitizer.parseExtractRules(step.getExtractRaw(),
                    scenarioId, stepId, stepIssues));
            step.setIssues(stepIssues);
            stepIssues.forEach(bundle::merge);
            if (strict && !stepIssues.isEmpty()) {
                throw new E2EDataException("严格模式下步骤数据质量问题终止装载: "
                        + scenarioId + "/" + stepId + " -> " + stepIssues);
            }

            owner.addStep(step);
        }

        // 4. 场景级校验：孤儿场景（无步骤）、重复 stepId
        bundle.getScenarios().values().stream()
                .filter(s -> s.getSteps().isEmpty())
                .forEach(s -> bundle.merge(new DataQualityIssue(source, s.getScenarioId(), null, "Steps",
                        "场景已启用但没有任何步骤（孤儿场景）", "执行时按 SKIP 处理并在报告中标注")));
        for (ScenarioDefinition s : bundle.getScenarios().values()) {
            List<String> seen = new ArrayList<>();
            for (StepDefinition step : s.getSteps()) {
                if (seen.contains(step.getStepId())) {
                    bundle.merge(new DataQualityIssue(source, s.getScenarioId(), step.getStepId(), "STEP_ID",
                            "场景内 STEP_ID 重复", "两个步骤都会执行，但依赖引用存在歧义"));
                }
                seen.add(step.getStepId());
            }
        }

        return bundle;
    }

    // ---------------- 行取值工具 ----------------

    static String value(Map<String, String> row, String... keys) {
        for (String k : keys) {
            String v = row.get(k);
            if (v != null && !v.isBlank()) {
                return v.trim();
            }
        }
        return null;
    }

    static boolean blank(String s) { return s == null || s.isBlank(); }

    static boolean parseBool(String s, boolean defaultValue) {
        if (s == null || s.isBlank()) {
            return defaultValue;
        }
        String v = s.trim().toUpperCase(Locale.ROOT);
        return v.equals("Y") || v.equals("YES") || v.equals("TRUE") || v.equals("1") || v.equals("ON");
    }

    static int parseInt(String s, int defaultValue) {
        if (s == null || s.isBlank()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            try {
                return (int) Double.parseDouble(s.trim()); // Excel 数值单元格可能出现 "1.0"
            } catch (NumberFormatException e2) {
                return defaultValue;
            }
        }
    }

    /** 按 ; 或 , 拆分列表（Tags / DEPENDS_ON），自动清理 JSON 括号 */
    static List<String> splitList(String s) {
        if (s == null || s.isBlank()) {
            return List.of();
        }
        String cleaned = s.trim();
        // 清理 JSON 数组括号："[]" → 空，"[A,B]" → "A,B"
        if (cleaned.startsWith("[")) cleaned = cleaned.substring(1);
        if (cleaned.endsWith("]")) cleaned = cleaned.substring(0, cleaned.length() - 1);
        cleaned = cleaned.replace("，", ",").replace("；", ";").trim();
        if (cleaned.isEmpty()) {
            return List.of();
        }
        List<String> result = new ArrayList<>();
        for (String part : cleaned.split("[;,]")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                result.add(trimmed);
            }
        }
        return result;
    }

    private static String upper(String s) {
        return s == null ? null : s.trim().toUpperCase(Locale.ROOT);
    }

    private void recordIssue(TestDataBundle bundle, DataQualityIssue issue) {
        bundle.merge(issue);
        if (strict) {
            throw new E2EDataException("严格模式下数据质量问题终止装载: " + issue);
        }
    }
}
