package com.e2e.framework.protocol.impl.mq;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.MqClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * MQ 桩实现（demo 模式）：内存队列 —— send 存入报文，consume 取出报文，形成完整收发闭环。
 *
 * <p>live 接入：实现 MqClient（如基于 IBM MQ / RocketMQ 客户端），
 * 并通过 ProtocolClients 或自定义 @ActionSpec 覆盖（见 README 扩展指南）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StubMqClient implements MqClient {

    private static final Logger log = LoggerFactory.getLogger(StubMqClient.class);

    private final String defaultQueue;

    /** 内存队列：queue -> 报文列表 */
    private final Map<String, ConcurrentLinkedDeque<String>> queues = new ConcurrentHashMap<>();

    public StubMqClient(String defaultQueue) {
        this.defaultQueue = defaultQueue;
    }

    @Override
    public void send(Object params, String message) {
        String queue = resolveQueue(params);
        queues.computeIfAbsent(queue, k -> new ConcurrentLinkedDeque<>()).add(message == null ? "" : message);
        log.info("[stub-mq] send to queue='{}' messageBytes={} messageHead={}",
                queue, message == null ? 0 : message.length(), head(message));
    }

    @Override
    public List<String> consume(String queue, int maxMessages, long timeoutMs) {
        String target = (queue == null || queue.isBlank()) ? defaultQueue : queue;
        ConcurrentLinkedDeque<String> deque = queues.get(target);
        List<String> messages = new ArrayList<>();
        if (deque != null) {
            long deadline = System.currentTimeMillis() + timeoutMs;
            while (messages.size() < maxMessages && System.currentTimeMillis() < deadline) {
                String msg = deque.poll();
                if (msg == null) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    continue;
                }
                messages.add(msg);
                log.info("[stub-mq] consumed from queue='{}' messageBytes={}", target, msg.length());
            }
        }
        return messages;
    }

    private String resolveQueue(Object params) {
        if (params instanceof JSONObject jo && jo.containsKey("queue")) {
            String q = jo.getString("queue");
            if (q != null && !q.isBlank()) {
                return q;
            }
        }
        return defaultQueue;
    }

    private static String head(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        String one = s.replaceAll("\\s+", " ");
        return one.length() > 120 ? one.substring(0, 120) + "..." : one;
    }

    @Override
    public String describe() {
        return "stub-mq (demo, queue=" + defaultQueue + ", buffered=" + queues.values().stream().mapToInt(d -> d.size()).sum() + ")";
    }
}
