package com.e2e.framework.protocol;

import java.util.List;
import java.util.Map;

/**
 * MAIL 协议客户端（COMMON_MAIL_ACTIONS 使用）。
 *
 * <p>基于 jakarta.mail（angus-mail 实现）SMTP 发送；收件验证可通过 IMAP 扩展。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface MailClient {

    /** 发送邮件 */
    MailResult send(MailSpec spec);

    String describe();

    /** 邮件规格 */
    class MailSpec {
        private String subject;
        private String body;
        private boolean html = false;             // false=纯文本
        private List<String> to = List.of();
        private List<String> cc = List.of();
        private List<String> attachmentPaths = List.of();

        public String getSubject() { return subject; }
        public void setSubject(String subject) { this.subject = subject; }
        public String getBody() { return body; }
        public void setBody(String body) { this.body = body; }
        public boolean isHtml() { return html; }
        public void setHtml(boolean html) { this.html = html; }
        public List<String> getTo() { return to == null ? List.of() : to; }
        public void setTo(List<String> to) { this.to = to; }
        public List<String> getCc() { return cc == null ? List.of() : cc; }
        public void setCc(List<String> cc) { this.cc = cc; }
        public List<String> getAttachmentPaths() { return attachmentPaths == null ? List.of() : attachmentPaths; }
        public void setAttachmentPaths(List<String> attachmentPaths) { this.attachmentPaths = attachmentPaths; }
    }

    /** 邮件发送结果 */
    class MailResult {
        private boolean success;
        private String message;
        private String messageId;

        public MailResult(boolean success, String message, String messageId) {
            this.success = success;
            this.message = message == null ? "" : message;
            this.messageId = messageId == null ? "" : messageId;
        }

        public static MailResult ok(String message, String messageId) { return new MailResult(true, message, messageId); }
        public static MailResult fail(String message) { return new MailResult(false, message, ""); }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public String getMessageId() { return messageId; }
    }
}
