package com.e2e.framework.actions.ssh;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * DATAHUB 域：COMMON_SFTP_ACTIONS —— SFTP 安全文件传输（基于 JSch ChannelSftp）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 上传（可覆盖连接参数，缺省用 e2e.sftp.* 或复用 e2e.ssh.*）
 * [{"SFTP":{"op":"upload","local":"test-output/report.pdf","remote":"/upload/report.pdf"}}]
 *
 * // 下载
 * [{"SFTP":{"op":"download","remote":"/data/result.csv","local":"test-output/result.csv"}}]
 *
 * // 列目录（支持 pattern 正则过滤）
 * [{"SFTP":{"op":"list","dir":"/upload"}}]
 *
 * // 删除 / 建目录 / 存在检查
 * [{"SFTP":{"op":"delete","remote":"/upload/old.pdf"}}]
 * [{"SFTP":{"op":"mkdir","dir":"/upload/e2e"}}]
 * [{"SFTP":{"op":"exists","remote":"/upload/report.pdf"}}]
 * </pre>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_SFTP_ACTIONS",
            description = "SFTP 安全文件传输：upload/download/list/delete/mkdir/exists")
public class CommonSftpActions implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonSftpActions.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("SFTP");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 SFTP 协议载荷: [{\"SFTP\":{\"op\":\"upload\",\"local\":\"...\",\"remote\":\"...\"}}]");
        }
        String op = p.getString("op");
        if (op == null || op.isBlank()) {
            return ActionResult.fail("SFTP 载荷缺少 op 字段（upload/download/list/delete/mkdir/exists）");
        }

        E2EProperties.Ssh ssh = context.props().getSsh();
        E2EProperties.Sftp sftp = context.props().getSftp();
        // 连接参数：载荷 > sftp 配置 > ssh 配置
        String host = firstNonBlank(p.getString("host"), sftp.getHost(), ssh.getUser() == null ? "" : sftp.getHost());
        if (host == null || host.isBlank()) {
            host = "localhost";
        }
        int port = p.containsKey("port") ? Integer.parseInt(String.valueOf(p.get("port")).trim()) : sftp.getPort();
        String user = firstNonBlank(p.getString("user"), sftp.getUser(), ssh.getUser());
        String password = firstNonBlank(p.getString("password"), sftp.getPassword(), ssh.getPassword());

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("op", op);
        outputs.put("host", host);

        try {
            Session session = null;
            ChannelSftp channel = null;
            try {
                JSch jsch = new JSch();
                session = jsch.getSession(user, host, port);
                session.setPassword(password);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect(15_000);
                channel = (ChannelSftp) session.openChannel("sftp");
                channel.connect(30_000);
                log.info("  SFTP connected {}:{} user={}", host, port, user);

                switch (op.toLowerCase()) {
                    case "upload" -> {
                        String local = p.getString("local");
                        String remote = p.getString("remote");
                        if (local == null || remote == null) return ActionResult.fail("upload 需要 local + remote", outputs);
                        try (InputStream is = Files.newInputStream(Paths.get(local))) {
                            channel.put(is, remote);
                        }
                        outputs.put("success", true);
                        outputs.put("local", local);
                        outputs.put("remote", remote);
                        return ActionResult.ok("SFTP 上传成功: " + local + " -> " + remote, outputs);
                    }
                    case "download" -> {
                        String remote = p.getString("remote");
                        String local = p.getString("local");
                        if (remote == null || local == null) return ActionResult.fail("download 需要 remote + local", outputs);
                        Path localPath = Paths.get(local);
                        if (localPath.getParent() != null) Files.createDirectories(localPath.getParent());
                        try (OutputStream os = Files.newOutputStream(localPath)) {
                            channel.get(remote, os);
                        }
                        outputs.put("success", true);
                        outputs.put("remote", remote);
                        outputs.put("local", local);
                        return ActionResult.ok("SFTP 下载成功: " + remote + " -> " + local, outputs);
                    }
                    case "list" -> {
                        String dir = p.getString("dir");
                        if (dir == null || dir.isBlank()) return ActionResult.fail("list 需要 dir", outputs);
                        String pattern = p.getString("pattern");
                        Vector<ChannelSftp.LsEntry> entries = channel.ls(dir);
                        List<Map<String, Object>> files = new ArrayList<>();
                        for (ChannelSftp.LsEntry e : entries) {
                            String name = e.getFilename();
                            if (name.equals(".") || name.equals("..")) continue;
                            if (pattern != null && !pattern.isBlank() && !name.matches(pattern)) continue;
                            Map<String, Object> row = new LinkedHashMap<>();
                            row.put("name", name);
                            row.put("size", e.getAttrs().getSize());
                            row.put("type", e.getAttrs().isDir() ? "DIR" : "FILE");
                            files.add(row);
                        }
                        outputs.put("files", files);
                        outputs.put("fileCount", files.size());
                        return ActionResult.ok("SFTP 列目录: " + dir + " (" + files.size() + " entries)", outputs);
                    }
                    case "delete" -> {
                        String remote = p.getString("remote");
                        if (remote == null) return ActionResult.fail("delete 需要 remote", outputs);
                        channel.rm(remote);
                        outputs.put("success", true);
                        return ActionResult.ok("SFTP 删除成功: " + remote, outputs);
                    }
                    case "mkdir" -> {
                        String dir = p.getString("dir");
                        if (dir == null) return ActionResult.fail("mkdir 需要 dir", outputs);
                        channel.mkdir(dir);
                        outputs.put("success", true);
                        return ActionResult.ok("SFTP 目录创建: " + dir, outputs);
                    }
                    case "exists" -> {
                        String remote = p.getString("remote");
                        if (remote == null) return ActionResult.fail("exists 需要 remote", outputs);
                        boolean exists = checkExists(channel, remote);
                        outputs.put("exists", exists);
                        return ActionResult.ok("SFTP 存在检查: " + remote + " -> " + exists, outputs);
                    }
                    default -> {
                        return ActionResult.fail("不支持的 SFTP 操作: " + op, outputs);
                    }
                }
            } finally {
                if (channel != null) channel.disconnect();
                if (session != null) session.disconnect();
            }
        } catch (Exception e) {
            log.warn("  SFTP 操作失败: {}", e.getMessage());
            outputs.put("success", false);
            outputs.put("error", e.getMessage());
            return ActionResult.fail("SFTP 操作失败 " + host + ":" + port + ": " + e.getMessage(), outputs);
        }
    }

    private boolean checkExists(ChannelSftp channel, String remote) {
        try {
            channel.ls(remote);
            return true;
        } catch (SftpException e) {
            return false;
        }
    }

    private static String firstNonBlank(String... vals) {
        for (String v : vals) {
            if (v != null && !v.isBlank()) return v;
        }
        return null;
    }
}
