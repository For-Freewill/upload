package com.e2e.framework.protocol;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.ui.UiActionRegistry;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

/**
 * 协议客户端门面 —— 按运行模式（e2e.mode=demo|live）统一装配各协议实现。
 *
 * <ul>
 *   <li>demo：全部使用内置桩，开箱即跑；</li>
 *   <li>live：DB 按 {@code e2e.db.driver} 二选一 ——
 *       jdbc（原生 JDBC PreparedStatement，默认）或 mybatis-plus（SqlSessionFactory 动态 statement），
 *       HTTP 走 REST Assured，SSH 走 JSch，本地命令需 e2e.cmd.allow-local-execution=true；
 *       MQ 仍为桩（接入点见 README）。</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class ProtocolClients {

    private static final Logger log = LoggerFactory.getLogger(ProtocolClients.class);

    private final DbClient db;
    private final MqClient mq;
    private final HttpApiClient http;
    private final SshCommandClient ssh;
    private final LocalCommandClient cmd;
    private final FtpClient ftp;
    private final MailClient mail;
    private final UiActionRegistry uiRegistry;

    public ProtocolClients(E2EProperties props,
                           ObjectProvider<DataSource> dataSource,
                           ObjectProvider<SqlSessionFactory> sqlSessionFactory,
                           UiActionRegistry uiRegistry) {
        this.uiRegistry = uiRegistry;

        boolean liveDb = props.useLiveDb();
        DataSource ds = liveDb ? dataSource.getIfAvailable() : null;
        if (ds != null) {
            if (props.getDb().useMybatisPlus()) {
                SqlSessionFactory factory = sqlSessionFactory.getIfAvailable();
                if (factory != null) {
                    this.db = new com.e2e.framework.protocol.impl.db.MybatisPlusDbClient(factory);
                    log.info("DB 协议: MyBatis-Plus SqlSessionTemplate ({} live, driver=mybatis-plus)",
                            props.getDb().getMode());
                } else {
                    log.warn("e2e.db.driver=mybatis-plus 但 SqlSessionFactory 未装配（starter 未生效？），回退原生 JDBC");
                    this.db = new com.e2e.framework.protocol.impl.db.JdbcDbClient(ds);
                }
            } else {
                this.db = new com.e2e.framework.protocol.impl.db.JdbcDbClient(ds);
                log.info("DB 协议: 原生 JDBC PreparedStatement ({} live, driver=jdbc)", props.getDb().getMode());
            }
        } else {
            if (liveDb) {
                log.warn("e2e.mode=live 但未配置 spring.datasource.*，DB 协议降级为 stub（e2e.db.mode={}）",
                        props.getDb().getMode());
            }
            this.db = new com.e2e.framework.protocol.impl.db.StubDbClient();
        }

        this.mq = new com.e2e.framework.protocol.impl.mq.StubMqClient(props.getMq().getQueue());

        if (props.isDemoMode()) {
            this.http = new com.e2e.framework.protocol.impl.http.StubHttpApiClient();
            this.ssh = new com.e2e.framework.protocol.impl.ssh.StubSshCommandClient();
            this.ftp = new com.e2e.framework.protocol.impl.ftp.StubFtpClient();
            this.mail = new com.e2e.framework.protocol.impl.mail.StubMailClient();
        } else {
            this.http = new com.e2e.framework.protocol.impl.http.RestAssuredHttpApiClient();
            this.ssh = new com.e2e.framework.protocol.impl.ssh.JschSshClient(props.getSsh());
            this.ftp = new com.e2e.framework.protocol.impl.ftp.CommonsNetFtpClient(props.getFtp());
            this.mail = new com.e2e.framework.protocol.impl.mail.JakartaMailClient(props.getMail());
        }
        this.cmd = new com.e2e.framework.protocol.impl.cmd.ProcessBuilderLocalCommandClient(props.getCmd());

        log.info("协议客户端装配: db={}, mq={}, http={}, ssh={}, ftp={}, mail={}, cmd={}, uiHandlers={}",
                db.describe(), mq.describe(), http.describe(), ssh.describe(),
                ftp.describe(), mail.describe(), cmd.describe(), uiRegistry.describe());
    }

    public DbClient db() { return db; }
    public MqClient mq() { return mq; }
    public HttpApiClient http() { return http; }
    public SshCommandClient ssh() { return ssh; }
    public LocalCommandClient cmd() { return cmd; }
    public FtpClient ftp() { return ftp; }
    public MailClient mail() { return mail; }
    public UiActionRegistry ui() { return uiRegistry; }
}
