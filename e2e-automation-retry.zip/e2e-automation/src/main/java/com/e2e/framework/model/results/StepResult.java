package com.e2e.framework.model.results;

import com.e2e.framework.model.StepDefinition;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 单个步骤的执行结果
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StepResult {

    private final StepDefinition step;
    private StepStatus status = StepStatus.PENDING;
    private String message = "";
    private long durationMs;
    private int attempts = 1;
    private Map<String, Object> outputs = new LinkedHashMap<>();
    private String screenshotPath;

    public StepResult(StepDefinition step) { this.step = step; }

    public StepDefinition getStep() { return step; }
    public StepStatus getStatus() { return status; }
    public void setStatus(StepStatus status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message == null ? "" : message; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public int getAttempts() { return attempts; }
    public void setAttempts(int attempts) { this.attempts = attempts; }
    public Map<String, Object> getOutputs() { return outputs == null ? Collections.emptyMap() : outputs; }
    public void setOutputs(Map<String, Object> outputs) { this.outputs = outputs; }
    public String getScreenshotPath() { return screenshotPath; }
    public void setScreenshotPath(String screenshotPath) { this.screenshotPath = screenshotPath; }

    public String summaryLine() {
        return String.format("[%s] %-28s %-22s attempts=%d %5dms %s",
                status, step.getStepId(), step.actionKey(), attempts, durationMs,
                message == null || message.isBlank() ? "" : "- " + firstLine(message));
    }

    private static String firstLine(String msg) {
        int idx = msg.indexOf('\n');
        String line = idx > 0 ? msg.substring(0, idx) : msg;
        return line.length() > 160 ? line.substring(0, 157) + "..." : line;
    }
}
