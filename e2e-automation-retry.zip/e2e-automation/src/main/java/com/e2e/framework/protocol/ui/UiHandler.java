package com.e2e.framework.protocol.ui;

import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * UI 处理器注册注解 —— 标注在 {@link UiAction} 实现类上，
 * value 为 JAVA 载荷中 url 字段引用的注册名（如模版中的 automation.qa.e2e.uiaction1）。
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component

/**
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public @interface UiHandler {

    /** 注册名（同时作为 Spring Bean 名） */
    @AliasFor(annotation = Component.class, attribute = "value")
    String value();

    String description() default "";
}
