package com.e2e.framework.protocol.impl.ftp;

import com.e2e.framework.protocol.FtpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FTP 桩实现（demo 模式）：内存虚拟目录，记录操作日志。
 *
 * <p>upload/download 只记录不真实传输；list 返回虚拟文件列表；
 * 用于 demo 模式跑通全链路（开箱即跑、离线可用）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StubFtpClient implements FtpClient {

    private static final Logger log = LoggerFactory.getLogger(StubFtpClient.class);

    /** 虚拟文件系统：remotePath -> size */
    private final Map<String, Long> virtualFiles = new ConcurrentHashMap<>();

    @Override
    public FtpResult upload(String localPath, String remotePath) {
        log.info("[stub-ftp] upload {} -> {} (simulated)", localPath, remotePath);
        virtualFiles.put(remotePath, 1024L);
        return FtpResult.ok("上传成功(stub): " + localPath + " -> " + remotePath);
    }

    @Override
    public FtpResult download(String remotePath, String localPath) {
        log.info("[stub-ftp] download {} -> {} (simulated)", remotePath, localPath);
        return FtpResult.ok("下载成功(stub): " + remotePath + " -> " + localPath);
    }

    @Override
    public List<Map<String, Object>> list(String remoteDir) {
        log.info("[stub-ftp] list {} (simulated)", remoteDir);
        List<Map<String, Object>> result = new ArrayList<>();
        virtualFiles.forEach((path, size) -> {
            if (path.startsWith(remoteDir)) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("name", path.substring(path.lastIndexOf('/') + 1));
                row.put("size", size);
                row.put("type", "FILE");
                row.put("modifiedTime", System.currentTimeMillis());
                result.add(row);
            }
        });
        return result;
    }

    @Override
    public FtpResult delete(String remotePath) {
        log.info("[stub-ftp] delete {} (simulated)", remotePath);
        virtualFiles.remove(remotePath);
        return FtpResult.ok("删除成功(stub): " + remotePath);
    }

    @Override
    public FtpResult mkdir(String remoteDir) {
        log.info("[stub-ftp] mkdir {} (simulated)", remoteDir);
        return FtpResult.ok("目录创建成功(stub): " + remoteDir);
    }

    @Override
    public boolean exists(String remotePath) {
        boolean exists = virtualFiles.containsKey(remotePath);
        log.info("[stub-ftp] exists {} -> {}", remotePath, exists);
        return exists;
    }

    @Override
    public String describe() {
        return "stub-ftp (demo, files=" + virtualFiles.size() + ")";
    }
}
