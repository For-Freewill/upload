package com.e2e.framework.actions.redis;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DATAHUB 域：COMMON_REDIS_OPERATE —— Redis 缓存操作（验证缓存一致性场景）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // String 操作
 * [{"REDIS":{"op":"set","key":"user:1001","value":"{\"name\":\"张三\"}","ttl":300}}]
 * [{"REDIS":{"op":"get","key":"user:1001"}}]
 * [{"REDIS":{"op":"del","key":"user:1001"}}]
 *
 * // TTL / 存在 / 键扫描
 * [{"REDIS":{"op":"ttl","key":"user:1001"}}]
 * [{"REDIS":{"op":"exists","key":"user:1001"}}]
 * [{"REDIS":{"op":"keys","pattern":"user:*"}}]
 *
 * // Hash / List
 * [{"REDIS":{"op":"hset","key":"session:1001","field":"status","value":"active"}}]
 * [{"REDIS":{"op":"hget","key":"session:1001","field":"status"}}]
 * [{"REDIS":{"op":"lpush","key":"queue:tasks","value":"task-001"}}]
 * [{"REDIS":{"op":"lrange","key":"queue:tasks","start":0,"end":-1}}]
 * </pre>
 *
 * <p>demo 模式：内存模拟（与真实 Redis 语义一致）；live 模式：Jedis 真实连接。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_REDIS_OPERATE",
            description = "Redis 缓存操作：get/set/del/ttl/exists/keys/hset/hget/lpush/lrange")
public class CommonRedisOperateAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonRedisOperateAction.class);

    /** demo 模式内存存储 */
    private static final Map<String, String> MEM_STRING = new ConcurrentHashMap<>();
    private static final Map<String, Map<String, String>> MEM_HASH = new ConcurrentHashMap<>();
    private static final Map<String, List<String>> MEM_LIST = new ConcurrentHashMap<>();
    private static final Map<String, Long> MEM_EXPIRE = new ConcurrentHashMap<>();

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("REDIS");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 REDIS 协议载荷: [{\"REDIS\":{\"op\":\"set\",\"key\":\"...\",\"value\":\"...\"}}]");
        }
        String op = p.getString("op");
        String key = p.getString("key");
        if (op == null || op.isBlank()) return ActionResult.fail("REDIS 载荷缺少 op 字段");
        if (key == null || key.isBlank()) return ActionResult.fail("REDIS 载荷缺少 key 字段");

        boolean demo = context.props().isDemoMode();
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("op", op);
        outputs.put("key", key);

        try {
            if (demo) {
                return executeInMemory(p, op, key, outputs);
            }
            return executeJedis(context, p, op, key, outputs);
        } catch (Exception e) {
            log.warn("  REDIS 操作失败: {}", e.getMessage());
            return ActionResult.fail("Redis 操作失败: " + e.getClass().getSimpleName() + ": " + e.getMessage(), outputs);
        }
    }

    // ===================== demo：内存模拟 =====================

    private ActionResult executeInMemory(JSONObject p, String op, String key, Map<String, Object> outputs) {
        switch (op.toLowerCase()) {
            case "set" -> {
                String value = p.getString("value");
                MEM_STRING.put(key, value == null ? "" : value);
                Integer ttl = p.getInteger("ttl");
                if (ttl != null && ttl > 0) {
                    MEM_EXPIRE.put(key, System.currentTimeMillis() + ttl * 1000L);
                }
                outputs.put("result", "OK");
                log.info("  [redis-stub] SET {} = {} (ttl={})", key, abbreviate(p.getString("value")), ttl);
                return ActionResult.ok("SET " + key + " (stub)", outputs);
            }
            case "get" -> {
                checkExpire(key);
                String value = MEM_STRING.get(key);
                outputs.put("value", value);
                outputs.put("exists", value != null);
                log.info("  [redis-stub] GET {} -> {}", key, abbreviate(value));
                return ActionResult.ok("GET " + key + " -> " + abbreviate(value), outputs);
            }
            case "del" -> {
                boolean removed = MEM_STRING.remove(key) != null | MEM_HASH.remove(key) != null | MEM_LIST.remove(key) != null;
                MEM_EXPIRE.remove(key);
                outputs.put("deleted", removed ? 1 : 0);
                return ActionResult.ok("DEL " + key + " -> " + removed, outputs);
            }
            case "ttl" -> {
                checkExpire(key);
                Long expireAt = MEM_EXPIRE.get(key);
                long ttl = expireAt == null
                        ? (MEM_STRING.containsKey(key) ? -1 : -2)
                        : Math.max(0, (expireAt - System.currentTimeMillis()) / 1000);
                outputs.put("ttl", ttl);
                return ActionResult.ok("TTL " + key + " -> " + ttl, outputs);
            }
            case "exists" -> {
                checkExpire(key);
                boolean exists = MEM_STRING.containsKey(key) || MEM_HASH.containsKey(key) || MEM_LIST.containsKey(key);
                outputs.put("exists", exists);
                return ActionResult.ok("EXISTS " + key + " -> " + exists, outputs);
            }
            case "keys" -> {
                String pattern = p.getString("pattern") == null ? "*" : p.getString("pattern");
                String regex = pattern.replace("*", ".*").replace("?", ".");
                List<String> keys = new ArrayList<>();
                for (String k : MEM_STRING.keySet()) {
                    if (k.matches(regex)) keys.add(k);
                }
                outputs.put("keys", keys);
                outputs.put("keyCount", keys.size());
                return ActionResult.ok("KEYS " + pattern + " -> " + keys.size() + " keys", outputs);
            }
            case "hset" -> {
                String field = p.getString("field");
                String value = p.getString("value");
                MEM_HASH.computeIfAbsent(key, k -> new ConcurrentHashMap<>()).put(field, value);
                outputs.put("result", "OK");
                return ActionResult.ok("HSET " + key + " " + field, outputs);
            }
            case "hget" -> {
                String field = p.getString("field");
                String value = MEM_HASH.getOrDefault(key, Map.of()).get(field);
                outputs.put("value", value);
                return ActionResult.ok("HGET " + key + " " + field + " -> " + abbreviate(value), outputs);
            }
            case "lpush" -> {
                String value = p.getString("value");
                MEM_LIST.computeIfAbsent(key, k -> new ArrayList<>()).add(0, value);
                outputs.put("listSize", MEM_LIST.get(key).size());
                return ActionResult.ok("LPUSH " + key, outputs);
            }
            case "lrange" -> {
                int start = p.getIntValue("start", 0);
                int end = p.getIntValue("end", -1);
                List<String> list = MEM_LIST.getOrDefault(key, List.of());
                int to = end < 0 ? list.size() + end + 1 : end + 1;
                List<String> range = list.subList(Math.max(0, start), Math.min(list.size(), to));
                outputs.put("values", range);
                outputs.put("listSize", range.size());
                return ActionResult.ok("LRANGE " + key + " -> " + range.size() + " items", outputs);
            }
            default -> {
                return ActionResult.fail("不支持的 Redis 操作: " + op, outputs);
            }
        }
    }

    private void checkExpire(String key) {
        Long expireAt = MEM_EXPIRE.get(key);
        if (expireAt != null && System.currentTimeMillis() > expireAt) {
            MEM_STRING.remove(key);
            MEM_EXPIRE.remove(key);
        }
    }

    // ===================== live：Jedis 真实连接 =====================

    private ActionResult executeJedis(ActionContext context, JSONObject p, String op, String key,
                                       Map<String, Object> outputs) {
        var cfg = context.props().getRedis();
        try (Jedis jedis = new Jedis(cfg.getHost(), cfg.getPort())) {
            if (cfg.getPassword() != null && !cfg.getPassword().isBlank()) {
                jedis.auth(cfg.getPassword());
            }
            if (cfg.getDatabase() != 0) {
                jedis.select(cfg.getDatabase());
            }
            switch (op.toLowerCase()) {
                case "set" -> {
                    String value = p.getString("value");
                    Integer ttl = p.getInteger("ttl");
                    if (ttl != null && ttl > 0) jedis.setex(key, ttl, value);
                    else jedis.set(key, value);
                    outputs.put("result", "OK");
                }
                case "get" -> {
                    String value = jedis.get(key);
                    outputs.put("value", value);
                    outputs.put("exists", value != null);
                }
                case "del" -> {
                    long removed = jedis.del(key);
                    outputs.put("deleted", removed);
                }
                case "ttl" -> outputs.put("ttl", jedis.ttl(key));
                case "exists" -> outputs.put("exists", jedis.exists(key));
                case "keys" -> {
                    String pattern = p.getString("pattern") == null ? "*" : p.getString("pattern");
                    var keys = new ArrayList<>(jedis.keys(pattern));
                    outputs.put("keys", keys);
                    outputs.put("keyCount", keys.size());
                }
                case "hset" -> {
                    String field = p.getString("field");
                    String value = p.getString("value");
                    jedis.hset(key, field, value);
                    outputs.put("result", "OK");
                }
                case "hget" -> {
                    String field = p.getString("field");
                    outputs.put("value", jedis.hget(key, field));
                }
                case "lpush" -> {
                    jedis.lpush(key, p.getString("value"));
                    outputs.put("listSize", jedis.llen(key));
                }
                case "lrange" -> {
                    int start = p.getIntValue("start", 0);
                    int end = p.getIntValue("end", -1);
                    outputs.put("values", jedis.lrange(key, start, end));
                }
                default -> {
                    return ActionResult.fail("不支持的 Redis 操作: " + op, outputs);
                }
            }
            log.info("  [redis] {} {} (live {}:{})", op.toUpperCase(), key, cfg.getHost(), cfg.getPort());
            return ActionResult.ok("REDIS " + op.toUpperCase() + " " + key, outputs);
        }
    }

    private static String abbreviate(String s) {
        if (s == null) return "null";
        return s.length() > 60 ? s.substring(0, 60) + "..." : s;
    }
}
