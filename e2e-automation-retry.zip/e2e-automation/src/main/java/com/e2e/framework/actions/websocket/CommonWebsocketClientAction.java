package com.e2e.framework.actions.websocket;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * DATAHUB 域：COMMON_WEBSOCKET_CLIENT —— WebSocket 长连接客户端（推送验证）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 连接并等待接收（连接后监听 timeout 秒内的服务端推送）
 * [{"WS":{"op":"connect","url":"wss://push.example.com/ws","timeout":10}}]
 *
 * // 连接 + 发送消息 + 等待响应
 * [{"WS":{"op":"send","url":"wss://echo.example.com/ws","message":"hello","timeout":5}}]
 * </pre>
 *
 * <p>输出（可断言/EXTRACT）：{@code messages}（收到的消息列表）/ {@code messageCount} / {@code lastMessage}
 * <p>demo 模式：模拟回显（发送即视为收到回显消息）；live 模式：java.net.http.WebSocket 真实连接。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_WEBSOCKET_CLIENT",
            description = "WebSocket 客户端（connect/send + 推送消息接收断言）")
public class CommonWebsocketClientAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonWebsocketClientAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("WS");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 WS 协议载荷: [{\"WS\":{\"op\":\"send\",\"url\":\"wss://...\",\"message\":\"...\",\"timeout\":5}}]");
        }
        String op = p.getString("op");
        String url = p.getString("url");
        if (op == null || op.isBlank()) op = "send";
        if (url == null || url.isBlank()) {
            return ActionResult.fail("WS 载荷缺少 url 字段（wss:// 或 ws://）");
        }
        String message = p.getString("message");
        // timeout 秒（等待服务端推送/响应的时长）
        int timeoutSec = p.containsKey("timeout") ? Integer.parseInt(String.valueOf(p.get("timeout")).trim()) : 10;

        if (context.props().isDemoMode()) {
            return executeDemo(op, url, message, timeoutSec);
        }
        return executeLive(op, url, message, timeoutSec);
    }

    // ===================== demo：模拟回显 =====================

    private ActionResult executeDemo(String op, String url, String message, int timeoutSec) {
        List<String> messages = new ArrayList<>();
        if (message != null && !message.isBlank()) {
            messages.add(message); // 回显语义：发送即收到
        }
        log.info("  [ws-stub] {} url={} message='{}' (simulated echo)", op, url, message);

        var outputs = new java.util.LinkedHashMap<String, Object>();
        outputs.put("connected", true);
        outputs.put("messages", messages);
        outputs.put("messageCount", messages.size());
        outputs.put("lastMessage", messages.isEmpty() ? "" : messages.get(messages.size() - 1));
        return ActionResult.ok("WebSocket " + op + " 完成 (stub 回显, " + messages.size() + " messages)", outputs);
    }

    // ===================== live：java.net.http.WebSocket =====================

    private ActionResult executeLive(String op, String url, String message, int timeoutSec) {
        ConcurrentLinkedDeque<String> received = new ConcurrentLinkedDeque<>();
        AtomicReference<Throwable> error = new AtomicReference<>();

        try {
            HttpClient client = HttpClient.newHttpClient();
            WebSocket.Listener listener = new WebSocket.Listener() {
                final StringBuilder buffer = new StringBuilder();

                @Override
                public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
                    buffer.append(data);
                    if (last) {
                        received.add(buffer.toString());
                        buffer.setLength(0);
                        log.info("  [ws] received: {}", abbreviate(buffer.length() == 0 ? data.toString() : ""));
                    }
                    ws.request(1);
                    return CompletableFuture.completedFuture(null);
                }

                @Override
                public void onError(WebSocket ws, Throwable throwable) {
                    error.set(throwable);
                    log.warn("  [ws] error: {}", throwable.getMessage());
                }
            };

            // ① 连接
            CompletableFuture<WebSocket> wsFuture = client.newWebSocketBuilder()
                    .buildAsync(URI.create(url), listener);
            WebSocket ws = wsFuture.get(15, TimeUnit.SECONDS);
            log.info("  [ws] connected: {}", url);

            try {
                // ② 发送消息（如指定）
                if (message != null && !message.isBlank()) {
                    ws.sendText(message, true).get(10, TimeUnit.SECONDS);
                    log.info("  [ws] sent: {}", abbreviate(message));
                }

                // ③ 等待接收（timeout 秒内收到的全部消息）
                long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
                while (System.currentTimeMillis() < deadline) {
                    Thread.sleep(100);
                }
            } finally {
                ws.sendClose(WebSocket.NORMAL_CLOSURE, "e2e-done");
                ws.abort();
            }

            List<String> messages = new ArrayList<>(received);
            var outputs = new java.util.LinkedHashMap<String, Object>();
            outputs.put("connected", true);
            outputs.put("messages", messages);
            outputs.put("messageCount", messages.size());
            outputs.put("lastMessage", messages.isEmpty() ? "" : messages.get(messages.size() - 1));
            return ActionResult.ok("WebSocket " + op + " 完成 (" + messages.size() + " messages)", outputs);

        } catch (Exception e) {
            Throwable cause = error.get() != null ? error.get() : e;
            return ActionResult.fail("WebSocket 操作失败: " + cause.getClass().getSimpleName() + ": " + cause.getMessage());
        }
    }

    private static String abbreviate(String s) {
        if (s == null) return "";
        return s.length() > 80 ? s.substring(0, 80) + "..." : s;
    }
}
