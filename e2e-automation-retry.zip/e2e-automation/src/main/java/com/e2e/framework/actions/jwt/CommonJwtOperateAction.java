package com.e2e.framework.actions.jwt;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TAP 域：COMMON_JWT_OPERATE —— JWT 生成/解析/校验（认证链路验证）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 生成 JWT（HMAC-SHA256）
 * [{"JWT":{"op":"generate","secret":"my-e2e-secret-key-32bytes!!","subject":"e2e-user",
 *          "claims":{"role":"tester","org":"qa"},"expireSeconds":3600}}]
 *
 * // 解析 JWT（提取 claims）
 * [{"JWT":{"op":"parse","secret":"my-e2e-secret-key-32bytes!!","token":"eyJhbGci..."}}]
 *
 * // 校验 JWT（签名 + 过期）
 * [{"JWT":{"op":"verify","secret":"my-e2e-secret-key-32bytes!!","token":"eyJhbGci..."}}]
 * </pre>
 *
 * <p>输出（可断言/EXTRACT）：
 * <ul>
 *   <li>{@code token} — generate 生成的 JWT（后续步骤 Bearer 引用 ${extract.jwtToken}）</li>
 *   <li>{@code claims} / {@code subject} / {@code expired} — parse 结果</li>
 *   <li>{@code valid} — verify 结果（true/false）</li>
 * </ul>
 * <p>generate 成功后自动执行 {@code ctx.setVar("jwtToken", token)}，后续用 {@code ${extract.jwtToken}}。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"TAP"}, action = "COMMON_JWT_OPERATE",
            description = "JWT 生成/解析/校验（HMAC-SHA256，自动写入 ${extract.jwtToken}）")
public class CommonJwtOperateAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonJwtOperateAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("JWT");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 JWT 协议载荷: [{\"JWT\":{\"op\":\"generate\",\"secret\":\"...\",\"subject\":\"...\"}}]");
        }
        String op = p.getString("op");
        String secret = p.getString("secret");
        if (op == null || op.isBlank()) return ActionResult.fail("JWT 载荷缺少 op 字段（generate/parse/verify）");
        if (secret == null || secret.isBlank()) return ActionResult.fail("JWT 载荷缺少 secret 字段");

        // HMAC-SHA256 密钥（至少 32 字节）
        if (secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            // 自动补齐到 32 字节（测试便利性）
            secret = padSecret(secret);
        }
        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> outputs = new LinkedHashMap<>();
        try {
            switch (op.toLowerCase()) {
                case "generate" -> {
                    String subject = p.getString("subject");
                    JSONObject claims = p.getJSONObject("claims");
                    long expireSeconds = p.getLongValue("expireSeconds", 3600);

                    var builder = Jwts.builder()
                            .subject(subject == null ? "e2e" : subject)
                            .issuedAt(new Date())
                            .expiration(new Date(System.currentTimeMillis() + expireSeconds * 1000));
                    if (claims != null) {
                        claims.forEach(builder::claim);
                    }
                    String token = builder.signWith(key).compact();

                    outputs.put("token", token);
                    outputs.put("expireSeconds", expireSeconds);
                    // 自动写入场景变量
                    context.setVar("jwtToken", token);
                    log.info("  JWT generate subject={} expire={}s（已写入 ${{extract.jwtToken}}）", subject, expireSeconds);
                    return ActionResult.ok("JWT 生成成功 (subject=" + subject + ", expire=" + expireSeconds + "s)", outputs);
                }
                case "parse" -> {
                    String token = p.getString("token");
                    if (token == null || token.isBlank()) return ActionResult.fail("parse 需要 token 字段", outputs);
                    if (token.startsWith("${")) token = String.valueOf(context.getVar("jwtToken"));
                    Claims claims = Jwts.parser().verifyWith(key).build()
                            .parseSignedClaims(token).getPayload();
                    outputs.put("claims", claims.toString());
                    outputs.put("subject", claims.getSubject());
                    outputs.put("expired", claims.getExpiration() != null && claims.getExpiration().before(new Date()));
                    log.info("  JWT parse subject={}", claims.getSubject());
                    return ActionResult.ok("JWT 解析成功 (subject=" + claims.getSubject() + ")", outputs);
                }
                case "verify" -> {
                    String token = p.getString("token");
                    if (token == null || token.isBlank()) return ActionResult.fail("verify 需要 token 字段", outputs);
                    if (token.startsWith("${")) token = String.valueOf(context.getVar("jwtToken"));
                    try {
                        Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
                        outputs.put("valid", true);
                        log.info("  JWT verify -> valid");
                        return ActionResult.ok("JWT 校验通过", outputs);
                    } catch (Exception e) {
                        outputs.put("valid", false);
                        outputs.put("error", e.getMessage());
                        return ActionResult.fail("JWT 校验失败: " + e.getMessage(), outputs);
                    }
                }
                default -> {
                    return ActionResult.fail("不支持的 JWT 操作: " + op + "（generate/parse/verify）", outputs);
                }
            }
        } catch (Exception e) {
            return ActionResult.fail("JWT 操作异常: " + e.getClass().getSimpleName() + ": " + e.getMessage(), outputs);
        }
    }

    /** 短密钥补齐到 32 字节（HMAC-SHA256 最小长度） */
    private static String padSecret(String secret) {
        StringBuilder sb = new StringBuilder(secret);
        while (sb.length() < 32) {
            sb.append(secret);
        }
        return sb.substring(0, 32);
    }
}
