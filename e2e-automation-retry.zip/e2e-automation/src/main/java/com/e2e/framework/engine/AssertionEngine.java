package com.e2e.framework.engine;

import com.e2e.framework.model.AssertionRule;
import org.awaitility.Awaitility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 断言引擎 —— 统一评估步骤 ASSERT 列规则的<b>编排层</b>。
 *
 * <p>三拆架构（单一职责）：
 * <ul>
 *   <li>{@link ContentResolver} —— 内容加载与路径求值（DB/FILE/JSONPath/XPath/outputs）</li>
 *   <li>{@link OperatorEvaluator} —— 操作符评估（字符串模式 14 种 + Map 模式）</li>
 *   <li>{@link AssertionEngine}（本类）—— 编排调度 + 异步轮询（WAIT_UNTIL）</li>
 * </ul>
 *
 * <p>支持两种断言模式：
 * <ul>
 *   <li><b>字符串模式（向后兼容）</b>：EXPECTED 为字符串列表，如 {@code ["200", "OK"]}
 *     <pre>{"DB":"SELECT name FROM orders","OP":"EQ","EXPECTED":["order-001"]}</pre></li>
 *   <li><b>Map 模式（多字段批量验证）</b>：EXPECTED 为 JSON 对象数组，每个对象描述一行期望值，
 *     引擎将查询结果（多行多列）按字段逐行比对。
 *     <pre>{"DB":"SELECT id,name,status FROM orders","OP":"EQ","EXPECTED":[{"id":"1","name":"test"}]}</pre></li>
 * </ul>
 *
 * <p>异步轮询断言：OP=WAIT_UNTIL 在 timeout 内反复取值直到通过（适配 MQ 异步消费 / DB 最终一致性）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class AssertionEngine {

    private static final Logger log = LoggerFactory.getLogger(AssertionEngine.class);

    private final ContentResolver contentResolver;
    private final OperatorEvaluator operatorEvaluator;

    @Autowired
    public AssertionEngine(ContentResolver contentResolver, OperatorEvaluator operatorEvaluator) {
        this.contentResolver = contentResolver;
        this.operatorEvaluator = operatorEvaluator;
    }

    /**
     * 评估全部断言规则：模式检测 → 同步/异步分发 → 内容加载 → 操作符评估。
     * 任一规则失败抛出 {@link AssertionFailureException}（由 StepExecutor 捕获转为步骤 FAILED）。
     */
    public void evaluate(List<AssertionRule> rules, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        for (AssertionRule rule : rules) {
            boolean isMapMode = isMapExpected(rule);
            if (rule.isAsync()) {
                evaluateAsync(rule, outputs, ctx, isMapMode);
            } else if (isMapMode) {
                List<Map<String, Object>> actualRows = contentResolver.loadActualRows(rule, outputs, ctx);
                operatorEvaluator.evaluateMapRule(rule, actualRows);
            } else {
                List<String> actual = contentResolver.loadActual(rule, outputs, ctx);
                operatorEvaluator.evaluateRule(rule, actual);
            }
            log.info("    断言通过: {} [{}] {} expected={}", rule.getSource(), rule.getOp(),
                    isMapMode ? "(map mode)" : "", abbreviateExpected(rule));
        }
    }

    // ===================== 异步轮询（WAIT_UNTIL） =====================

    private void evaluateAsync(AssertionRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx,
                               boolean isMapMode) {
        int timeoutSec = rule.getTimeoutSeconds() > 0 ? rule.getTimeoutSeconds() : 30;
        long pollMs = rule.getPollIntervalMs() > 0 ? rule.getPollIntervalMs() : 1000;
        log.info("    异步断言开始轮询: {} [{}] timeout={}s pollInterval={}ms",
                rule.getSource(), rule.getOp(), timeoutSec, pollMs);

        try {
            Awaitility.await()
                    .atMost(timeoutSec, TimeUnit.SECONDS)
                    .pollDelay(0, TimeUnit.MILLISECONDS)
                    .pollInterval(pollMs, TimeUnit.MILLISECONDS)
                    .untilAsserted(() -> {
                        // Awaitility untilAsserted 仅对 AssertionError 重试；
                        // 断言失败异常需转译为 AssertionError 才能触发轮询（超时前每轮重试）
                        try {
                            if (isMapMode) {
                                List<Map<String, Object>> actualRows = contentResolver.loadActualRows(rule, outputs, ctx);
                                operatorEvaluator.evaluateMapRule(rule, actualRows);
                            } else {
                                List<String> actual = contentResolver.loadActual(rule, outputs, ctx);
                                operatorEvaluator.evaluateRule(rule, actual);
                            }
                        } catch (AssertionFailureException e) {
                            throw new AssertionError(e);
                        }
                    });
        } catch (org.awaitility.core.ConditionTimeoutException e) {
            // 超时统一转译为断言失败异常（步骤标记 FAILED 而非 ERROR，消息含超时上下文）
            throw new AssertionFailureException("异步断言超时(" + timeoutSec + "s)未满足 ["
                    + rule.getSource() + " " + rule.getOp() + "] 期望值: " + rule.getExpected()
                    + "\n  规则原文: " + rule.getRaw());
        }
    }

    // ===================== 模式检测 =====================

    /** 检测 EXPECTED 是否为 JSON 对象数组（以 { 开头）→ Map 模式 */
    private boolean isMapExpected(AssertionRule rule) {
        List<String> expected = rule.getExpected();
        if (expected == null || expected.isEmpty()) return false;
        return expected.stream().anyMatch(e -> e != null && e.trim().startsWith("{"));
    }

    private String abbreviateExpected(AssertionRule rule) {
        String s = Objects.toString(rule.getExpected(), "");
        return s.length() > 80 ? s.substring(0, 80) + "..." : s;
    }

    /** 断言失败（含差异详情，OperatorEvaluator 抛出，StepExecutor 捕获） */
    public static class AssertionFailureException extends RuntimeException {
        public AssertionFailureException(String message) { super(message); }
    }
}
