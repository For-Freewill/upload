package com.e2e.framework.protocol;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * HTTP 协议客户端接口。
 *
 * <p>支持全部 HTTP method + JSON/form/raw body + query params + headers + auth。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface HttpApiClient {

    HttpResult execute(HttpSpec spec);

    String describe();

    /** HTTP 请求规格 */
    class HttpSpec {
        private String url;
        private String method = "GET";
        private Map<String, String> headers = new LinkedHashMap<>();
        private Map<String, String> queryParams = new LinkedHashMap<>();
        private Map<String, String> formParams = new LinkedHashMap<>();
        private Object body;              // JSON body（Object/Map/List/String）
        private String contentType;       // 覆盖 Content-Type（默认根据 body 自动推断）
        private Auth auth;

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public String getMethod() { return method; }
        public void setMethod(String method) { this.method = method == null ? "GET" : method.toUpperCase(); }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers == null ? new LinkedHashMap<>() : headers; }
        public Map<String, String> getQueryParams() { return queryParams; }
        public void setQueryParams(Map<String, String> queryParams) { this.queryParams = queryParams == null ? new LinkedHashMap<>() : queryParams; }
        public Map<String, String> getFormParams() { return formParams; }
        public void setFormParams(Map<String, String> formParams) { this.formParams = formParams == null ? new LinkedHashMap<>() : formParams; }
        public Object getBody() { return body; }
        public void setBody(Object body) { this.body = body; }
        public String getContentType() { return contentType; }
        public void setContentType(String contentType) { this.contentType = contentType; }
        public Auth getAuth() { return auth; }
        public void setAuth(Auth auth) { this.auth = auth; }

        /** 认证配置 */
        public static class Auth {
            private String type;    // bearer / basic / none
            private String token;
            private String username;
            private String password;

            public String getType() { return type; }
            public void setType(String type) { this.type = type; }
            public String getToken() { return token; }
            public void setToken(String token) { this.token = token; }
            public String getUsername() { return username; }
            public void setUsername(String username) { this.username = username; }
            public String getPassword() { return password; }
            public void setPassword(String password) { this.password = password; }
        }
    }

    /** HTTP 响应 */
    class HttpResult {
        private int statusCode;
        private String body = "";
        private Map<String, String> headers = new LinkedHashMap<>();
        private long responseTimeMs;

        public int getStatusCode() { return statusCode; }
        public void setStatusCode(int statusCode) { this.statusCode = statusCode; }
        public String getBody() { return body; }
        public void setBody(String body) { this.body = body == null ? "" : body; }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers; }
        public long getResponseTimeMs() { return responseTimeMs; }
        public void setResponseTimeMs(long responseTimeMs) { this.responseTimeMs = responseTimeMs; }
    }
}
