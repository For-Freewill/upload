package com.e2e.framework.actions.ftp;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.FtpClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DATAHUB 域：COMMON_FTP_ACTIONS —— FTP 文件传输操作。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 上传文件
 * [{"FTP":{"op":"upload","local":"test-output/report.pdf","remote":"/upload/report.pdf"}}]
 *
 * // 下载文件
 * [{"FTP":{"op":"download","remote":"/data/result.csv","local":"test-output/result.csv"}}]
 *
 * // 列出远程目录
 * [{"FTP":{"op":"list","dir":"/upload"}}]
 *
 * // 删除远程文件
 * [{"FTP":{"op":"delete","remote":"/upload/old-report.pdf"}}]
 *
 * // 创建远程目录
 * [{"FTP":{"op":"mkdir","dir":"/upload/e2e-evidence"}}]
 *
 * // 检查远程文件存在
 * [{"FTP":{"op":"exists","remote":"/upload/report.pdf"}}]
 * </pre>
 *
 * <p>FTP 连接参数使用 e2e.ftp.* 全局配置（host/port/user/password）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_FTP_ACTIONS",
            description = "FTP 文件传输：upload/download/list/delete/mkdir/exists")
public class CommonFtpActions implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonFtpActions.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject params = context.jsonParams("FTP");
        if (params == null || params.isEmpty()) {
            return ActionResult.fail("缺少 FTP 协议载荷: [{\"FTP\":{\"op\":\"upload\",\"local\":\"...\",\"remote\":\"...\"}}]");
        }

        String op = params.getString("op");
        if (op == null || op.isBlank()) {
            return ActionResult.fail("FTP 载荷缺少 op 字段（upload/download/list/delete/mkdir/exists）");
        }

        FtpClient ftp = context.clients().ftp();
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("op", op);

        try {
            switch (op.toLowerCase()) {
                case "upload" -> {
                    String local = params.getString("local");
                    String remote = params.getString("remote");
                    if (local == null || remote == null) {
                        return ActionResult.fail("upload 操作需要 local + remote 字段", outputs);
                    }
                    FtpClient.FtpResult r = ftp.upload(local, remote);
                    outputs.put("success", r.isSuccess());
                    outputs.put("message", r.getMessage());
                    outputs.put("local", local);
                    outputs.put("remote", remote);
                    return r.isSuccess()
                            ? ActionResult.ok(r.getMessage(), outputs)
                            : ActionResult.fail(r.getMessage(), outputs);
                }
                case "download" -> {
                    String remote = params.getString("remote");
                    String local = params.getString("local");
                    if (remote == null || local == null) {
                        return ActionResult.fail("download 操作需要 remote + local 字段", outputs);
                    }
                    FtpClient.FtpResult r = ftp.download(remote, local);
                    outputs.put("success", r.isSuccess());
                    outputs.put("message", r.getMessage());
                    outputs.put("remote", remote);
                    outputs.put("local", local);
                    return r.isSuccess()
                            ? ActionResult.ok(r.getMessage(), outputs)
                            : ActionResult.fail(r.getMessage(), outputs);
                }
                case "list" -> {
                    String dir = params.getString("dir");
                    if (dir == null || dir.isBlank()) {
                        return ActionResult.fail("list 操作需要 dir 字段", outputs);
                    }
                    var files = ftp.list(dir);
                    outputs.put("files", files);
                    outputs.put("fileCount", files.size());
                    outputs.put("dir", dir);
                    log.info("  FTP list {}: {} entries", dir, files.size());
                    return ActionResult.ok("目录列出: " + dir + " (" + files.size() + " entries)", outputs);
                }
                case "delete" -> {
                    String remote = params.getString("remote");
                    if (remote == null || remote.isBlank()) {
                        return ActionResult.fail("delete 操作需要 remote 字段", outputs);
                    }
                    FtpClient.FtpResult r = ftp.delete(remote);
                    outputs.put("success", r.isSuccess());
                    outputs.put("message", r.getMessage());
                    return r.isSuccess()
                            ? ActionResult.ok(r.getMessage(), outputs)
                            : ActionResult.fail(r.getMessage(), outputs);
                }
                case "mkdir" -> {
                    String dir = params.getString("dir");
                    if (dir == null || dir.isBlank()) {
                        return ActionResult.fail("mkdir 操作需要 dir 字段", outputs);
                    }
                    FtpClient.FtpResult r = ftp.mkdir(dir);
                    outputs.put("success", r.isSuccess());
                    outputs.put("message", r.getMessage());
                    return r.isSuccess()
                            ? ActionResult.ok(r.getMessage(), outputs)
                            : ActionResult.fail(r.getMessage(), outputs);
                }
                case "exists" -> {
                    String remote = params.getString("remote");
                    if (remote == null || remote.isBlank()) {
                        return ActionResult.fail("exists 操作需要 remote 字段", outputs);
                    }
                    boolean exists = ftp.exists(remote);
                    outputs.put("exists", exists);
                    outputs.put("remote", remote);
                    log.info("  FTP exists {} -> {}", remote, exists);
                    return ActionResult.ok("文件存在检查: " + remote + " -> " + exists, outputs);
                }
                default -> {
                    return ActionResult.fail("不支持的 FTP 操作: " + op
                            + "（支持 upload/download/list/delete/mkdir/exists）", outputs);
                }
            }
        } catch (Exception e) {
            log.error("  FTP 操作异常: {}", e.getMessage());
            return ActionResult.fail("FTP 操作异常: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
