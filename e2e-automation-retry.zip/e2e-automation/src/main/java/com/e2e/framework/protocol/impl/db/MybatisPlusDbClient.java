package com.e2e.framework.protocol.impl.db;

import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.e2e.framework.protocol.DbClient;
import org.apache.ibatis.builder.StaticSqlSource;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ResultMap;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * DB live 实现 ①（MyBatis-Plus 方式，e2e.db.driver=mybatis-plus 启用）。
 *
 * <p>基于 mybatis-plus-spring-boot4-starter 自动装配的 {@link SqlSessionFactory}
 * （MybatisSqlSessionFactoryBean 产物，MybatisConfiguration），以
 * 「动态注册 MappedStatement + {@link SqlSessionTemplate}」执行任意 SQL：
 * 完整走 MyBatis 执行链（StatementHandler → ParameterHandler → ResultSetHandler，
 * SELECT 结果按 Map 类型 ResultMap 自动映射列名 -> 值）。
 *
 * <p>说明：MyBatis-Plus 3.5.9 起移除了旧版 SqlRunner 任意 SQL 入口，官方 Db / SqlHelper
 * 面向实体 CRUD；本框架面向模版任意 SQL，故采用动态 statement 方案 ——
 * 相同 SQL 按内容缓存 statement（断言轮询中重复执行的 SQL 命中缓存零注册开销）。
 * 事务由 SqlSessionTemplate 按操作自动提交（mybatis-spring 非事务场景强制 commit）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class MybatisPlusDbClient implements DbClient {

    private static final Logger log = LoggerFactory.getLogger(MybatisPlusDbClient.class);
    private static final String STATEMENT_PREFIX = "e2e.raw.";

    private final SqlSessionTemplate sqlSessionTemplate;
    private final MybatisConfiguration configuration;
    private final ConcurrentMap<String, String> statementCache = new ConcurrentHashMap<>();
    private final AtomicInteger statementSeq = new AtomicInteger();

    public MybatisPlusDbClient(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
        this.configuration = (MybatisConfiguration) sqlSessionFactory.getConfiguration();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> query(String sql) {
        String statementId = registerStatement(sql, SqlCommandType.SELECT);
        List<Map<String, Object>> rows =
                (List<Map<String, Object>>) (List<?>) sqlSessionTemplate.selectList(statementId);
        log.debug("[mybatis-plus] selectList -> {} rows: {}", rows.size(), abbreviate(sql));
        return rows;
    }

    @Override
    public int[] execute(List<String> sqls) {
        if (sqls == null || sqls.isEmpty()) {
            return new int[0];
        }
        int[] counts = new int[sqls.size()];
        for (int i = 0; i < sqls.size(); i++) {
            // UPDATE 类型统一承载 DML / DDL（均走 executeUpdate）
            String statementId = registerStatement(sqls.get(i), SqlCommandType.UPDATE);
            counts[i] = sqlSessionTemplate.update(statementId);
            log.debug("[mybatis-plus] update -> {} rows: {}", counts[i], abbreviate(sqls.get(i)));
        }
        return counts;
    }

    @Override
    public String describe() {
        return "mybatis-plus(SqlSessionTemplate@" + Integer.toHexString(System.identityHashCode(sqlSessionTemplate))
                + ", dynamicStatements=" + statementCache.size() + ")";
    }

    /**
     * 按内容缓存地注册动态 MappedStatement：
     * <ul>
     *   <li>SELECT：Map 类型 inline ResultMap（等价 resultType="map"），列名自动映射；</li>
     *   <li>UPDATE：无结果映射，走 executeUpdate 返回影响行数。</li>
     * </ul>
     */
    private String registerStatement(String sql, SqlCommandType type) {
        String cacheKey = type.name() + ':' + sql;
        return statementCache.computeIfAbsent(cacheKey, key -> {
            String id = STATEMENT_PREFIX + type.name().toLowerCase() + '.' + statementSeq.incrementAndGet();
            MappedStatement.Builder builder = new MappedStatement.Builder(configuration, id,
                    new StaticSqlSource(configuration, sql), type);
            if (type == SqlCommandType.SELECT) {
                ResultMap inlineMapResult = new ResultMap.Builder(configuration, id + "-inline",
                        Map.class, Collections.emptyList()).build();
                builder.resultMaps(List.of(inlineMapResult));
            }
            configuration.addMappedStatement(builder.build());
            log.debug("注册动态 MyBatis statement: {} ({})", id, abbreviate(sql));
            return id;
        });
    }

    private static String abbreviate(String sql) {
        String s = sql.replaceAll("\\s+", " ").trim();
        return s.length() > 120 ? s.substring(0, 120) + "..." : s;
    }
}
