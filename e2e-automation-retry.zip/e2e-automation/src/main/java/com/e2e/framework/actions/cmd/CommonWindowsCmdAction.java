package com.e2e.framework.actions.cmd;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DATAHUB 域：COMMON_WINDOWS_CMD —— 本地 Windows 命令执行。
 *
 * <p>仅支持本地 Windows 命令（host=local），支持 base_dir 工作目录 + 批量命令。
 * 远程 Windows 执行请使用 SSH 协议或 COMMON_LINUX_CMD（远程 Linux）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // base_dir + 批量命令
 * [{"WINDOWS-CMD":{
 *   "base_dir":"C:/dev",
 *   "cmd":["dir","set_env alpha test","cd scratch && dir"]
 * }}]
 *
 * // 无 base_dir（当前目录执行）
 * [{"WINDOWS-CMD":{"cmd":["echo hello","ipconfig"]}}]
 * </pre>
 *
 * <h3>输出（outputs，供 ASSERT / EXTRACT 使用）</h3>
 * <ul>
 *   <li>{@code CMD} — 最终退出码（0=成功）</li>
 *   <li>{@code STDOUT} — 全部命令的合并标准输出</li>
 *   <li>{@code STDERR} — 全部命令的合并标准错误</li>
 *   <li>{@code commandCount} — 执行的命令数量</li>
 *   <li>{@code lastCommand} — 最后一条执行的命令</li>
 *   <li>{@code lines} — STDOUT 按行分割的列表</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_WINDOWS_CMD",
            description = "本地 Windows 命令执行（base_dir 工作目录 + 批量命令）")
public class CommonWindowsCmdAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonWindowsCmdAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("WINDOWS-CMD");
        if (payload == null) {
            return ActionResult.fail("COMMON_WINDOWS_CMD 需要 WINDOWS-CMD 协议载荷: "
                    + "[{\"WINDOWS-CMD\":{\"base_dir\":\"C:/dev\",\"cmd\":[\"dir\"]}}]");
        }
        return executeLocalCmd(context, payload.paramsAsObject(), true);
    }

    /**
     * 本地命令执行：{base_dir, cmd[]}。
     * <p>仅供子类复用（CommonLinuxCmdAction 本地模式）。
     */
    protected ActionResult executeLocalCmd(ActionContext context, JSONObject params, boolean windows) {
        // ① 解析命令列表
        List<String> commands = parseCommands(params);
        if (commands.isEmpty()) {
            return ActionResult.fail("命令载荷缺少 cmd 字段（支持数组或单字符串）");
        }

        // ② 解析 base_dir（可选，工作目录）
        String baseDir = params.getString("base_dir");
        if (baseDir == null) baseDir = params.getString("baseDir");

        // ③ 本地执行
        CommandResult result = context.clients().cmd().run(commands, baseDir, windows);
        log.info("  CMD@local base_dir={} commands={}", baseDir, commands);

        // ④ 构建输出
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("CMD", result.getExitCode());
        outputs.put("STDOUT", result.getStdout());
        outputs.put("STDERR", result.getStderr());
        outputs.put("commandCount", commands.size());
        outputs.put("lastCommand", commands.get(commands.size() - 1));
        outputs.put("host", "local");
        if (baseDir != null) outputs.put("baseDir", baseDir);

        String stdoutStr = result.getStdout() == null ? "" : result.getStdout();
        List<String> lines = stdoutStr.isBlank() ? List.of() : stdoutStr.lines().toList();
        outputs.put("lines", lines);

        // ⑤ 判定
        String cmdType = windows ? "WINDOWS-CMD" : "LINUX-CMD";
        if (result.getExitCode() == 0) {
            return ActionResult.ok(cmdType + "@local 执行 " + commands.size()
                    + " 条命令成功 (base_dir=" + baseDir + ")", outputs);
        }
        return ActionResult.fail(cmdType + "@local 命令执行失败 exit=" + result.getExitCode()
                + " stderr=" + abbreviate(result.getStderr()), outputs);
    }

    /**
     * 解析命令列表：支持 JSON 数组 ["cmd1","cmd2"] 或单字符串 "cmd1"。
     */
    protected List<String> parseCommands(JSONObject params) {
        List<String> commands = new ArrayList<>();
        Object cmdObj = params.get("cmd");
        if (cmdObj instanceof JSONArray cmdArr) {
            for (Object n : cmdArr) {
                commands.add(n instanceof String s ? s : String.valueOf(n));
            }
        } else if (cmdObj instanceof String s && !s.isBlank()) {
            commands.add(s);
        }
        return commands;
    }

    protected static String abbreviate(String s) {
        if (s == null) return "";
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
