package com.e2e.framework.engine;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionRegistry;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.AppAction;
import com.e2e.framework.ai.AiAssistant;
import com.e2e.framework.data.ResourcePathResolver;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.model.ExtractRule;
import com.e2e.framework.model.OnFailure;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.model.results.StepStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 步骤执行器 —— 单个步骤的完整生命周期：
 * 变量替换 -> Action 查找 -> 带超时执行 -> 失败重试 -> 断言评估 -> 变量提取 -> 失败策略。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class StepExecutor {

    private static final Logger log = LoggerFactory.getLogger(StepExecutor.class);

    private final ActionRegistry registry;
    private final AssertionEngine assertionEngine;
    private final ScreenshotService screenshotService;
    private final E2EProperties props;
    private final ExecutorService stepPool;
    private final AiAssistant aiAssistant;

    public StepExecutor(ActionRegistry registry, AssertionEngine assertionEngine,
                        ScreenshotService screenshotService, E2EProperties props,
                        @Qualifier("e2eStepPool") ExecutorService stepPool,
                        AiAssistant aiAssistant) {
        this.registry = registry;
        this.assertionEngine = assertionEngine;
        this.screenshotService = screenshotService;
        this.props = props;
        this.stepPool = stepPool;
        this.aiAssistant = aiAssistant;
    }

    public StepResult execute(StepDefinition step, ScenarioExecutionContext ctx) {
        StepResult result = new StepResult(step);
        long start = System.currentTimeMillis();
        ctx.markStepStart(step.getStepId()); // 记录步骤开始时间到上下文

        // 0. 步骤级 enable 过滤（与场景级 enable 同语义，颗粒度更细）
        if (!step.isEnabled()) {
            result.setStatus(StepStatus.SKIPPED);
            result.setMessage("步骤 Enabled=N，未启用");
            log.info("  -- 步骤 {} 跳过（未启用）", step.getStepId());
            result.setDurationMs(System.currentTimeMillis() - start);
            return result;
        }

        log.info("  -> 步骤 {} [{}] 开始（输入载荷 {} 个，断言 {} 条，提取 {} 条）",
                step.getStepId(), step.actionKey(), step.getInputPayloads().size(),
                step.getAssertRules().size(), step.getExtractRules().size());

        // 1. 变量替换（INPUT 载荷 + 断言目标）
        Map<String, Object> extractVars = ctx.getExtractVars();
        List<ProtocolPayload> resolvedPayloads = resolvePayloads(step, extractVars, ctx);
        List<AssertionRule> resolvedAsserts = resolveAsserts(step, extractVars, ctx);

        // 2. Action 查找（SPI 注册表）
        AppAction action = registry.lookup(step.getApp(), step.getAction());
        if (action == null) {
            result.setStatus(StepStatus.DATA_ERROR);
            result.setMessage("未注册的 APP 操作: " + step.actionKey()
                    + "。当前注册表: " + registry.describe()
                    + "。注册方式：实现 AppAction 接口并标注 @ActionSpec(apps={\"" + step.getApp()
                    + "\"}, action=\"" + step.getAction() + "\"})");
            log.error("  xx 步骤 {} 失败(未注册): {}", step.getStepId(), result.getMessage());
            result.setDurationMs(System.currentTimeMillis() - start);
            return result;
        }

        // 3. 带超时 + 重试执行（Action 与断言全链路参与重试）
        // 步骤 RETRY 列 > e2e.retry.step-retry-default > 0；ON_FAILURE=RETRY 时强制至少 1 次重试
        int stepRetry = Math.max(step.getRetry(), props.getRetry().getStepRetryDefault());
        if (step.getOnFailure() == OnFailure.RETRY && stepRetry == 0) {
            stepRetry = 1;
        }
        int maxAttempts = stepRetry + 1;
        StepStatus status = StepStatus.PASSED;
        String failureMessage = "";
        ActionResult actionResult = null;
        Map<String, Object> outputs = new LinkedHashMap<>();

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            result.setAttempts(attempt);
            status = StepStatus.PASSED;
            failureMessage = "";
            actionResult = null;
            outputs = new LinkedHashMap<>();
            Future<ActionResult> future = null;
            try {
                future = stepPool.submit(() ->
                        action.execute(new ActionContext(step.getScenarioId(), step.getStepId(),
                                resolvedPayloads, ctx)));
                int timeoutSeconds = step.getTimeoutSeconds() > 0
                        ? step.getTimeoutSeconds() : props.getExecutor().getStepTimeoutDefaultSeconds();
                actionResult = future.get(timeoutSeconds, TimeUnit.SECONDS);
                if (!actionResult.isSuccess()) {
                    status = StepStatus.FAILED;
                    failureMessage = actionResult.getMessage();
                }
            } catch (TimeoutException e) {
                if (future != null) {
                    future.cancel(true);
                }
                status = StepStatus.TIMEOUT;
                failureMessage = "步骤超时（>" + step.getTimeoutSeconds() + "s）: " + e.getMessage();
            } catch (Exception e) {
                status = StepStatus.FAILED;
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                failureMessage = cause.getClass().getSimpleName() + ": " + cause.getMessage();
            }

            if (actionResult != null && actionResult.getOutputs() != null) {
                outputs.putAll(actionResult.getOutputs());
            }

            // 4. 断言评估 —— 位于重试循环内：Action 成功但断言失败同样触发重试
            //    （典型场景：异步数据未就绪 → 断言失败 → 重试后数据落地 → 通过）
            if (status == StepStatus.PASSED && !resolvedAsserts.isEmpty()) {
                try {
                    assertionEngine.evaluate(resolvedAsserts, outputs, ctx);
                } catch (AssertionEngine.AssertionFailureException e) {
                    status = StepStatus.FAILED;
                    failureMessage = e.getMessage();
                }
            }

            if (status == StepStatus.PASSED) {
                break; // action + 断言全部通过，进入变量提取
            }
            if (attempt < maxAttempts) {
                long delay = props.getRetry().getStepRetryDelayMs() > 0
                        ? props.getRetry().getStepRetryDelayMs() : props.getExecutor().getRetryDelayMs();
                log.warn("  !! 步骤 {} 第 {} 次尝试失败: {}（{}ms 后重试）", step.getStepId(), attempt,
                        failureMessage, delay);
                sleep(delay);
            }
        }

        // 5. 变量提取（EXTRACT）—— 支持提取模式（from+path）与字面量模式（value）
        if (status == StepStatus.PASSED && !step.getExtractRules().isEmpty()) {
            for (ExtractRule rule : step.getExtractRules()) {
                try {
                    if (rule.isLiteral()) {
                        // 字面量模式：场景级参数设置（value 支持 ${global.}/${env.}/${extract.} 引用组合）
                        String resolved = ctx.resolver().resolve(rule.getValue(), ctx.getExtractVars());
                        ctx.putExtract(rule.getName(), resolved);
                        log.info("    设置场景参数: {} = {}（字面量）", rule.getName(), resolved);
                    } else {
                        Object value = evaluatePath(rule, outputs, ctx);
                        ctx.putExtract(rule.getName(), value);
                        log.info("    提取变量: {} = {}", rule.getName(), value);
                    }
                } catch (Exception e) {
                    status = StepStatus.FAILED;
                    failureMessage = "变量提取失败 " + rule.getName() + ": " + e.getMessage();
                }
            }
        }

        // 6. 失败策略（ON_FAILURE）
        if (status.isTerminalFailure()) {
            result.setStatus(status);
            result.setMessage(failureMessage);
            result.setOutputs(outputs);
            switch (step.getOnFailure()) {
                case SCREENSHOT -> {
                    String path = screenshotService.capture(step.getScenarioId(), step.getStepId());
                    result.setScreenshotPath(path);
                    log.error("  xx 步骤 {} 失败({}), 已留存截图证据: {}", step.getStepId(), status, path);
                }
                case SAVE_EVIDENCE -> {
                    // 保存截图 + outputs 快照
                    String path = screenshotService.capture(step.getScenarioId(), step.getStepId());
                    result.setScreenshotPath(path);
                    result.setOutputs(outputs);
                    log.error("  xx 步骤 {} 失败({}), 已保存全部证据: screenshot={}, outputs={}",
                            step.getStepId(), status, path, outputs.keySet());
                }
                default -> {
                    // STOP / CONTINUE / RETRY 耗尽：CONTINUE 不在此分支（非 terminal failure 例外）
                    log.error("  xx 步骤 {} 失败({}): {}", step.getStepId(), status, failureMessage);
                }
            }
            // AI 钩子：步骤失败时调用 AI 优化器给出建议（e2e.ai.features.step-optimization=true 时生效）
            if (aiAssistant.isEnabled() && props.getAi().getFeatures().isStepOptimization()) {
                try {
                    var suggestions = aiAssistant.stepOptimizer()
                            .suggest(step, result, null);
                    if (suggestions != null && !suggestions.isEmpty()) {
                        for (var s : suggestions) {
                            log.info("    [AI 建议] {}: {} → {}", s.type(), s.description(), s.suggestedChange());
                        }
                    }
                } catch (Exception e) {
                    log.debug("    [AI] 步骤优化建议调用失败: {}", e.getMessage());
                }
            }
        } else {
            result.setStatus(StepStatus.PASSED);
            result.setOutputs(outputs);
            result.setMessage(actionResult == null ? "" : actionResult.getMessage());
            log.info("  ok 步骤 {} 完成 ({} 次尝试)", step.getStepId(), result.getAttempts());
        }

        result.setDurationMs(System.currentTimeMillis() - start);
        ctx.recordStepResult(result); // 记录步骤结果到上下文历史
        return result;
    }

    // ---------------- 变量替换 ----------------

    private List<ProtocolPayload> resolvePayloads(StepDefinition step, Map<String, Object> extractVars,
                                                  ScenarioExecutionContext ctx) {
        List<ProtocolPayload> resolved = new ArrayList<>();
        for (ProtocolPayload payload : step.getInputPayloads()) {
            Object node = ctx.resolver().resolveInJson(payload.getParams(), extractVars);
            resolved.add(new ProtocolPayload(payload.getProtocol(), node));
        }
        return resolved;
    }

    private List<AssertionRule> resolveAsserts(StepDefinition step, Map<String, Object> extractVars,
                                               ScenarioExecutionContext ctx) {
        List<AssertionRule> resolved = new ArrayList<>();
        for (AssertionRule rule : step.getAssertRules()) {
            String target = ctx.resolver().resolve(rule.getTarget(), extractVars);
            List<String> expected = new ArrayList<>();
            for (String e : rule.getExpected()) {
                expected.add(ctx.resolver().resolve(e, extractVars));
            }
            resolved.add(new AssertionRule(rule.getSource(), target, rule.getOp(), expected,
                    rule.getField(), rule.getRaw(), rule.getTimeoutSeconds(), rule.getPollIntervalMs()));
        }
        return resolved;
    }

    // ---------------- EXTRACT 路径求值 ----------------

    /**
     * 路径语法（按 path 前缀自动路由）：
     * <ul>
     *   <li>JSONPath：path 以 {@code $.} 开头 → jayway 求值（from 指向 JSON 输出，如 body/firstDoc）</li>
     *   <li>XPath：path 以 {@code //} 或 {@code /} 开头 → JDK XPath 取首个匹配（from 指向 XML 输出，如 firstMessage）</li>
     *   <li>Regex：path 以 {@code regex:} 开头 → 正则首个匹配 group(1)（无分组则 group(0)）</li>
     *   <li>FILE：from=FILE 时 path 为文件路径（支持 {@code #L<n>} 后缀取第 n 行）</li>
     *   <li>Token 导航（默认）：{@code [0].ACCT_NO} / {@code rows[0].ACCT_NO} / {@code key.subkey[1]}；
     *       base 为 JSON 字符串时自动解析后再导航</li>
     * </ul>
     */
    private Object evaluatePath(ExtractRule rule, Map<String, Object> outputs, ScenarioExecutionContext ctx) {
        String from = rule.getFrom() == null ? "" : rule.getFrom().trim();
        String path = rule.getPath() == null ? "" : rule.getPath().trim();

        // ① FILE 来源：path = 文件路径（支持 #L<n> 行号后缀）
        if ("FILE".equalsIgnoreCase(from)) {
            return extractFromFile(path);
        }

        Object base = getOutputCaseInsensitive(outputs, from);
        if (base == null) {
            if ("DB".equalsIgnoreCase(from)) {
                throw new IllegalArgumentException("DB 提取需要步骤同时配置 DB 断言（或 action 输出 DB 结果）");
            }
            throw new IllegalArgumentException("输出中不存在来源键 " + from + "（可用: " + outputs.keySet() + "）");
        }

        if (path.isEmpty()) {
            return base;
        }

        // ② JSONPath：$. 开头
        if (path.startsWith("$.")) {
            return evalExtractJsonPath(path, toJsonString(base));
        }
        // ③ XPath：// 或 / 开头（XML 字符串输出）
        if (path.startsWith("//") || path.startsWith("/")) {
            return evalExtractXPath(path, String.valueOf(base));
        }
        // ④ Regex：regex: 开头
        if (path.startsWith("regex:")) {
            return evalExtractRegex(path.substring("regex:".length()), String.valueOf(base));
        }

        // ⑤ base 为 JSON 字符串且带点路径 → 解析后导航（HTTP body 等 String 输出）
        if (base instanceof String s && s.length() > 1) {
            char c = s.charAt(0);
            if (c == '{' || c == '[') {
                try {
                    base = com.alibaba.fastjson2.JSON.parse(s);
                } catch (Exception ignore) {
                    // 非 JSON 字符串，按纯文本处理
                }
            }
        }

        // ⑥ Token 导航（原有语义）：[0].COL / rows[0].COL / key.sub
        Object current = base;
        String normalized = path.startsWith("rows") ? path.substring(4) : path;
        for (String token : normalized.split("\\.")) {
            if (token.isEmpty()) continue;
            current = navigate(current, token);
            if (current == null) {
                throw new IllegalArgumentException("路径 " + path + " 在 " + token + " 处中断");
            }
        }
        return current;
    }

    /** 大小写不敏感的 outputs 取值 */
    private Object getOutputCaseInsensitive(Map<String, Object> outputs, String key) {
        Object v = outputs.get(key);
        if (v != null) return v;
        for (var entry : outputs.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue();
        }
        return null;
    }

    /** FILE 提取：读取文件内容；path 支持 "文件路径#L3" 取第 3 行 */
    private Object extractFromFile(String path) {
        String filePath = path;
        int lineNo = -1;
        int hash = path.lastIndexOf("#L");
        if (hash > 0 && hash + 2 < path.length()) {
            try {
                lineNo = Integer.parseInt(path.substring(hash + 2).trim());
                filePath = path.substring(0, hash);
            } catch (NumberFormatException ignore) {
                // 无行号后缀
            }
        }
        try {
            java.nio.file.Path resolved = com.e2e.framework.core.FilePathResolver.resolve(filePath);
            if (!java.nio.file.Files.exists(resolved)) {
                throw new IllegalArgumentException("EXTRACT 文件不存在: " + filePath);
            }
            String content = java.nio.file.Files.readString(resolved, java.nio.charset.StandardCharsets.UTF_8);
            if (lineNo > 0) {
                String[] lines = content.split("\n");
                if (lineNo > lines.length) {
                    throw new IllegalArgumentException("EXTRACT 行号越界: #" + lineNo + "（共 " + lines.length + " 行）");
                }
                return lines[lineNo - 1].trim();
            }
            return content;
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("EXTRACT 文件读取失败: " + filePath + " - " + e.getMessage());
        }
    }

    /** base 转 JSON 字符串（Map/List 序列化；String 原样） */
    private String toJsonString(Object base) {
        if (base instanceof String s) return s;
        return com.alibaba.fastjson2.JSON.toJSONString(base);
    }

    /** JSONPath 提取：单值直接返回；单元素 List 解包 */
    private Object evalExtractJsonPath(String jsonPath, String json) {
        try {
            Object result = com.jayway.jsonpath.JsonPath.read(json, jsonPath);
            if (result instanceof java.util.List<?> list && list.size() == 1) {
                return list.get(0);
            }
            return result;
        } catch (Exception e) {
            throw new IllegalArgumentException("EXTRACT JSONPath 求值失败: " + jsonPath + " - " + e.getMessage());
        }
    }

    /** XPath 提取：返回首个匹配节点的文本 */
    private Object evalExtractXPath(String xpathExpr, String xml) {
        try {
            var xpathFactory = javax.xml.xpath.XPathFactory.newInstance();
            var xpath = xpathFactory.newXPath();
            var dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            var doc = dbf.newDocumentBuilder()
                    .parse(new java.io.ByteArrayInputStream(xml.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            var nodes = (org.w3c.dom.NodeList) xpath.evaluate(xpathExpr, doc, javax.xml.xpath.XPathConstants.NODESET);
            if (nodes.getLength() == 0) {
                throw new IllegalArgumentException("EXTRACT XPath 无匹配节点: " + xpathExpr);
            }
            String text = nodes.item(0).getTextContent();
            return text == null ? "" : text.trim();
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("EXTRACT XPath 求值失败: " + xpathExpr + " - " + e.getMessage());
        }
    }

    /** Regex 提取：首个匹配的 group(1)（无分组则 group(0)）；无匹配返回 null 并报错 */
    private Object evalExtractRegex(String regex, String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.DOTALL).matcher(text);
        if (!m.find()) {
            throw new IllegalArgumentException("EXTRACT 正则无匹配: " + regex);
        }
        return m.groupCount() >= 1 ? m.group(1) : m.group();
    }

    private Object navigate(Object current, String token) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\w+)?(?:\\[(\\d+)])?$").matcher(token);
        if (!m.find()) {
            throw new IllegalArgumentException("非法路径片段: " + token);
        }
        if (m.group(1) != null && current instanceof Map<?, ?> map) {
            current = map.get(m.group(1));
        } else if (m.group(1) != null) {
            throw new IllegalArgumentException("片段 " + m.group(1) + " 需要 Map 但当前是 " + current.getClass().getSimpleName());
        }
        if (m.group(2) != null) {
            if (current instanceof List<?> list) {
                int idx = Integer.parseInt(m.group(2));
                current = idx < list.size() ? list.get(idx) : null;
            } else {
                throw new IllegalArgumentException("下标 " + m.group(2) + " 需要 List 但当前是 " + current.getClass().getSimpleName());
            }
        }
        return current;
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
