package com.e2e.framework.ai;

import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.results.StepResult;

import java.util.List;

/**
 * AI 步骤优化器 —— 在步骤执行失败时给出优化建议。
 *
 * <p>预留接入点：StepExecutor 在步骤失败后调用（e2e.ai.features.step-optimization=true 时），
 * AI 可基于失败上下文建议「调整超时 / 增加重试 / 修改断言期望值 / 添加前置数据准备」等优化。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface AiStepOptimizer {

    /**
     * 对失败步骤给出优化建议。
     *
     * @param step     失败的步骤定义
     * @param result   步骤执行结果（含状态、消息、输出、重试次数）
     * @param scenario 所属场景（可选，供 AI 理解更广泛的流程上下文）
     * @return 优化建议列表（每条含建议类型 + 描述 + 具体修改方案）
     */
    List<OptimizationSuggestion> suggest(StepDefinition step, StepResult result, ScenarioDefinition scenario);

    /** 优化建议数据结构 */
    record OptimizationSuggestion(
            String type,           // TIMEOUT / RETRY / ASSERT / DATA_PREP / DEPENDENCY
            String description,     // 自然语言描述
            String suggestedChange  // 具体修改方案（如 JSON 片段）
    ) {}
}
