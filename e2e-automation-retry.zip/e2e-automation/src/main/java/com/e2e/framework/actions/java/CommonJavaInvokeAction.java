package com.e2e.framework.actions.java;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.ui.PlaywrightUiEngine;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用 JAVA 反射调用 Action —— 通过反射执行 INPUT 中指定的 Java 方法。
 *
 * <p>支持三种调用模式：
 * <ul>
 *   <li><b>Spring Bean 调用</b>：{@code {"bean":"myService","method":"createOrder","params":["ORD-001",100]}}</li>
 *   <li><b>静态方法调用</b>：{@code {"class":"java.lang.System","method":"getProperty","params":["user.home"]}}</li>
 *   <li><b>Playwright 页面方法</b>：{@code {"engine":"playwright","method":"navigate","params":["http://example.com"]}}</li>
 * </ul>
 *
 * <p>参数自动类型推断：String / Integer / Long / Double / Boolean / JSONObject / JSONArray。
 * 可通过 paramTypes 指定精确类型消除重载歧义。
 *
 * <p>向后兼容：当 INPUT 包含 url 字段时，回退到 UiAction 处理器查找。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"SMARTS", "DRP"}, action = "COMMON_JAVA_INVOKE",
            description = "通用 Java 反射方法调用（Spring Bean / 静态方法 / Playwright）")
public class CommonJavaInvokeAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonJavaInvokeAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject params = context.jsonParams("JAVA");
        if (params == null || params.isEmpty()) {
            return ActionResult.fail("缺少 JAVA 协议载荷");
        }

        try {
            // 向后兼容：url 字段 → UiAction 处理器
            if (params.containsKey("url")) {
                return invokeUiHandler(context, params);
            }

            // 反射调用模式
            String bean = params.getString("bean");
            String className = params.getString("class");
            String engine = params.getString("engine");
            String method = params.getString("method");

            if (method == null || method.isBlank()) {
                return ActionResult.fail("JAVA 载荷缺少 method 字段");
            }

            Object target = null;
            Class<?> targetClass = null;

            if (bean != null && !bean.isBlank()) {
                // Spring Bean 调用
                ApplicationContext ctx = context.scenarioContext().clients().ui() instanceof ApplicationContext ac
                        ? ac : null;
                // 通过 ActionContext 获取 Spring 上下文
                target = getSpringBean(context, bean);
                if (target == null) {
                    return ActionResult.fail("Spring Bean 未找到: '" + bean + "'");
                }
                targetClass = target.getClass();
            } else if (className != null && !className.isBlank()) {
                // 静态方法调用
                targetClass = Class.forName(className);
            } else if (engine != null && !engine.isBlank()) {
                // 引擎调用（Playwright / Selenium）
                target = resolveEngine(context, engine);
                if (target == null) {
                    return ActionResult.fail("引擎未启用: '" + engine + "'（检查 e2e.mode 配置）");
                }
                targetClass = target.getClass();
            } else {
                return ActionResult.fail("JAVA 载荷需指定 bean / class / engine / url 之一");
            }

            // 解析参数
            JSONArray rawParams = params.getJSONArray("params");
            List<Class<?>> paramTypes = parseParamTypes(params.getJSONArray("paramTypes"));
            Object[] args = parseArgs(rawParams, paramTypes);

            // 反射查找方法
            Method methodRef = findMethod(targetClass, method, args, paramTypes);
            if (methodRef == null) {
                return ActionResult.fail("方法未找到: " + targetClass.getSimpleName() + "." + method
                        + "(" + describeArgs(args) + ")");
            }
            methodRef.setAccessible(true);

            // 执行
            log.info("  JAVA 反射调用: {}.{}({})", targetClass.getSimpleName(), method, describeArgs(args));
            Object result = methodRef.invoke(target, args);

            // 构建输出
            Map<String, Object> outputs = new LinkedHashMap<>();
            outputs.put("JAVA", "OK");
            outputs.put("result", result);
            outputs.put("method", method);
            outputs.put("target", targetClass.getSimpleName());
            if (result != null) {
                outputs.put("resultType", result.getClass().getSimpleName());
            }

            return ActionResult.ok("JAVA 反射调用 " + targetClass.getSimpleName() + "." + method + " 完成", outputs);

        } catch (ClassNotFoundException e) {
            return ActionResult.fail("类未找到: " + e.getMessage());
        } catch (Exception e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            log.error("  JAVA 反射调用异常: {}", cause.getMessage(), cause);
            return ActionResult.fail("反射调用异常: " + cause.getClass().getSimpleName() + ": " + cause.getMessage());
        }
    }

    // ===================== UiHandler 向后兼容 =====================

    private ActionResult invokeUiHandler(ActionContext context, JSONObject params) {
        String handlerName = params.getString("url");
        Object rawParamsObj = params.get("params");
        String rawParams = rawParamsObj == null ? ""
                : (rawParamsObj instanceof String s ? s : JSONObject.toJSONString(rawParamsObj));

        var handler = context.clients().ui().lookup(handlerName);
        if (handler == null) {
            return ActionResult.fail("未注册的 UI 处理器: '" + handlerName + "'。已注册: "
                    + context.clients().ui().describe());
        }
        Map<String, Object> handlerOutputs = handler.execute(rawParams);
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("JAVA", "OK");
        outputs.putAll(handlerOutputs);
        return ActionResult.ok("UI 处理器 '" + handlerName + "' 完成, params=" + rawParams, outputs);
    }

    // ===================== Spring Bean 获取 =====================

    private Object getSpringBean(ActionContext context, String beanName) {
        try {
            var bootstrap = com.e2e.framework.bootstrap.E2ESpringBootstrap.getInstance();
            return bootstrap.getBean(beanName);
        } catch (Exception e) {
            log.debug("Spring Bean 未找到: {} - {}", beanName, e.getMessage());
            return null;
        }
    }

    // ===================== 引擎解析 =====================

    private Object resolveEngine(ActionContext context, String engine) {
        return switch (engine.toLowerCase()) {
            case "playwright", "browser", "page" -> {
                // 通过 Spring 上下文获取 PlaywrightUiEngine
                try {
                    var bootstrap = com.e2e.framework.bootstrap.E2ESpringBootstrap.getInstance();
                    PlaywrightUiEngine uiEngine = bootstrap.getBean(PlaywrightUiEngine.class);
                    if (uiEngine != null && uiEngine.isEnabled()) {
                        yield uiEngine.page();
                    }
                } catch (Exception ignored) {}
                yield null;
            }
            default -> null;
        };
    }

    // ===================== 参数解析 =====================

    private List<Class<?>> parseParamTypes(JSONArray rawTypes) {
        if (rawTypes == null || rawTypes.isEmpty()) return null;
        List<Class<?>> types = new ArrayList<>();
        for (Object t : rawTypes) {
            String typeName = String.valueOf(t);
            types.add(switch (typeName.toLowerCase()) {
                case "string", "str" -> String.class;
                case "int", "integer" -> int.class;
                case "long" -> long.class;
                case "double" -> double.class;
                case "boolean", "bool" -> boolean.class;
                case "object", "jsonobject" -> JSONObject.class;
                case "array", "jsonarray" -> JSONArray.class;
                case "map" -> Map.class;
                default -> {
                    try { yield Class.forName(typeName); }
                    catch (ClassNotFoundException e) { yield Object.class; }
                }
            });
        }
        return types;
    }

    private Object[] parseArgs(JSONArray rawParams, List<Class<?>> paramTypes) {
        if (rawParams == null || rawParams.isEmpty()) return new Object[0];
        Object[] args = new Object[rawParams.size()];
        for (int i = 0; i < rawParams.size(); i++) {
            Object val = rawParams.get(i);
            Class<?> expectedType = (paramTypes != null && i < paramTypes.size()) ? paramTypes.get(i) : null;
            args[i] = convertArg(val, expectedType);
        }
        return args;
    }

    private Object convertArg(Object val, Class<?> expectedType) {
        if (val == null) return null;
        if (expectedType == null) {
            // 自动类型推断
            return val; // 保持原始类型（String/Integer/Double/Boolean/JSONObject/JSONArray）
        }
        if (expectedType == String.class) return String.valueOf(val);
        if (expectedType == int.class || expectedType == Integer.class) return Integer.parseInt(String.valueOf(val));
        if (expectedType == long.class || expectedType == Long.class) return Long.parseLong(String.valueOf(val));
        if (expectedType == double.class || expectedType == Double.class) return Double.parseDouble(String.valueOf(val));
        if (expectedType == boolean.class || expectedType == Boolean.class) return Boolean.parseBoolean(String.valueOf(val));
        return val;
    }

    // ===================== 方法查找 =====================

    private Method findMethod(Class<?> clazz, String methodName, Object[] args, List<Class<?>> paramTypes) {
        // ① 精确匹配（如果指定了 paramTypes）
        if (paramTypes != null) {
            try {
                return clazz.getDeclaredMethod(methodName, paramTypes.toArray(new Class[0]));
            } catch (NoSuchMethodException ignored) {}
        }

        // ② 遍历方法列表，找名称匹配 + 参数数量匹配的
        int argCount = args.length;
        for (Method m : clazz.getDeclaredMethods()) {
            if (!m.getName().equals(methodName)) continue;
            if (m.getParameterCount() != argCount) continue;

            // 检查参数是否兼容
            Class<?>[] mParamTypes = m.getParameterTypes();
            boolean compatible = true;
            for (int i = 0; i < argCount; i++) {
                if (!isAssignable(mParamTypes[i], args[i])) {
                    compatible = false;
                    break;
                }
            }
            if (compatible) return m;
        }

        // ③ 父类方法
        if (clazz.getSuperclass() != null) {
            return findMethod(clazz.getSuperclass(), methodName, args, paramTypes);
        }
        return null;
    }

    private boolean isAssignable(Class<?> paramType, Object arg) {
        if (arg == null) return !paramType.isPrimitive();
        if (paramType.isInstance(arg)) return true;
        if (paramType == String.class) return true;  // 任何值都可以转为 String
        if (paramType == int.class || paramType == Integer.class) return arg instanceof Number;
        if (paramType == long.class || paramType == Long.class) return arg instanceof Number;
        if (paramType == double.class || paramType == Double.class) return arg instanceof Number;
        if (paramType == boolean.class || paramType == Boolean.class) return arg instanceof Boolean;
        if (paramType == Object.class) return true;
        return false;
    }

    private String describeArgs(Object[] args) {
        if (args.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(args[i] == null ? "null" : args[i].getClass().getSimpleName());
        }
        return sb.toString();
    }
}
