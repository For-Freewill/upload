package com.e2e.framework.actions.file;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.core.FilePathResolver;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * FILE 域通用文件操作 Action。
 *
 * <p><b>路径解析</b>：path 支持绝对路径（C:/xxx 或 /usr/xxx）和相对路径（基于工程根目录）。
 *
 * <p><b>操作</b>：create / write / append / read / delete / exists / deletePattern / listPattern
 *
 * <p>INPUT 格式示例：
 * <pre>
 * // 相对路径（基于工程根目录）
 * [{"FILE":{"op":"create","path":"test-output/test.txt"}}]
 *
 * // 绝对路径
 * [{"FILE":{"op":"create","path":"C:/Users/xxx/test.txt"}}]
 *
 * // 正则批量删除：删除 test-output 下所有匹配 e2e-.*\.txt 的文件
 * [{"FILE":{"op":"deletePattern","path":"test-output","pattern":"e2e-.*\\.txt"}}]
 *
 * // 正则批量删除（递归子目录）
 * [{"FILE":{"op":"deletePattern","path":"test-output","pattern":".*\\.log","recursive":true}}]
 *
 * // 正则列出匹配文件
 * [{"FILE":{"op":"listPattern","path":"test-output","pattern":"e2e-.*\\.txt"}}]
 * </pre>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_FILE_ACTIONS",
            description = "通用文件操作：create/write/append/read/delete/exists/deletePattern/listPattern")
public class CommonFileActions implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonFileActions.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject params = context.jsonParams("FILE");
        if (params == null || params.isEmpty()) {
            return ActionResult.fail("缺少 FILE 协议载荷");
        }

        String op = params.getString("op");
        if (op == null || op.isBlank()) {
            return ActionResult.fail("FILE 载荷缺少 op 字段");
        }
        String pathStr = params.getString("path");
        if (pathStr == null || pathStr.isBlank()) {
            return ActionResult.fail("FILE 载荷缺少 path 字段");
        }

        // 路径解析：绝对路径原样使用，相对路径基于工程根目录
        Path path = FilePathResolver.resolve(pathStr);
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("inputPath", pathStr);
        outputs.put("resolvedPath", path.toAbsolutePath().toString());

        try {
            switch (op.toLowerCase()) {
                case "create" -> {
                    if (path.getParent() != null) Files.createDirectories(path.getParent());
                    if (!Files.exists(path)) Files.createFile(path);
                    outputs.put("exists", true);
                    outputs.put("path", path.toString());
                    log.info("  FILE create: {} (resolved: {})", pathStr, path.toAbsolutePath());
                    return ActionResult.ok("文件创建: " + pathStr, outputs);
                }
                case "write" -> {
                    String content = params.getString("content");
                    if (content == null) content = "";
                    if (path.getParent() != null) Files.createDirectories(path.getParent());
                    Files.writeString(path, content, StandardCharsets.UTF_8,
                            StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    outputs.put("path", path.toString());
                    outputs.put("bytes", content.getBytes(StandardCharsets.UTF_8).length);
                    log.info("  FILE write: {} ({} chars)", pathStr, content.length());
                    return ActionResult.ok("文件写入: " + pathStr + " (" + content.length() + " chars)", outputs);
                }
                case "append" -> {
                    String content = params.getString("content");
                    if (content == null) content = "";
                    if (path.getParent() != null) Files.createDirectories(path.getParent());
                    Files.writeString(path, content, StandardCharsets.UTF_8,
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                    outputs.put("path", path.toString());
                    outputs.put("appendedBytes", content.getBytes(StandardCharsets.UTF_8).length);
                    log.info("  FILE append: {} ({} chars)", pathStr, content.length());
                    return ActionResult.ok("文件追加: " + pathStr + " (" + content.length() + " chars)", outputs);
                }
                case "read" -> {
                    if (!Files.exists(path)) {
                        return ActionResult.fail("文件不存在: " + pathStr + " (resolved: " + path.toAbsolutePath() + ")", outputs);
                    }
                    String content = Files.readString(path, StandardCharsets.UTF_8);
                    List<String> lines = content.isBlank() ? List.of() : content.lines().toList();
                    outputs.put("content", content);
                    outputs.put("lines", lines);
                    outputs.put("lineCount", lines.size());
                    outputs.put("size", content.getBytes(StandardCharsets.UTF_8).length);
                    log.info("  FILE read: {} ({} lines, {} bytes)", pathStr, lines.size(), content.length());
                    return ActionResult.ok("文件读取: " + pathStr + " (" + lines.size() + " lines)", outputs);
                }
                case "delete" -> {
                    boolean deleted = Files.deleteIfExists(path);
                    outputs.put("deleted", deleted);
                    outputs.put("path", path.toString());
                    log.info("  FILE delete: {} -> {}", pathStr, deleted);
                    return ActionResult.ok("文件删除: " + pathStr + " -> " + deleted, outputs);
                }
                case "exists" -> {
                    boolean exists = Files.exists(path);
                    outputs.put("exists", exists);
                    outputs.put("path", path.toString());
                    log.info("  FILE exists: {} -> {}", pathStr, exists);
                    return ActionResult.ok("文件存在检查: " + pathStr + " -> " + exists, outputs);
                }
                case "deletepattern", "delete_regex" -> {
                    // 正则批量删除
                    String pattern = params.getString("pattern");
                    if (pattern == null || pattern.isBlank()) {
                        return ActionResult.fail("deletePattern 操作缺少 pattern 字段（正则表达式）");
                    }
                    boolean recursive = Boolean.parseBoolean(params.getString("recursive"));
                    List<Path> matched = FilePathResolver.matchFiles(pathStr, pattern, recursive);
                    List<String> deletedFiles = new ArrayList<>();
                    int deleteCount = 0;
                    for (Path p : matched) {
                        try {
                            Files.deleteIfExists(p);
                            deletedFiles.add(p.getFileName().toString());
                            deleteCount++;
                        } catch (IOException e) {
                            log.warn("  删除失败: {} - {}", p, e.getMessage());
                        }
                    }
                    outputs.put("matched", matched.size());
                    outputs.put("deleted", deleteCount);
                    outputs.put("deletedFiles", deletedFiles);
                    outputs.put("pattern", pattern);
                    log.info("  FILE deletePattern: dir={} pattern={} matched={} deleted={}",
                            pathStr, pattern, matched.size(), deleteCount);
                    return ActionResult.ok("正则批量删除: " + pattern + " 匹配 " + matched.size()
                            + " 个, 删除 " + deleteCount + " 个", outputs);
                }
                case "listpattern", "list_regex" -> {
                    // 正则列出匹配文件
                    String pattern = params.getString("pattern");
                    if (pattern == null || pattern.isBlank()) {
                        return ActionResult.fail("listPattern 操作缺少 pattern 字段（正则表达式）");
                    }
                    boolean recursive = Boolean.parseBoolean(params.getString("recursive"));
                    List<Path> matched = FilePathResolver.matchFiles(pathStr, pattern, recursive);
                    List<String> fileNames = matched.stream().map(p -> p.getFileName().toString()).toList();
                    outputs.put("matched", matched.size());
                    outputs.put("files", fileNames);
                    outputs.put("pattern", pattern);
                    log.info("  FILE listPattern: dir={} pattern={} matched={}", pathStr, pattern, matched.size());
                    return ActionResult.ok("正则匹配: " + pattern + " 找到 " + matched.size() + " 个文件", outputs);
                }
                default -> {
                    return ActionResult.fail("不支持的文件操作: " + op
                            + "（支持 create/write/append/read/delete/exists/deletePattern/listPattern）");
                }
            }
        } catch (IOException e) {
            log.error("  FILE 操作异常: {}", e.getMessage());
            return ActionResult.fail("文件操作异常: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
