package com.e2e.framework.model;

/**
 * 步骤失败策略 —— 模版 ON_FAILURE 列。
 *
 * <p>控制步骤失败后的处理方式，与 {@code e2e.retry.*} 配置联动：
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public enum OnFailure {

    /** 终止整个场景，后续步骤置为 SKIPPED（默认） */
    STOP,

    /** 记录失败但继续执行后续步骤 */
    CONTINUE,

    /** 先调用截图钩子留存证据，再按 STOP 终止（UI 类步骤） */
    SCREENSHOT,

    /** 失败后先按 e2e.retry 配置重试，重试耗尽仍失败则按 STOP 终止 */
    RETRY,

    /** 保存全部证据（截图 + outputs 快照 + 协议报文），再按 STOP 终止 */
    SAVE_EVIDENCE;

    public static OnFailure parse(String value) {
        if (value == null || value.isBlank()) {
            return STOP;
        }
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return STOP;
        }
    }

    /** 是否在失败后终止后续步骤（STOP / SCREENSHOT / RETRY 耗尽 / SAVE_EVIDENCE 均为 true） */
    public boolean isStopOnFailure() {
        return this != CONTINUE;
    }
}
