package com.e2e.framework.protocol;

import java.util.List;
import java.util.Map;

/**
 * FTP 协议客户端（COMMON_FTP_ACTIONS 使用）。
 *
 * <p>基于 Apache commons-net FTPClient；SFTP 场景可另行扩展（JSch ChannelSftp）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface FtpClient {

    /** 上传本地文件到远程路径 */
    FtpResult upload(String localPath, String remotePath);

    /** 下载远程文件到本地路径 */
    FtpResult download(String remotePath, String localPath);

    /** 列出远程目录文件（名称-大小字节） */
    List<Map<String, Object>> list(String remoteDir);

    /** 删除远程文件 */
    FtpResult delete(String remotePath);

    /** 创建远程目录 */
    FtpResult mkdir(String remoteDir);

    /** 检查远程文件是否存在 */
    boolean exists(String remotePath);

    String describe();

    /** FTP 操作结果 */
    class FtpResult {
        private boolean success;
        private String message;

        public FtpResult(boolean success, String message) {
            this.success = success;
            this.message = message == null ? "" : message;
        }

        public static FtpResult ok(String message) { return new FtpResult(true, message); }
        public static FtpResult fail(String message) { return new FtpResult(false, message); }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
    }
}
