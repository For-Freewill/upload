package com.e2e.framework.protocol;

import java.util.List;

/**
 * 本地命令客户端（WINDOWS-CMD / LINUX-CMD 载荷中 host=local 时使用）。
 *
 * <p>安全默认：live 模式下也需 e2e.cmd.allow-local-execution=true 才真正执行，
 * 否则 dry-run 只记录日志。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface LocalCommandClient {

    CommandResult run(List<String> commands, String baseDir, boolean windows);

    String describe();
}
