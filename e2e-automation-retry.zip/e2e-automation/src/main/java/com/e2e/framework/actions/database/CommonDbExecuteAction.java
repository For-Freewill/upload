package com.e2e.framework.actions.database;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

import java.util.ArrayList;
import java.util.List;

/**
 * 通用 DB 执行操作（数据准备 / 数据清理）。
 *
 * <p>INPUT 示例：{@code [{"DB":["SQL1","SQL2"]}]}（数组）或 {@code [{"DB":"UPDATE ..."}]}（单条）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"SMARTS","STP"}, action = "COMMON_DB_EXECUTE",
        description = "执行 SQL（数据准备/清理），支持单条与批量")
public class CommonDbExecuteAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("DB");
        if (payload == null) {
            return ActionResult.fail("COMMON_DB_EXECUTE 需要 DB 协议载荷: [{\"DB\":[\"SQL1\",\"SQL2\"]}]");
        }
        Object params = payload.getParams();
        List<String> sqls = new ArrayList<>();
        if (params instanceof JSONArray arr) {
            for (Object n : arr) {
                sqls.add(n instanceof String s ? s : JSON.toJSONString(n));
            }
        } else if (params instanceof String s) {
            sqls.add(s);
        } else {
            return ActionResult.fail("DB 载荷应为 SQL 字符串或字符串数组: " + JSON.toJSONString(params));
        }
        if (sqls.isEmpty()) {
            return ActionResult.fail("DB 载荷为空");
        }
        int[] counts = context.clients().db().execute(sqls);
        int total = 0;
        for (int c : counts) {
            total += Math.max(0, c);
        }
        return ActionResult.ok("已执行 " + sqls.size() + " 条 SQL，共影响 " + total + " 行",
                java.util.Map.of("SQL", total, "statements", sqls.size()));
    }
}
