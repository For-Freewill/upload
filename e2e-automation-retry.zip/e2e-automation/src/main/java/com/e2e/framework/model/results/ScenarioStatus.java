package com.e2e.framework.model.results;

/**
 * 场景执行状态
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public enum ScenarioStatus {
    PASSED, FAILED, SKIPPED, TIMEOUT, ERROR
}
