package com.e2e.framework.actions.mail;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.MailClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DATAHUB 域：COMMON_MAIL_ACTIONS —— 发送邮件通知。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 纯文本邮件
 * [{"MAIL":{
 *   "to":["user1@example.com","user2@example.com"],
 *   "subject":"E2E 测试完成通知",
 *   "body":"全部用例执行完成，详见附件报告。"
 * }}]
 *
 * // HTML 邮件 + 抄送 + 附件
 * [{"MAIL":{
 *   "to":["team@example.com"],
 *   "cc":["lead@example.com"],
 *   "subject":"E2E 测试报告",
 *   "body":"&lt;h2&gt;测试报告&lt;/h2&gt;&lt;p&gt;通过率 100%&lt;/p&gt;",
 *   "html":true,
 *   "attachments":["test-output/test_report.html","test-output/test_report.json"]
 * }}]
 * </pre>
 *
 * <p>SMTP 参数使用 e2e.mail.* 全局配置（host/port/from/user/password/authEnabled/starttls）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_MAIL_ACTIONS",
            description = "发送邮件通知（纯文本/HTML/附件）")
public class CommonMailActions implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonMailActions.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject params = context.jsonParams("MAIL");
        if (params == null || params.isEmpty()) {
            return ActionResult.fail("缺少 MAIL 协议载荷: [{\"MAIL\":{\"to\":[\"x@x.com\"],\"subject\":\"...\",\"body\":\"...\"}}]");
        }

        MailClient.MailSpec spec = new MailClient.MailSpec();

        // ① 收件人（to 数组或逗号分隔字符串）
        List<String> to = parseAddressList(params.get("to"));
        if (to.isEmpty()) {
            return ActionResult.fail("MAIL 载荷缺少 to 字段（收件人）");
        }
        spec.setTo(to);

        // ② 抄送（可选）
        spec.setCc(parseAddressList(params.get("cc")));

        // ③ 主题 + 正文
        spec.setSubject(params.getString("subject"));
        spec.setBody(params.getString("body"));

        // ④ HTML 模式（可选，默认纯文本）
        spec.setHtml(Boolean.parseBoolean(params.getString("html")));

        // ⑤ 附件（可选，本地文件路径数组）
        List<String> attachments = new ArrayList<>();
        Object attObj = params.get("attachments");
        if (attObj instanceof JSONArray arr) {
            for (Object n : arr) attachments.add(String.valueOf(n));
        } else if (attObj instanceof String s && !s.isBlank()) {
            attachments.add(s);
        }
        spec.setAttachmentPaths(attachments);

        // ⑥ 发送
        MailClient mail = context.clients().mail();
        log.info("  MAIL send to={} cc={} subject='{}' html={} attachments={}",
                to, spec.getCc(), spec.getSubject(), spec.isHtml(), attachments.size());
        MailClient.MailResult result = mail.send(spec);

        // ⑦ 输出
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("success", result.isSuccess());
        outputs.put("message", result.getMessage());
        outputs.put("messageId", result.getMessageId());
        outputs.put("to", String.join(",", to));
        outputs.put("subject", spec.getSubject());
        outputs.put("attachmentCount", attachments.size());

        return result.isSuccess()
                ? ActionResult.ok(result.getMessage(), outputs)
                : ActionResult.fail(result.getMessage(), outputs);
    }

    /** 解析地址列表：支持 JSON 数组或逗号分隔字符串 */
    private List<String> parseAddressList(Object obj) {
        List<String> result = new ArrayList<>();
        if (obj instanceof JSONArray arr) {
            for (Object n : arr) result.add(String.valueOf(n).trim());
        } else if (obj instanceof String s && !s.isBlank()) {
            for (String part : s.split("[,;]")) {
                if (!part.isBlank()) result.add(part.trim());
            }
        }
        return result;
    }
}
