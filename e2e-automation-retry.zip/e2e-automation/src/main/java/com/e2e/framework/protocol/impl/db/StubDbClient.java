package com.e2e.framework.protocol.impl.db;

import com.e2e.framework.protocol.DbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DB 桩实现（demo 模式 / 未配置数据源时）。
 *
 * <p>演示语义：
 * <ul>
 *   <li>从 SELECT 解析列名列表（支持 SELECT * / SELECT col1,col2 / SELECT 'literal'）；</li>
 *   <li>从 WHERE 解析 col=val 条件（支持 AND 多条件，值支持引号/无引号）；</li>
 *   <li>返回包含全部 SELECT 列的结果行（WHERE 值填充到对应列，其他列用列名或字面量作为值）。</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StubDbClient implements DbClient {

    private static final Logger log = LoggerFactory.getLogger(StubDbClient.class);

    // WHERE clause: col=val [AND col2=val2 ...]，$ 不需要前置空格
    private static final Pattern WHERE_PATTERN =
            Pattern.compile("WHERE\\s+(.+?)(?:$|;|\\s+(?:ORDER\\s+BY|GROUP\\s+BY|LIMIT\\s))",
                    Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern COND_PATTERN =
            Pattern.compile("(\\w+)\\s*=\\s*'?([^'\\s;)]+)", Pattern.CASE_INSENSITIVE);
    // SELECT col1, col2, ... FROM
    private static final Pattern SELECT_COLS =
            Pattern.compile("SELECT\\s+(.+?)\\s+FROM", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    // SELECT 'literal' WHERE ... （无 FROM）
    private static final Pattern SELECT_LITERAL =
            Pattern.compile("SELECT\\s+'([^']+)'", Pattern.CASE_INSENSITIVE);

    @Override
    public List<Map<String, Object>> query(String sql) {
        log.info("[stub-db] query: {}", sql);
        List<Map<String, Object>> rows = new ArrayList<>();

        // 1. 解析 SELECT 部分
        List<String> selectCols = parseSelectColumns(sql);
        boolean isLiteralSelect = !sql.toUpperCase().contains(" FROM ");

        // 2. 解析 WHERE 条件
        Map<String, String> whereConds = parseWhereConditions(sql);

        if (isLiteralSelect) {
            // SELECT 'literal' WHERE ... → 返回字面量 + WHERE 列
            Matcher litM = SELECT_LITERAL.matcher(sql);
            String literal = litM.find() ? litM.group(1) : "val";
            Map<String, Object> row = new LinkedHashMap<>();
            row.put(literal, literal); // 字面量作为 key 和 value（向后兼容：取第一列 = literal 值）
            // 同时填充 WHERE 条件列
            for (var entry : whereConds.entrySet()) {
                row.put(entry.getKey(), entry.getValue());
            }
            rows.add(row);
            return rows;
        }

        if (whereConds.isEmpty()) {
            // 无 WHERE：返回一行，各列用列名作为值
            Map<String, Object> row = new LinkedHashMap<>();
            for (String col : selectCols) {
                row.put(col, col);
            }
            rows.add(row);
            return rows;
        }

        // 3. 构建 result row：WHERE 条件列用条件值，其他 SELECT 列用列名
        Map<String, Object> row = new LinkedHashMap<>();
        for (String col : selectCols) {
            String condVal = findCaseInsensitive(whereConds, col);
            if (condVal != null) {
                row.put(col, condVal);
            } else {
                row.put(col, col); // 非 WHERE 列用列名作为模拟值
            }
        }
        rows.add(row);

        // 4. IN (v1, v2) 多行支持
        Matcher inMatcher = Pattern.compile("(\\w+)\\s+IN\\s*\\(([^)]+)\\)", Pattern.CASE_INSENSITIVE).matcher(sql);
        if (inMatcher.find()) {
            String inCol = inMatcher.group(1);
            String[] inValues = inMatcher.group(2).split(",");
            rows.clear();
            for (String val : inValues) {
                String cleanVal = val.trim().replaceAll("'", "");
                Map<String, Object> inRow = new LinkedHashMap<>();
                for (String col : selectCols) {
                    if (col.equalsIgnoreCase(inCol)) {
                        inRow.put(col, cleanVal);
                    } else {
                        String condVal = findCaseInsensitive(whereConds, col);
                        inRow.put(col, condVal != null ? condVal : col + "_" + cleanVal);
                    }
                }
                rows.add(inRow);
            }
        }

        return rows;
    }

    private List<String> parseSelectColumns(String sql) {
        List<String> cols = new ArrayList<>();
        Matcher m = SELECT_COLS.matcher(sql);
        if (m.find()) {
            String colPart = m.group(1).trim();
            if (colPart.equals("*")) {
                // SELECT * → 用 WHERE 列填充
                return new ArrayList<>(parseWhereConditions(sql).keySet());
            }
            for (String col : colPart.split(",")) {
                String c = col.trim();
                if (c.contains(" AS ")) c = c.split("(?i) AS ")[1].trim();
                if (c.contains(".")) c = c.substring(c.lastIndexOf('.') + 1);
                cols.add(c);
            }
        }
        if (cols.isEmpty()) cols.add("val");
        return cols;
    }

    private Map<String, String> parseWhereConditions(String sql) {
        Map<String, String> conds = new LinkedHashMap<>();
        Matcher whereM = WHERE_PATTERN.matcher(sql);
        if (whereM.find()) {
            String whereClause = whereM.group(1);
            Matcher condM = COND_PATTERN.matcher(whereClause);
            while (condM.find()) {
                conds.put(condM.group(1), condM.group(2));
            }
        }
        return conds;
    }

    private String findCaseInsensitive(Map<String, String> map, String key) {
        String v = map.get(key);
        if (v != null) return v;
        for (var entry : map.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue();
        }
        return null;
    }

    @Override
    public int[] execute(List<String> sqls) {
        int[] counts = new int[sqls.size()];
        for (int i = 0; i < sqls.size(); i++) {
            log.info("[stub-db] execute: {} -> 1 row affected (simulated)", sqls.get(i));
            counts[i] = 1;
        }
        return counts;
    }

    @Override
    public String describe() {
        return "stub-db (demo)";
    }
}
