package com.e2e.framework.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 执行引擎线程池装配
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Configuration
public class E2EExecutorConfig {

    /** 步骤执行池（含超时控制），容量 = 并行度 + 4 保证嵌套提交不饥饿 */
    @Bean(name = "e2eStepPool", destroyMethod = "shutdown")
    public ExecutorService e2eStepPool(E2EProperties props) {
        int size = Math.max(4, props.getExecutor().getParallelThreads() + 4);
        return Executors.newFixedThreadPool(size, r -> {
            Thread t = new Thread(r, "e2e-step");
            t.setDaemon(true);
            return t;
        });
    }

    /** 场景执行池（场景级超时控制用） */
    @Bean(name = "e2eScenarioPool", destroyMethod = "shutdown")
    public ExecutorService e2eScenarioPool() {
        return Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "e2e-scenario");
            t.setDaemon(true);
            return t;
        });
    }
}
