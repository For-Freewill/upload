package com.e2e.framework.bootstrap;

import com.e2e.framework.data.TestDataLoader;
import com.e2e.framework.model.TestDataBundle;
import com.e2e.framework.model.results.ScenarioResult;
import com.e2e.framework.report.ConsoleReportPrinter;
import com.e2e.framework.report.ReportWriter;
import com.e2e.framework.bootstrap.E2ESpringBootstrap;
import com.e2e.framework.bootstrap.ResultStore;
import org.testng.ISuite;
import org.testng.ISuiteListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 套件生命周期监听：结束时输出控制台摘要、生成 JSON/HTML 报告、关闭 Spring 上下文。
 *
 * <p>报告中的场景顺序与 Excel/YAML 模版 Scenarios 表的定义顺序完全一致
 * （按数据装载时的 LinkedHashMap 插入序排序，而非执行完成序）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class E2ESuiteLifecycleListener implements ISuiteListener {

    @Override
    public void onStart(ISuite suite) {
        System.out.println(">>> E2E 套件开始: " + suite.getName()
                + "（数据源: " + System.getProperty("e2e.data.excel.path", "classpath:e2e/E2E-Test-Scenarios.xlsx")
                + " / 运行模式: " + System.getProperty("e2e.mode", "demo") + "）");
    }

    @Override
    public void onFinish(ISuite suite) {
        try {
            E2ESpringBootstrap bootstrap = E2ESpringBootstrap.getInstance();
            TestDataLoader loader = bootstrap.getBean(TestDataLoader.class);
            TestDataBundle bundle = loader.load();

            // 按模版定义顺序排序结果（LinkedHashMap 的 keySet 保持插入序 = Excel 行序）
            List<String> definitionOrder = new ArrayList<>(bundle.getScenarios().keySet());
            List<ScenarioResult> results = new ArrayList<>(ResultStore.all());
            results.sort(Comparator.comparingInt(r -> {
                int idx = definitionOrder.indexOf(r.getScenario().getScenarioId());
                return idx >= 0 ? idx : Integer.MAX_VALUE;
            }));

            var issues = bundle.getIssues();
            bootstrap.getBean(ConsoleReportPrinter.class).print(results, issues);
            ReportWriter reportWriter = bootstrap.getBean(ReportWriter.class);
            reportWriter.write(results, issues, loader.sourceName());
        } finally {
            E2ESpringBootstrap.shutdown();
        }
    }
}
