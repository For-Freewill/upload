package com.e2e.framework.actions.nosql;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * SMARTS/DNS 域：COMMON_NOSQL_ASSERT —— MongoDB 文档断言（查询 + 结果进入 ASSERT 规则评估）。
 *
 * <h3>INPUT + ASSERT 联合格式</h3>
 * <pre>
 * // INPUT：指定集合 + 查询条件
 * [{"MONGO":{"collection":"orders","filter":{"status":"CREATED"}}}]
 *
 * // ASSERT：对 docCount / 字段值断言
 * [{"docCount":"","OP":"EQ","EXPECTED":["1"]}]
 * </pre>
 *
 * <p>输出（供 ASSERT 列直接引用）：
 * <ul>
 *   <li>{@code docCount} — 匹配文档数（SIZE/GT/LTE 断言）</li>
 *   <li>{@code docs} — 匹配文档列表（CONTAINS 断言 JSON 内容）</li>
 *   <li>{@code firstDoc} — 首个文档 JSON（CONTAINS 断言字段值）</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"SMARTS", "DNS"}, action = "COMMON_NOSQL_ASSERT",
            description = "MongoDB 文档断言（filter 查询 → docCount/docs/firstDoc 断言）")
public class CommonNosqlAssertAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonNosqlAssertAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("MONGO");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 MONGO 协议载荷: [{\"MONGO\":{\"collection\":\"...\",\"filter\":{...}}}]");
        }
        String collection = p.getString("collection");
        if (collection == null || collection.isBlank()) {
            return ActionResult.fail("MONGO 载荷缺少 collection 字段");
        }
        JSONObject filter = p.getJSONObject("filter");

        boolean demo = context.props().isDemoMode();
        List<JSONObject> matched = new ArrayList<>();

        if (demo) {
            // demo：内存文档库查询
            List<JSONObject> docs = CommonNosqlExecuteAction.MEM_DB.getOrDefault(collection, List.of());
            for (JSONObject doc : docs) {
                if (CommonNosqlExecuteAction.matchesFilter(doc, filter)) {
                    matched.add(doc);
                }
            }
            log.info("  [mongo-stub] ASSERT query {} filter={} -> {} docs", collection, filter, matched.size());
        } else {
            // live：MongoDB 查询
            var cfg = context.props().getNosql();
            try (var client = com.mongodb.client.MongoClients.create(cfg.getUri())) {
                var db = client.getDatabase(cfg.getDatabase());
                var coll = db.getCollection(collection);
                var filterDoc = filter == null ? new org.bson.Document() : org.bson.Document.parse(filter.toJSONString());
                try (var cursor = coll.find(filterDoc).limit(1000).iterator()) {
                    while (cursor.hasNext()) {
                        matched.add(JSONObject.parseObject(cursor.next().toJson()));
                    }
                }
            } catch (Exception e) {
                return ActionResult.fail("Mongo 断言查询失败: " + e.getMessage());
            }
            log.info("  [mongo] ASSERT query {} filter={} -> {} docs", collection, filter, matched.size());
        }

        Map<String, Object> outputs = new java.util.LinkedHashMap<>();
        outputs.put("docCount", matched.size());
        outputs.put("docs", matched);
        outputs.put("firstDoc", matched.isEmpty() ? "" : matched.get(0).toJSONString());
        return ActionResult.ok("Mongo 断言查询 " + collection + " -> " + matched.size() + " 文档", outputs);
    }
}
