package com.e2e.framework.actions.service;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.ui.PlaywrightUiEngine;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * UI 自动化服务 —— 封装 Playwright 页面操作的常用方法。
 *
 * <p>作为 Spring Bean 注册，可通过 COMMON_JAVA_INVOKE 的 bean 模式反射调用：
 * <pre>
 * {"JAVA":{"bean":"uiAutomationService","method":"navigateTo","params":["https://www.baidu.com"]}}
 * {"JAVA":{"bean":"uiAutomationService","method":"inputText","params":["#kw","搜索关键词"]}}
 * {"JAVA":{"bean":"uiAutomationService","method":"clickElement","params":["#su"]}}
 * {"JAVA":{"bean":"uiAutomationService","method":"getElementText","params":["#result-count"]}}
 * {"JAVA":{"bean":"uiAutomationService","method":"getPageTitle","params":[]}}
 * </pre>
 *
 * <p>demo 模式下 Playwright 不可用，方法返回带 stub 标记的结果（不抛异常），
 * 使测试场景可以优雅降级；live 模式下执行真实浏览器操作。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component("uiAutomationService")
public class UiAutomationService {

    private static final Logger log = LoggerFactory.getLogger(UiAutomationService.class);

    @Autowired(required = false)
    private PlaywrightUiEngine playwrightEngine;

    /**
     * 导航到指定 URL。
     * @param url 目标地址
     * @return 执行结果（含 url / status）
     */
    public Map<String, Object> navigateTo(String url) {
        log.info("[UI] navigateTo: {}", url);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("url", url);
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            result.put("reason", "demo 模式 Playwright 未启动");
            return result;
        }
        page.navigate(url);
        result.put("status", "navigated");
        result.put("title", page.title());
        return result;
    }

    /**
     * 在输入框中填入文本。
     * @param selector CSS 选择器（如 #username）
     * @param text 要输入的文本
     * @return 执行结果
     */
    public Map<String, Object> inputText(String selector, String text) {
        log.info("[UI] inputText: {} = {}", selector, text);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("selector", selector);
        result.put("text", text);
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            return result;
        }
        page.fill(selector, text);
        result.put("status", "filled");
        return result;
    }

    /**
     * 点击页面元素。
     * @param selector CSS 选择器
     * @return 执行结果
     */
    public Map<String, Object> clickElement(String selector) {
        log.info("[UI] clickElement: {}", selector);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("selector", selector);
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            return result;
        }
        page.click(selector);
        result.put("status", "clicked");
        return result;
    }

    /**
     * 获取元素的文本内容。
     * @param selector CSS 选择器
     * @return 含 text 字段的结果
     */
    public Map<String, Object> getElementText(String selector) {
        log.info("[UI] getElementText: {}", selector);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("selector", selector);
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            result.put("text", "");
            return result;
        }
        String text = page.textContent(selector);
        result.put("status", "ok");
        result.put("text", text == null ? "" : text.trim());
        return result;
    }

    /**
     * 获取当前页面标题。
     * @return 含 title 字段的结果
     */
    public Map<String, Object> getPageTitle() {
        log.info("[UI] getPageTitle");
        Map<String, Object> result = new LinkedHashMap<>();
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            result.put("title", "");
            return result;
        }
        result.put("status", "ok");
        result.put("title", page.title());
        return result;
    }

    /**
     * 等待元素出现（可指定超时）。
     * @param selector CSS 选择器
     * @param timeoutMs 超时毫秒数
     * @return 执行结果
     */
    public Map<String, Object> waitForElement(String selector, int timeoutMs) {
        log.info("[UI] waitForElement: {} timeout={}ms", selector, timeoutMs);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("selector", selector);
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            return result;
        }
        page.waitForSelector(selector, new Page.WaitForSelectorOptions()
                .setState(WaitForSelectorState.VISIBLE)
                .setTimeout(timeoutMs));
        result.put("status", "appeared");
        return result;
    }

    /**
     * 截图并保存到 test-output/screenshots/。
     * @param fileName 截图文件名（不含扩展名）
     * @return 含 screenshotPath 字段的结果
     */
    public Map<String, Object> takeScreenshot(String fileName) {
        log.info("[UI] takeScreenshot: {}", fileName);
        Map<String, Object> result = new LinkedHashMap<>();
        Page page = getPage();
        if (page == null) {
            result.put("status", "skipped");
            return result;
        }
        String path = "test-output/screenshots/" + fileName + ".png";
        page.screenshot(new Page.ScreenshotOptions()
                .setPath(java.nio.file.Paths.get(path))
                .setFullPage(true));
        result.put("status", "captured");
        result.put("screenshotPath", path);
        return result;
    }

    // ===================== 内部方法 =====================

    /**
     * 获取 Playwright Page 对象（demo 模式返回 null）。
     */
    private Page getPage() {
        if (playwrightEngine == null || !playwrightEngine.isEnabled()) {
            return null;
        }
        return playwrightEngine.page();
    }
}
