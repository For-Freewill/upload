package com.e2e.framework.data;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.e2e.framework.model.TestDataBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Excel 模版装载器（EasyExcel 实现）—— 读取《E2E Test Scenarios.xlsx》结构：
 * <ul>
 *   <li>Scenarios：场景定义（表头 + 数据行）；</li>
 *   <li>Steps：步骤定义（表头 + 数据行，ENBALED 拼写自动容错）；</li>
 *   <li>_GlobalConfig：全局变量键值对（无表头，A 列 key / B 列 value）。</li>
 * </ul>
 *
 * <p>使用 EasyExcel 的 {@code doReadAll} 一次性读入全部工作表（headRowNumber(0) 关闭内置表头解析，
 * 表头归一化由本类自行完成，保证与 YAML 数据源行为一致）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ExcelTestDataLoader implements TestDataLoader {

    private static final Logger log = LoggerFactory.getLogger(ExcelTestDataLoader.class);

    private final String path;
    private final boolean strict;

    public ExcelTestDataLoader(String path, boolean strict) {
        this.path = path;
        this.strict = strict;
    }

    @Override
    public String sourceName() {
        return "excel:" + path;
    }

    @Override
    public TestDataBundle load() {
        log.info("从 Excel 模版加载数据: {}", path);
        // EasyExcel 基于 File 读取（headRowNumber(0) + 多 Sheet 全量收集）
        Path local = materialize();
        try {
            Map<String, List<Map<Integer, String>>> sheets = readAllSheets(local);
            List<Map<String, String>> scenarioRows = tableRows(sheets, "Scenarios");
            List<Map<String, String>> stepRows = tableRows(sheets, "Steps");
            Map<String, String> globalConfig = keyValueRows(sheets, "GlobalConfig");

            if (scenarioRows == null || stepRows == null) {
                throw new E2EDataException("模版缺少 Scenarios 或 Steps 工作表: " + path);
            }

            TestDataBundle bundle = new TestDataAssembler(sourceName(), strict)
                    .assemble(scenarioRows, stepRows, globalConfig);

            log.info("加载完成: {} 个场景, {} 个步骤, {} 个全局变量, {} 条数据质量提示",
                    bundle.getScenarios().size(),
                    bundle.getScenarios().values().stream().mapToInt(s -> s.getSteps().size()).sum(),
                    bundle.getGlobalConfig().size(),
                    bundle.getIssues().size());
            return bundle;
        } finally {
            try {
                Files.deleteIfExists(local);
            } catch (IOException ignore) {
                // 临时文件清理失败不影响主流程
            }
        }
    }

    // ---------------- EasyExcel 读取 ----------------

    /** classpath/file 数据源物化为本地临时文件（EasyExcel 按文件读取最稳，且自动识别 .xlsx） */
    private Path materialize() {
        try (InputStream in = ResourcePathResolver.open(path)) {
            Path temp = Files.createTempFile("e2e-excel-", ".xlsx");
            Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
            return temp;
        } catch (IOException e) {
            throw new E2EDataException("读取 Excel 失败: " + path + " (" + e.getMessage() + ")", e);
        }
    }

    /** doReadAll + 单监听器：按工作表名分组收集所有行（Map<列号, 单元格文本>） */
    private Map<String, List<Map<Integer, String>>> readAllSheets(Path file) {
        Map<String, List<Map<Integer, String>>> sheets = new LinkedHashMap<>();
        EasyExcel.read(file.toFile(), new RowCollectListener(sheets))
                .headRowNumber(0) // 全部行作为数据行（表头归一化由本类自行处理）
                .doReadAll();
        return sheets;
    }

    /** EasyExcel 行收集监听器：无模型读取时每行为 Map<列号, 值> */
    private static final class RowCollectListener implements ReadListener<Object> {

        private final Map<String, List<Map<Integer, String>>> sink;

        private RowCollectListener(Map<String, List<Map<Integer, String>>> sink) {
            this.sink = sink;
        }

        @Override
        @SuppressWarnings("unchecked")
        public void invoke(Object row, AnalysisContext context) {
            if (!(row instanceof Map<?, ?> raw)) {
                return;
            }
            String sheetName = context.readSheetHolder().getSheetName();
            Map<Integer, String> values = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : ((Map<Object, Object>) raw).entrySet()) {
                if (e.getKey() instanceof Integer col) {
                    values.put(col, e.getValue() == null ? "" : String.valueOf(e.getValue()).trim());
                }
            }
            sink.computeIfAbsent(sheetName == null ? "" : sheetName, k -> new ArrayList<>()).add(values);
        }

        @Override
        public void doAfterAllAnalysed(AnalysisContext context) {
            // 单 Sheet 读毕回调（汇总在 sink 中）
        }
    }

    // ---------------- 结构解析（与 POI 版行为一致） ----------------

    /** 按名称查找工作表（忽略大小写与下划线前缀），返回其行数据 */
    static List<Map<Integer, String>> findSheet(Map<String, List<Map<Integer, String>>> sheets, String name) {
        String target = name.toUpperCase(Locale.ROOT).replaceFirst("^_", "");
        for (Map.Entry<String, List<Map<Integer, String>>> e : sheets.entrySet()) {
            String sheetName = e.getKey().trim().toUpperCase(Locale.ROOT).replaceFirst("^_", "");
            if (sheetName.equals(target)) {
                return e.getValue();
            }
        }
        return null;
    }

    /** 表格式工作表：首行为表头，返回每行的 键-值 Map（表头归一化为大写无符号） */
    static List<Map<String, String>> tableRows(Map<String, List<Map<Integer, String>>> sheets, String name) {
        List<Map<Integer, String>> sheet = findSheet(sheets, name);
        if (sheet == null) {
            return null;
        }
        List<Map<String, String>> rows = new ArrayList<>();
        if (sheet.isEmpty()) {
            return rows;
        }
        Map<Integer, String> headerRow = sheet.get(0);
        int colCount = columnCount(headerRow);
        List<String> headers = new ArrayList<>();
        for (int c = 0; c < colCount; c++) {
            String h = headerRow.getOrDefault(c, "");
            // 归一化：大写 + 去下划线/连字符/前导下划线（Scenario_ID -> SCENARIOID）
            h = h.trim().toUpperCase(Locale.ROOT)
                    .replaceFirst("^_", "").replace("_", "").replace("-", "");
            // 模版拼写容错: ENBALED -> ENABLED
            if ("ENBALED".equals(h)) {
                h = "ENABLED";
            }
            headers.add(h);
        }
        for (int r = 1; r < sheet.size(); r++) {
            Map<Integer, String> row = sheet.get(r);
            Map<String, String> map = new LinkedHashMap<>();
            boolean hasValue = false;
            for (int c = 0; c < headers.size(); c++) {
                String value = row.getOrDefault(c, "");
                map.put(headers.get(c), value);
                hasValue = hasValue || !value.isEmpty();
            }
            if (hasValue) {
                rows.add(map);
            }
        }
        return rows;
    }

    /** 键值对工作表（_GlobalConfig）：A 列 key / B 列 value，无表头 */
    static Map<String, String> keyValueRows(Map<String, List<Map<Integer, String>>> sheets, String name) {
        Map<String, String> config = new LinkedHashMap<>();
        List<Map<Integer, String>> sheet = findSheet(sheets, name);
        if (sheet == null) {
            return config;
        }
        for (Map<Integer, String> row : sheet) {
            String key = row.getOrDefault(0, "");
            String value = row.getOrDefault(1, "");
            if (key != null && !key.isBlank()) {
                config.put(key.trim(), value == null ? "" : value.trim());
            }
        }
        return config;
    }

    private static int columnCount(Map<Integer, String> headerRow) {
        int max = -1;
        for (Integer c : headerRow.keySet()) {
            if (c != null && c > max) {
                max = c;
            }
        }
        return max + 1;
    }
}
