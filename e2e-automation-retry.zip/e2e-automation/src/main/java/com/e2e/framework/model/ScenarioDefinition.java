package com.e2e.framework.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 场景定义 —— 对应模版 Scenarios 表一行。
 *
 * <p>字段与模版列的映射：Seq / Scenario_ID / Scenario_Name / Enabled / Tags / Env / Timeout / Description / Owner。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ScenarioDefinition {

    private final int seqNo;
    private final String scenarioId;
    private final String name;
    private final boolean enabled;
    private final List<String> tags;
    private final String env;
    private final int timeoutSeconds;
    private final String description;
    private final String owner;
    private final List<StepDefinition> steps = new ArrayList<>();

    public ScenarioDefinition(int seqNo, String scenarioId, String name, boolean enabled, List<String> tags,
                              String env, int timeoutSeconds, String description, String owner) {
        this.seqNo = seqNo;
        this.scenarioId = scenarioId;
        this.name = name;
        this.enabled = enabled;
        this.tags = tags == null ? List.of() : tags;
        this.env = env;
        this.timeoutSeconds = timeoutSeconds;
        this.description = description;
        this.owner = owner;
    }

    /** 兼容旧调用（无 seqNo） */
    public ScenarioDefinition(String scenarioId, String name, boolean enabled, List<String> tags,
                              String env, int timeoutSeconds, String description, String owner) {
        this(0, scenarioId, name, enabled, tags, env, timeoutSeconds, description, owner);
    }

    public int getSeqNo() { return seqNo; }
    public String getScenarioId() { return scenarioId; }
    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }
    public List<String> getTags() { return tags; }
    public String getEnv() { return env; }
    public int getTimeoutSeconds() { return timeoutSeconds; }
    public String getDescription() { return description == null ? "" : description; }
    public String getOwner() { return owner; }
    public List<StepDefinition> getSteps() { return steps; }

    public void addStep(StepDefinition step) { this.steps.add(step); }

    @Override
    public String toString() { return scenarioId; }
}
