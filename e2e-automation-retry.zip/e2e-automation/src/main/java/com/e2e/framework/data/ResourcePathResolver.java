package com.e2e.framework.data;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 资源路径解析：支持 classpath: / file: 前缀与绝对/相对路径
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public final class ResourcePathResolver {

    private ResourcePathResolver() {
    }

    /** 按路径规范打开输入流 */
    public static InputStream open(String path) {
        if (path == null || path.isBlank()) {
            throw new E2EDataException("数据源路径为空");
        }
        String p = path.trim();
        if (p.toLowerCase().startsWith("classpath:")) {
            String resource = p.substring("classpath:".length()).replace('\\', '/');
            InputStream in = ResourcePathResolver.class.getClassLoader().getResourceAsStream(resource);
            if (in == null) {
                throw new E2EDataException("classpath 资源不存在: " + resource);
            }
            return in;
        }
        if (p.toLowerCase().startsWith("file:")) {
            p = p.substring("file:".length());
            if (p.startsWith("/") && System.getProperty("os.name", "").toLowerCase().contains("win")) {
                p = p.substring(1);
            }
        }
        try {
            return Files.newInputStream(Paths.get(p));
        } catch (IOException e) {
            throw new E2EDataException("无法打开数据文件: " + p + " (" + e.getMessage() + ")", e);
        }
    }

    /**
     * 文本型资源（如 MQ 报文 XML）读取：无前缀时先按 payloadBase（classpath: 或 file:）解析，
     * 再回退文件系统。
     */
    public static String readText(String ref, String base) {
        String resolved = ref;
        boolean fromClasspath = false;
        if (ref.toLowerCase().startsWith("classpath:") || ref.toLowerCase().startsWith("file:")) {
            resolved = ref;
        } else if (base != null && !base.isBlank()) {
            resolved = base.endsWith("/") || base.endsWith(":") ? base + ref : base + "/" + ref;
            fromClasspath = base.toLowerCase().startsWith("classpath:");
        }
        try (InputStream in = fromClasspath
                ? ResourcePathResolver.class.getClassLoader().getResourceAsStream(resolved.substring("classpath:".length()).replace('\\', '/'))
                : open(resolved)) {
            if (in == null) {
                // 回退：按文件系统直接读
                Path fsPath = Paths.get(ref);
                if (Files.exists(fsPath)) {
                    return Files.readString(fsPath);
                }
                throw new E2EDataException("报文文件不存在: " + ref + "（基准目录 " + base + "）");
            }
            return new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new E2EDataException("读取报文文件失败: " + ref + " (" + e.getMessage() + ")", e);
        }
    }
}
