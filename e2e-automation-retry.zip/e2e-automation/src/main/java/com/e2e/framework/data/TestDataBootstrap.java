package com.e2e.framework.data;

import com.e2e.framework.config.E2EProperties;

/**
 * 数据装载引导（Spring 与 TestNG 两侧共用的工厂）。
 *
 * <p>命令行系统属性优先级高于 application.yml：
 * <ul>
 *   <li>-De2e.data.source=excel|yaml</li>
 *   <li>-De2e.data.excel.path=C:/path/E2E Test Scenarios.xlsx（支持 classpath:/file:/绝对路径）</li>
 *   <li>-De2e.data.yaml.path=...</li>
 *   <li>-De2e.strict=true</li>
 * </ul>
 *
 * <p>JSON 解析统一走 fastjson2 静态 API（JSON/JSONObject），无需注入解析器实例。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public final class TestDataBootstrap {

    private TestDataBootstrap() {
    }

    /** 不依赖 Spring 容器的装载器创建（TestNG DataProvider 在容器外先行执行） */
    public static TestDataLoader createLoader() {
        String source = sysProp("e2e.data.source", "excel").toLowerCase();
        boolean strict = Boolean.parseBoolean(sysProp("e2e.strict", "false"));
        if ("yaml".equals(source)) {
            String path = sysProp("e2e.data.yaml.path", "classpath:e2e/scenarios.yml");
            return new YamlTestDataLoader(path, strict);
        }
        String path = sysProp("e2e.data.excel.path", "classpath:e2e/E2E-Test-Scenarios.xlsx");
        return new ExcelTestDataLoader(path, strict);
    }

    /** Spring 容器内的装载器 Bean（配置属性 + 系统属性覆盖） */
    public static TestDataLoader createLoader(E2EProperties props) {
        String source = sysProp("e2e.data.source", props.getData().getSource()).toLowerCase();
        boolean strict = Boolean.parseBoolean(sysProp("e2e.strict", String.valueOf(props.isStrict())));
        if ("yaml".equals(source)) {
            String path = sysProp("e2e.data.yaml.path", props.getData().getYaml().getPath());
            return new YamlTestDataLoader(path, strict);
        }
        String path = sysProp("e2e.data.excel.path", props.getData().getExcel().getPath());
        return new ExcelTestDataLoader(path, strict);
    }

    private static String sysProp(String key, String defaultValue) {
        String v = System.getProperty(key);
        return v == null || v.isBlank() ? defaultValue : v;
    }
}
