package com.e2e.framework.actions.compare;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * SMARTS 域：COMMON_DATA_COMPARE —— 双数据源比对（迁移验证 / 一致性校验）。
 *
 * <h3>INPUT 格式（sourceA / sourceB 各支持 db / file / http）</h3>
 * <pre>
 * // ★ 跨环境 DB vs DB（prod vs pre-prod 同表比对，env 引用 e2e.compare.envs.* 配置）
 * [{"COMPARE":{
 *   "sourceA":{"type":"db","env":"prod","sql":"SELECT id,name,status FROM users ORDER BY id"},
 *   "sourceB":{"type":"db","env":"pre-prod","sql":"SELECT id,name,status FROM users ORDER BY id"},
 *   "ignoreOrder":true
 * }}]
 *
 * // 内联连接参数（无需预配置）
 * [{"COMPARE":{
 *   "sourceA":{"type":"db","url":"jdbc:mysql://prod-host:3306/userdb","user":"r","password":"x",
 *              "driver":"com.mysql.cj.jdbc.Driver","sql":"SELECT id,name FROM users"},
 *   "sourceB":{"type":"db","url":"jdbc:mysql://pre-host:3306/userdb","user":"r","password":"y",
 *              "sql":"SELECT id,name FROM users"}
 * }}]
 *
 * // 默认数据源 DB vs DB（向后兼容，用框架 DbClient）
 * [{"COMPARE":{
 *   "sourceA":{"type":"db","sql":"SELECT id,name FROM src_table"},
 *   "sourceB":{"type":"db","sql":"SELECT id,name FROM dst_table"},
 *   "ignoreOrder":true
 * }}]
 *
 * // 文件 vs 文件（逐行比对）
 * [{"COMPARE":{
 *   "sourceA":{"type":"file","path":"test-output/expected.csv"},
 *   "sourceB":{"type":"file","path":"test-output/actual.csv"}
 * }}]
 *
 * // 前序步骤输出 vs 文件（HTTP body 与期望文件比对）
 * [{"COMPARE":{
 *   "sourceA":{"type":"http","from":"body"},
 *   "sourceB":{"type":"file","path":"test-output/expected.json"}
 * }}]
 * </pre>
 *
 * <p>DB 数据源三级路由：① {@code env} 命名环境（e2e.compare.envs.*）→ ② 内联 {@code url/user/password}
 * → ③ 默认 DbClient（向后兼容）。行格式为 {@code {列名=值, ...}}，列序由 SQL SELECT 顺序保证跨环境可比。
 *
 * <p>输出（可断言）：{@code equal} / {@code onlyInA} / {@code onlyInB} / {@code diffCount}
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"SMARTS"}, action = "COMMON_DATA_COMPARE",
            description = "双数据源比对（db/file/http × db/file/http，忽略行序可选）")
public class CommonDataCompareAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonDataCompareAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("COMPARE");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 COMPARE 协议载荷: [{\"COMPARE\":{\"sourceA\":{...},\"sourceB\":{...}}}]");
        }
        JSONObject srcA = p.getJSONObject("sourceA");
        JSONObject srcB = p.getJSONObject("sourceB");
        if (srcA == null || srcB == null) {
            return ActionResult.fail("COMPARE 载荷需要 sourceA + sourceB 两个数据源");
        }
        boolean ignoreOrder = !p.containsKey("ignoreOrder") || p.getBooleanValue("ignoreOrder");

        try {
            List<String> dataA = loadData(context, srcA, "A");
            List<String> dataB = loadData(context, srcB, "B");

            Map<String, Object> outputs = new LinkedHashMap<>();
            outputs.put("countA", dataA.size());
            outputs.put("countB", dataB.size());

            // ① 完全相等快速路径
            if (dataA.equals(dataB)) {
                outputs.put("equal", true);
                outputs.put("diffCount", 0);
                outputs.put("onlyInA", List.of());
                outputs.put("onlyInB", List.of());
                log.info("  DATA COMPARE: 完全一致 ({} 行)", dataA.size());
                return ActionResult.ok("数据比对一致 (" + dataA.size() + " 行)", outputs);
            }

            // ② 差异计算
            List<String> onlyInA = new ArrayList<>(dataA);
            onlyInA.removeAll(dataB);
            List<String> onlyInB = new ArrayList<>(dataB);
            onlyInB.removeAll(dataA);
            int diffCount = onlyInA.size() + onlyInB.size();

            outputs.put("equal", false);
            outputs.put("diffCount", diffCount);
            outputs.put("onlyInA", abbreviateList(onlyInA));
            outputs.put("onlyInB", abbreviateList(onlyInB));
            log.info("  DATA COMPARE: 不一致 diffCount={} (onlyInA={}, onlyInB={})",
                    diffCount, onlyInA.size(), onlyInB.size());
            return ActionResult.fail("数据比对不一致: 差异 " + diffCount + " 条"
                    + "（仅A有 " + onlyInA.size() + "，仅B有 " + onlyInB.size() + "）", outputs);

        } catch (Exception e) {
            return ActionResult.fail("数据比对异常: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /** 按数据源类型加载数据为字符串行列表 */
    private List<String> loadData(ActionContext context, JSONObject src, String label) throws Exception {
        String type = src.getString("type");
        if (type == null) type = "db";
        switch (type.toLowerCase()) {
            case "db" -> {
                String sql = src.getString("sql");
                if (sql == null || sql.isBlank()) throw new IllegalArgumentException("source" + label + " 缺少 sql");
                // ① env 命名环境（如 prod / pre-prod，配置于 e2e.compare.envs.*）
                String env = src.getString("env");
                // ② 内联连接参数（url/user/password/driver）
                String inlineUrl = src.getString("url");
                if (env != null && !env.isBlank()) {
                    return queryByEnv(context, env, sql, label);
                }
                if (inlineUrl != null && !inlineUrl.isBlank()) {
                    return queryInline(src, sql, label);
                }
                // ③ 默认数据源（context DbClient，向后兼容）
                List<Map<String, Object>> rows = context.clients().db().query(sql);
                return rowsToStrings(rows);
            }
            case "file" -> {
                String path = src.getString("path");
                if (path == null || path.isBlank()) throw new IllegalArgumentException("source" + label + " 缺少 path");
                java.nio.file.Path resolved = com.e2e.framework.core.FilePathResolver.resolve(path);
                if (!Files.exists(resolved)) throw new IllegalArgumentException("source" + label + " 文件不存在: " + path);
                return Files.readAllLines(resolved, StandardCharsets.UTF_8);
            }
            case "http", "output" -> {
                String from = src.getString("from");
                if (from == null || from.isBlank()) from = "body";
                Object value = context.getVar(from);
                if (value == null) value = context.getVar("HTTP_BODY");
                if (value == null) throw new IllegalArgumentException("source" + label + " 未找到输出变量: " + from);
                String content = String.valueOf(value);
                List<String> lines = new ArrayList<>();
                for (String line : content.split("\n")) {
                    if (!line.isBlank()) lines.add(line.trim());
                }
                return lines;
            }
            default -> throw new IllegalArgumentException("不支持的数据源类型: " + type + "（db/file/http）");
        }
    }

    /** 按命名环境查询（e2e.compare.envs.{env} 配置的 JDBC 连接） */
    private List<String> queryByEnv(ActionContext context, String env, String sql, String label) throws Exception {
        var dbEnv = context.props().getCompare().getEnvs().get(env);
        if (dbEnv == null || dbEnv.getUrl() == null || dbEnv.getUrl().isBlank()) {
            throw new IllegalArgumentException("source" + label + " 环境未配置: '" + env
                    + "'（请在 e2e.compare.envs." + env + " 配置 url/user/password）");
        }
        log.info("  DATA COMPARE source{} 使用环境 '{}' ({})", label, env, maskUrl(dbEnv.getUrl()));
        return queryJdbc(dbEnv.getUrl(), dbEnv.getDriver(), dbEnv.getUser(), dbEnv.getPassword(), sql);
    }

    /** 按内联连接参数查询（载荷 url/user/password） */
    private List<String> queryInline(JSONObject src, String sql, String label) throws Exception {
        String url = src.getString("url");
        String driver = src.getString("driver") == null ? "" : src.getString("driver");
        String user = src.getString("user") == null ? "" : src.getString("user");
        String password = src.getString("password") == null ? "" : src.getString("password");
        log.info("  DATA COMPARE source{} 使用内联连接 ({})", label, maskUrl(url));
        return queryJdbc(url, driver, user, password, sql);
    }

    /** ad-hoc JDBC 查询（每次新建连接，命令式短连接语义） */
    private List<String> queryJdbc(String url, String driver, String user, String password, String sql) throws Exception {
        if (driver != null && !driver.isBlank()) {
            Class.forName(driver);
        }
        try (var conn = java.sql.DriverManager.getConnection(url, user, password);
             var stmt = conn.prepareStatement(sql);
             var rs = stmt.executeQuery()) {
            var meta = rs.getMetaData();
            int colCount = meta.getColumnCount();
            List<String> lines = new ArrayList<>();
            while (rs.next()) {
                // 行转「列名=值」有序字符串（列序由 SQL SELECT 顺序保证，跨环境可比）
                StringBuilder sb = new StringBuilder("{");
                for (int i = 1; i <= colCount; i++) {
                    if (i > 1) sb.append(", ");
                    sb.append(meta.getColumnLabel(i)).append('=').append(rs.getString(i));
                }
                sb.append('}');
                lines.add(sb.toString());
            }
            return lines;
        }
    }

    /** 查询结果行列表转字符串 */
    private List<String> rowsToStrings(List<Map<String, Object>> rows) {
        List<String> lines = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            lines.add(row.toString());
        }
        return lines;
    }

    /** URL 脱敏（隐藏密码，保留 host:port/db 结构） */
    private static String maskUrl(String url) {
        if (url == null) return "";
        int schemeEnd = url.indexOf("//");
        if (schemeEnd < 0) return url;
        return url.substring(0, schemeEnd + 2) + "***@" + url.substring(schemeEnd + 2);
    }

    private List<String> abbreviateList(List<String> list) {
        return list.size() > 20 ? list.subList(0, 20) : list;
    }
}
