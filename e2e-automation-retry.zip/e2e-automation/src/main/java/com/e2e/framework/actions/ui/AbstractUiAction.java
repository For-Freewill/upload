package com.e2e.framework.actions.ui;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.ui.PlaywrightUiEngine;
import com.e2e.framework.protocol.ui.UiAction;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JAVA 协议 UI 单点操作通用骨架 —— 三层路由：
 *
 * <ol>
 *   <li><b>UiAction 处理器</b>（优先）：INPUT 中 url 字段指向 {@code UiActionRegistry} 的注册名（@UiHandler），
 *       params 透传给 UI 处理器；处理器返回的变量进入步骤 outputs。</li>
 *   <li><b>Playwright 反射</b>：INPUT 中 engine="playwright" 时，直接在 Playwright Page 对象上
 *       通过反射调用指定方法（navigate / click / fill / textContent 等）。</li>
 *   <li><b>子类业务逻辑</b>：子类可覆盖 doExecute() 实现自定义逻辑。</li>
 * </ol>
 *
 * <p>INPUT 格式：
 * <pre>
 * // 方式 1：UiAction 处理器（向后兼容）
 * [{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":{"action":"navigate","target":"/reports"}}}]
 *
 * // 方式 2：Playwright 反射调用
 * [{"JAVA":{"engine":"playwright","method":"navigate","params":["http://example.com"]}}]
 * [{"JAVA":{"engine":"playwright","method":"fill","params":["#search-box","test keyword"]}}]
 * [{"JAVA":{"engine":"playwright","method":"textContent","params":["#result-count"]}}]
 *
 * // 方式 3：自定义子类逻辑
 * [{"JAVA":{"url":"处理器名","params":"..."}}]
 * </pre>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public abstract class AbstractUiAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(AbstractUiAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("JAVA");
        if (payload == null) {
            return ActionResult.fail("需要 JAVA 协议载荷: [{\"JAVA\":{\"url\":\"处理器名\"}}] 或 [{\"JAVA\":{\"engine\":\"playwright\",\"method\":\"navigate\"}}]");
        }
        JSONObject params = payload.paramsAsObject();

        // 路由 1：engine 字段 → Playwright/Selenium 反射
        String engine = params.getString("engine");
        if (engine != null && !engine.isBlank()) {
            return invokeViaReflection(context, params, engine);
        }

        // 路由 2：url 字段 → UiAction 处理器
        String handlerName = params.getString("url");
        if (handlerName != null && !handlerName.isBlank()) {
            return invokeUiHandler(context, params, handlerName);
        }

        // 路由 3：子类自定义
        return doExecute(context, params);
    }

    // ===================== Playwright 反射 =====================

    private ActionResult invokeViaReflection(ActionContext context, JSONObject params, String engine) {
        String method = params.getString("method");
        if (method == null || method.isBlank()) {
            return ActionResult.fail("engine 模式需要 method 字段");
        }

        Object target = resolveEngineTarget(context, engine);
        if (target == null) {
            return ActionResult.fail("引擎未启用: '" + engine + "'（检查 e2e.mode=live 和 e2e.ui.browser 配置）");
        }

        // 解析参数
        Object rawParamsObj = params.get("params");
        Object[] args;
        if (rawParamsObj instanceof com.alibaba.fastjson2.JSONArray arr) {
            args = new Object[arr.size()];
            for (int i = 0; i < arr.size(); i++) {
                Object v = arr.get(i);
                args[i] = (v instanceof com.alibaba.fastjson2.JSONObject || v instanceof com.alibaba.fastjson2.JSONArray)
                        ? v : String.valueOf(v);
            }
        } else if (rawParamsObj != null) {
            args = new Object[]{String.valueOf(rawParamsObj)};
        } else {
            args = new Object[0];
        }

        // 反射查找方法
        Method methodRef = findMethod(target.getClass(), method, args);
        if (methodRef == null) {
            return ActionResult.fail("Playwright 方法未找到: " + target.getClass().getSimpleName()
                    + "." + method + "(" + describeArgs(args) + ")");
        }

        try {
            methodRef.setAccessible(true);
            log.info("  [{}] 反射调用: {}.{}({})", engine, target.getClass().getSimpleName(), method, describeArgs(args));
            Object result = methodRef.invoke(target, args);

            Map<String, Object> outputs = new LinkedHashMap<>();
            outputs.put("JAVA", "OK");
            outputs.put("method", method);
            outputs.put("engine", engine);
            if (result != null) {
                outputs.put("result", result);
                outputs.put("resultType", result.getClass().getSimpleName());
            }
            return ActionResult.ok(engine + "." + method + "() 完成" + (result != null ? " → " + result : ""), outputs);
        } catch (Exception e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            log.error("  [{}] 反射调用异常: {}", engine, cause.getMessage());
            return ActionResult.fail(engine + "." + method + " 异常: " + cause.getMessage());
        }
    }

    private Object resolveEngineTarget(ActionContext context, String engine) {
        return switch (engine.toLowerCase()) {
            case "playwright", "browser", "page" -> {
                var uiRegistry = context.clients().ui();
                // 从 Spring 上下文获取 PlaywrightUiEngine
                try {
                    var bootstrap = com.e2e.framework.bootstrap.E2ESpringBootstrap.getInstance();
                    PlaywrightUiEngine uiEngine = bootstrap.getBean(PlaywrightUiEngine.class);
                    if (uiEngine != null && uiEngine.isEnabled()) {
                        yield uiEngine.page();
                    }
                } catch (Exception ignored) {}
                yield null;
            }
            default -> null;
        };
    }

    private Method findMethod(Class<?> clazz, String methodName, Object[] args) {
        int argCount = args.length;
        // 优先精确匹配
        for (Method m : clazz.getMethods()) {
            if (!m.getName().equals(methodName)) continue;
            if (m.getParameterCount() != argCount) continue;
            boolean ok = true;
            for (int i = 0; i < argCount; i++) {
                Class<?> pt = m.getParameterTypes()[i];
                if (args[i] != null && !pt.isInstance(args[i]) && pt != String.class && pt != Object.class) {
                    // 尝试字符串转换
                    if (pt == int.class || pt == Integer.class) {
                        try { Integer.parseInt(String.valueOf(args[i])); } catch (Exception e) { ok = false; break; }
                    } else if (pt == boolean.class || pt == Boolean.class) {
                        // ok
                    } else {
                        ok = false; break;
                    }
                }
            }
            if (ok) return m;
        }
        return null;
    }

    // ===================== UiHandler 向后兼容 =====================

    private ActionResult invokeUiHandler(ActionContext context, JSONObject params, String handlerName) {
        Object rawParamsObj = params.get("params");
        String rawParams = rawParamsObj == null ? ""
                : (rawParamsObj instanceof String s ? s : JSON.toJSONString(rawParamsObj));

        UiAction handler = context.clients().ui().lookup(handlerName);
        if (handler == null) {
            return ActionResult.fail("未注册的 UI 处理器: '" + handlerName + "'。已注册: "
                    + context.clients().ui().describe()
                    + "。注册方式：实现 UiAction 并标注 @UiHandler(\"" + handlerName + "\")");
        }
        Map<String, Object> handlerOutputs = handler.execute(rawParams);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("JAVA", "OK");
        outputs.putAll(handlerOutputs);
        return ActionResult.ok(businessName() + " 通过 UI 处理器 '" + handlerName + "' 完成, params=" + rawParams, outputs);
    }

    // ===================== 子类扩展点 =====================

    /** 子类可覆盖，实现自定义业务逻辑（默认返回 DATA_ERROR） */
    protected ActionResult doExecute(ActionContext context, JSONObject params) {
        return ActionResult.fail("JAVA 载荷需指定 url（UiHandler）或 engine（playwright）或 method+bean/class");
    }

    protected abstract String businessName();

    private String describeArgs(Object[] args) {
        if (args.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(args[i] == null ? "null" : "\"" + args[i] + "\"");
        }
        return sb.toString();
    }
}
