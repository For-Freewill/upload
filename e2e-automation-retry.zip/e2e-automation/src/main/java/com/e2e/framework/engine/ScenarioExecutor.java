package com.e2e.framework.engine;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.data.VariableResolver;
import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.results.ScenarioResult;
import com.e2e.framework.model.results.ScenarioStatus;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.model.results.StepStatus;
import com.e2e.framework.protocol.ProtocolClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 场景执行器 —— 数据驱动 E2E 场景的完整执行编排。
 *
 * <p>流程：DAG 依赖解析 -> 逐层执行（可配并行）-> 汇总结果。
 * STOP / SCREENSHOT 失败终止剩余步骤；CONTINUE 失败不终止。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class ScenarioExecutor {

    private static final Logger log = LoggerFactory.getLogger(ScenarioExecutor.class);

    private final DagResolver dagResolver;
    private final StepExecutor stepExecutor;
    private final VariableResolver resolver;
    private final ProtocolClients clients;
    private final E2EProperties props;
    private final ExecutorService scenarioPool;

    public ScenarioExecutor(DagResolver dagResolver, StepExecutor stepExecutor, VariableResolver resolver,
                            ProtocolClients clients, E2EProperties props,
                            @Qualifier("e2eScenarioPool") ExecutorService scenarioPool) {
        this.dagResolver = dagResolver;
        this.stepExecutor = stepExecutor;
        this.resolver = resolver;
        this.clients = clients;
        this.props = props;
        this.scenarioPool = scenarioPool;
    }

    public ScenarioResult execute(ScenarioDefinition scenario) {
        log.info("==========================================================");
        log.info("场景开始: {} ({}) env={} owner={} timeout={}s",
                scenario.getScenarioId(), scenario.getName(), scenario.getEnv(),
                scenario.getOwner(), scenario.getTimeoutSeconds());
        ScenarioResult result = new ScenarioResult(scenario);
        long start = System.currentTimeMillis();

        if (!scenario.isEnabled()) {
            result.setStatus(ScenarioStatus.SKIPPED);
            result.setMessage("模版 Enabled=N，场景未启用");
            log.info("场景跳过: {}（未启用）", scenario.getScenarioId());
            return result;
        }
        if (scenario.getSteps().isEmpty()) {
            result.setStatus(ScenarioStatus.SKIPPED);
            result.setMessage("孤儿场景：Steps 表中没有该场景的步骤（Scenarios 表已启用但无步骤行）");
            log.warn("场景跳过: {}（无步骤）", scenario.getScenarioId());
            return result;
        }

        Future<Void> future = scenarioPool.submit(() -> {
            doExecute(scenario, result);
            return null;
        });
        int scenarioTimeout = scenario.getTimeoutSeconds() > 0 ? scenario.getTimeoutSeconds() : 1800;
        try {
            future.get(scenarioTimeout + 10L, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            future.cancel(true);
            result.setStatus(ScenarioStatus.TIMEOUT);
            result.setMessage("场景超时（>" + scenarioTimeout + "s）");
        } catch (Exception e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            result.setStatus(ScenarioStatus.ERROR);
            result.setMessage(cause.getClass().getSimpleName() + ": " + cause.getMessage());
        }

        result.setDurationMs(System.currentTimeMillis() - start);
        log.info("场景结束: {} -> {} ({} 步: {} 通过 / {} 失败 / {} 跳过, {}ms)",
                scenario.getScenarioId(), result.getStatus(), result.getStepResults().size(),
                result.passedCount(), result.failedCount(), result.skippedCount(), result.getDurationMs());
        log.info("==========================================================");
        return result;
    }

    private void doExecute(ScenarioDefinition scenario, ScenarioResult result) {
        List<DataQualityIssue> dagIssues = new ArrayList<>();
        List<List<StepDefinition>> levels = dagResolver.resolve(scenario, dagIssues);
        dagIssues.forEach(i -> log.warn("[{}] {}", scenario.getScenarioId(), i));

        ScenarioExecutionContext ctx = new ScenarioExecutionContext(scenario, resolver, clients, props);
        int parallel = Math.max(1, props.getExecutor().getParallelThreads());

        for (List<StepDefinition> level : levels) {
            if (ctx.isAborted()) {
                for (StepDefinition step : level) {
                    result.addStepResult(skipped(step, "前置 STOP 失败，未执行"));
                }
                continue;
            }
            if (parallel > 1 && level.size() > 1) {
                executeLevelParallel(level, ctx, result);
            } else {
                executeLevelSequential(level, ctx, result);
            }
            if (ctx.isAborted()) {
                log.warn("[{}] ON_FAILURE=STOP/SCREENSHOT 已触发，后续步骤将跳过", scenario.getScenarioId());
            }
        }

        summarize(result);
        ctx.markEnd(); // 标记上下文生命周期结束
        log.info("[{}] 上下文摘要: {}", scenario.getScenarioId(), ctx.summarize());
    }

    private void executeLevelSequential(List<StepDefinition> level, ScenarioExecutionContext ctx, ScenarioResult result) {
        for (StepDefinition step : level) {
            StepResult r = stepExecutor.execute(step, ctx);
            result.addStepResult(r);
            if (r.getStatus().isTerminalFailure() && step.getOnFailure().isStopOnFailure()) {
                ctx.abort(); // STOP / SCREENSHOT / RETRY 耗尽 / SAVE_EVIDENCE
            }
        }
    }

    private void executeLevelParallel(List<StepDefinition> level, ScenarioExecutionContext ctx, ScenarioResult result) {
        log.info("  == 并行执行依赖层: {}（{} 个步骤）",
                level.stream().map(StepDefinition::getStepId).toList(), level.size());
        List<StepResult> collected = java.util.Collections.synchronizedList(new ArrayList<>());
        List<Thread> workers = new ArrayList<>();
        for (StepDefinition step : level) {
            Thread worker = new Thread(() -> collected.add(stepExecutor.execute(step, ctx)), "e2e-level-worker");
            workers.add(worker);
            worker.start();
        }
        for (Thread w : workers) {
            try {
                w.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        // 按 SEQ_NO 稳定顺序写入结果
        level.forEach(step -> collected.stream()
                .filter(r -> r.getStep().getStepId().equals(step.getStepId()))
                .findFirst()
                .ifPresent(result::addStepResult));
        for (StepResult r : collected) {
            if (r.getStatus().isTerminalFailure() && r.getStep().getOnFailure().isStopOnFailure()) {
                ctx.abort();
            }
        }
    }

    private StepResult skipped(StepDefinition step, String reason) {
        StepResult r = new StepResult(step);
        r.setStatus(StepStatus.SKIPPED);
        r.setMessage(reason);
        return r;
    }

    private void summarize(ScenarioResult result) {
        boolean anyFailed = result.getStepResults().stream().anyMatch(r -> r.getStatus().isTerminalFailure());
        if (anyFailed) {
            result.setStatus(result.getStatus() == ScenarioStatus.TIMEOUT
                    ? ScenarioStatus.TIMEOUT : ScenarioStatus.FAILED);
            result.getStepResults().stream()
                    .filter(r -> r.getStatus().isTerminalFailure())
                    .findFirst()
                    .ifPresent(r -> result.setMessage("首个失败步骤: " + r.getStep().getStepId() + " - "
                            + r.getMessage().split("\n")[0]));
        } else {
            result.setStatus(ScenarioStatus.PASSED);
        }
    }
}
