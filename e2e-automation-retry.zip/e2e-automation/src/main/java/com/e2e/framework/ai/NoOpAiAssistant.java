package com.e2e.framework.ai;

import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.TestDataBundle;
import com.e2e.framework.model.results.ScenarioResult;
import com.e2e.framework.model.results.StepResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * NoOp AI 助手 —— 默认实现，所有方法返回空/null，框架行为与无 AI 时完全一致。
 *
 * <p>当 e2e.ai.enabled=false（默认）或未配置 provider 时，由 {@link AiConfig} 装配为本实现。
 * 这确保 AI 是「可选增强」而非「必选依赖」—— 框架在任何环境下都能开箱即跑。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class NoOpAiAssistant implements AiAssistant,
        AiTestCaseGenerator, AiReportInterpreter, AiStepOptimizer, AiAnomalyDetector {

    private static final Logger log = LoggerFactory.getLogger(NoOpAiAssistant.class);

    @Override
    public AiTestCaseGenerator testCaseGenerator() { return this; }

    @Override
    public AiReportInterpreter reportInterpreter() { return this; }

    @Override
    public AiStepOptimizer stepOptimizer() { return this; }

    @Override
    public AiAnomalyDetector anomalyDetector() { return this; }

    @Override
    public boolean isEnabled() { return false; }

    // ---- AiTestCaseGenerator ----

    @Override
    public Map<String, List<Map<String, String>>> generate(String requirement, Map<String, Object> context) {
        log.debug("[AI-NoOp] testCaseGenerator.generate 被调用但 AI 未启用");
        return Map.of();
    }

    @Override
    public List<String> suggestScenarios(List<String> existingScenarios, Map<String, Object> context) {
        return List.of();
    }

    // ---- AiReportInterpreter ----

    @Override
    public String summarize(List<ScenarioResult> results) {
        return "";
    }

    @Override
    public Map<String, String> analyzeFailures(List<ScenarioResult> failedResults) {
        return Map.of();
    }

    // ---- AiStepOptimizer ----

    @Override
    public List<OptimizationSuggestion> suggest(StepDefinition step, StepResult result, ScenarioDefinition scenario) {
        return List.of();
    }

    // ---- AiAnomalyDetector ----

    @Override
    public List<String> detectDataAnomalies(TestDataBundle bundle) {
        return List.of();
    }

    @Override
    public Map<Integer, String> classifyIssues(List<DataQualityIssue> issues) {
        return Map.of();
    }
}
