package com.e2e.framework.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据装载结果：场景集合（按模版顺序）+ 全局配置 + 数据质量报告。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class TestDataBundle {

    private final Map<String, ScenarioDefinition> scenarios = new LinkedHashMap<>();
    private final Map<String, String> globalConfig = new LinkedHashMap<>();
    private final List<DataQualityIssue> issues = new ArrayList<>();

    public Map<String, ScenarioDefinition> getScenarios() { return scenarios; }
    public Map<String, String> getGlobalConfig() { return globalConfig; }
    public List<DataQualityIssue> getIssues() { return issues; }

    public Map<String, String> getGlobalConfigView() { return Collections.unmodifiableMap(globalConfig); }

    public TestDataBundle merge(DataQualityIssue issue) {
        issues.add(issue);
        return this;
    }
}
