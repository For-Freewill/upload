package com.e2e.framework.model;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;

/**
 * 协议载荷 —— INPUT 列 JSON 数组中的单键对象，如 {"MQ":{"file":"..."}}。
 *
 * <p>protocol 为协议类型（MQ/DB/HTTP/SSH/WINDOWS-CMD/JAVA 等，按模版数据约定大写），
 * params 为该协议的参数体（fastjson2 JSONObject / JSONArray / String，由模版 JSON 决定）。
 * 执行期参数体内的 ${global.x}/${extract.x}/${env.x} 会被变量引擎替换。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ProtocolPayload {

    private final String protocol;
    private final Object params;

    public ProtocolPayload(String protocol, Object params) {
        this.protocol = protocol;
        this.params = params;
    }

    public String getProtocol() { return protocol; }
    public Object getParams() { return params; }

    /** 参数体按对象取（非对象时返回空 JSONObject，不抛错） */
    public JSONObject paramsAsObject() {
        return params instanceof JSONObject ? (JSONObject) params : new JSONObject();
    }

    /** 参数体按数组取（非数组时返回空 JSONArray，不抛错） */
    public JSONArray paramsAsArray() {
        return params instanceof JSONArray ? (JSONArray) params : new JSONArray();
    }

    @Override
    public String toString() { return protocol + ":" + JSON.toJSONString(params); }
}
