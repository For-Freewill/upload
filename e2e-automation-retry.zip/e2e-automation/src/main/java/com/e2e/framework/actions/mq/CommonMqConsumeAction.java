package com.e2e.framework.actions.mq;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * STP 域：COMMON_MQ_CONSUME —— 消费 MQ 队列消息（与 COMMON_MQ_SEND 形成收发闭环）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 消费默认队列（e2e.mq.queue），最多 10 条，等待 5 秒
 * [{"MQ":{"op":"consume","maxMessages":10,"timeout":5}}]
 *
 * // 指定队列
 * [{"MQ":{"op":"consume","queue":"E2E.OUT","maxMessages":5,"timeout":10}}]
 * </pre>
 *
 * <p>demo 模式：消费 StubMqClient 内存队列中 COMMON_MQ_SEND 发送的报文；
 * live 模式：需 MqClient 实现覆盖 consume 方法（如 RocketMQ/IBM MQ）。
 *
 * <p>输出（可断言/EXTRACT）：
 * <ul>
 *   <li>{@code messages} — 消费到的报文列表</li>
 *   <li>{@code messageCount} — 消费条数</li>
 *   <li>{@code firstMessage} / {@code lastMessage} — 首条/末条报文</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"STP"}, action = "COMMON_MQ_CONSUME",
            description = "消费 MQ 队列消息（queue/maxMessages/timeout）")
public class CommonMqConsumeAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonMqConsumeAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("MQ");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 MQ 协议载荷: [{\"MQ\":{\"op\":\"consume\",\"queue\":\"...\",\"maxMessages\":10}}]");
        }
        String queue = p.getString("queue");
        int maxMessages = p.containsKey("maxMessages") ? Integer.parseInt(String.valueOf(p.get("maxMessages")).trim()) : 10;
        // timeout 秒 → 毫秒
        long timeoutMs = p.containsKey("timeout")
                ? (long) (Double.parseDouble(String.valueOf(p.get("timeout")).trim()) * 1000) : 5000;

        try {
            List<String> messages = context.clients().mq().consume(queue, maxMessages, timeoutMs);
            Map<String, Object> outputs = new LinkedHashMap<>();
            outputs.put("messages", messages);
            outputs.put("messageCount", messages.size());
            outputs.put("queue", queue == null || queue.isBlank() ? context.props().getMq().getQueue() : queue);
            if (!messages.isEmpty()) {
                outputs.put("firstMessage", messages.get(0));
                outputs.put("lastMessage", messages.get(messages.size() - 1));
            } else {
                outputs.put("firstMessage", "");
                outputs.put("lastMessage", "");
            }
            log.info("  MQ consume queue={} -> {} messages", outputs.get("queue"), messages.size());
            return ActionResult.ok("MQ 消费 " + messages.size() + " 条 (queue=" + outputs.get("queue") + ")", outputs);
        } catch (UnsupportedOperationException e) {
            return ActionResult.fail("MQ 消费未实现: " + e.getMessage()
                    + "（live 模式请在 MqClient 实现中覆盖 consume 方法）");
        } catch (Exception e) {
            return ActionResult.fail("MQ 消费异常: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
