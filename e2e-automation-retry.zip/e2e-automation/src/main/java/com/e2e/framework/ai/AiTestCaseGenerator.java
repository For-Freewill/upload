package com.e2e.framework.ai;

import java.util.List;
import java.util.Map;

/**
 * AI 测试用例生成器 —— 根据「自然语言描述 / 已有用例 / 接口文档」生成 E2E 测试用例数据。
 *
 * <p>预留接入点：未来可对接 LLM（OpenAI / 通义千问 / DeepSeek 等），
 * 将自然语言需求转化为标准 Scenarios + Steps + _GlobalConfig 三表数据。
 *
 * <p>实现方式：
 * <ol>
 *   <li>实现本接口并注册为 Spring Bean（优先级高于 NoOp）；</li>
 *   <li>或设置 e2e.ai.enabled=true + e2e.ai.features.test-case-generation=true，
 *       框架内置的 HTTP 调用器（见 AiHttpClient）将自动装载。</li>
 * </ol>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface AiTestCaseGenerator {

    /**
     * 根据自然语言描述生成测试用例数据（Scenarios + Steps + GlobalConfig 三表）。
     *
     * @param requirement 自然语言需求描述（如"测试用户注册到下单的完整流程"）
     * @param context    上下文（已有用例、接口文档、APP 域列表等，供 AI 参考）
     * @return 生成的用例数据（键为 sheet 名，值为行数据列表）
     */
    Map<String, List<Map<String, String>>> generate(String requirement, Map<String, Object> context);

    /**
     * 基于已有用例推荐补充场景（边界值、异常路径、组合覆盖等）。
     *
     * @param existingScenarios 已有用例的场景 ID 列表
     * @param context           上下文
     * @return 推荐的新场景描述列表（由人工确认后转为正式用例）
     */
    List<String> suggestScenarios(List<String> existingScenarios, Map<String, Object> context);
}
