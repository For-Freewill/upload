package com.e2e.framework.protocol.ui;

import java.util.Map;

/**
 * JAVA 协议 UI 单点操作 —— INPUT 中 {"JAVA":{"url":"automation.qa.e2e.uiaction1","params":"..."}} 的 url
 * 即 UI 处理器注册名。
 *
 * <p>真实接入：实现本接口并用 @UiHandler("注册名") 标注（Spring 自动注册），
 * 例如封装 Selenium / PlayDriver 的页面操作。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface UiAction {

    /** @return 输出变量（进入步骤 outputs，可供断言与 EXTRACT 使用） */
    Map<String, Object> execute(String params);
}
