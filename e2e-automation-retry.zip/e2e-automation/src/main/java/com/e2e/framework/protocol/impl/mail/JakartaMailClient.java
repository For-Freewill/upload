package com.e2e.framework.protocol.impl.mail;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.MailClient;
import jakarta.activation.DataHandler;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import jakarta.mail.util.ByteArrayDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;

/**
 * MAIL live 实现：基于 jakarta.mail（angus-mail）SMTP 发送。
 *
 * <p>支持纯文本/HTML 正文 + 多收件人(CC) + 附件；
 * 连接参数来自 e2e.mail.* 全局配置。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class JakartaMailClient implements MailClient {

    private static final Logger log = LoggerFactory.getLogger(JakartaMailClient.class);

    private final E2EProperties.Mail mailProps;

    public JakartaMailClient(E2EProperties.Mail mailProps) {
        this.mailProps = mailProps;
    }

    @Override
    public MailResult send(MailSpec spec) {
        try {
            Session session = createSession();
            MimeMessage message = new MimeMessage(session);

            // 发件人
            message.setFrom(new InternetAddress(mailProps.getFrom()));

            // 收件人
            List<String> to = spec.getTo();
            if (to.isEmpty()) {
                return MailResult.fail("缺少收件人（to 字段）");
            }
            for (String addr : to) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(addr));
            }
            // 抄送
            for (String addr : spec.getCc()) {
                message.addRecipient(Message.RecipientType.CC, new InternetAddress(addr));
            }

            // 主题
            message.setSubject(spec.getSubject() == null ? "(no subject)" : spec.getSubject());

            // 正文 + 附件
            List<String> attachments = spec.getAttachmentPaths();
            if (attachments.isEmpty()) {
                // 无附件：直接设置正文
                if (spec.isHtml()) {
                    message.setContent(spec.getBody(), "text/html; charset=UTF-8");
                } else {
                    message.setText(spec.getBody() == null ? "" : spec.getBody(), "UTF-8");
                }
            } else {
                // 有附件：MimeMultipart
                MimeMultipart multipart = new MimeMultipart();
                // 正文
                MimeBodyPart bodyPart = new MimeBodyPart();
                if (spec.isHtml()) {
                    bodyPart.setContent(spec.getBody(), "text/html; charset=UTF-8");
                } else {
                    bodyPart.setText(spec.getBody() == null ? "" : spec.getBody(), "UTF-8");
                }
                multipart.addBodyPart(bodyPart);
                // 附件
                for (String attachmentPath : attachments) {
                    Path path = Paths.get(attachmentPath);
                    if (!Files.exists(path)) {
                        log.warn("[mail] 附件不存在，跳过: {}", attachmentPath);
                        continue;
                    }
                    MimeBodyPart attachPart = new MimeBodyPart();
                    attachPart.setDataHandler(new DataHandler(new ByteArrayDataSource(
                            Files.readAllBytes(path), "application/octet-stream")));
                    attachPart.setFileName(path.getFileName().toString());
                    multipart.addBodyPart(attachPart);
                }
                message.setContent(multipart);
            }

            // 发送
            Transport.send(message);
            String messageId = message.getMessageID() == null ? "" : message.getMessageID();
            log.info("[mail] 已发送 -> {} subject='{}' messageId={}", to, spec.getSubject(), messageId);
            return MailResult.ok("邮件已发送至 " + to, messageId);

        } catch (Exception e) {
            log.error("[mail] 发送失败: {}", e.getMessage());
            return MailResult.fail("邮件发送失败: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    @Override
    public String describe() {
        return "jakarta-mail (live, smtp=" + mailProps.getHost() + ":" + mailProps.getPort() + ")";
    }

    private Session createSession() {
        Properties props = new Properties();
        props.put("mail.smtp.host", mailProps.getHost());
        props.put("mail.smtp.port", String.valueOf(mailProps.getPort()));
        props.put("mail.smtp.auth", String.valueOf(mailProps.isAuthEnabled()));
        props.put("mail.smtp.starttls.enable", String.valueOf(mailProps.isStarttls()));
        // 超时
        props.put("mail.smtp.connectiontimeout", "15000");
        props.put("mail.smtp.timeout", "30000");

        if (mailProps.isAuthEnabled()) {
            return Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(mailProps.getUser(), mailProps.getPassword());
                }
            });
        }
        return Session.getInstance(props);
    }
}
