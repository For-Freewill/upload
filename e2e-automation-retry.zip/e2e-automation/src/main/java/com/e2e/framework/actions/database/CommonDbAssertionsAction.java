package com.e2e.framework.actions.database;

import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;

/**
 * 通用 DB 断言操作（注册于多个 APP 域，体现「一个操作服务多个 APP」的注册模型）。
 *
 * <p>本操作自身的副作用为空 —— 真正的 SQL 查询与比对由执行引擎的断言引擎统一驱动
 * （ASSERT 列：{@code [{"DB":"SELECT ...","OP":"EQ","EXPECTED":["1"]}]}}），
 * 这保证了重试/超时/失败策略对所有断言语义一致。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"TMS", "SMARTS", "DNS"}, action = "COMMON_DB_ASSERTIONS",
        description = "数据库断言：执行 ASSERT 列 SQL 并按 OP 比对 EXPECTED")
public class CommonDbAssertionsAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext context) {
        return ActionResult.ok("DB 断言由断言引擎统一执行（见 ASSERT 列）");
    }
}
