package com.e2e.framework.actions.http;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.HttpApiClient;
import com.e2e.framework.protocol.HttpApiClient.HttpSpec.Auth;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TAP / STP 域：COMMON_HTTP_REQUEST —— 发送 HTTP 请求。
 *
 * <p>支持全部 HTTP method（GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS），
 * 支持 JSON body / form params / query params / headers / Bearer+Basic 认证。
 *
 * <h3>INPUT 格式示例</h3>
 * <pre>
 * // GET with query params
 * [{"HTTP":{"url":"http://api.example.com/users","method":"GET","params":{"page":"1","size":"10"}}}]
 *
 * // POST with JSON body
 * [{"HTTP":{"url":"http://api.example.com/users","method":"POST","body":{"name":"test","age":25}}}]
 *
 * // PUT with JSON body + headers + bearer auth
 * [{"HTTP":{"url":"http://api.example.com/users/1","method":"PUT",
 *   "body":{"name":"updated"},"headers":{"X-Request-Id":"123"},
 *   "auth":{"type":"bearer","token":"eyJhbG..."}}}]
 *
 * // POST with form params
 * [{"HTTP":{"url":"http://api.example.com/login","method":"POST",
 *   "formParams":{"username":"admin","password":"123"}}}]
 *
 * // POST with raw string body + custom content-type
 * [{"HTTP":{"url":"http://api.example.com/echo","method":"POST",
 *   "body":"plain text content","contentType":"text/plain"}}]
 *
 * // DELETE
 * [{"HTTP":{"url":"http://api.example.com/users/1","method":"DELETE"}}]
 * </pre>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"TAP", "STP"}, action = "COMMON_HTTP_REQUEST", description = "发送 HTTP 请求")
public class CommonHttpRequestAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonHttpRequestAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject params = context.jsonParams("HTTP");

        // 模版中 INPUT 留空时使用默认 URL
        if (params == null || params.isEmpty()) {
            HttpApiClient.HttpSpec spec = new HttpApiClient.HttpSpec();
            spec.setUrl(context.props().getHttp().getDefaultUrl());
            return doRequest(context, spec);
        }

        HttpApiClient.HttpSpec spec = new HttpApiClient.HttpSpec();

        // ① URL（支持 ${global.}/${extract.} 变量替换）
        String url = params.getString("url");
        spec.setUrl(url == null || url.isBlank() ? context.props().getHttp().getDefaultUrl() : url);

        // ② Method（GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS）
        String method = params.getString("method");
        spec.setMethod(method);  // null → 默认 GET

        // ③ Headers
        Object headersObj = params.get("headers");
        if (headersObj instanceof JSONObject headers) {
            Map<String, String> headerMap = new LinkedHashMap<>();
            headers.forEach((k, v) -> headerMap.put(k, v == null ? "" : String.valueOf(v)));
            spec.setHeaders(headerMap);
        }

        // ④ Query params（两种写法：params 或 queryParams）
        Object queryObj = params.get("params");
        if (queryObj == null) queryObj = params.get("queryParams");
        if (queryObj instanceof JSONObject query) {
            Map<String, String> queryMap = new LinkedHashMap<>();
            query.forEach((k, v) -> queryMap.put(k, v == null ? "" : String.valueOf(v)));
            spec.setQueryParams(queryMap);
        }

        // ⑤ Form params
        Object formObj = params.get("formParams");
        if (formObj instanceof JSONObject form) {
            Map<String, String> formMap = new LinkedHashMap<>();
            form.forEach((k, v) -> formMap.put(k, v == null ? "" : String.valueOf(v)));
            spec.setFormParams(formMap);
        }

        // ⑥ Body（JSON object/array → JSON 字符串；String → raw body）
        if (params.containsKey("body")) {
            spec.setBody(params.get("body"));
        }

        // ⑦ Content-Type（覆盖默认推断）
        String contentType = params.getString("contentType");
        if (contentType != null && !contentType.isBlank()) {
            spec.setContentType(contentType);
        }

        // ⑧ Auth（bearer / basic）
        Object authObj = params.get("auth");
        if (authObj instanceof JSONObject auth) {
            Auth authConfig = new Auth();
            authConfig.setType(auth.getString("type"));
            authConfig.setToken(auth.getString("token"));
            authConfig.setUsername(auth.getString("username"));
            authConfig.setPassword(auth.getString("password"));
            spec.setAuth(authConfig);
        }

        log.info("  HTTP {} {} (query={} form={} body={} auth={})",
                spec.getMethod(), spec.getUrl(),
                spec.getQueryParams().isEmpty() ? "none" : spec.getQueryParams().keySet(),
                spec.getFormParams().isEmpty() ? "none" : spec.getFormParams().keySet(),
                spec.getBody() == null ? "none" : "yes",
                spec.getAuth() == null ? "none" : spec.getAuth().getType());

        return doRequest(context, spec);
    }

    private ActionResult doRequest(ActionContext context, HttpApiClient.HttpSpec spec) {
        HttpApiClient.HttpResult response = context.clients().http().execute(spec);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("status", response.getStatusCode());
        outputs.put("HTTP", response.getStatusCode());      // 向后兼容
        outputs.put("body", response.getBody());
        outputs.put("HTTP_BODY", response.getBody());        // 向后兼容
        outputs.put("headers", response.getHeaders());
        outputs.put("HTTP_HEADERS", response.getHeaders());  // 向后兼容
        outputs.put("responseTimeMs", response.getResponseTimeMs());

        if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
            return ActionResult.ok("HTTP " + spec.getMethod() + " " + spec.getUrl()
                    + " -> " + response.getStatusCode() + " (" + response.getResponseTimeMs() + "ms)", outputs);
        }
        return ActionResult.fail("HTTP " + spec.getMethod() + " " + spec.getUrl()
                + " -> " + response.getStatusCode() + " body=" + abbreviate(response.getBody()), outputs);
    }

    private static String abbreviate(String s) {
        if (s == null) return "";
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }
}
