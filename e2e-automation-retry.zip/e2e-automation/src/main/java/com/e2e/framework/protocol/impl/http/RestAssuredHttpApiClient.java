package com.e2e.framework.protocol.impl.http;

import com.alibaba.fastjson2.JSON;
import com.e2e.framework.protocol.HttpApiClient;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * HTTP live 实现：基于 REST Assured。
 *
 * <p>全面支持 GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS，
 * 支持 JSON body / form params / query params / headers / Bearer+Basic 认证。
 * 非 2xx 响应不抛异常（由 Action 层按状态码判定成败）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class RestAssuredHttpApiClient implements HttpApiClient {

    private static final Logger log = LoggerFactory.getLogger(RestAssuredHttpApiClient.class);

    @Override
    public HttpResult execute(HttpSpec spec) {
        log.info("[http] {} {} (query={}, form={}, body={})",
                spec.getMethod(), spec.getUrl(),
                spec.getQueryParams().isEmpty() ? "none" : spec.getQueryParams().keySet(),
                spec.getFormParams().isEmpty() ? "none" : spec.getFormParams().keySet(),
                spec.getBody() == null ? "none" : "yes");

        RequestSpecification request = given().relaxedHTTPSValidation();

        // ① Auth
        if (spec.getAuth() != null) {
            String authType = spec.getAuth().getType() == null ? "" : spec.getAuth().getType().toLowerCase();
            switch (authType) {
                case "bearer" -> request.auth().oauth2(spec.getAuth().getToken());
                case "basic" -> request.auth().basic(spec.getAuth().getUsername(), spec.getAuth().getPassword());
                default -> { /* none */ }
            }
        }

        // ② Headers
        for (Map.Entry<String, String> h : spec.getHeaders().entrySet()) {
            request.header(h.getKey(), h.getValue());
        }

        // ③ Query params
        if (!spec.getQueryParams().isEmpty()) {
            request.queryParams(spec.getQueryParams());
        }

        // ④ Body（JSON / form / raw）
        String method = spec.getMethod();
        boolean hasBody = !"GET".equals(method) && !"HEAD".equals(method) && !"OPTIONS".equals(method);

        if (hasBody) {
            if (!spec.getFormParams().isEmpty()) {
                // Form 表单
                request.formParams(spec.getFormParams());
            } else if (spec.getBody() != null) {
                // JSON body（Object/Map/List → JSON 字符串）或 raw string
                String contentType = spec.getContentType();
                if (contentType != null && !contentType.isBlank()) {
                    request.contentType(contentType);
                } else {
                    request.contentType(ContentType.JSON);
                }
                if (spec.getBody() instanceof String raw) {
                    request.body(raw);
                } else {
                    request.body(JSON.toJSONString(spec.getBody()));
                }
            }
        }

        // ⑤ 发送请求
        long start = System.currentTimeMillis();
        Response response = request.request(method, spec.getUrl());
        long elapsed = System.currentTimeMillis() - start;

        // ⑥ 构建结果
        HttpResult result = new HttpResult();
        result.setStatusCode(response.getStatusCode());
        result.setBody(response.getBody() == null ? "" : response.getBody().asString());
        result.setResponseTimeMs(elapsed);
        for (Header h : response.getHeaders()) {
            result.getHeaders().put(h.getName(), h.getValue());
        }
        return result;
    }

    @Override
    public String describe() {
        return "rest-assured (live)";
    }
}
