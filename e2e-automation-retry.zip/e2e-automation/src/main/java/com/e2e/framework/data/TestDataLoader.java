package com.e2e.framework.data;

import com.e2e.framework.model.TestDataBundle;

/**
 * 数据驱动模版装载器（Excel / YAML 等多源实现）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface TestDataLoader {

    /** 数据源名称（用于日志与报告，如 "excel:E2E-Test-Scenarios.xlsx"） */
    String sourceName();

    /** 装载全部场景、步骤与全局配置 */
    TestDataBundle load();
}
