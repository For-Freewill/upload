package com.e2e.framework.model;

import com.e2e.framework.model.results.StepStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * 步骤定义 —— 对应模版 Steps 表一行。
 *
 * <p>一个步骤 = 指定 APP 域内的一个单点操作（ACTION），
 * 通过 DEPENDS_ON 与 INPUT/ASSERT/EXTRACT/RETRY/ON_FAILURE 等编排信息组合为端到端用例。
 *
 * <p>列映射（含模版拼写 ENBALED 的容错）：
 * Scenario_ID / SEQ_NO / STEP_ID / APP / ACTION / DEPENDS_ON / INPUT / ASSERT / EXTRACT / TIMEOUT / RETRY / ON_FAILURE / EN(B)ALED。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StepDefinition {

    private final String scenarioId;
    private final int seqNo;
    private final String stepId;
    private final String app;
    private final String action;
    private final List<String> dependsOn;
    private final String inputRaw;
    private final String assertRaw;
    private final String extractRaw;
    private final int timeoutSeconds;
    private final int retry;
    private final OnFailure onFailure;
    private final boolean enabled;

    /** 加载期解析后的结构化数据 */
    private List<ProtocolPayload> inputPayloads = new ArrayList<>();
    private List<AssertionRule> assertRules = new ArrayList<>();
    private List<ExtractRule> extractRules = new ArrayList<>();
    private List<DataQualityIssue> issues = new ArrayList<>();
    private StepStatus status = StepStatus.PENDING;

    public StepDefinition(String scenarioId, int seqNo, String stepId, String app, String action,
                          List<String> dependsOn, String inputRaw, String assertRaw, String extractRaw,
                          int timeoutSeconds, int retry, OnFailure onFailure, boolean enabled) {
        this.scenarioId = scenarioId;
        this.seqNo = seqNo;
        this.stepId = stepId;
        this.app = app;
        this.action = action;
        this.dependsOn = dependsOn == null ? List.of() : dependsOn;
        this.inputRaw = inputRaw;
        this.assertRaw = assertRaw;
        this.extractRaw = extractRaw;
        this.timeoutSeconds = timeoutSeconds;
        this.retry = retry;
        this.onFailure = onFailure;
        this.enabled = enabled;
    }

    public String getScenarioId() { return scenarioId; }
    public int getSeqNo() { return seqNo; }
    public String getStepId() { return stepId; }
    public String getApp() { return app; }
    public String getAction() { return action; }
    public List<String> getDependsOn() { return dependsOn; }
    public String getInputRaw() { return inputRaw == null ? "" : inputRaw; }
    public String getAssertRaw() { return assertRaw == null ? "" : assertRaw; }
    public String getExtractRaw() { return extractRaw == null ? "" : extractRaw; }
    public int getTimeoutSeconds() { return timeoutSeconds; }
    public int getRetry() { return retry; }
    public OnFailure getOnFailure() { return onFailure; }
    public boolean isEnabled() { return enabled; }

    public List<ProtocolPayload> getInputPayloads() { return inputPayloads; }
    public void setInputPayloads(List<ProtocolPayload> inputPayloads) { this.inputPayloads = inputPayloads; }
    public List<AssertionRule> getAssertRules() { return assertRules; }
    public void setAssertRules(List<AssertionRule> assertRules) { this.assertRules = assertRules; }
    public List<ExtractRule> getExtractRules() { return extractRules; }
    public void setExtractRules(List<ExtractRule> extractRules) { this.extractRules = extractRules; }
    public List<DataQualityIssue> getIssues() { return issues; }
    public void setIssues(List<DataQualityIssue> issues) { this.issues = issues; }
    public StepStatus getStatus() { return status; }
    public void setStatus(StepStatus status) { this.status = status; }

    /** 唯一键：APP:ACTION，用于 Action 注册表查找 */
    public String actionKey() { return app + ":" + action; }

    @Override
    public String toString() { return "Step[" + stepId + " " + app + "/" + action + "]"; }
}
