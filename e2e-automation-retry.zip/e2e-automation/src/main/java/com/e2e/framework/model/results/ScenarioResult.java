package com.e2e.framework.model.results;

import com.e2e.framework.model.ScenarioDefinition;

import java.util.ArrayList;
import java.util.List;

/**
 * 场景执行结果（含每个步骤的明细）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ScenarioResult {

    private final ScenarioDefinition scenario;
    private ScenarioStatus status = ScenarioStatus.PASSED;
    private String message = "";
    private final List<StepResult> stepResults = new ArrayList<>();
    private long durationMs;

    public ScenarioResult(ScenarioDefinition scenario) { this.scenario = scenario; }

    public ScenarioDefinition getScenario() { return scenario; }
    public ScenarioStatus getStatus() { return status; }
    public void setStatus(ScenarioStatus status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message == null ? "" : message; }
    public List<StepResult> getStepResults() { return stepResults; }
    public void addStepResult(StepResult r) { stepResults.add(r); }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }

    public long passedCount() { return stepResults.stream().filter(r -> r.getStatus() == StepStatus.PASSED).count(); }
    public long failedCount() { return stepResults.stream().filter(r -> r.getStatus().isTerminalFailure()).count(); }
    public long skippedCount() { return stepResults.stream().filter(r -> r.getStatus() == StepStatus.SKIPPED).count(); }
}
