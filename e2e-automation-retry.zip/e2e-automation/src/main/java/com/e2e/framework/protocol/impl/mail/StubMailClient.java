package com.e2e.framework.protocol.impl.mail;

import com.e2e.framework.protocol.MailClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;

/**
 * MAIL 桩实现（demo 模式）：内存收件箱，记录已发送邮件。
 *
 * <p>send 只记录不真实发送；收件箱可供断言查询（sentCount / lastSubject）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StubMailClient implements MailClient {

    private static final Logger log = LoggerFactory.getLogger(StubMailClient.class);

    /** 内存收件箱 */
    private final List<Map<String, Object>> sentBox = new CopyOnWriteArrayList<>();

    @Override
    public MailResult send(MailSpec spec) {
        String messageId = "stub-" + UUID.randomUUID();
        log.info("[stub-mail] send to={} subject='{}' html={} attachments={} (simulated)",
                spec.getTo(), spec.getSubject(), spec.isHtml(), spec.getAttachmentPaths().size());

        Map<String, Object> record = new LinkedHashMap<>();
        record.put("messageId", messageId);
        record.put("to", String.join(",", spec.getTo()));
        record.put("cc", String.join(",", spec.getCc()));
        record.put("subject", spec.getSubject() == null ? "" : spec.getSubject());
        record.put("body", spec.getBody() == null ? "" : spec.getBody());
        record.put("html", spec.isHtml());
        record.put("attachments", spec.getAttachmentPaths().size());
        sentBox.add(record);

        return MailResult.ok("邮件已发送(stub)至 " + spec.getTo(), messageId);
    }

    /** 已发送邮件数（demo 断言用） */
    public int sentCount() {
        return sentBox.size();
    }

    /** 内存收件箱（demo 查询用） */
    public List<Map<String, Object>> sentBox() {
        return List.copyOf(sentBox);
    }

    @Override
    public String describe() {
        return "stub-mail (demo, sent=" + sentBox.size() + ")";
    }
}
