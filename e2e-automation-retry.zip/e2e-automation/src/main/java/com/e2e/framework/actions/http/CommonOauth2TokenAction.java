package com.e2e.framework.actions.http;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TAP/STP 域：COMMON_OAUTH2_TOKEN —— 获取 OAuth2 Token 并自动写入场景变量。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 密码模式（resource owner password credentials）
 * [{"OAUTH2":{
 *   "tokenUrl":"https://auth.example.com/oauth/token",
 *   "grantType":"password",
 *   "username":"e2e-user",
 *   "password":"secret",
 *   "clientId":"e2e-client",
 *   "clientSecret":"client-secret"
 * }}]
 *
 * // 客户端凭证模式（client credentials）
 * [{"OAUTH2":{
 *   "tokenUrl":"https://auth.example.com/oauth/token",
 *   "grantType":"client_credentials",
 *   "clientId":"e2e-client",
 *   "clientSecret":"client-secret",
 *   "scope":"read write"
 * }}]
 * </pre>
 *
 * <p>成功后自动执行 {@code ctx.setVar("oauthToken", token)}，
 * 后续步骤可直接用 {@code ${extract.oauthToken}} 作为 Bearer Token：
 * {@code "auth":{"type":"bearer","token":"${extract.oauthToken}"} }
 *
 * <p>输出（可断言/EXTRACT）：{@code token} / {@code tokenType} / {@code expiresIn} / {@code status}
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"TAP", "STP"}, action = "COMMON_OAUTH2_TOKEN",
            description = "获取 OAuth2 Token（password/client_credentials），自动写入 ${extract.oauthToken}")
public class CommonOauth2TokenAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonOauth2TokenAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("OAUTH2");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 OAUTH2 协议载荷: [{\"OAUTH2\":{\"tokenUrl\":\"...\",\"grantType\":\"password\",...}}]");
        }
        String tokenUrl = p.getString("tokenUrl");
        String grantType = p.getString("grantType");
        if (tokenUrl == null || tokenUrl.isBlank()) {
            return ActionResult.fail("OAUTH2 载荷缺少 tokenUrl 字段");
        }
        if (grantType == null || grantType.isBlank()) {
            grantType = "client_credentials";
        }

        // ① 构建表单参数（OAuth2 token endpoint 为 form-urlencoded）
        Map<String, String> form = new LinkedHashMap<>();
        form.put("grant_type", grantType);
        String clientId = p.getString("clientId");
        String clientSecret = p.getString("clientSecret");
        if (clientId != null) form.put("client_id", clientId);
        if (clientSecret != null) form.put("client_secret", clientSecret);
        if ("password".equalsIgnoreCase(grantType)) {
            String username = p.getString("username");
            String password = p.getString("password");
            if (username == null || password == null) {
                return ActionResult.fail("密码模式需要 username + password 字段");
            }
            form.put("username", username);
            form.put("password", password);
        }
        String scope = p.getString("scope");
        if (scope != null && !scope.isBlank()) form.put("scope", scope);

        // ② 通过 HTTP 客户端 POST 表单
        var spec = new com.e2e.framework.protocol.HttpApiClient.HttpSpec();
        spec.setUrl(tokenUrl);
        spec.setMethod("POST");
        spec.setFormParams(form);
        var response = context.clients().http().execute(spec);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("status", response.getStatusCode());

        // ③ 解析响应提取 token
        if (response.getStatusCode() == 200 && response.getBody() != null && !response.getBody().isBlank()) {
            try {
                JSONObject tokenResp = JSONObject.parseObject(response.getBody());
                String token = tokenResp.getString("access_token");
                if (token != null && !token.isBlank()) {
                    outputs.put("token", token);
                    outputs.put("tokenType", tokenResp.getString("token_type"));
                    outputs.put("expiresIn", tokenResp.get("expires_in"));
                    // 自动写入场景变量，后续步骤用 ${extract.oauthToken} 引用
                    context.setVar("oauthToken", token);
                    log.info("  OAUTH2 token 获取成功（已写入 ${extract.oauthToken}，expires_in={}）",
                            tokenResp.get("expires_in"));
                    return ActionResult.ok("OAuth2 Token 获取成功 (" + grantType + ")", outputs);
                }
                return ActionResult.fail("Token 响应缺少 access_token: " + abbreviate(response.getBody()), outputs);
            } catch (Exception e) {
                return ActionResult.fail("Token 响应解析失败: " + e.getMessage(), outputs);
            }
        }
        return ActionResult.fail("Token 请求失败 status=" + response.getStatusCode()
                + " body=" + abbreviate(response.getBody()), outputs);
    }

    private static String abbreviate(String s) {
        if (s == null) return "";
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
