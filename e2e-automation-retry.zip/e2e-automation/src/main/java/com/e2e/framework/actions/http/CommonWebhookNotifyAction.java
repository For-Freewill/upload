package com.e2e.framework.actions.http;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DATAHUB 域：COMMON_WEBHOOK_NOTIFY —— IM Webhook 通知（钉钉/企业微信/飞书/自定义）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 钉钉机器人
 * [{"WEBHOOK":{"channel":"dingtalk","text":"E2E 测试完成，全部通过"}}]
 *
 * // 企业微信机器人（支持 @ 手机号）
 * [{"WEBHOOK":{"channel":"wecom","text":"构建失败","mentioned":["13800000000"]}}]
 *
 * // 飞书机器人
 * [{"WEBHOOK":{"channel":"feishu","title":"测试报告","text":"通过率 100%"}}]
 *
 * // 自定义 webhook URL（任意 JSON 体）
 * [{"WEBHOOK":{"url":"https://hooks.example.com/xxx","body":{"event":"e2e-done","score":100}}}]
 * </pre>
 *
 * <p>渠道 URL 优先级：载荷 url > e2e.webhook.{channel}-url 配置。
 * 底层复用 HTTP 客户端（demo 模式走桩，live 模式真实 POST）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_WEBHOOK_NOTIFY",
            description = "IM Webhook 通知（dingtalk/wecom/feishu/自定义 url）")
public class CommonWebhookNotifyAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonWebhookNotifyAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("WEBHOOK");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 WEBHOOK 协议载荷: [{\"WEBHOOK\":{\"channel\":\"dingtalk\",\"text\":\"...\"}}]");
        }

        String channel = p.getString("channel");
        String url = p.getString("url");
        String text = p.getString("text");
        if (text == null) text = p.getString("content");
        if (text == null) text = "";

        // ① 解析 URL：载荷 url 优先，其次渠道配置
        if (url == null || url.isBlank()) {
            url = switch (channel == null ? "" : channel.toLowerCase()) {
                case "dingtalk", "dingding", "dd" -> context.props().getWebhook().getDingtalkUrl();
                case "wecom", "wechat-work", "wxwork" -> context.props().getWebhook().getWecomUrl();
                case "feishu", "lark" -> context.props().getWebhook().getFeishuUrl();
                default -> "";
            };
        }
        if (url == null || url.isBlank()) {
            return ActionResult.fail("缺少 webhook URL（载荷 url 字段或 e2e.webhook." + channel + "-url 配置）");
        }

        // ② 构建渠道报文体
        Object bodyObj = p.get("body");
        JSONObject body;
        if (bodyObj instanceof JSONObject bo) {
            body = bo; // 自定义 JSON 体直接透传
        } else {
            body = buildChannelBody(channel, p, text);
        }

        // ③ 通过 HTTP 客户端 POST（demo 走桩 / live 真实发送）
        var spec = new com.e2e.framework.protocol.HttpApiClient.HttpSpec();
        spec.setUrl(url);
        spec.setMethod("POST");
        spec.setBody(body);
        var response = context.clients().http().execute(spec);

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("channel", channel == null ? "custom" : channel);
        outputs.put("url", url);
        outputs.put("status", response.getStatusCode());
        outputs.put("responseBody", response.getBody());

        log.info("  WEBHOOK notify channel={} status={}", outputs.get("channel"), response.getStatusCode());
        if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
            return ActionResult.ok("Webhook 通知已发送 (" + outputs.get("channel") + " -> " + response.getStatusCode() + ")", outputs);
        }
        return ActionResult.fail("Webhook 通知失败 status=" + response.getStatusCode()
                + " body=" + abbreviate(response.getBody()), outputs);
    }

    /** 按渠道构建标准机器人报文体 */
    private JSONObject buildChannelBody(String channel, JSONObject p, String text) {
        JSONObject body = new JSONObject();
        String ch = channel == null ? "" : channel.toLowerCase();
        switch (ch) {
            case "dingtalk", "dingding", "dd" -> {
                JSONObject at = new JSONObject();
                Object mentioned = p.get("mentioned");
                if (mentioned instanceof JSONArray arr) {
                    List<String> phones = new ArrayList<>();
                    for (Object m : arr) phones.add(String.valueOf(m));
                    at.put("atMobiles", phones);
                }
                body.put("msgtype", "text");
                body.put("text", new JSONObject().fluentPut("content", text));
                if (!at.isEmpty()) body.put("at", at);
            }
            case "wecom", "wechat-work", "wxwork" -> {
                body.put("msgtype", "text");
                JSONObject textObj = new JSONObject();
                textObj.put("content", text);
                Object mentioned = p.get("mentioned");
                if (mentioned instanceof JSONArray arr) {
                    List<String> phones = new ArrayList<>();
                    for (Object m : arr) phones.add(String.valueOf(m));
                    textObj.put("mentioned_mobile_list", phones);
                }
                body.put("text", textObj);
            }
            case "feishu", "lark" -> {
                String title = p.getString("title");
                body.put("msg_type", "text");
                body.put("content", new JSONObject().fluentPut("text",
                        (title == null ? "" : title + "\n") + text));
            }
            default -> body.put("text", text); // 自定义：简单 text 字段
        }
        return body;
    }

    private static String abbreviate(String s) {
        if (s == null) return "";
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
