package com.e2e.framework.protocol.impl.http;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.protocol.HttpApiClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * HTTP 桩实现（demo 模式）：回显请求详情并返回 200。
 *
 * <p>回显 method / url / headers / queryParams / formParams / body，方便 demo 模式验证配置。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StubHttpApiClient implements HttpApiClient {

    private static final Logger log = LoggerFactory.getLogger(StubHttpApiClient.class);

    @Override
    public HttpResult execute(HttpSpec spec) {
        log.info("[stub-http] {} {} (query={}, form={}, body={})",
                spec.getMethod(), spec.getUrl(),
                spec.getQueryParams().isEmpty() ? "none" : spec.getQueryParams().keySet(),
                spec.getFormParams().isEmpty() ? "none" : spec.getFormParams().keySet(),
                spec.getBody() == null ? "none" : "yes");

        JSONObject echo = new JSONObject();
        echo.put("stub", true);
        echo.put("method", spec.getMethod());
        echo.put("url", spec.getUrl());
        echo.put("headers", spec.getHeaders());
        echo.put("queryParams", spec.getQueryParams());
        echo.put("formParams", spec.getFormParams());
        echo.put("body", spec.getBody() == null ? new JSONObject() : spec.getBody());
        echo.put("contentType", spec.getContentType() == null ? "application/json" : spec.getContentType());
        if (spec.getAuth() != null) {
            JSONObject auth = new JSONObject();
            auth.put("type", spec.getAuth().getType());
            echo.put("auth", auth);
        }

        HttpResult result = new HttpResult();
        result.setStatusCode(200);
        result.setBody(echo.toJSONString());
        for (Map.Entry<String, String> h : spec.getHeaders().entrySet()) {
            result.getHeaders().put(h.getKey(), h.getValue());
        }
        result.setResponseTimeMs(1);
        return result;
    }

    @Override
    public String describe() {
        return "stub-http (demo)";
    }
}
