package com.e2e.framework.protocol.ui;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * UI 处理器注册表 —— 收集所有 @UiHandler 标注的 Bean，按注册名索引；
 * 亦支持编程式动态注册 {@link #register(String, UiAction)}。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class UiActionRegistry {

    private static final Logger log = LoggerFactory.getLogger(UiActionRegistry.class);

    private final Map<String, UiAction> handlers = new ConcurrentHashMap<>();

    @Autowired
    public void collect(ApplicationContext context) {
        Map<String, Object> beans = context.getBeansWithAnnotation(UiHandler.class);
        beans.forEach((beanName, bean) -> {
            UiHandler spec = bean.getClass().getAnnotation(UiHandler.class);
            if (spec != null && bean instanceof UiAction action) {
                register(spec.value(), action);
            }
        });
        log.info("UI 处理器注册完成: {} 个 -> {}", handlers.size(), handlers.keySet());
    }

    /** 编程式注册（支持运行时热插拔 / 非 Spring 管理的实现） */
    public void register(String name, UiAction action) {
        UiAction old = handlers.put(name, action);
        if (old != null) {
            log.warn("UI 处理器 '{}' 被覆盖注册: {} -> {}", name, old.getClass().getName(), action.getClass().getName());
        }
    }

    public UiAction lookup(String name) {
        return handlers.get(name);
    }

    public String describe() {
        return String.join(",", new LinkedHashMap<>(handlers).keySet());
    }

    public List<String> names() {
        return List.copyOf(handlers.keySet());
    }
}
