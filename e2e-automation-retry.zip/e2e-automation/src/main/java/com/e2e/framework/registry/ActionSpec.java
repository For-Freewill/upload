package com.e2e.framework.registry;

import org.springframework.stereotype.Component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * APP 域单点操作注册注解 —— 标注在 {@link AppAction} 实现类上。
 *
 * <p>一个实现可注册到多个 APP 域（如 COMMON_DB_ASSERTIONS 同时作用于 TMS/SMARTS/DNS）。
 * 查找键为 {@code APP:ACTION}（忽略大小写）。
 *
 * <p>扩展新 APP / 新操作的完整步骤见 README：
 * <ol>
 *   <li>实现 {@link AppAction}；</li>
 *   <li>标注 {@code @ActionSpec(apps = {"新APP"}, action = "新ACTION")}（含 @Component 元注解，自动扫描）；</li>
 *   <li>在模版 Steps 表中使用 {@code APP=新APP, ACTION=新ACTION}。</li>
 * </ol>
 * 覆盖内置实现：同 key 注册且 order 更大者生效（默认 order=0，覆盖时设 order=100）。
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component

/**
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public @interface ActionSpec {

    /** 适用的 APP 域列表（大写），如 {"STP"} / {"TMS", "SMARTS", "DNS"} */
    String[] apps();

    /** 操作名（大写），如 COMMON_MQ_SEND */
    String action();

    String description() default "";

    /** 注册优先级：同 key 冲突时 order 大者覆盖小者 */
    int order() default 0;
}
