package com.e2e.framework.actions.nosql;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SMARTS 域：COMMON_NOSQL_EXECUTE —— MongoDB 文档库操作（插入/查询/更新/删除）。
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 插入文档
 * [{"MONGO":{"op":"insert","collection":"orders","docs":[{"id":1,"status":"CREATED"},{"id":2,"status":"SHIPPED"}]}}]
 *
 * // 查询（filter 为 MongoDB 查询条件 JSON）
 * [{"MONGO":{"op":"find","collection":"orders","filter":{"status":"CREATED"}}}]
 *
 * // 更新（update 为 $set 表达式）
 * [{"MONGO":{"op":"update","collection":"orders","filter":{"id":1},"update":{"$set":{"status":"DONE"}}}}]
 *
 * // 删除 / 计数
 * [{"MONGO":{"op":"delete","collection":"orders","filter":{"id":2}}}]
 * [{"MONGO":{"op":"count","collection":"orders","filter":{}}}]
 * </pre>
 *
 * <p>demo 模式：内存文档库（与 Mongo 语义一致）；live 模式：mongodb-driver 真实连接。
 * 输出（可断言/EXTRACT）：{@code docs} / {@code docCount} / {@code matchedCount} / {@code deletedCount}
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"SMARTS"}, action = "COMMON_NOSQL_EXECUTE",
            description = "MongoDB 文档操作：insert/find/update/delete/count")
public class CommonNosqlExecuteAction implements AppAction {

    private static final Logger log = LoggerFactory.getLogger(CommonNosqlExecuteAction.class);

    /** demo 模式内存文档库：collection -> 文档列表 */
    static final Map<String, List<JSONObject>> MEM_DB = new ConcurrentHashMap<>();

    @Override
    public ActionResult execute(ActionContext context) {
        JSONObject p = context.jsonParams("MONGO");
        if (p == null || p.isEmpty()) {
            return ActionResult.fail("缺少 MONGO 协议载荷: [{\"MONGO\":{\"op\":\"insert\",\"collection\":\"...\",\"docs\":[...]}}]");
        }
        String op = p.getString("op");
        String collection = p.getString("collection");
        if (op == null || op.isBlank()) return ActionResult.fail("MONGO 载荷缺少 op 字段");
        if (collection == null || collection.isBlank()) return ActionResult.fail("MONGO 载荷缺少 collection 字段");

        boolean demo = context.props().isDemoMode();
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("op", op);
        outputs.put("collection", collection);

        try {
            if (demo) {
                return executeInMemory(p, op, collection, outputs);
            }
            return executeMongo(context, p, op, collection, outputs);
        } catch (Exception e) {
            log.warn("  NOSQL 操作失败: {}", e.getMessage());
            return ActionResult.fail("Mongo 操作失败: " + e.getClass().getSimpleName() + ": " + e.getMessage(), outputs);
        }
    }

    // ===================== demo：内存文档库 =====================

    private ActionResult executeInMemory(JSONObject p, String op, String collection, Map<String, Object> outputs) {
        List<JSONObject> docs = MEM_DB.computeIfAbsent(collection, k -> new ArrayList<>());
        JSONObject filter = p.getJSONObject("filter");
        switch (op.toLowerCase()) {
            case "insert" -> {
                JSONArray docsArr = p.getJSONArray("docs");
                if (docsArr == null || docsArr.isEmpty()) return ActionResult.fail("insert 需要 docs 数组", outputs);
                int inserted = 0;
                for (Object d : docsArr) {
                    if (d instanceof JSONObject doc) {
                        docs.add(doc);
                        inserted++;
                    }
                }
                outputs.put("insertedCount", inserted);
                log.info("  [mongo-stub] INSERT {} -> {} docs", collection, inserted);
                return ActionResult.ok("插入 " + inserted + " 文档到 " + collection + " (stub)", outputs);
            }
            case "find" -> {
                List<JSONObject> matched = new ArrayList<>();
                for (JSONObject doc : docs) {
                    if (matchesFilter(doc, filter)) matched.add(doc);
                }
                outputs.put("docs", matched);
                outputs.put("docCount", matched.size());
                log.info("  [mongo-stub] FIND {} -> {} docs", collection, matched.size());
                return ActionResult.ok("查询 " + collection + " -> " + matched.size() + " 文档", outputs);
            }
            case "update" -> {
                JSONObject update = p.getJSONObject("update");
                JSONObject setExpr = update != null ? update.getJSONObject("$set") : null;
                int matched = 0;
                for (JSONObject doc : docs) {
                    if (matchesFilter(doc, filter) && setExpr != null) {
                        doc.putAll(setExpr);
                        matched++;
                    }
                }
                outputs.put("matchedCount", matched);
                return ActionResult.ok("更新 " + matched + " 文档", outputs);
            }
            case "delete" -> {
                int before = docs.size();
                docs.removeIf(doc -> matchesFilter(doc, filter));
                outputs.put("deletedCount", before - docs.size());
                return ActionResult.ok("删除 " + (before - docs.size()) + " 文档", outputs);
            }
            case "count" -> {
                long count = docs.stream().filter(doc -> matchesFilter(doc, filter)).count();
                outputs.put("count", count);
                return ActionResult.ok("计数 " + count, outputs);
            }
            default -> {
                return ActionResult.fail("不支持的 Mongo 操作: " + op, outputs);
            }
        }
    }

    /** 简易 filter 匹配：filter 中每个 key 的值等于 doc 中的值 */
    static boolean matchesFilter(JSONObject doc, JSONObject filter) {
        if (filter == null || filter.isEmpty()) return true;
        for (var entry : filter.entrySet()) {
            if (!String.valueOf(doc.get(entry.getKey())).equals(String.valueOf(entry.getValue()))) {
                return false;
            }
        }
        return true;
    }

    // ===================== live：MongoDB 真实连接 =====================

    private ActionResult executeMongo(ActionContext context, JSONObject p, String op, String collection,
                                        Map<String, Object> outputs) {
        var cfg = context.props().getNosql();
        try (MongoClient client = MongoClients.create(cfg.getUri())) {
            MongoDatabase db = client.getDatabase(cfg.getDatabase());
            MongoCollection<Document> coll = db.getCollection(collection);
            Document filterDoc = p.getJSONObject("filter") == null ? new Document() : Document.parse(p.getJSONObject("filter").toJSONString());
            switch (op.toLowerCase()) {
                case "insert" -> {
                    JSONArray docsArr = p.getJSONArray("docs");
                    if (docsArr == null || docsArr.isEmpty()) return ActionResult.fail("insert 需要 docs 数组", outputs);
                    List<Document> documents = new ArrayList<>();
                    for (Object d : docsArr) {
                        if (d instanceof JSONObject doc) documents.add(Document.parse(doc.toJSONString()));
                    }
                    coll.insertMany(documents);
                    outputs.put("insertedCount", documents.size());
                }
                case "find" -> {
                    List<JSONObject> matched = new ArrayList<>();
                    try (var cursor = coll.find(filterDoc).limit(1000).iterator()) {
                        while (cursor.hasNext()) {
                            matched.add(JSONObject.parseObject(cursor.next().toJson()));
                        }
                    }
                    outputs.put("docs", matched);
                    outputs.put("docCount", matched.size());
                }
                case "update" -> {
                    JSONObject update = p.getJSONObject("update");
                    Document updateDoc = update == null ? new Document() : Document.parse(update.toJSONString());
                    var result = coll.updateMany(filterDoc, updateDoc);
                    outputs.put("matchedCount", result.getMatchedCount());
                    outputs.put("modifiedCount", result.getModifiedCount());
                }
                case "delete" -> {
                    var result = coll.deleteMany(filterDoc);
                    outputs.put("deletedCount", result.getDeletedCount());
                }
                case "count" -> outputs.put("count", coll.countDocuments(filterDoc));
                default -> {
                    return ActionResult.fail("不支持的 Mongo 操作: " + op, outputs);
                }
            }
            log.info("  [mongo] {} {} (live {})", op.toUpperCase(), collection, cfg.getUri());
            return ActionResult.ok("MONGO " + op.toUpperCase() + " " + collection, outputs);
        }
    }
}
