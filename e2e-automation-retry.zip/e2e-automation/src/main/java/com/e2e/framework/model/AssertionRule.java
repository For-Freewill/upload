package com.e2e.framework.model;

import java.util.List;

/**
 * 断言规则 —— ASSERT 列 JSON 数组中的对象，如
 * {"DB":"SELECT ...","FIELD":"name","OP":"EQ","EXPECTED":["1"]}。
 *
 * <p>source 指明断言数据来源协议：
 * <ul>
 *   <li>DB —— 规则自带 SQL，由断言引擎直接查询并比对（模版中的主要用法）；</li>
 *   <li>OUTPUT / HTTP / SSH 等非 DB 来源 —— 从当前步骤 action 的 outputs 中按键取值比对。</li>
 * </ul>
 *
 * <p><b>FIELD 字段</b>（仅 DB 来源生效）：
 * <ul>
 *   <li>不指定 —— 取结果集第一列（向后兼容）；</li>
 *   <li>指定列名（如 "name"）—— 取该列的值列表；</li>
 *   <li>"*" 或 "ROW" —— 每行序列化为 JSON 字符串，支持全行内容断言。</li>
 * </ul>
 *
 * <p>异步轮询断言（配合 awaitility）：
 * 设置 {@code OP="WAIT_UNTIL"} + {@code TIMEOUT=30} + {@code POLL_INTERVAL=1000}，
 * 引擎会在 timeout 内每隔 pollInterval 重新查询/取值，直到断言通过或超时。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class AssertionRule {

    private final String source;
    private final String target;
    private final String op;
    private final List<String> expected;
    private final String field;                // DB 断言：指定提取的列名（null=第一列，*=全行JSON）
    private final String raw;
    private final int timeoutSeconds;
    private final long pollIntervalMs;

    public AssertionRule(String source, String target, String op, List<String> expected, String raw) {
        this(source, target, op, expected, null, raw, 0, 0);
    }

    public AssertionRule(String source, String target, String op, List<String> expected, String raw,
                         int timeoutSeconds, long pollIntervalMs) {
        this(source, target, op, expected, null, raw, timeoutSeconds, pollIntervalMs);
    }

    public AssertionRule(String source, String target, String op, List<String> expected,
                         String field, String raw, int timeoutSeconds, long pollIntervalMs) {
        this.source = source;
        this.target = target;
        this.op = op == null || op.isBlank() ? "EQ" : op.toUpperCase();
        this.expected = expected == null ? List.of() : expected;
        this.field = field;
        this.raw = raw;
        this.timeoutSeconds = timeoutSeconds;
        this.pollIntervalMs = pollIntervalMs;
    }

    public String getSource() { return source; }
    public String getTarget() { return target; }
    public String getOp() { return op; }
    public List<String> getExpected() { return expected; }
    public String getField() { return field; }
    public String getRaw() { return raw == null ? "" : raw; }
    public int getTimeoutSeconds() { return timeoutSeconds; }
    public long getPollIntervalMs() { return pollIntervalMs; }

    /** 是否为异步轮询断言 */
    public boolean isAsync() {
        return "WAIT_UNTIL".equals(op) || "POLL_UNTIL".equals(op);
    }

    @Override
    public String toString() { return source + "[" + op + "] " + target
            + (field != null ? " FIELD=" + field : ""); }
}
