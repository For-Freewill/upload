package com.e2e.framework.protocol.ui;

import com.e2e.framework.config.E2EProperties;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Playwright UI 自动化引擎 —— 懒启动、会话内单页面复用。
 *
 * <ul>
 *   <li><b>demo 模式</b>：不创建 Playwright、不下载浏览器，UI 处理器走桩（保证开箱即跑、离线可用）；</li>
 *   <li><b>live 模式</b>：首次使用时启动配置的浏览器（e2e.ui.browser，默认 Chromium 无头），
 *       页面跨步骤复用（模拟真实 E2E 连续操作流：登录 → 预订 → 校验）。</li>
 * </ul>
 *
 * <p>浏览器二进制在首次 live 启动时由 Playwright 自动下载至本机缓存目录；
 * CI 环境可预先执行 {@code mvn exec:java -e -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"} 离线安装。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class PlaywrightUiEngine {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightUiEngine.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private final E2EProperties props;

    private Playwright playwright;
    private Browser browser;
    private final AtomicReference<Page> currentPage = new AtomicReference<>();

    public PlaywrightUiEngine(E2EProperties props) {
        this.props = props;
    }

    /** live 模式才启用真实浏览器；demo 模式 UI 处理器走桩 */
    public boolean isEnabled() {
        return !props.isDemoMode();
    }

    /**
     * 获取当前页面（无则新开）—— 跨步骤复用同一页面，模拟连续操作流。
     *
     * @throws IllegalStateException demo 模式下调用（提示切换 live）
     */
    public Page page() {
        if (!isEnabled()) {
            throw new IllegalStateException(
                    "e2e.mode=demo：Playwright 未启动（demo 模式 UI 走桩）。使用 -De2e.mode=live 启用真实浏览器。");
        }
        Page existing = currentPage.get();
        if (existing != null) {
            return existing;
        }
        ensureBrowser();
        Page page = browser.newPage();
        currentPage.set(page);
        log.info("[playwright] 新页面已打开（会话复用）");
        return page;
    }

    /** 显式新开页面（需要多页面/隔离会话的 UI 处理器使用） */
    public Page newPage() {
        if (!isEnabled()) {
            throw new IllegalStateException(
                    "e2e.mode=demo：Playwright 未启动（demo 模式 UI 走桩）。使用 -De2e.mode=live 启用真实浏览器。");
        }
        ensureBrowser();
        Page page = browser.newPage();
        currentPage.set(page);
        return page;
    }

    public Page currentPage() {
        return currentPage.get();
    }

    /**
     * ON_FAILURE=SCREENSHOT 证据截图：存在活动页面时全页截图，返回文件路径；否则返回 null（走占位实现）。
     */
    public String captureIfActive(String scenarioId, String stepId) {
        Page page = currentPage.get();
        if (page == null || !isEnabled()) {
            return null;
        }
        try {
            Path dir = Paths.get(props.getReport().getOutputDir(), "screenshots");
            Files.createDirectories(dir);
            Path path = dir.resolve(scenarioId + "_" + stepId + "_" + LocalDateTime.now().format(TS) + ".png");
            page.screenshot(new Page.ScreenshotOptions().setPath(path).setFullPage(true));
            log.info("[playwright] 失败证据截图: {}", path);
            return path.toString();
        } catch (Exception e) {
            log.warn("[playwright] 截图失败: {}", e.getMessage());
            return null;
        }
    }

    private synchronized void ensureBrowser() {
        if (browser == null) {
            playwright = Playwright.create();
            String engine = props.getUi().getBrowser().toLowerCase();
            BrowserType type = switch (engine) {
                case "firefox" -> playwright.firefox();
                case "webkit" -> playwright.webkit();
                default -> playwright.chromium();
            };
            browser = type.launch(new BrowserType.LaunchOptions()
                    .setHeadless(props.getUi().isHeadless()));
            log.info("[playwright] {} 已启动 (headless={})", engine, props.getUi().isHeadless());
        }
    }

    @PreDestroy
    public synchronized void shutdown() {
        try {
            Page page = currentPage.getAndSet(null);
            if (page != null) {
                page.close();
            }
        } catch (Exception ignore) {
            // 关闭失败不影响退出
        }
        try {
            if (browser != null) {
                browser.close();
                browser = null;
            }
        } catch (Exception ignore) {
            // 同上
        }
        try {
            if (playwright != null) {
                playwright.close();
                playwright = null;
            }
        } catch (Exception ignore) {
            // 同上
        }
        log.info("[playwright] 引擎已释放");
    }
}
