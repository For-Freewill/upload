package com.e2e.framework.protocol.ui;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.config.E2EProperties;
import com.microsoft.playwright.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Playwright UI 处理器 —— 对应模版 JAVA 载荷 url=automation.qa.e2e.uiaction1。
 *
 * <p>双模式行为：
 * <ul>
 *   <li><b>demo</b>：与桩行为一致（uiStatus=OK / account=params / screenshots=1），不启动浏览器；</li>
 *   <li><b>live</b>：通过 {@link PlaywrightUiEngine} 复用页面会话，
 *       params 支持 {@code {"url":"https://...","account":"xxx"}} JSON 或纯文本（视为 account，
 *       未给 url 时导航至 e2e.ui.base-url）。</li>
 * </ul>
 *
 * <p>扩展真实业务 UI 流程：实现新的 {@code @UiHandler} 处理器（内部调用 engine.page() 的
 * navigate/click/fill 等 Playwright API），模版 JAVA 载荷的 url 换成新注册名即可。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
@UiHandler(value = "automation.qa.e2e.uiaction1", description = "Playwright UI 单点操作（demo 桩 / live 真实浏览器）")
public class PlaywrightUiHandler implements UiAction {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightUiHandler.class);

    private final PlaywrightUiEngine engine;
    private final E2EProperties props;

    public PlaywrightUiHandler(PlaywrightUiEngine engine, E2EProperties props) {
        this.engine = engine;
        this.props = props;
    }

    @Override
    public Map<String, Object> execute(String params) {
        if (!engine.isEnabled()) {
            log.info("[demo-ui] automation.qa.e2e.uiaction1 executed, params={}", params);
            Map<String, Object> outputs = new LinkedHashMap<>();
            outputs.put("uiStatus", "OK");
            outputs.put("account", params);
            outputs.put("screenshots", 1);
            return outputs;
        }

        // live：params 支持 {"url":"...","account":"..."} JSON，或纯文本 account
        String account = params == null ? "" : params;
        String url = null;
        String trimmed = account.trim();
        if (trimmed.startsWith("{")) {
            try {
                JSONObject p = JSON.parseObject(trimmed);
                url = p.getString("url");
                String acc = p.getString("account");
                if (acc != null && !acc.isBlank()) {
                    account = acc;
                }
            } catch (Exception ignore) {
                // 非 JSON 则按纯文本处理
            }
        }
        if (url == null || url.isBlank()) {
            url = props.getUi().getBaseUrl();
        }

        Page page = engine.page();
        if (url != null && !url.isBlank()) {
            log.info("[playwright] 导航: {}", url);
            page.navigate(url);
        }

        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("uiStatus", "OK");
        outputs.put("account", account);
        outputs.put("screenshots", 1);
        outputs.put("pageUrl", page.url());
        outputs.put("pageTitle", page.title());
        return outputs;
    }
}
