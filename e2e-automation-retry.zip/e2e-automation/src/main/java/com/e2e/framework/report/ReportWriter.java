package com.e2e.framework.report;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONWriter;
import com.e2e.framework.ai.AiAssistant;
import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.results.ScenarioResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON + HTML 报告落盘（test-output/，JSON 序列化 fastjson2）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class ReportWriter {

    private static final Logger log = LoggerFactory.getLogger(ReportWriter.class);
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter TITLE_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final E2EProperties props;
    private final AiAssistant aiAssistant;

    public ReportWriter(E2EProperties props, AiAssistant aiAssistant) {
        this.props = props;
        this.aiAssistant = aiAssistant;
    }

    public Path write(List<ScenarioResult> results, List<DataQualityIssue> issues, String sourceName) {
        try {
            Path dir = Paths.get(props.getReport().getOutputDir());
            Files.createDirectories(dir);

            // JSON 报告
            Map<String, Object> json = new HashMap<>();
            json.put("title", "E2E Test Reports-" + LocalDateTime.now().format(TITLE_DATE));
            json.put("generatedAt", LocalDateTime.now().format(TS));
            json.put("dataSource", sourceName);
            json.put("total", results.size());
            json.put("passed", results.stream().filter(r -> r.getStatus().name().equals("PASSED")).count());
            json.put("failed", results.stream().filter(r -> r.getStatus().name().equals("FAILED")).count());
            json.put("skipped", results.stream().filter(r -> r.getStatus().name().equals("SKIPPED")).count());
            json.put("dataQualityIssues", issues);
            json.put("scenarios", results);

            // AI 钩子：报告解读（e2e.ai.features.report-interpretation=true 时生效）
            String aiSummary = "";
            if (aiAssistant.isEnabled() && props.getAi().getFeatures().isReportInterpretation()) {
                try {
                    aiSummary = aiAssistant.reportInterpreter().summarize(results);
                    json.put("aiSummary", aiSummary);
                    // 失败根因分析
                    var failedResults = results.stream()
                            .filter(r -> r.getStatus().name().equals("FAILED")).toList();
                    if (!failedResults.isEmpty()) {
                        json.put("aiFailureAnalysis", aiAssistant.reportInterpreter().analyzeFailures(failedResults));
                    }
                } catch (Exception e) {
                    log.debug("[AI] 报告解读调用失败: {}", e.getMessage());
                }
            }

            Files.writeString(dir.resolve("test_report.json"),
                    JSON.toJSONString(json, JSONWriter.Feature.PrettyFormat),
                    StandardCharsets.UTF_8);

            // HTML 报告
            Files.writeString(dir.resolve("test_report.html"), renderHtml(results, issues, sourceName, aiSummary),
                    StandardCharsets.UTF_8);

            log.info("E2E 报告已生成: {}", dir.toAbsolutePath());
            return dir.resolve("test_report.html");
        } catch (IOException e) {
            log.error("报告写入失败: {}", e.getMessage());
            return null;
        }
    }

    private String renderHtml(List<ScenarioResult> results, List<DataQualityIssue> issues,
                              String sourceName, String aiSummary) {
        // ---- 统计数据 ----
        int total = results.size();
        long passed = results.stream().filter(r -> r.getStatus().name().equals("PASSED")).count();
        long failed = results.stream().filter(r -> r.getStatus().name().equals("FAILED")).count();
        long skipped = results.stream().filter(r -> r.getStatus().name().equals("SKIPPED")).count();
        long totalDurationMs = results.stream().mapToLong(ScenarioResult::getDurationMs).sum();
        double passRate = total > 0 ? (double) passed / total * 100 : 0;
        double failRate = total > 0 ? (double) failed / total * 100 : 0;
        String dateStr = LocalDateTime.now().format(TITLE_DATE);

        StringBuilder sb = new StringBuilder(16 * 1024);
        // ---- 构建导航侧边栏链接 ----
        StringBuilder navLinks = new StringBuilder();
        navLinks.append("<nav class='sidebar'><div class='nav-title'>E2E Report</div>");
        navLinks.append("<a href='#summary'>测试汇总</a>");
        navLinks.append("<a href='#scenarios'>场景结果</a>");
        navLinks.append("<a href='#steps'>步骤明细</a>");
        navLinks.append("<div class='nav-section'>Scenarios</div>");
        for (ScenarioResult r : results) {
            String sid = "S" + (r.getScenario().getSeqNo() > 0 ? r.getScenario().getSeqNo() : "");
            navLinks.append("<a href='#").append(sid).append("' class='nav-")
                    .append(r.getStatus().name().equals("PASSED") ? "pass" : "fail").append("'>")
                    .append(sid).append("-").append(esc(r.getScenario().getScenarioId())).append("</a>");
        }
        navLinks.append("</nav>");

        sb.append("<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"UTF-8\">")
                .append("<title>E2E Test Reports-").append(dateStr).append("</title><style>")
                .append("body{font-family:system-ui,'Microsoft YaHei',sans-serif;margin:0;background:#f0f2f5;color:#1f2329}")
                .append("*{box-sizing:border-box}")
                .append(".layout{display:flex;min-height:100vh}")
                .append(".sidebar{width:220px;position:fixed;top:0;left:0;height:100vh;overflow-y:auto;background:#1e293b;border-right:1px solid #334155;padding:16px 10px;z-index:100;box-shadow:2px 0 8px rgba(0,0,0,0.1)}")
                .append(".nav-title{font-size:15px;font-weight:700;margin-bottom:16px;padding:8px 10px;color:#fff;border-bottom:1px solid #334155}")
                .append(".nav-section{font-size:10px;color:#94a3b8;text-transform:uppercase;margin:16px 6px 6px;font-weight:600;letter-spacing:0.5px}")
                .append(".sidebar a{display:block;padding:6px 12px;font-size:12px;color:#cbd5e1;text-decoration:none;border-radius:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:background 0.15s}")
                .append(".sidebar a:hover{background:#334155;color:#fff}")
                .append(".sidebar a.nav-pass::before{content:'\\2705 '}.sidebar a.nav-fail::before{content:'\\274C '}")
                .append(".content{margin-left:220px;padding:28px 32px;flex:1;min-width:0}")
                .append("h1{font-size:24px;margin-bottom:4px}")
                .append("h2{font-size:17px;margin-top:32px;padding-bottom:6px;border-bottom:2px solid #e0e0e0}")
                .append(".card{background:#fff;border-radius:8px;padding:16px 20px;margin:12px 0;box-shadow:0 1px 3px rgba(0,0,0,0.08)}")
                .append("table{border-collapse:collapse;width:100%;background:#fff;font-size:13px;margin-top:10px;border-radius:6px;overflow:hidden}")
                .append("th,td{border:1px solid #e2e8f0;padding:7px 12px;text-align:left;vertical-align:top}")
                .append("th{background:#f8fafc;font-weight:600;color:#475569}")
                .append("td:last-child,th:last-child{max-width:300px;word-break:break-word;overflow-wrap:break-word}")
                .append(".pass{color:#16a34a;font-weight:600}.fail{color:#dc2626;font-weight:600}")
                .append(".skip{color:#d97706;font-weight:600}.muted{color:#94a3b8}")
                .append(".summary-box{display:flex;gap:24px;align-items:center;margin:16px 0;flex-wrap:nowrap;width:100%}")
                .append(".summary-table{flex:1 1 auto;border:1px solid #e2e8f0;border-collapse:collapse;font-size:12px;border-radius:6px;overflow:hidden}")
                .append(".summary-table td{padding:5px 12px;border:1px solid #e2e8f0}")
                .append(".summary-table .label{color:#64748b;font-weight:600;white-space:nowrap;background:#f8fafc}")
                .append(".summary-table .value{font-weight:700}")
                .append(".pie-chart{flex:0 0 160px;min-width:160px}")
                .append(".dag-label{font-size:12px;font-weight:600;color:#64748b;margin:10px 0 4px}")
                .append(".dag-container{background:#fff;border-radius:6px;padding:12px;margin-bottom:8px;border:1px solid #e2e8f0}")
                .append("</style></head><body>");
        sb.append("<div class='layout'>");
        sb.append(navLinks);
        sb.append("<main class='content'>");
        sb.append("<h1>E2E Test Reports-").append(dateStr).append("</h1>")
                .append("<p class=\"muted\">生成时间: ").append(LocalDateTime.now().format(TS))
                .append(" &nbsp;|&nbsp; 数据源: ").append(esc(sourceName)).append("</p>");

        // ---- 汇总表格 + 饼图 ----
        sb.append("<h2 id='summary'>测试汇总</h2>");
        sb.append("<div class='summary-box'>");
        // 汇总表（左侧）
        sb.append("<table class='summary-table'>");
        sb.append("<tr><td class='label'>日期</td><td class='value'>").append(dateStr).append("</td></tr>");
        sb.append("<tr><td class='label'>测试 Scenarios 总数量</td><td class='value'>").append(total).append("</td></tr>");
        sb.append("<tr><td class='label'>通过</td><td class='value' style='color:#1a7f37'>").append(passed).append("</td></tr>");
        sb.append("<tr><td class='label'>失败</td><td class='value' style='color:#c62828'>").append(failed).append("</td></tr>");
        sb.append("<tr><td class='label'>跳过</td><td class='value' style='color:#b58900'>").append(skipped).append("</td></tr>");
        sb.append("<tr><td class='label'>成功率</td><td class='value' style='color:#1a7f37'>").append(String.format("%.1f%%", passRate)).append("</td></tr>");
        sb.append("<tr><td class='label'>失败率</td><td class='value' style='color:#c62828'>").append(String.format("%.1f%%", failRate)).append("</td></tr>");
        sb.append("<tr><td class='label'>总耗时</td><td class='value'>").append(totalDurationMs).append("ms</td></tr>");
        sb.append("</table>");
        // 饼图（右侧）
        sb.append("<div class='pie-chart'>");
        sb.append(renderPieChart((int) passed, (int) failed, (int) skipped));
        sb.append("</div>");
        sb.append("</div>");

        // ---- 场景结果表（含 Seq 列） ----
        sb.append("<h2 id='scenarios'>场景结果</h2><table><tr><th>Seq</th><th>Scenario</th><th>Owner</th><th>状态</th><th>步骤</th><th>通过/失败/跳过</th><th>耗时</th><th>消息</th></tr>");
        for (ScenarioResult r : results) {
            sb.append("<tr><td>").append(r.getScenario().getSeqNo() > 0 ? r.getScenario().getSeqNo() : "")
                    .append("</td><td>").append(esc(r.getScenario().getScenarioId()))
                    .append("</td><td>").append(esc(r.getScenario().getOwner()))
                    .append("</td><td class=\"").append(css(r.getStatus().name())).append("\">")
                    .append(r.getStatus()).append("</td><td>").append(r.getStepResults().size())
                    .append("</td><td>").append(r.passedCount()).append("/").append(r.failedCount())
                    .append("/").append(r.skippedCount()).append("</td><td>").append(r.getDurationMs()).append("ms</td><td>")
                    .append(esc(r.getMessage()).replace("\n", "<br>")).append("</td></tr>");
        }
        sb.append("</table>");

        sb.append("<h2 id='steps'>步骤明细</h2>");
        for (ScenarioResult r : results) {
            String sid = "S" + (r.getScenario().getSeqNo() > 0 ? r.getScenario().getSeqNo() : "");
            sb.append("<h2 id='").append(sid).append("' style='font-size:14px'>").append(sid).append("-").append(esc(r.getScenario().getScenarioId())).append("</h2>");
            // DAG 依赖图（节点=APP，边标记=步骤状态）
            sb.append("<div class='dag-label'>Scenario Flow DAG</div>");
            sb.append("<div class='dag-container'>");
            sb.append(renderDagDiagram(r));
            sb.append("</div>");
            sb.append("<table><tr><th>SEQ</th><th>Step</th><th>APP:ACTION</th><th>状态</th><th>尝试</th><th>耗时</th><th>消息</th></tr>");
            for (var step : r.getStepResults()) {
                sb.append("<tr><td>").append(step.getStep().getSeqNo())
                        .append("</td><td>").append(esc(step.getStep().getStepId()))
                        .append("</td><td>").append(esc(step.getStep().actionKey()))
                        .append("</td><td class=\"").append(css(step.getStatus().name())).append("\">")
                        .append(step.getStatus())
                        .append("</td><td>").append(step.getAttempts())
                        .append("</td><td>").append(step.getDurationMs()).append("ms</td><td>")
                        .append(esc(step.getMessage()).replace("\n", "<br>")).append("</td></tr>");
            }
            sb.append("</table>");
        }

        if (issues != null && !issues.isEmpty()) {
            sb.append("<h2>数据质量提示</h2><table><tr><th>来源</th><th>场景/步骤</th><th>问题</th><th>处理</th></tr>");
            for (DataQualityIssue i : issues) {
                sb.append("<tr><td>").append(esc(i.getSource()))
                        .append("</td><td>").append(esc((i.getScenarioId() == null ? "" : i.getScenarioId())
                                + (i.getStepId() == null ? "" : "/" + i.getStepId())))
                        .append("</td><td>").append(esc(i.getField() + ": " + i.getIssue()))
                        .append("</td><td>").append(esc(i.getHandling())).append("</td></tr>");
            }
            sb.append("</table>");
        }

        // AI 执行摘要（e2e.ai.features.report-interpretation=true 时填充）
        if (aiSummary != null && !aiSummary.isBlank()) {
            sb.append("<h2>AI 执行摘要</h2><div style='background:#fff;border:1px solid #dcdfe6;"
                    + "padding:16px;white-space:pre-wrap;font-size:13px;line-height:1.6'>")
                    .append(esc(aiSummary))
                    .append("</div>");
        }

        sb.append("</main></div>"); // close content + layout
        sb.append("</body></html>");
        return sb.toString();
    }

    /**
     * 渲染场景的 DAG 依赖图（SVG）。
     * <p>节点 = APP 名称（矩形），颜色按步骤状态着色（绿=PASSED/红=FAILED/黄=SKIPPED）。
     * 边 = DEPENDS_ON 依赖箭头，边上标注 ✓（通过）/ ✗（失败）/ ⊘（跳过）。
     */
    private static String renderDagDiagram(ScenarioResult result) {
        var stepResults = result.getStepResults();
        if (stepResults == null || stepResults.isEmpty()) {
            return "";
        }
        // 只对 2+ 步骤的场景画 DAG
        if (stepResults.size() < 2) {
            return "";
        }

        // 1. 构建依赖图 + 收集节点信息
        java.util.Map<String, StepNode> nodes = new java.util.LinkedHashMap<>();
        java.util.Map<String, java.util.List<String>> edges = new java.util.LinkedHashMap<>(); // targetStepId -> [sourceStepId...]
        for (var sr : stepResults) {
            String stepId = sr.getStep().getStepId();
            String app = sr.getStep().getApp() == null ? "?" : sr.getStep().getApp();
            String status = sr.getStatus().name();
            // 节点标签：序号-APP（如 1-SMARTS, 2-DNS）
            String label = sr.getStep().getSeqNo() + "-" + app;
            nodes.put(stepId, new StepNode(stepId, label, status));
        }
        // 第二遍：构建边（只保留指向存在节点的依赖）
        for (var sr : stepResults) {
            String stepId = sr.getStep().getStepId();
            for (String dep : sr.getStep().getDependsOn()) {
                if (nodes.containsKey(dep)) {
                    edges.computeIfAbsent(stepId, k -> new java.util.ArrayList<>()).add(dep);
                }
            }
        }

        // 2. 拓扑分层（Kahn 算法简化版）
        java.util.Set<String> remaining = new java.util.LinkedHashSet<>(nodes.keySet());
        java.util.Set<String> completed = new java.util.HashSet<>();
        java.util.List<java.util.List<String>> layers = new java.util.ArrayList<>();
        while (!remaining.isEmpty()) {
            java.util.List<String> layer = new java.util.ArrayList<>();
            for (String sid : remaining) {
                java.util.List<String> deps = edges.getOrDefault(sid, java.util.List.of());
                if (completed.containsAll(deps)) {
                    layer.add(sid);
                }
            }
            if (layer.isEmpty()) {
                // 依赖环：剩余节点全部放一层
                layer.addAll(remaining);
            }
            for (String sid : layer) {
                remaining.remove(sid);
                completed.add(sid);
            }
            layers.add(layer);
        }

        // 3. 计算 SVG 布局（纯横向：层左→右，层内节点也左→右）
        int nodeW = 72, nodeH = 26;
        int baseLayerGap = 140, nodeGap = 50;
        int maxNodesInLayer = 1;
        for (var layer : layers) {
            maxNodesInLayer = Math.max(maxNodesInLayer, layer.size());
        }
        // 有效层间距 = max(基础间距, 最宽层宽度 + 40px gap)，确保多节点层不与下一层重叠
        int maxLayerWidth = nodeW;
        for (var layer : layers) {
            int w = layer.size() * (nodeW + 12) - 12;
            maxLayerWidth = Math.max(maxLayerWidth, w);
        }
        int layerGap = Math.max(baseLayerGap, maxLayerWidth + 40);
        int svgW = 10 + layers.size() * layerGap + 10;
        // SVG 高度：单节点层只需 nodeH + padding；多节点层按实际间距
        int singleLayerH = nodeH + 10;
        int multiLayerH = maxNodesInLayer > 1 ? (maxNodesInLayer - 1) * nodeGap + nodeH + 10 : singleLayerH;
        int svgH = Math.max(singleLayerH, multiLayerH);
        java.util.Map<String, int[]> coords = new java.util.HashMap<>();
        for (int li = 0; li < layers.size(); li++) {
            var layer = layers.get(li);
            // 每层的实际内容高度（单节点=nodeH，多节点按间距展开）
            int layerContentH = layer.size() > 1 ? (layer.size() - 1) * nodeGap + nodeH : nodeH;
            int startY = (svgH - layerContentH) / 2;
            for (int ni = 0; ni < layer.size(); ni++) {
                String sid = layer.get(ni);
                int x = 10 + li * layerGap + (layer.size() > 1 ? ni * (nodeW + 12) : 0);
                int y = startY + (layer.size() > 1 ? ni * nodeGap : 0);
                coords.put(sid, new int[]{x, y});
            }
        }

        // 4. 绘制 SVG
        StringBuilder svg = new StringBuilder();
        svg.append("<svg width='").append(svgW).append("' height='").append(svgH)
                .append("' style='display:block;overflow:visible'>");

        // 先画边（水平连接：源节点右侧 → 目标节点左侧）
        for (var entry : edges.entrySet()) {
            String targetId = entry.getKey();
            StepNode targetNode = nodes.get(targetId);
            int[] targetCoord = coords.get(targetId);
            if (targetCoord == null) continue;
            int tx = targetCoord[0];        // 目标节点左侧中点
            int ty = targetCoord[1] + nodeH / 2;
            for (String sourceId : entry.getValue()) {
                int[] sourceCoord = coords.get(sourceId);
                if (sourceCoord == null) continue;
                int sx = sourceCoord[0] + nodeW;  // 源节点右侧中点
                int sy = sourceCoord[1] + nodeH / 2;
                // 边颜色：按目标步骤状态
                String edgeColor = "#1a7f37";
                String mark = "\u2713";
                if (targetNode.status.equals("FAILED") || targetNode.status.equals("TIMEOUT")
                        || targetNode.status.equals("ERROR") || targetNode.status.equals("DATA_ERROR")) {
                    edgeColor = "#c62828";
                    mark = "\u2717";
                } else if (targetNode.status.equals("SKIPPED")) {
                    edgeColor = "#b58900";
                    mark = "\u2298";
                }
                // 贝塞尔曲线（水平 S 形，控制点在中间偏移）
                int midX = (sx + tx) / 2;
                int cpOffset = (tx - sx) / 3; // 控制点偏移量
                svg.append("<path d='M").append(sx).append(",").append(sy)
                        .append(" C").append(sx + cpOffset).append(",").append(sy)
                        .append(" ").append(tx - cpOffset).append(",").append(ty)
                        .append(" ").append(tx).append(",").append(ty)
                        .append("' stroke='").append(edgeColor).append("' stroke-width='2' fill='none'")
                        .append(" marker-end='url(#dagarrow-").append(edgeColor.replace("#","")).append(")'/>");
                // 边上标记（放在连线中点上方）
                int labelY = (sy + ty) / 2 - 4;
                svg.append("<rect x='").append(midX - 8).append("' y='").append(labelY - 10)
                        .append("' width='16' height='14' rx='3' fill='#fff' stroke='").append(edgeColor)
                        .append("' stroke-width='1'/>");
                svg.append("<text x='").append(midX).append("' y='").append(labelY)
                        .append("' text-anchor='middle' font-size='12' font-weight='bold' fill='").append(edgeColor).append("'>")
                        .append(mark).append("</text>");
            }
        }

        // 定义箭头标记
        for (String[] arrowDef : new String[][]{
                {"#1a7f37", "dagarrow-1a7f37"},
                {"#c62828", "dagarrow-c62828"},
                {"#b58900", "dagarrow-b58900"}}) {
            svg.append("<defs><marker id='").append(arrowDef[1])
                    .append("' markerWidth='8' markerHeight='8' refX='7' refY='4' orient='auto'>")
                    .append("<path d='M0,0 L7,4 L0,8 Z' fill='").append(arrowDef[0]).append("'/></marker></defs>");
        }

        // 画节点
        for (var layer : layers) {
            for (String sid : layer) {
                StepNode node = nodes.get(sid);
                int[] coord = coords.get(sid);
                String fill, textColor, borderColor;
                switch (node.status) {
                    case "PASSED" -> { fill = "#dcfce7"; textColor = "#15803d"; borderColor = "#86efac"; }
                    case "FAILED", "TIMEOUT", "ERROR", "DATA_ERROR" -> { fill = "#fee2e2"; textColor = "#dc2626"; borderColor = "#fca5a5"; }
                    case "SKIPPED" -> { fill = "#fef3c7"; textColor = "#d97706"; borderColor = "#fcd34d"; }
                    default -> { fill = "#f1f5f9"; textColor = "#475569"; borderColor = "#cbd5e1"; }
                }
                svg.append("<rect x='").append(coord[0]).append("' y='").append(coord[1])
                        .append("' width='").append(nodeW).append("' height='").append(nodeH)
                        .append("' rx='5' fill='").append(fill).append("' stroke='").append(borderColor)
                        .append("' stroke-width='1.5'/>");
                svg.append("<text x='").append(coord[0] + nodeW / 2).append("' y='")
                        .append(coord[1] + nodeH / 2 + 4)
                        .append("' text-anchor='middle' font-size='11' font-weight='600' fill='")
                        .append(textColor).append("'>").append(esc(node.app)).append("</text>");
            }
        }

        svg.append("</svg>");
        return svg.toString();
    }

    /** DAG 节点内部数据结构 */
    private record StepNode(String stepId, String app, String status) {}

    /** SVG donut 饼图：通过/失败/跳过三段 */
    private static String renderPieChart(int passed, int failed, int skipped) {
        int total = passed + failed + skipped;
        if (total == 0) {
            return "<svg width='160' height='110'><circle cx='50' cy='55' r='42' fill='none' stroke='#e0e0e0' stroke-width='12'/></svg>";
        }
        int[] values = {passed, failed, skipped};
        String[] colors = {"#1a7f37", "#c62828", "#b58900"};
        String[] labels = {"Pass", "Fail", "Skip"};
        int cx = 50, cy = 55, r = 42, hole = 22;

        // 特殊情况：只有一个非零段（100%）→ 画整圆
        int nonZero = 0, nonZeroIdx = -1;
        for (int i = 0; i < 3; i++) {
            if (values[i] > 0) { nonZero++; nonZeroIdx = i; }
        }
        if (nonZero == 1) {
            return "<svg width='160' height='110'>"
                    + "<circle cx='" + cx + "' cy='" + cy + "' r='" + r + "' fill='" + colors[nonZeroIdx] + "'/>"
                    + "<circle cx='" + cx + "' cy='" + cy + "' r='" + hole + "' fill='#f7f8fa'/>"
                    + legendSvg(colors, labels, values)
                    + "</svg>";
        }

        // 多段弧形
        double startAngle = -Math.PI / 2;
        StringBuilder arcs = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            if (values[i] == 0) continue;
            double fraction = (double) values[i] / total;
            double endAngle = startAngle + fraction * 2 * Math.PI;
            if (fraction >= 0.999) {
                arcs.append("<circle cx='").append(cx).append("' cy='").append(cy).append("' r='")
                        .append(r).append("' fill='").append(colors[i]).append("'/>");
            } else {
                double largeArc = fraction > 0.5 ? 1 : 0;
                double x1 = cx + r * Math.cos(startAngle);
                double y1 = cy + r * Math.sin(startAngle);
                double x2 = cx + r * Math.cos(endAngle);
                double y2 = cy + r * Math.sin(endAngle);
                arcs.append("<path d='M").append(cx).append(",").append(cy).append(" L")
                        .append(fmt(x1)).append(",").append(fmt(y1))
                        .append(" A").append(r).append(",").append(r).append(" 0 ")
                        .append((int) largeArc).append(" 1 ")
                        .append(fmt(x2)).append(",").append(fmt(y2))
                        .append(" Z' fill='").append(colors[i]).append("'/>");
            }
            startAngle = endAngle;
        }
        arcs.append("<circle cx='").append(cx).append("' cy='").append(cy).append("' r='")
                .append(hole).append("' fill='#f7f8fa'/>");
        return "<svg width='160' height='110'>" + arcs + legendSvg(colors, labels, values) + "</svg>";
    }

    /** 图例 SVG */
    private static String legendSvg(String[] colors, String[] labels, int[] values) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            sb.append("<text x='100' y='").append(30 + i * 16).append("' font-size='11' fill='#5f6368'>")
                    .append("<tspan fill='").append(colors[i]).append("'>\u25CF</tspan> ")
                    .append(labels[i]).append(": ").append(values[i]).append("</text>");
        }
        return sb.toString();
    }

    private static String fmt(double v) {
        return String.format(java.util.Locale.ROOT, "%.2f", v);
    }

    private static String css(String status) {
        return switch (status) {
            case "PASSED" -> "pass";
            case "FAILED", "TIMEOUT", "ERROR", "DATA_ERROR" -> "fail";
            default -> "skip";
        };
    }

    private static String esc(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
