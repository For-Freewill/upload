package com.e2e.framework;

import com.e2e.framework.engine.ScenarioExecutor;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.TestDataBundle;
import com.e2e.framework.model.results.ScenarioResult;
import com.e2e.framework.model.results.ScenarioStatus;
import com.e2e.framework.report.ConsoleReportPrinter;
import com.e2e.framework.data.TestDataLoader;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.List;

/**
 * E2E 自动化测试框架入口。
 *
 * <p>两种运行形态：
 * <ul>
 *   <li><b>TestNG 数据驱动</b>（推荐）：由 {@code testng.xml} 驱动 {@code E2ETestRunner}，
 *       每个启用的场景作为一个 TestNG 用例执行；</li>
 *   <li><b>CLI 直跑</b>：{@code java -jar e2e-automation.jar --cli.execute}，
 *       直接执行全部启用场景并输出控制台报告（适合流水线冒烟）。</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@SpringBootApplication(scanBasePackages = {"com.e2e.framework"})
@ConfigurationPropertiesScan(basePackages = {"com.e2e.framework"})
@EnableScheduling
public class E2EApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(E2EApplication.class);
        app.setBannerMode(Banner.Mode.OFF);
        ConfigurableApplicationContext ctx = app.run(args);

        boolean cliExecute = List.of(args).contains("--cli.execute");
        if (cliExecute) {
            runAllAndExit(ctx);
        }
    }

    private static void runAllAndExit(ConfigurableApplicationContext ctx) {
        TestDataLoader loader = ctx.getBean(TestDataLoader.class);
        ScenarioExecutor executor = ctx.getBean(ScenarioExecutor.class);
        ConsoleReportPrinter printer = ctx.getBean(ConsoleReportPrinter.class);

        TestDataBundle bundle = loader.load();
        List<ScenarioResult> results = bundle.getScenarios().values().stream()
                .filter(ScenarioDefinition::isEnabled)
                .map(executor::execute)
                .toList();

        printer.print(results, bundle.getIssues());

        boolean allGreen = results.stream()
                .allMatch(r -> r.getStatus() == ScenarioStatus.PASSED || r.getStatus() == ScenarioStatus.SKIPPED);
        ctx.close();
        System.exit(allGreen ? 0 : 1);
    }
}
