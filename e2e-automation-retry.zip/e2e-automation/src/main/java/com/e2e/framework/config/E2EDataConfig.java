package com.e2e.framework.config;

import com.e2e.framework.data.TestDataBootstrap;
import com.e2e.framework.data.TestDataLoader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 数据装载层 Spring 装配（支持系统属性覆盖，见 TestDataBootstrap）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Configuration
public class E2EDataConfig {

    @Bean
    public TestDataLoader testDataLoader(E2EProperties props) {
        return TestDataBootstrap.createLoader(props);
    }
}
