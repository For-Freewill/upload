package com.e2e.framework.engine;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.AssertionRule;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 断言操作符评估器 —— 评估「实际值 vs 期望值」（AssertionEngine 的操作符职责拆分）。
 *
 * <p>职责边界：只负责<b>比对与判定</b>，不做内容加载（见 {@link ContentResolver}）。
 * 失败时抛出 {@link AssertionEngine.AssertionFailureException}（含差异详情）。
 *
 * <h3>字符串模式操作符（14 种）</h3>
 * EQ / NE / CONTAINS / NOT_CONTAINS / EMPTY / NOT_EMPTY / SIZE / GT / GTE / LT / LTE /
 * REGEX / EXISTS / WAIT_UNTIL（POLL_UNTIL 别名）
 *
 * <h3>Map 模式操作符</h3>
 * EQ（行集合全等）/ NE / CONTAINS（子集）/ NOT_CONTAINS / EXISTS / SIZE 族 / EMPTY 族
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@Component
public class OperatorEvaluator {

    // ===================== 字符串模式 =====================

    public void evaluateRule(AssertionRule rule, List<String> actual) {
        String op = rule.getOp();
        List<String> expected = rule.getExpected();
        switch (op) {
            case "EQ" -> requireEqual(rule, actual, expected);
            case "NE" -> {
                if (sortedCopy(actual).equals(sortedCopy(expected))) {
                    fail(rule, actual, "实际值与期望值不应相等");
                }
            }
            case "CONTAINS" -> {
                for (String e : expected) {
                    boolean found = actual.stream().anyMatch(a -> a != null && a.contains(e));
                    if (!found) fail(rule, actual, "缺少期望值: " + e);
                }
            }
            case "NOT_CONTAINS" -> {
                for (String e : expected) {
                    boolean found = actual.stream().anyMatch(a -> a != null && a.contains(e));
                    if (found) fail(rule, actual, "出现了不应出现的值: " + e);
                }
            }
            case "EMPTY" -> { if (!actual.isEmpty()) fail(rule, actual, "期望结果为空"); }
            case "NOT_EMPTY" -> { if (actual.isEmpty()) fail(rule, actual, "期望结果非空"); }
            case "SIZE", "GT", "GTE", "LT", "LTE" -> compareSize(rule, actual, op, expected);
            case "REGEX" -> {
                if (expected.isEmpty()) fail(rule, actual, "REGEX 断言缺少期望表达式");
                boolean matched = actual.stream().anyMatch(a -> a != null && a.matches(expected.get(0)));
                if (!matched) fail(rule, actual, "无任何值匹配正则: " + expected.get(0));
            }
            case "EXISTS" -> { if (actual.isEmpty()) fail(rule, actual, "期望存在值"); }
            case "WAIT_UNTIL", "POLL_UNTIL" -> {
                if (actual.isEmpty() && !expected.isEmpty()) fail(rule, actual, "轮询条件未满足: 实际为空");
                if (!expected.isEmpty() && !actual.containsAll(expected))
                    fail(rule, actual, "轮询条件未满足: 缺少期望值 " + expected);
            }
            default -> fail(rule, actual, "不支持的断言操作符: " + op);
        }
    }

    // ===================== Map 模式 =====================

    public void evaluateMapRule(AssertionRule rule, List<Map<String, Object>> actualRows) {
        String op = rule.getOp();
        List<Map<String, String>> expectedRows = parseExpectedMaps(rule);

        switch (op) {
            case "EQ" -> assertMapEqual(rule, actualRows, expectedRows);
            case "NE" -> {
                if (mapSetEquals(actualRows, expectedRows)) {
                    failMap(rule, actualRows, "实际行与期望行不应相等");
                }
            }
            case "CONTAINS" -> assertMapContains(rule, actualRows, expectedRows);
            case "NOT_CONTAINS" -> assertMapNotContains(rule, actualRows, expectedRows);
            case "EXISTS" -> assertMapExists(rule, actualRows, expectedRows);
            case "SIZE", "GT", "GTE", "LT", "LTE" -> {
                int expectedSize = expectedRows.size();
                int actualSize = actualRows.size();
                boolean ok = switch (op) {
                    case "SIZE" -> actualSize == expectedSize;
                    case "GT" -> actualSize > expectedSize;
                    case "GTE" -> actualSize >= expectedSize;
                    case "LT" -> actualSize < expectedSize;
                    case "LTE" -> actualSize <= expectedSize;
                    default -> false;
                };
                if (!ok) {
                    failMap(rule, actualRows, "实际行数 " + actualSize + " 不满足 " + op + " " + expectedSize);
                }
            }
            case "EMPTY" -> {
                if (!actualRows.isEmpty()) {
                    failMap(rule, actualRows, "期望结果为空");
                }
            }
            case "NOT_EMPTY" -> {
                if (actualRows.isEmpty()) {
                    failMap(rule, actualRows, "期望结果非空");
                }
            }
            default -> failMap(rule, actualRows, "Map 模式不支持操作符: " + op
                    + "（支持 EQ/NE/CONTAINS/NOT_CONTAINS/EXISTS/SIZE/GT/GTE/LT/LTE/EMPTY/NOT_EMPTY）");
        }
    }

    /** EQ：实际行集合 == 期望行集合（忽略行序，每行所有字段完全匹配） */
    private void assertMapEqual(AssertionRule rule, List<Map<String, Object>> actualRows,
                                 List<Map<String, String>> expectedRows) {
        if (!mapSetEquals(actualRows, expectedRows)) {
            List<String> missing = new ArrayList<>();
            for (Map<String, String> exp : expectedRows) {
                boolean found = actualRows.stream().anyMatch(act -> rowMatches(act, exp));
                if (!found) missing.add(JSON.toJSONString(exp));
            }
            List<String> extra = new ArrayList<>();
            for (Map<String, Object> act : actualRows) {
                boolean found = expectedRows.stream().anyMatch(exp -> rowMatches(act, exp));
                if (!found) extra.add(JSON.toJSONString(act));
            }
            failMap(rule, actualRows, "行集合不匹配\n  缺少的期望行: " + missing
                    + "\n  多出的实际行: " + extra);
        }
    }

    /** CONTAINS：每个期望行是某个实际行的子集 */
    private void assertMapContains(AssertionRule rule, List<Map<String, Object>> actualRows,
                                    List<Map<String, String>> expectedRows) {
        for (Map<String, String> exp : expectedRows) {
            boolean found = actualRows.stream().anyMatch(act -> rowMatches(act, exp));
            if (!found) {
                failMap(rule, actualRows, "没有实际行匹配期望行: " + JSON.toJSONString(exp));
            }
        }
    }

    /** NOT_CONTAINS：没有实际行匹配任何期望行 */
    private void assertMapNotContains(AssertionRule rule, List<Map<String, Object>> actualRows,
                                       List<Map<String, String>> expectedRows) {
        for (Map<String, String> exp : expectedRows) {
            boolean found = actualRows.stream().anyMatch(act -> rowMatches(act, exp));
            if (found) {
                failMap(rule, actualRows, "存在不应出现的行: " + JSON.toJSONString(exp));
            }
        }
    }

    /** EXISTS：至少有一个实际行匹配某个期望行 */
    private void assertMapExists(AssertionRule rule, List<Map<String, Object>> actualRows,
                                  List<Map<String, String>> expectedRows) {
        boolean anyMatch = expectedRows.stream()
                .anyMatch(exp -> actualRows.stream().anyMatch(act -> rowMatches(act, exp)));
        if (!anyMatch) {
            failMap(rule, actualRows, "没有任何实际行匹配期望行");
        }
    }

    // ===================== Map 模式工具 =====================

    /** 检查实际行集合是否等于期望行集合（忽略顺序） */
    private boolean mapSetEquals(List<Map<String, Object>> actualRows, List<Map<String, String>> expectedRows) {
        if (actualRows.size() != expectedRows.size()) return false;
        for (Map<String, String> exp : expectedRows) {
            boolean found = actualRows.stream().anyMatch(act -> rowMatches(act, exp));
            if (!found) return false;
        }
        return true;
    }

    /** 实际行匹配期望行（期望行每个字段在实际行中存在且值相等，字符串比较，列名大小写不敏感） */
    private boolean rowMatches(Map<String, Object> actualRow, Map<String, String> expectedRow) {
        for (var entry : expectedRow.entrySet()) {
            Object actualVal = getCaseInsensitive(actualRow, entry.getKey());
            if (actualVal == null) return false;
            if (!String.valueOf(actualVal).equals(entry.getValue())) return false;
        }
        return true;
    }

    /** 大小写不敏感的 Map 取值 */
    private Object getCaseInsensitive(Map<String, Object> map, String key) {
        Object val = map.get(key);
        if (val != null) return val;
        for (var entry : map.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue();
        }
        return null;
    }

    /** 解析 EXPECTED 中的 JSON 对象为 Map 列表 */
    private List<Map<String, String>> parseExpectedMaps(AssertionRule rule) {
        List<Map<String, String>> result = new ArrayList<>();
        for (String exp : rule.getExpected()) {
            if (exp == null || exp.isBlank()) continue;
            String trimmed = exp.trim();
            if (trimmed.startsWith("{")) {
                JSONObject obj = JSON.parseObject(trimmed);
                Map<String, String> map = new java.util.LinkedHashMap<>();
                for (var entry : obj.entrySet()) {
                    map.put(entry.getKey(), entry.getValue() == null ? null : String.valueOf(entry.getValue()));
                }
                result.add(map);
            }
        }
        return result;
    }

    // ===================== 字符串模式工具 =====================

    private void compareSize(AssertionRule rule, List<String> actual, String op, List<String> expected) {
        if (expected.isEmpty()) fail(rule, actual, op + " 断言缺少期望值");
        int expectedSize;
        try { expectedSize = Integer.parseInt(expected.get(0).trim()); }
        catch (NumberFormatException e) { fail(rule, actual, "期望值不是数字: " + expected.get(0)); return; }
        int actualSize = actual.size();
        boolean ok = switch (op) {
            case "SIZE" -> actualSize == expectedSize;
            case "GT" -> actualSize > expectedSize;
            case "GTE" -> actualSize >= expectedSize;
            case "LT" -> actualSize < expectedSize;
            case "LTE" -> actualSize <= expectedSize;
            default -> false;
        };
        if (!ok) fail(rule, actual, "实际条数 " + actualSize + " 不满足 " + op + " " + expectedSize);
    }

    private void requireEqual(AssertionRule rule, List<String> actual, List<String> expected) {
        if (!sortedCopy(actual).equals(sortedCopy(expected))) {
            fail(rule, actual, "实际值 " + actual + " != 期望值 " + expected);
        }
    }

    private List<String> sortedCopy(List<String> list) {
        List<String> copy = new ArrayList<>();
        for (String s : list) copy.add(s == null ? "<null>" : s);
        copy.sort(String::compareTo);
        return copy;
    }

    // ===================== 失败报告 =====================

    private void fail(AssertionRule rule, List<String> actual, String reason) {
        throw new AssertionEngine.AssertionFailureException("断言失败 [" + rule.getSource() + " " + rule.getOp() + "] "
                + reason + "\n  规则原文: " + rule.getRaw());
    }

    private void failMap(AssertionRule rule, List<Map<String, Object>> actualRows, String reason) {
        throw new AssertionEngine.AssertionFailureException("断言失败 [" + rule.getSource() + " " + rule.getOp() + " (Map)] "
                + reason + "\n  规则原文: " + rule.getRaw()
                + "\n  实际行(" + actualRows.size() + "): " + abbreviateRows(actualRows));
    }

    private String abbreviateRows(List<Map<String, Object>> rows) {
        String s = JSON.toJSONString(rows);
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
