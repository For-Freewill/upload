package com.e2e.framework.actions.ui;

import com.e2e.framework.actions.ui.AbstractUiAction;
import com.e2e.framework.registry.ActionSpec;

/**
 * DRP 域：DRP_UI_REPORTS —— 通过 UI（JAVA 协议）验证 DRP 报表。
 *
 * <p>INPUT 示例：{@code [{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":"test_account2"}}]}
 * url 为 UI 处理器注册名（@UiHandler），实现 Selenium 等真实页面操作时替换同名处理器即可。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DRP"}, action = "DRP_UI_REPORTS", description = "DRP 报表 UI 校验（JAVA 协议）")
public class DrpUiReportsAction extends AbstractUiAction {
    @Override
    protected String businessName() { return "DRP 报表校验"; }
}
