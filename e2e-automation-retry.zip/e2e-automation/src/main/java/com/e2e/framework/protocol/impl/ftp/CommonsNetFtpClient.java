package com.e2e.framework.protocol.impl.ftp;

import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.protocol.FtpClient;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * FTP live 实现：基于 Apache commons-net FTPClient。
 *
 * <p>每次操作建立新连接（命令式短连接语义，与测试步骤天然对齐），
 * 连接参数来自 e2e.ftp.* 全局配置。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class CommonsNetFtpClient implements FtpClient {

    private static final Logger log = LoggerFactory.getLogger(CommonsNetFtpClient.class);

    private final E2EProperties.Ftp ftpProps;

    public CommonsNetFtpClient(E2EProperties.Ftp ftpProps) {
        this.ftpProps = ftpProps;
    }

    @Override
    public FtpResult upload(String localPath, String remotePath) {
        return withClient((client, out) -> {
            Path local = Paths.get(localPath);
            if (!Files.exists(local)) {
                out.success = false;
                out.message = "本地文件不存在: " + localPath;
                return;
            }
            try (InputStream is = Files.newInputStream(local)) {
                boolean ok = client.storeFile(remotePath, is);
                out.success = ok;
                out.message = ok ? "上传成功: " + localPath + " -> " + remotePath
                        : "上传失败: " + client.getReplyString();
            }
        });
    }

    @Override
    public FtpResult download(String remotePath, String localPath) {
        return withClient((client, out) -> {
            Path local = Paths.get(localPath);
            if (local.getParent() != null) Files.createDirectories(local.getParent());
            try (OutputStream os = Files.newOutputStream(local)) {
                boolean ok = client.retrieveFile(remotePath, os);
                out.success = ok;
                out.message = ok ? "下载成功: " + remotePath + " -> " + localPath
                        : "下载失败: " + client.getReplyString();
            }
        });
    }

    @Override
    public List<Map<String, Object>> list(String remoteDir) {
        FTPClient client;
        try {
            client = connect();
        } catch (Exception e) {
            log.warn("[ftp] 连接失败，list 返回空: {}", e.getMessage());
            return List.of();
        }
        try {
            FTPFile[] files = client.listFiles(remoteDir);
            List<Map<String, Object>> result = new ArrayList<>();
            for (FTPFile f : files) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("name", f.getName());
                row.put("size", f.getSize());
                row.put("type", f.isDirectory() ? "DIR" : "FILE");
                row.put("modifiedTime", f.getTimestamp() == null ? "" : f.getTimestamp().getTimeInMillis());
                result.add(row);
            }
            log.info("[ftp] list {} -> {} entries", remoteDir, result.size());
            return result;
        } catch (IOException e) {
            log.warn("[ftp] list 失败: {} - {}", remoteDir, e.getMessage());
            return List.of();
        } finally {
            disconnect(client);
        }
    }

    @Override
    public FtpResult delete(String remotePath) {
        return withClient((client, out) -> {
            try {
                boolean ok = client.deleteFile(remotePath);
                out.success = ok;
                out.message = ok ? "删除成功: " + remotePath : "删除失败: " + client.getReplyString();
            } catch (IOException e) {
                out.success = false;
                out.message = "删除异常: " + e.getMessage();
            }
        });
    }

    @Override
    public FtpResult mkdir(String remoteDir) {
        return withClient((client, out) -> {
            try {
                boolean ok = client.makeDirectory(remoteDir);
                out.success = ok;
                out.message = ok ? "目录创建成功: " + remoteDir : "目录创建失败: " + client.getReplyString();
            } catch (IOException e) {
                out.success = false;
                out.message = "创建目录异常: " + e.getMessage();
            }
        });
    }

    @Override
    public boolean exists(String remotePath) {
        FTPClient client;
        try {
            client = connect();
        } catch (Exception e) {
            log.warn("[ftp] 连接失败，exists 返回 false: {}", e.getMessage());
            return false;
        }
        try {
            try {
                FTPFile[] files = client.listFiles(remotePath);
                boolean exists = files != null && files.length > 0;
                log.info("[ftp] exists {} -> {}", remotePath, exists);
                return exists;
            } catch (IOException e) {
                return false;
            }
        } finally {
            disconnect(client);
        }
    }

    @Override
    public String describe() {
        return "commons-net-ftp (live, host=" + ftpProps.getHost() + ":" + ftpProps.getPort() + ")";
    }

    // ===================== 内部方法 =====================

    private interface FtpOperation {
        void run(FTPClient client, FtpResultHolder holder) throws IOException;
    }

    private static class FtpResultHolder {
        boolean success;
        String message = "";
    }

    private FtpResult withClient(FtpOperation op) {
        FtpResultHolder holder = new FtpResultHolder();
        holder.success = true;
        FTPClient client;
        try {
            client = connect();
        } catch (Exception e) {
            // 连接失败优雅返回（不抛异常，Action 层按 success=false 处理）
            return FtpResult.fail("FTP 连接失败 " + ftpProps.getHost() + ":" + ftpProps.getPort()
                    + ": " + e.getMessage());
        }
        try {
            op.run(client, holder);
        } catch (Exception e) {
            holder.success = false;
            holder.message = "FTP 操作异常: " + e.getMessage();
        } finally {
            disconnect(client);
        }
        return new FtpResult(holder.success, holder.message);
    }

    private FTPClient connect() {
        FTPClient client = new FTPClient();
        client.setControlEncoding("UTF-8");
        client.setConnectTimeout(15_000);
        try {
            client.connect(ftpProps.getHost(), ftpProps.getPort());
            if (!FTPReply.isPositiveCompletion(client.getReplyCode())) {
                throw new IllegalStateException("FTP 连接被拒绝: " + client.getReplyString());
            }
            if (!client.login(ftpProps.getUser(), ftpProps.getPassword())) {
                throw new IllegalStateException("FTP 登录失败: " + client.getReplyString());
            }
            client.enterLocalPassiveMode();
            client.setFileType(FTPClient.BINARY_FILE_TYPE);
            log.info("[ftp] 已连接 {}:{} user={}", ftpProps.getHost(), ftpProps.getPort(), ftpProps.getUser());
            return client;
        } catch (Exception e) {
            disconnect(client);
            throw new IllegalStateException("FTP 连接失败 " + ftpProps.getHost() + ":" + ftpProps.getPort()
                    + ": " + e.getMessage(), e);
        }
    }

    private void disconnect(FTPClient client) {
        try {
            if (client.isConnected()) {
                client.logout();
                client.disconnect();
            }
        } catch (IOException ignore) {
            // 忽略断开异常
        }
    }
}
