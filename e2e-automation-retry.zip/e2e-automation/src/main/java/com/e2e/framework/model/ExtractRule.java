package com.e2e.framework.model;

/**
 * 提取规则 —— EXTRACT 列 JSON 数组中的对象，将步骤输出提取为场景级变量，
 * 供下游步骤通过 ${extract.name} 引用。
 *
 * <p>两种模式：
 * <ul>
 *   <li><b>提取模式</b>（from + path）：
 *       <pre>[{"name":"acctNo","from":"DB","path":"rows[0].ACCT_NO"}]</pre>
 *       from 指向 outputs 键（DB/STDOUT/body/firstMessage/FILE...），path 支持
 *       JSONPath（$.）/XPath（//）/Regex（regex:）/文件行（#L n）/Token 导航。</li>
 *   <li><b>字面量模式</b>（value）⭐ 场景级参数设置：
 *       <pre>[{"name":"acct","value":"999999"}]</pre>
 *       直接设置常量（支持 ${global.}/${env.} 引用组合），无需 from 输出。
 *       典型用法：scenario 首个 step 的 EXTRACT 定义场景级通用参数，后续步骤
 *       在 INPUT/ASSERT 中以 ${extract.acct} 引用，实现参数化传参。</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ExtractRule {

    private final String name;
    private final String from;
    private final String path;
    private final String raw;
    /** 字面量模式：直接设置值（非空时跳过 from/path 提取）；支持 ${} 变量引用 */
    private final String value;

    public ExtractRule(String name, String from, String path, String raw) {
        this(name, from, path, raw, null);
    }

    public ExtractRule(String name, String from, String path, String raw, String value) {
        this.name = name;
        this.from = from;
        this.path = path;
        this.raw = raw;
        this.value = value;
    }

    public String getName() { return name; }
    public String getFrom() { return from; }
    public String getPath() { return path; }
    public String getRaw() { return raw == null ? "" : raw; }
    /** 字面量值（null=提取模式）；支持 ${global.}/${env.}/${extract.} 引用 */
    public String getValue() { return value; }

    /** 是否为字面量设置模式 */
    public boolean isLiteral() { return value != null; }

    @Override
    public String toString() {
        return isLiteral()
                ? name + " = " + value + "（字面量设置）"
                : name + " <- " + from + "." + path;
    }
}
