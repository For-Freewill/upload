package com.e2e.framework.registry;

/**
 * APP 域单点操作接口 —— 框架的核心 SPI。
 *
 * <p>每个 (APP, ACTION) 组合对应一个实现，实现内完成该单点操作的全部副作用，
 * 并将可供断言/提取的数据放入 {@link ActionResult#getOutputs()}。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface AppAction {

    /**
     * @param context 步骤执行上下文（含变量替换后的 INPUT 载荷、协议客户端、场景变量等）
     * @return 执行结果（success + outputs）
     */
    ActionResult execute(ActionContext context) throws Exception;
}
