package com.e2e.framework.protocol;

import java.util.List;

/**
 * MQ 协议客户端（COMMON_MQ_SEND 发送 / COMMON_MQ_CONSUME 消费；live 实现为框架预留扩展点）
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public interface MqClient {

    /**
     * @param params  INPUT 中 MQ 载荷参数（fastjson2 对象，可含 queue/topic 覆盖项）
     * @param message 报文内容（由 file 字段加载的 XML/JSON 文本）
     */
    void send(Object params, String message);

    /**
     * 消费队列消息（COMMON_MQ_CONSUME 使用）。
     *
     * @param queue       队列名
     * @param maxMessages 最多消费条数
     * @param timeoutMs   等待超时（毫秒）
     * @return 消费到的报文列表（可能为空）
     */
    default List<String> consume(String queue, int maxMessages, long timeoutMs) {
        throw new UnsupportedOperationException("当前 MQ 客户端未实现消费（live 实现请覆盖 consume 方法）");
    }

    String describe();
}
