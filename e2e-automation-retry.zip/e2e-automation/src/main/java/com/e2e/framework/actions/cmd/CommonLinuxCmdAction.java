package com.e2e.framework.actions.cmd;

import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.ProtocolPayload;
import com.e2e.framework.protocol.CommandResult;
import com.e2e.framework.protocol.SshCommandClient;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.ActionSpec;
import com.e2e.framework.registry.AppAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DATAHUB 域：COMMON_LINUX_CMD —— Linux 命令执行（本地 + 远程 SSH）。
 *
 * <h3>两种执行模式</h3>
 * <ul>
 *   <li><b>本地模式</b>：host=local（或缺省），走本地命令客户端（sh -c）</li>
 *   <li><b>远程 SSH 模式</b>：host 指定远程服务器 IP/域名，走 SSH 连接（支持 user/password/port 认证）</li>
 * </ul>
 *
 * <h3>INPUT 格式</h3>
 * <pre>
 * // 本地 Linux 命令（base_dir + 批量命令）
 * [{"LINUX-CMD":{
 *   "host":"local",
 *   "base_dir":"/tmp",
 *   "cmd":["echo hello","ls -la","cat /etc/hostname"]
 * }}]
 *
 * // 远程 SSH 执行（完整认证参数）
 * [{"LINUX-CMD":{
 *   "host":"192.168.1.100",
 *   "port":22,
 *   "user":"root",
 *   "password":"secret",
 *   "base_dir":"/opt/app",
 *   "cmd":["ls -la","cat config.ini","df -h"]
 * }}]
 *
 * // 远程文件内容校验（cat 命令 + STDOUT 断言）
 * [{"LINUX-CMD":{
 *   "host":"192.168.1.100",
 *   "user":"root",
 *   "password":"secret",
 *   "cmd":["cat /etc/myapp/config.properties","tail -20 /var/log/myapp.log"]
 * }}]
 * ASSERT: [{"STDOUT":"","OP":"CONTAINS","EXPECTED":["database=mysql","port=3306"]}]
 * </pre>
 *
 * <h3>输出（outputs，供 ASSERT / EXTRACT 使用）</h3>
 * <ul>
 *   <li>{@code CMD} — 最终退出码</li>
 *   <li>{@code STDOUT} / {@code STDERR} — 合并输出</li>
 *   <li>{@code commandCount} / {@code lastCommand} — 命令信息</li>
 *   <li>{@code host} / {@code baseDir} — 执行环境</li>
 *   <li>{@code lines} — STDOUT 按行分割</li>
 * </ul>
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
@ActionSpec(apps = {"DATAHUB"}, action = "COMMON_LINUX_CMD",
            description = "Linux 命令执行（本地 或 远程 SSH：host/port/user/password 认证）")
public class CommonLinuxCmdAction extends CommonWindowsCmdAction {

    private static final Logger log = LoggerFactory.getLogger(CommonLinuxCmdAction.class);

    @Override
    public ActionResult execute(ActionContext context) {
        ProtocolPayload payload = context.payload("LINUX-CMD");
        if (payload == null) {
            // 兼容：LINUX 步骤可能携带 WINDOWS-CMD 载荷（host=local 时按本地命令执行）
            payload = context.payload("WINDOWS-CMD");
        }
        if (payload == null) {
            return ActionResult.fail("COMMON_LINUX_CMD 需要 LINUX-CMD 协议载荷: "
                    + "[{\"LINUX-CMD\":{\"host\":\"192.168.1.100\",\"user\":\"root\",\"password\":\"xxx\",\"cmd\":[\"ls\"]}}]");
        }
        JSONObject params = payload.paramsAsObject();
        String host = params.getString("host");

        // 路由：host=local/localhost/缺省 → 本地执行；否则 → 远程 SSH
        if (host == null || host.isBlank() || "local".equalsIgnoreCase(host) || "localhost".equalsIgnoreCase(host)) {
            return executeLocalCmd(context, params, false);
        }
        return executeRemoteCmd(context, params, host);
    }

    /**
     * 远程 SSH 执行：解析 host/port/user/password 认证参数，构建 SshSpec 并执行。
     */
    private ActionResult executeRemoteCmd(ActionContext context, JSONObject params, String host) {
        // ① 解析命令
        List<String> commands = parseCommands(params);
        if (commands.isEmpty()) {
            return ActionResult.fail("远程命令载荷缺少 cmd 字段");
        }

        // ② 解析 base_dir
        String baseDir = params.getString("base_dir");
        if (baseDir == null) baseDir = params.getString("baseDir");

        // ③ 构建 SSH 规格（认证参数）
        SshCommandClient.SshSpec spec = new SshCommandClient.SshSpec();
        spec.setHost(stripScheme(host));
        spec.setCommands(commands);
        spec.setBaseDir(baseDir);
        // 端口（默认 22）
        if (params.containsKey("port")) {
            try {
                spec.setPort(Integer.parseInt(String.valueOf(params.get("port")).trim()));
            } catch (NumberFormatException ignored) {
                // 保持默认 22
            }
        }
        // 用户名（支持 user/username 别名，缺省用全局配置）
        String user = params.getString("user");
        if (user == null || user.isBlank()) user = params.getString("username");
        if (user != null && !user.isBlank()) spec.setUser(user);
        // 密码（支持 password/pwd 别名，缺省用全局配置）
        String password = params.getString("password");
        if (password == null || password.isBlank()) password = params.getString("pwd");
        if (password != null && !password.isBlank()) spec.setPassword(password);

        // ④ 执行 SSH 命令
        log.info("  LINUX-CMD@ssh host={} port={} user={} base_dir={} commands={}",
                spec.getHost(), spec.getPort(), spec.getUser(), spec.getBaseDir(), commands);
        CommandResult result = context.clients().ssh().run(spec);

        // ⑤ 构建输出
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("CMD", result.getExitCode());
        outputs.put("STDOUT", result.getStdout());
        outputs.put("STDERR", result.getStderr());
        outputs.put("commandCount", commands.size());
        outputs.put("lastCommand", commands.get(commands.size() - 1));
        outputs.put("host", spec.getHost());
        outputs.put("port", spec.getPort());
        if (spec.getUser() != null) outputs.put("user", spec.getUser());
        if (baseDir != null) outputs.put("baseDir", baseDir);

        String stdoutStr = result.getStdout() == null ? "" : result.getStdout();
        List<String> lines = stdoutStr.isBlank() ? List.of() : stdoutStr.lines().toList();
        outputs.put("lines", lines);

        // ⑥ 判定
        if (result.getExitCode() == 0) {
            return ActionResult.ok("LINUX-CMD@ssh " + spec.getHost() + ":" + spec.getPort()
                    + " 执行 " + commands.size() + " 条命令成功", outputs);
        }
        return ActionResult.fail("LINUX-CMD@ssh " + spec.getHost() + " 命令执行失败 exit="
                + result.getExitCode() + " stderr=" + abbreviate(result.getStderr()), outputs);
    }

    private static String stripScheme(String url) {
        String s = url.replaceFirst("^https?://", "");
        int slash = s.indexOf('/');
        return slash > 0 ? s.substring(0, slash) : s;
    }
}
