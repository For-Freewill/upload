package com.e2e.test;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.e2e.framework.data.TestDataBootstrap;
import com.e2e.framework.data.TestDataLoader;
import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.TestDataBundle;
import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 独立全局场景 DAG 报告生成器。
 *
 * <p>从 Excel/YAML 数据源直接加载场景定义（不执行测试），为每个场景渲染拓扑 DAG 图。
 * 节点显示 {seq}-{APP}，边为纯依赖箭头（无通过/失败状态），因为生成时场景尚未执行。
 *
 * <p>运行方式：
 * <pre>
 * mvn test -Dsurefire.suiteXmlFiles=testng-global-dag.xml
 * # 或
 * mvn test -Dtest=GlobalDagReport
 * </pre>
 *
 * <p>输出：test-output/Global_Scenarios_Dag_Report.html
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class GlobalDagReport {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter TITLE_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Test
    public void generate() throws Exception {
        // 1. 加载数据（不启动 Spring，纯数据装载）
        TestDataLoader loader = TestDataBootstrap.createLoader();
        TestDataBundle bundle = loader.load();

        // 2. 按 Excel 定义顺序获取全部场景
        List<ScenarioDefinition> scenarios = new ArrayList<>(bundle.getScenarios().values());

        // 3. 生成 HTML
        String html = renderHtml(scenarios, loader.sourceName(), bundle.getIssues());

        // 4. 写入 test-output
        Path output = Paths.get("test-output", "Global_Scenarios_Dag_Report.html");
        Files.createDirectories(output.getParent());
        Files.writeString(output, html, StandardCharsets.UTF_8);

        System.out.println("[GlobalDagReport] 已生成: " + output.toAbsolutePath()
                + " (" + scenarios.size() + " scenarios)");
    }

    // ===================== HTML 渲染 =====================

    private String renderHtml(List<ScenarioDefinition> scenarios, String sourceName,
                              List<DataQualityIssue> issues) {
        String dateStr = LocalDateTime.now().format(TITLE_DATE);
        StringBuilder sb = new StringBuilder(32 * 1024);

        // ---- CSS ----
        sb.append("<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"UTF-8\">")
                .append("<title>Global Scenarios Dag Report-").append(dateStr).append("</title><style>")
                .append("*{box-sizing:border-box;margin:0;padding:0}")
                .append("body{font-family:'Segoe UI',system-ui,'Microsoft YaHei',sans-serif;background:#f1f5f9;color:#1e293b;line-height:1.5}")
                .append(".header{background:linear-gradient(135deg,#1e293b,#334155);color:#fff;padding:28px 36px;box-shadow:0 2px 8px rgba(0,0,0,0.15)}")
                .append(".header h1{font-size:24px;font-weight:700;margin-bottom:6px}")
                .append(".header .meta{font-size:13px;color:#94a3b8;display:flex;gap:20px;flex-wrap:wrap}")
                .append(".container{padding:24px 36px;max-width:1600px;margin:0 auto}")
                .append(".scenario-card{background:#fff;border-radius:10px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,0.06);overflow:hidden;border:1px solid #e2e8f0}")
                .append(".scenario-header{display:flex;align-items:center;gap:12px;padding:12px 20px;background:#f8fafc;border-bottom:1px solid #e2e8f0}")
                .append(".seq-badge{background:#3b82f6;color:#fff;font-size:13px;font-weight:700;width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}")
                .append(".scenario-title{font-size:15px;font-weight:600;color:#1e293b}")
                .append(".scenario-name{font-size:12px;color:#64748b;margin-top:2px}")
                .append(".scenario-tags{margin-left:auto;display:flex;gap:4px}")
                .append(".tag{background:#e2e8f0;color:#475569;font-size:10px;padding:2px 8px;border-radius:10px}")
                .append(".scenario-body{display:flex;gap:0;align-items:stretch}")
                .append(".steps-col{width:30%;flex-shrink:0;padding:14px 18px;border-right:1px solid #e2e8f0;background:#fafbfc;overflow-y:auto}")
                .append(".steps-title{font-size:10px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px}")
                .append(".step-item{display:flex;align-items:center;gap:8px;padding:4px 0;font-size:12px}")
                .append(".step-num{background:#e2e8f0;color:#475569;font-size:10px;font-weight:700;width:20px;height:20px;border-radius:4px;display:flex;align-items:center;justify-content:center;flex-shrink:0}")
                .append(".step-app{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}")
                .append(".app-TAP{background:#dbeafe;color:#1e40af}.app-SMARTS{background:#dcfce7;color:#15803d}")
                .append(".app-STP{background:#fef3c7;color:#d97706}.app-DATAHUB{background:#e0e7ff;color:#4338ca}")
                .append(".app-DRP{background:#fce7f3;color:#be185d}.app-DNS{background:#f1f5f9;color:#475569}")
                .append(".step-action{font-size:11px;color:#64748b;font-family:'Consolas',monospace}")
                .append(".dag-col{width:70%;flex-shrink:0;padding:14px 18px;overflow-x:auto}")
                .append(".dag-label{font-size:10px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px}")
                .append(".dag-container{background:#fff;border-radius:6px;padding:8px}")
                .append(".muted{color:#94a3b8}")
                .append("</style></head><body>");

        // ---- Header ----
        sb.append("<div class='header'>");
        sb.append("<h1>Global Scenarios Dag Report-").append(dateStr).append("</h1>");
        sb.append("<div class='meta'>")
                .append("<span>生成时间: ").append(LocalDateTime.now().format(TS)).append("</span>")
                .append("<span> | 数据源: ").append(esc(sourceName)).append("</span>")
                .append("<span> | 场景总数: ").append(scenarios.size()).append("</span>")
                .append("<span> | 步骤总数: ").append(scenarios.stream().mapToInt(s -> s.getSteps().size()).sum()).append("</span>")
                .append("</div></div>");

        sb.append("<div class='container'>");

        // ---- 每个场景一张卡片 ----
        for (ScenarioDefinition scenario : scenarios) {
            String sid = "S" + (scenario.getSeqNo() > 0 ? scenario.getSeqNo() : "");

            sb.append("<div class='scenario-card'>");
            // 卡片头
            sb.append("<div class='scenario-header'>");
            sb.append("<div class='seq-badge'>").append(scenario.getSeqNo() > 0 ? scenario.getSeqNo() : "").append("</div>");
            sb.append("<div><div class='scenario-title'>").append(esc(scenario.getScenarioId())).append("</div>");
            sb.append("<div class='scenario-name'>").append(esc(scenario.getName())).append("</div></div>");
            // Tags
            if (!scenario.getTags().isEmpty()) {
                sb.append("<div class='scenario-tags'>");
                for (String tag : scenario.getTags()) {
                    sb.append("<span class='tag'>").append(esc(tag)).append("</span>");
                }
                sb.append("</div>");
            }
            sb.append("</div>"); // scenario-header

            // 卡片主体
            sb.append("<div class='scenario-body'>");
            // 左列：Steps
            sb.append("<div class='steps-col'>");
            sb.append("<div class='steps-title'>Steps (").append(scenario.getSteps().size()).append(")</div>");
            for (StepDefinition step : scenario.getSteps()) {
                String app = step.getApp() == null ? "?" : step.getApp();
                sb.append("<div class='step-item'>");
                sb.append("<span class='step-num'>").append(step.getSeqNo()).append("</span>");
                sb.append("<span class='step-app app-").append(app).append("'>").append(app).append("</span>");
                sb.append("<span class='step-action'>").append(esc(step.getAction())).append("</span>");
                sb.append("</div>");
            }
            sb.append("</div>");
            // 右列：DAG
            sb.append("<div class='dag-col'>");
            sb.append("<div class='dag-label'>Scenario Flow DAG</div>");
            sb.append("<div class='dag-container'>");
            sb.append(renderDagFromDefinition(scenario));
            sb.append("</div></div>"); // dag-container + dag-col
            sb.append("</div>"); // scenario-body
            sb.append("</div>"); // scenario-card
        }

        sb.append("</div>"); // container

        // ---- 数据质量提示 ----
        if (issues != null && !issues.isEmpty()) {
            sb.append("<div class='container'><div class='scenario-card' style='padding:16px 20px'>");
            sb.append("<div class='steps-title' style='margin-bottom:8px'>Data Quality Issues (").append(issues.size()).append(")</div>");
            for (DataQualityIssue issue : issues) {
                sb.append("<div style='font-size:12px;color:#64748b;padding:2px 0'>")
                        .append(esc(issue.getScenarioId() == null ? "" : issue.getScenarioId()))
                        .append("/").append(esc(issue.getStepId() == null ? "" : issue.getStepId()))
                        .append(": ").append(esc(issue.getIssue()))
                        .append(" <span class='muted'>→ ").append(esc(issue.getHandling())).append("</span>")
                        .append("</div>");
            }
            sb.append("</div></div>");
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    // ===================== DAG 渲染（从定义，无状态色） =====================

    private String renderDagFromDefinition(ScenarioDefinition scenario) {
        List<StepDefinition> steps = scenario.getSteps();
        if (steps == null || steps.size() < 2) {
            return "";
        }

        // 1. 构建节点 + 依赖图（同时记录 APP 用于配色）
        Map<String, String> nodeLabels = new LinkedHashMap<>(); // stepId → "seq-APP"
        Map<String, String> nodeApps = new LinkedHashMap<>();   // stepId → APP 名
        Map<String, List<String>> edges = new LinkedHashMap<>(); // targetStepId → [sourceStepId...]
        for (StepDefinition step : steps) {
            String app = step.getApp() == null ? "?" : step.getApp();
            nodeLabels.put(step.getStepId(), step.getSeqNo() + "-" + app);
            nodeApps.put(step.getStepId(), app);
        }
        for (StepDefinition step : steps) {
            for (String dep : step.getDependsOn()) {
                if (nodeLabels.containsKey(dep)) {
                    edges.computeIfAbsent(step.getStepId(), k -> new ArrayList<>()).add(dep);
                }
            }
        }

        // 2. 拓扑分层（Kahn）
        Set<String> remaining = new LinkedHashSet<>(nodeLabels.keySet());
        Set<String> completed = new HashSet<>();
        List<List<String>> layers = new ArrayList<>();
        while (!remaining.isEmpty()) {
            List<String> layer = new ArrayList<>();
            for (String sid : remaining) {
                List<String> deps = edges.getOrDefault(sid, List.of());
                if (completed.containsAll(deps)) {
                    layer.add(sid);
                }
            }
            if (layer.isEmpty()) {
                layer.addAll(remaining);
            }
            for (String sid : layer) {
                remaining.remove(sid);
                completed.add(sid);
            }
            layers.add(layer);
        }

        // 3. SVG 布局（纯横向）
        int nodeW = 72, nodeH = 26;
        int baseLayerGap = 140;
        int maxNodesInLayer = 1;
        for (var layer : layers) {
            maxNodesInLayer = Math.max(maxNodesInLayer, layer.size());
        }
        int maxLayerWidth = nodeW;
        for (var layer : layers) {
            maxLayerWidth = Math.max(maxLayerWidth, layer.size() * (nodeW + 12) - 12);
        }
        int layerGap = Math.max(baseLayerGap, maxLayerWidth + 40);
        int nodeGap = 50;
        int svgW = 10 + layers.size() * layerGap + 10;
        int singleLayerH = nodeH + 10;
        int multiLayerH = maxNodesInLayer > 1 ? (maxNodesInLayer - 1) * nodeGap + nodeH + 10 : singleLayerH;
        int svgH = Math.max(singleLayerH, multiLayerH);

        Map<String, int[]> coords = new HashMap<>();
        for (int li = 0; li < layers.size(); li++) {
            var layer = layers.get(li);
            int layerContentH = layer.size() > 1 ? (layer.size() - 1) * nodeGap + nodeH : nodeH;
            int startY = (svgH - layerContentH) / 2;
            for (int ni = 0; ni < layer.size(); ni++) {
                String sid = layer.get(ni);
                int x = 10 + li * layerGap + (layer.size() > 1 ? ni * (nodeW + 12) : 0);
                int y = startY + (layer.size() > 1 ? ni * nodeGap : 0);
                coords.put(sid, new int[]{x, y});
            }
        }

        // 4. 绘制 SVG（全部节点统一蓝色，边无状态标记）
        StringBuilder svg = new StringBuilder();
        svg.append("<svg width='").append(svgW).append("' height='").append(svgH)
                .append("' style='display:block;overflow:visible'>");

        // 箭头定义（灰色，不与多色节点冲突）
        svg.append("<defs><marker id='dagarrow' markerWidth='8' markerHeight='8' refX='7' refY='4' orient='auto'>")
                .append("<path d='M0,0 L7,4 L0,8 Z' fill='#64748b'/></marker></defs>");

        // 画边（水平：源右侧 → 目标左侧，灰色箭头）
        for (var entry : edges.entrySet()) {
            String targetId = entry.getKey();
            int[] tc = coords.get(targetId);
            if (tc == null) continue;
            int tx = tc[0], ty = tc[1] + nodeH / 2;
            for (String sourceId : entry.getValue()) {
                int[] sc = coords.get(sourceId);
                if (sc == null) continue;
                int sx = sc[0] + nodeW, sy = sc[1] + nodeH / 2;
                int cpOffset = (tx - sx) / 3;
                svg.append("<path d='M").append(sx).append(",").append(sy)
                        .append(" C").append(sx + cpOffset).append(",").append(sy)
                        .append(" ").append(tx - cpOffset).append(",").append(ty)
                        .append(" ").append(tx).append(",").append(ty)
                        .append("' stroke='#64748b' stroke-width='1.5' fill='none' marker-end='url(#dagarrow)'/>");
            }
        }

        // 画节点（按 APP 域配色，与左侧 Steps 标签颜色一致）
        for (var layer : layers) {
            for (String sid : layer) {
                String label = nodeLabels.get(sid);
                String app = nodeApps.get(sid);
                int[] coord = coords.get(sid);
                String[] colors = appColors(app);
                svg.append("<rect x='").append(coord[0]).append("' y='").append(coord[1])
                        .append("' width='").append(nodeW).append("' height='").append(nodeH)
                        .append("' rx='5' fill='").append(colors[0])
                        .append("' stroke='").append(colors[2]).append("' stroke-width='1.5'/>");
                svg.append("<text x='").append(coord[0] + nodeW / 2).append("' y='")
                        .append(coord[1] + nodeH / 2 + 4)
                        .append("' text-anchor='middle' font-size='11' font-weight='600' fill='")
                        .append(colors[1]).append("'>").append(esc(label)).append("</text>");
            }
        }

        svg.append("</svg>");
        return svg.toString();
    }

    // ===================== 工具 =====================

    /**
     * APP 域配色（fill, text, border），与左侧 Steps 的 .app-XXX CSS 完全一致。
     * TAP=蓝, SMARTS=绿, STP=黄, DATAHUB=靛蓝, DRP=粉, DNS=灰, 其他=灰
     */
    private static String[] appColors(String app) {
        if (app == null) return new String[]{"#f1f5f9", "#475569", "#cbd5e1"};
        return switch (app.toUpperCase()) {
            case "TAP"      -> new String[]{"#dbeafe", "#1e40af", "#93c5fd"};
            case "SMARTS"   -> new String[]{"#dcfce7", "#15803d", "#86efac"};
            case "STP"      -> new String[]{"#fef3c7", "#d97706", "#fcd34d"};
            case "DATAHUB"  -> new String[]{"#e0e7ff", "#4338ca", "#a5b4fc"};
            case "DRP"      -> new String[]{"#fce7f3", "#be185d", "#f9a8d4"};
            case "DNS"      -> new String[]{"#f1f5f9", "#475569", "#cbd5e1"};
            default         -> new String[]{"#f1f5f9", "#475569", "#cbd5e1"};
        };
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
