package com.e2e.unittest;

import com.e2e.framework.engine.AssertionEngine;
import com.e2e.framework.engine.OperatorEvaluator;
import com.e2e.framework.model.AssertionRule;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertThrows;
import static org.testng.Assert.assertTrue;

/**
 * OperatorEvaluator 单元测试 —— 14 种字符串操作符 + Map 模式操作符全枚举验证。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class OperatorEvaluatorTest {

    private OperatorEvaluator evaluator;

    @BeforeMethod
    public void setUp() {
        evaluator = new OperatorEvaluator();
    }

    private AssertionRule rule(String op, List<String> expected) {
        return new AssertionRule("UT", "", op, expected, "{}");
    }

    /** 执行并捕获断言失败异常（TestNG assertThrows 返回 void，无法取异常对象） */
    private AssertionEngine.AssertionFailureException expectFail(Runnable r) {
        try {
            r.run();
            throw new AssertionError("应抛出 AssertionFailureException");
        } catch (AssertionEngine.AssertionFailureException e) {
            return e;
        }
    }

    // ===================== 字符串模式：正向 =====================

    @Test
    public void eqPass() {
        evaluator.evaluateRule(rule("EQ", List.of("200")), List.of("200"));
    }

    @Test
    public void eqIgnoresOrder() {
        evaluator.evaluateRule(rule("EQ", List.of("b", "a")), List.of("a", "b"));
    }

    @Test
    public void eqFailThrowsWithDetail() {
        AssertionEngine.AssertionFailureException e = expectFail(
                () -> evaluator.evaluateRule(rule("EQ", List.of("X")), List.of("Y")));
        assertTrue(e.getMessage().contains("实际值"));
    }

    @Test
    public void nePassWhenDifferent() {
        evaluator.evaluateRule(rule("NE", List.of("error")), List.of("ok"));
    }

    @Test
    public void neFailWhenEqual() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("NE", List.of("same")), List.of("same")));
    }

    @Test
    public void containsPass() {
        evaluator.evaluateRule(rule("CONTAINS", List.of("hello", "world")),
                List.of("say hello now", "the world is fine"));
    }

    @Test
    public void containsFailOnMissingKeyword() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("CONTAINS", List.of("missing")), List.of("nothing here")));
    }

    @Test
    public void notContainsPass() {
        evaluator.evaluateRule(rule("NOT_CONTAINS", List.of("ERROR")), List.of("all good"));
    }

    @Test
    public void notContainsFailWhenPresent() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("NOT_CONTAINS", List.of("ERROR")), List.of("has ERROR inside")));
    }

    @Test
    public void emptyPass() {
        evaluator.evaluateRule(rule("EMPTY", List.of()), List.of());
    }

    @Test
    public void notEmptyPass() {
        evaluator.evaluateRule(rule("NOT_EMPTY", List.of()), List.of("value"));
    }

    @Test
    public void notEmptyFailOnEmpty() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("NOT_EMPTY", List.of()), List.of()));
    }

    @Test
    public void sizeFamily() {
        evaluator.evaluateRule(rule("SIZE", List.of("2")), List.of("a", "b"));
        evaluator.evaluateRule(rule("GT", List.of("1")), List.of("a", "b"));
        evaluator.evaluateRule(rule("GTE", List.of("2")), List.of("a", "b"));
        evaluator.evaluateRule(rule("LT", List.of("3")), List.of("a", "b"));
        evaluator.evaluateRule(rule("LTE", List.of("2")), List.of("a", "b"));
    }

    @Test
    public void sizeFail() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("SIZE", List.of("5")), List.of("a")));
    }

    @Test
    public void sizeNonNumericExpectedFails() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("SIZE", List.of("abc")), List.of("a")));
    }

    @Test
    public void regexPass() {
        evaluator.evaluateRule(rule("REGEX", List.of("^GET$")), List.of("GET"));
    }

    @Test
    public void regexFail() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("REGEX", List.of("^\\d{4}$")), List.of("abc")));
    }

    @Test
    public void existsPass() {
        evaluator.evaluateRule(rule("EXISTS", List.of()), List.of("anything"));
    }

    @Test
    public void unsupportedOpFails() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateRule(rule("FLY", List.of()), List.of("x")));
    }

    // ===================== Map 模式 =====================

    private List<Map<String, Object>> actualRows() {
        return List.of(
                Map.of("id", 1, "name", "alice"),
                Map.of("id", 2, "name", "bob"));
    }

    private AssertionRule mapRule(String op, String... expectedJson) {
        return new AssertionRule("DB", "SELECT", op, List.of(expectedJson), "{}");
    }

    @Test
    public void mapEqPass() {
        evaluator.evaluateMapRule(mapRule("EQ",
                "{\"id\":\"1\",\"name\":\"alice\"}", "{\"id\":\"2\",\"name\":\"bob\"}"), actualRows());
    }

    @Test
    public void mapEqIgnoresRowOrder() {
        evaluator.evaluateMapRule(mapRule("EQ",
                "{\"id\":\"2\",\"name\":\"bob\"}", "{\"id\":\"1\",\"name\":\"alice\"}"), actualRows());
    }

    @Test
    public void mapEqFailOnMissingRow() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateMapRule(mapRule("EQ",
                        "{\"id\":\"999\",\"name\":\"ghost\"}"), actualRows()));
    }

    @Test
    public void mapContainsSubsetPass() {
        // 期望行是实际行的子集（只断言关心的字段）
        evaluator.evaluateMapRule(mapRule("CONTAINS", "{\"name\":\"alice\"}"), actualRows());
    }

    @Test
    public void mapContainsFailOnNoMatch() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateMapRule(mapRule("CONTAINS", "{\"name\":\"carol\"}"), actualRows()));
    }

    @Test
    public void mapNotContainsPass() {
        evaluator.evaluateMapRule(mapRule("NOT_CONTAINS", "{\"name\":\"carol\"}"), actualRows());
    }

    @Test
    public void mapNotContainsFailWhenExists() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateMapRule(mapRule("NOT_CONTAINS", "{\"name\":\"bob\"}"), actualRows()));
    }

    @Test
    public void mapExistsPass() {
        evaluator.evaluateMapRule(mapRule("EXISTS", "{\"id\":\"1\"}"), actualRows());
    }

    @Test
    public void mapSizeFamily() {
        evaluator.evaluateMapRule(mapRule("SIZE", "{\"x\":\"1\"}", "{\"x\":\"2\"}"), actualRows());
        evaluator.evaluateMapRule(mapRule("GTE", "{\"x\":\"1\"}"), actualRows());
    }

    @Test
    public void mapCaseInsensitiveColumn() {
        // 列名大小写不敏感：ID vs id
        evaluator.evaluateMapRule(mapRule("CONTAINS", "{\"ID\":\"1\"}"), actualRows());
    }

    @Test
    public void mapEmptyAndNotEmpty() {
        evaluator.evaluateMapRule(mapRule("EMPTY", "{}"), List.of());
        evaluator.evaluateMapRule(mapRule("NOT_EMPTY", "{}"), actualRows());
    }

    @Test
    public void mapUnsupportedOpFails() {
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> evaluator.evaluateMapRule(mapRule("REGEX", "{}"), actualRows()));
    }

    @Test
    public void failureMessageContainsRuleRaw() {
        AssertionEngine.AssertionFailureException e = expectFail(
                () -> evaluator.evaluateRule(rule("EQ", List.of("X")), List.of("Y")));
        assertTrue(e.getMessage().contains("规则原文"));
    }
}
