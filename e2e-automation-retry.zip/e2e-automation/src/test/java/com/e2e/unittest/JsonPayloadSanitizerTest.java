package com.e2e.unittest;

import com.e2e.framework.data.JsonPayloadSanitizer;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.model.ExtractRule;
import com.e2e.framework.model.ProtocolPayload;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

/**
 * JsonPayloadSanitizer 单元测试 —— ASSERT/EXTRACT/INPUT 三类解析规则的正确性。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class JsonPayloadSanitizerTest {

    private static final String SC = "UT-SC";
    private static final String STEP = "UT-STEP";

    // ===================== ASSERT 解析 =====================

    @Test
    public void assertStringMode() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"hello\"]}]", SC, STEP, List.of());
        assertEquals(rules.size(), 1);
        AssertionRule r = rules.get(0);
        assertEquals(r.getSource(), "STDOUT");
        assertEquals(r.getOp(), "CONTAINS");
        assertEquals(r.getExpected(), List.of("hello"));
    }

    @Test
    public void assertDbSourceWithSqlTarget() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"DB\":\"SELECT id FROM t\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getSource(), "DB");
        assertEquals(rules.get(0).getTarget(), "SELECT id FROM t");
    }

    @Test
    public void assertMapModeExpectedKeptAsJsonString() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"DB\":\"SELECT x\",\"OP\":\"EQ\",\"EXPECTED\":[{\"id\":\"1\"}]}]", SC, STEP, List.of());
        AssertionRule r = rules.get(0);
        assertEquals(r.getExpected().get(0), "{\"id\":\"1\"}");
    }

    @Test
    public void assertFieldParsed() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"DB\":\"SELECT a,b\",\"FIELD\":\"name\",\"OP\":\"EQ\",\"EXPECTED\":[\"x\"]}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getField(), "name");
    }

    @Test
    public void assertJsonpathFromFileCapturedIntoField() {
        // JSONPATH 显式模式：FROM/FILE 经 field 传递
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"JSONPATH\":\"$.user.name\",\"FILE\":\"data.json\",\"OP\":\"EQ\",\"EXPECTED\":[\"zhang\"]}]",
                SC, STEP, List.of());
        AssertionRule r = rules.get(0);
        assertEquals(r.getSource(), "JSONPATH");
        assertEquals(r.getTarget(), "$.user.name");
        assertEquals(r.getField(), "data.json");
    }

    @Test
    public void assertUnknownSourceFallsBackToFirstNonMetaKey() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"CUSTOM_KEY\":\"val\",\"OP\":\"EQ\",\"EXPECTED\":[\"x\"]}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getSource(), "CUSTOM_KEY");
    }

    @Test
    public void assertMissingNameSkippedWithIssue() {
        var issues = new java.util.ArrayList<com.e2e.framework.model.DataQualityIssue>();
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"OP\":\"EQ\",\"EXPECTED\":[\"x\"]}]", SC, STEP, issues);
        assertTrue(rules.isEmpty());
        assertFalse(issues.isEmpty());
    }

    @Test
    public void assertDefaultOpIsEq() {
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"STDOUT\":\"\",\"EXPECTED\":[\"x\"]}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getOp(), "EQ");
    }

    @Test
    public void assertNumericTimeoutAndPollIntervalParsed() {
        // JSON 数字值（非字符串）的 TIMEOUT/POLL_INTERVAL 必须被解析（修复：原先被忽略 → WAIT_UNTIL 走默认 30s）
        List<AssertionRule> rules = JsonPayloadSanitizer.parseAssertRules(
                "[{\"DB\":\"SELECT 1\",\"OP\":\"WAIT_UNTIL\",\"EXPECTED\":[\"OK\"],\"TIMEOUT\":2,\"POLL_INTERVAL\":500}]",
                SC, STEP, List.of());
        AssertionRule r = rules.get(0);
        assertEquals(r.getTimeoutSeconds(), 2, "数字 TIMEOUT 应被解析");
        assertEquals(r.getPollIntervalMs(), 500L, "数字 POLL_INTERVAL 应被解析");
        // 字符串形式保持兼容
        List<AssertionRule> rules2 = JsonPayloadSanitizer.parseAssertRules(
                "[{\"DB\":\"SELECT 1\",\"OP\":\"WAIT_UNTIL\",\"EXPECTED\":[\"OK\"],\"TIMEOUT\":\"3\"}]",
                SC, STEP, List.of());
        assertEquals(rules2.get(0).getTimeoutSeconds(), 3);
    }

    // ===================== EXTRACT 解析 =====================

    @Test
    public void extractStandardMode() {
        List<ExtractRule> rules = JsonPayloadSanitizer.parseExtractRules(
                "[{\"name\":\"orderId\",\"from\":\"body\",\"path\":\"$.data.id\"}]", SC, STEP, List.of());
        ExtractRule r = rules.get(0);
        assertEquals(r.getName(), "orderId");
        assertEquals(r.getFrom(), "body");
        assertEquals(r.getPath(), "$.data.id");
        assertFalse(r.isLiteral());
    }

    @Test
    public void extractLiteralMode() {
        List<ExtractRule> rules = JsonPayloadSanitizer.parseExtractRules(
                "[{\"name\":\"acct\",\"value\":\"999999\"}]", SC, STEP, List.of());
        ExtractRule r = rules.get(0);
        assertTrue(r.isLiteral());
        assertEquals(r.getValue(), "999999");
    }

    @Test
    public void extractLiteralSupportsCombinedVariables() {
        List<ExtractRule> rules = JsonPayloadSanitizer.parseExtractRules(
                "[{\"name\":\"ref\",\"value\":\"ACCT-${extract.acct}\"}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getValue(), "ACCT-${extract.acct}");
    }

    @Test
    public void extractNumericValueCoercedToString() {
        List<ExtractRule> rules = JsonPayloadSanitizer.parseExtractRules(
                "[{\"name\":\"n\",\"value\":42}]", SC, STEP, List.of());
        assertEquals(rules.get(0).getValue(), "42");
    }

    @Test
    public void extractMissingNameSkipped() {
        var issues = new java.util.ArrayList<com.e2e.framework.model.DataQualityIssue>();
        List<ExtractRule> rules = JsonPayloadSanitizer.parseExtractRules(
                "[{\"from\":\"body\"}]", SC, STEP, issues);
        assertTrue(rules.isEmpty());
    }

    // ===================== INPUT 解析 =====================

    @Test
    public void inputPayloadProtocolRecognized() {
        List<ProtocolPayload> payloads = JsonPayloadSanitizer.parseInputPayloads(
                "[{\"HTTP\":{\"url\":\"http://x\",\"method\":\"GET\"}}]", SC, STEP, List.of());
        assertEquals(payloads.size(), 1);
        assertEquals(payloads.get(0).getProtocol(), "HTTP");
        assertNotNull(payloads.get(0).getParams());
    }

    @Test
    public void inputMalformedJsonProducesIssueNotCrash() {
        var issues = new java.util.ArrayList<com.e2e.framework.model.DataQualityIssue>();
        List<ProtocolPayload> payloads = JsonPayloadSanitizer.parseInputPayloads(
                "not-a-json", SC, STEP, issues);
        // 非法 JSON 不抛异常（健壮性），产生数据质量问题
        assertTrue(payloads.isEmpty() || payloads.get(0) != null);
        assertFalse(issues.isEmpty());
    }

    @Test
    public void inputBlankReturnsEmpty() {
        List<ProtocolPayload> payloads = JsonPayloadSanitizer.parseInputPayloads(
                "", SC, STEP, List.of());
        assertTrue(payloads.isEmpty());
    }
}
