package com.e2e.unittest;

import com.e2e.framework.engine.DagResolver;
import com.e2e.framework.model.OnFailure;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.DataQualityIssue;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * DagResolver 单元测试 —— DAG 分层调度：线性链 / 并行扇出 / 依赖缺失降级。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class DagResolverTest {

    private DagResolver resolver;
    private List<DataQualityIssue> issues;

    @BeforeMethod
    public void setUp() {
        resolver = new DagResolver();
        issues = new ArrayList<>();
    }

    private StepDefinition step(String stepId, String... dependsOn) {
        return new StepDefinition("UT-SC", 1, stepId, "DATAHUB", "COMMON_HTTP_REQUEST",
                List.of(dependsOn), "[]", "[]", "[]", 30, 0, OnFailure.STOP, true);
    }

    private ScenarioDefinition scenario(StepDefinition... steps) {
        ScenarioDefinition sc = new ScenarioDefinition(1, "UT-SC", "单测场景", true, List.of("ut"), "demo", 60, "desc", "ut");
        for (StepDefinition s : steps) {
            sc.addStep(s);
        }
        return sc;
    }

    @Test
    public void linearChainThreeLayers() {
        ScenarioDefinition sc = scenario(step("A"), step("B", "A"), step("C", "B"));
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        assertEquals(layers.size(), 3, "A→B→C 应分 3 层");
        assertEquals(layers.get(0).get(0).getStepId(), "A");
        assertEquals(layers.get(1).get(0).getStepId(), "B");
        assertEquals(layers.get(2).get(0).getStepId(), "C");
    }

    @Test
    public void fanoutParallelInSameLayer() {
        // A → (B, C) → D：B/C 同层并行
        ScenarioDefinition sc = scenario(
                step("A"), step("B", "A"), step("C", "A"), step("D", "B", "C"));
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        assertEquals(layers.size(), 3);
        List<String> layer2 = layers.get(1).stream().map(StepDefinition::getStepId).toList();
        assertEquals(layer2.size(), 2);
        assertTrue(layer2.contains("B") && layer2.contains("C"), "B/C 应在同一并行层: " + layer2);
    }

    @Test
    public void independentStepsShareFirstLayer() {
        ScenarioDefinition sc = scenario(step("X"), step("Y"), step("Z"));
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        assertEquals(layers.size(), 1, "无依赖步骤应同层并行");
        assertEquals(layers.get(0).size(), 3);
    }

    @Test
    public void missingDependencyDegradesGracefully() {
        // B 依赖不存在的 "GHOST"：不崩溃，B 降级为根节点 + 数据质量告警
        ScenarioDefinition sc = scenario(step("A"), step("B", "GHOST"));
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        assertEquals(layers.size(), 1, "GHOST 缺失时 B 降级为根，与 A 同层");
        assertEquals(layers.get(0).size(), 2);
        assertTrue(issues.stream().anyMatch(i -> i.getIssue().contains("GHOST")
                        || String.valueOf(i).contains("GHOST")),
                "应产生依赖缺失的数据质量告警");
    }

    @Test
    public void disabledDependencyDegradesGracefully() {
        StepDefinition disabled = new StepDefinition("UT-SC", 1, "OFF", "DATAHUB",
                "COMMON_HTTP_REQUEST", List.of(), "[]", "[]", "[]", 30, 0, OnFailure.STOP, false);
        ScenarioDefinition sc = scenario(disabled, step("B", "OFF"));
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        // OFF 被过滤，B 的依赖缺失 → B 降级为根
        assertEquals(layers.size(), 1);
        assertEquals(layers.get(0).get(0).getStepId(), "B");
    }

    @Test
    public void emptyScenarioReturnsNoLayers() {
        ScenarioDefinition sc = scenario();
        List<List<StepDefinition>> layers = resolver.resolve(sc, issues);
        assertTrue(layers.isEmpty());
    }
}
