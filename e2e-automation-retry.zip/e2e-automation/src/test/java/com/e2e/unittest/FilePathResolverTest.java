package com.e2e.unittest;

import com.e2e.framework.core.FilePathResolver;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

/**
 * FilePathResolver 单元测试 —— 相对/绝对路径解析 + 正则文件匹配。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class FilePathResolverTest {

    @Test
    public void relativePathResolvedAgainstProjectRoot() {
        Path p = FilePathResolver.resolve("test-output/some-file.txt");
        assertTrue(p.isAbsolute(), "解析后应为绝对路径");
        assertTrue(p.toString().contains("test-output"), "应保留相对路径结构");
    }

    @Test
    public void absolutePathPreserved() {
        String abs = FilePathResolver.projectRoot() + "/test-output/x.txt";
        Path p = FilePathResolver.resolve(abs);
        assertEquals(p.toString().replace('\\', '/'), abs.replace('\\', '/'));
    }

    @Test
    public void windowsAbsolutePathPreserved() {
        Path p = FilePathResolver.resolve("C:/dev/report.pdf");
        assertEquals(p.toString().replace('\\', '/'), "C:/dev/report.pdf");
    }

    @Test
    public void isAbsoluteDetection() {
        assertTrue(FilePathResolver.isAbsolute("C:/dev/x"));
        // "/usr/local/x" 在 Windows 上非绝对路径（无盘符），平台相关故不断言
        assertFalse(FilePathResolver.isAbsolute("relative/x"));
        assertFalse(FilePathResolver.isAbsolute("test-output/x"));
    }

    @Test
    public void projectRootIsDirectory() {
        assertTrue(Files.isDirectory(Path.of(FilePathResolver.projectRoot())));
    }

    @Test
    public void matchFilesByRegex() throws Exception {
        Path dir = Path.of("test-output", "unit-tests", "matching");
        Files.createDirectories(dir);
        Path a = dir.resolve("e2e-alpha.txt");
        Path b = dir.resolve("e2e-beta.txt");
        Path c = dir.resolve("other.log");
        Files.writeString(a, "a");
        Files.writeString(b, "b");
        Files.writeString(c, "c");
        try {
            List<Path> matched = FilePathResolver.matchFiles(
                    dir.toString(), "e2e-.*\\.txt", false);
            assertEquals(matched.size(), 2, "应匹配 e2e-alpha/beta，不匹配 other.log");
        } finally {
            Files.deleteIfExists(a);
            Files.deleteIfExists(b);
            Files.deleteIfExists(c);
        }
    }

    @Test
    public void matchFilesOnNonExistDirReturnsEmpty() {
        List<Path> matched = FilePathResolver.matchFiles(
                "test-output/unit-tests/not-exist-dir", ".*", false);
        assertTrue(matched.isEmpty());
    }
}
