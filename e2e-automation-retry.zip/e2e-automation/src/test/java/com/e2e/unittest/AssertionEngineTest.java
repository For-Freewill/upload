package com.e2e.unittest;

import com.e2e.framework.engine.AssertionEngine;
import com.e2e.framework.engine.ContentResolver;
import com.e2e.framework.engine.OperatorEvaluator;
import com.e2e.framework.model.AssertionRule;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertThrows;
import static org.testng.Assert.assertTrue;

/**
 * AssertionEngine 单元测试 —— 编排层：模式检测分发 + 异步轮询 + 失败传播。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class AssertionEngineTest {

    private AssertionEngine engine;

    @BeforeMethod
    public void setUp() {
        engine = new AssertionEngine(new ContentResolver(), new OperatorEvaluator());
    }

    @Test
    public void stringModePass() {
        Map<String, Object> outputs = Map.of("status", 200);
        engine.evaluate(List.of(
                new AssertionRule("status", "", "EQ", List.of("200"), "{}")), outputs, null);
    }

    @Test
    public void mapModeDispatched() {
        Map<String, Object> outputs = Map.of("docs",
                List.of(Map.of("id", 1, "name", "alice")));
        engine.evaluate(List.of(
                new AssertionRule("docs", "", "EQ", List.of("{\"id\":\"1\",\"name\":\"alice\"}"), "{}")),
                outputs, null);
    }

    @Test
    public void mapModeFailurePropagates() {
        Map<String, Object> outputs = Map.of("docs", List.of(Map.of("id", 1)));
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> engine.evaluate(List.of(
                        new AssertionRule("docs", "", "EQ", List.of("{\"id\":\"999\"}"), "{}")),
                        outputs, null));
    }

    @Test
    public void failureStopsAtFirstRule() {
        Map<String, Object> outputs = Map.of("status", 200);
        // 第一条失败即抛出，第二条不执行
        assertThrows(AssertionEngine.AssertionFailureException.class,
                () -> engine.evaluate(List.of(
                        new AssertionRule("status", "", "EQ", List.of("500"), "{}"),
                        new AssertionRule("status", "", "EQ", List.of("should-not-run"), "{}")),
                        outputs, null));
    }

    @Test
    public void jsonPathAutoRoutingThroughEngine() {
        Map<String, Object> outputs = Map.of("body", "{\"data\":{\"ok\":true}}");
        engine.evaluate(List.of(
                new AssertionRule("body", "$.data.ok", "EQ", List.of("true"), "{}")), outputs, null);
    }

    @Test
    public void asyncWaitUntilImmediatePass() {
        // 条件立即满足：轮询首轮即通过（不超时）
        Map<String, Object> outputs = Map.of("status", 200);
        engine.evaluate(List.of(
                new AssertionRule("status", "", "WAIT_UNTIL", List.of("200"), "{}", 3, 200)),
                outputs, null);
    }

    @Test
    public void asyncWaitUntilActuallyRetriesBeforeTimeout() {
        // 轮询重试验证：首轮 actual 不满足 → 模拟数据就绪后通过
        // （验证 AssertionError 转译生效：不满足时重试而非立即失败）
        Map<String, Object> outputs = new HashMap<>();
        outputs.put("status", "pending");
        // 后台线程在 500ms 后把状态改为 ready，轮询(200ms 间隔)应在超时前捕捉到
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignored) { }
            outputs.put("status", "ready");
        }).start();
        engine.evaluate(List.of(
                new AssertionRule("status", "", "WAIT_UNTIL", List.of("ready"), "{}", 5, 200)),
                outputs, null);
        // 通过即证明：首轮失败后确实重试了（若无重试机制会立即失败）
    }

    @Test
    public void asyncWaitUntilTimeoutFails() {
        Map<String, Object> outputs = Map.of("status", "pending");
        long start = System.currentTimeMillis();
        try {
            engine.evaluate(List.of(
                    new AssertionRule("status", "", "WAIT_UNTIL", List.of("NEVER"), "{}", 1, 200)),
                    outputs, null);
            throw new AssertionError("应超时失败");
        } catch (AssertionEngine.AssertionFailureException e) {
            // 超时统一转译为断言失败异常（含超时上下文）
            long elapsed = System.currentTimeMillis() - start;
            assertTrue(elapsed >= 900, "应至少轮询等待 1 秒，实际 " + elapsed + "ms");
            assertTrue(e.getMessage().contains("超时"), "超时消息应包含超时上下文: " + e.getMessage());
        }
    }

    @Test
    public void multipleRulesAllPass() {
        Map<String, Object> outputs = new HashMap<>();
        outputs.put("status", 200);
        outputs.put("body", "{\"msg\":\"ok\"}");
        engine.evaluate(List.of(
                new AssertionRule("status", "", "EQ", List.of("200"), "{}"),
                new AssertionRule("body", "$.msg", "EQ", List.of("ok"), "{}"),
                new AssertionRule("body", "", "NOT_CONTAINS", List.of("ERROR"), "{}")),
                outputs, null);
    }
}
