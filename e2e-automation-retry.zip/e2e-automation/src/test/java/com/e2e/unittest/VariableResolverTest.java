package com.e2e.unittest;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.data.TestDataLoader;
import com.e2e.framework.data.VariableResolver;
import com.e2e.framework.model.TestDataBundle;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.assertEquals;

/**
 * VariableResolver 单元测试 —— ${global}/${extract}/${env} 占位符替换 + 未定义保留原文。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class VariableResolverTest {

    private static VariableResolver resolver;

    /** 内存 fake loader：仅提供全局变量，不读 Excel */
    private static TestDataLoader fakeLoader(Map<String, String> globals) {
        return new TestDataLoader() {
            @Override
            public String sourceName() { return "fake:unit-test"; }

            @Override
            public TestDataBundle load() {
                TestDataBundle bundle = new TestDataBundle();
                bundle.getGlobalConfig().putAll(globals);
                return bundle;
            }
        };
    }

    @BeforeClass
    public void setUp() {
        resolver = new VariableResolver(
                fakeLoader(Map.of(
                        "http_base_url", "http://www.baidu.com",
                        "ssh_host", "127.0.0.1")),
                new E2EProperties(),
                null);
    }

    @Test
    public void globalVariableResolved() {
        assertEquals(resolver.resolve("${global.http_base_url}/api", Map.of()),
                "http://www.baidu.com/api");
    }

    @Test
    public void extractVariableResolved() {
        assertEquals(resolver.resolve("ref-${extract.orderId}", Map.of("orderId", "ORD-9")),
                "ref-ORD-9");
    }

    @Test
    public void multipleVariablesInOneText() {
        assertEquals(resolver.resolve("${global.ssh_host} -> ${extract.port}",
                        Map.of("port", "22")),
                "127.0.0.1 -> 22");
    }

    @Test
    public void noPlaceholderReturnsAsIs() {
        assertEquals(resolver.resolve("plain-text", Map.of()), "plain-text");
    }

    @Test
    public void nullAndEmptySafe() {
        assertEquals(resolver.resolve(null, Map.of()), null);
        assertEquals(resolver.resolve("", Map.of()), "");
    }

    @Test
    public void undefinedVariableKeptAsLiteralNonStrict() {
        // 非 strict 模式：未定义变量保留原文（S22/R04 验证过的框架行为）
        assertEquals(resolver.resolve("${extract.ghost_var}", Map.of()),
                "${extract.ghost_var}");
    }

    @Test
    public void envVariableFromSystemProperty() {
        System.setProperty("ut.var.test", "ut-value");
        try {
            assertEquals(resolver.resolve("${env.ut.var.test}", Map.of()), "ut-value");
        } finally {
            System.clearProperty("ut.var.test");
        }
    }

    @Test
    public void resolveInJsonDeepReplacement() {
        JSONObject input = new JSONObject();
        input.put("url", "${global.http_base_url}/orders");
        input.put("ref", "${extract.orderId}");
        JSONArray arr = new JSONArray();
        arr.add("${extract.sku}");
        input.put("items", arr);

        JSONObject out = (JSONObject) resolver.resolveInJson(input,
                Map.of("orderId", "ORD-1", "sku", "A001"));

        assertEquals(out.getString("url"), "http://www.baidu.com/orders");
        assertEquals(out.getString("ref"), "ORD-1");
        assertEquals(out.getJSONArray("items").getString(0), "A001");
    }

    @Test
    public void resolveInJsonDoesNotMutateOriginal() {
        JSONObject input = new JSONObject();
        input.put("k", "${extract.v}");
        resolver.resolveInJson(input, Map.of("v", "resolved"));
        // 原树不被修改
        assertEquals(input.getString("k"), "${extract.v}");
    }
}
