package com.e2e.unittest;

import com.e2e.framework.ai.NoOpAiAssistant;
import com.e2e.framework.config.E2EProperties;
import com.e2e.framework.data.TestDataLoader;
import com.e2e.framework.data.VariableResolver;
import com.e2e.framework.engine.AssertionEngine;
import com.e2e.framework.engine.ContentResolver;
import com.e2e.framework.engine.OperatorEvaluator;
import com.e2e.framework.engine.ScenarioExecutionContext;
import com.e2e.framework.engine.ScreenshotService;
import com.e2e.framework.engine.StepExecutor;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.model.OnFailure;
import com.e2e.framework.model.ScenarioDefinition;
import com.e2e.framework.model.StepDefinition;
import com.e2e.framework.model.TestDataBundle;
import com.e2e.framework.model.results.StepResult;
import com.e2e.framework.model.results.StepStatus;
import com.e2e.framework.registry.ActionContext;
import com.e2e.framework.registry.ActionRegistry;
import com.e2e.framework.registry.ActionResult;
import com.e2e.framework.registry.AppAction;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.testng.Assert.assertEquals;

/**
 * StepExecutor 重试语义单元测试 —— 修复回归：ON_FAILURE=RETRY 时断言失败也必须触发重试。
 *
 * <p>修复前缺陷：断言评估位于重试循环之外 → Action 成功但断言失败时直接 FAILED，0 次重试。
 * 修复后语义：Action + 断言全链路参与重试（典型场景：异步数据未就绪 → 断言失败 → 重试后通过）。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class StepExecutorRetryTest {

    private ActionRegistry registry;
    private StepExecutor executor;
    private ExecutorService pool;
    private E2EProperties props;
    private ScenarioExecutionContext ctx;

    /** 有状态动作：每次调用输出 attempt=调用次数（模拟"数据延迟就绪"） */
    static class CountingAction implements AppAction {
        final AtomicInteger calls = new AtomicInteger();
        @Override
        public ActionResult execute(ActionContext context) {
            int n = calls.incrementAndGet();
            return ActionResult.ok("call#" + n, Map.of("attempt", n));
        }
    }

    /** 前置动作失败 N 次后成功（验证 Action 失败重试仍正常） */
    static class FailFirstAction implements AppAction {
        final AtomicInteger calls = new AtomicInteger();
        @Override
        public ActionResult execute(ActionContext context) {
            int n = calls.incrementAndGet();
            if (n == 1) {
                return ActionResult.fail("simulated transient failure");
            }
            return ActionResult.ok("call#" + n, Map.of("attempt", n));
        }
    }

    @BeforeMethod
    public void setUp() {
        registry = new ActionRegistry();
        props = new E2EProperties();
        props.getExecutor().setRetryDelayMs(0);
        props.getRetry().setStepRetryDelayMs(0);
        pool = Executors.newSingleThreadExecutor();
        executor = new StepExecutor(registry,
                new AssertionEngine(new ContentResolver(), new OperatorEvaluator()),
                (scenarioId, stepId) -> "",  // ScreenshotService 桩
                props, pool, new NoOpAiAssistant());
        ScenarioDefinition scenario = new ScenarioDefinition(1, "UT-RETRY-SC", "重试单测", true,
                List.of("ut"), "demo", 60, "desc", "ut");
        VariableResolver resolver = new VariableResolver(fakeLoader(), props, null);
        ctx = new ScenarioExecutionContext(scenario, resolver, null, props);
    }

    @AfterMethod
    public void tearDown() {
        pool.shutdownNow();
    }

    private TestDataLoader fakeLoader() {
        return new TestDataLoader() {
            @Override public String sourceName() { return "fake:unit"; }
            @Override public TestDataBundle load() { return new TestDataBundle(); }
        };
    }

    private StepDefinition step(String stepId, String app, String action, OnFailure onFailure,
                                int retry, List<AssertionRule> asserts) {
        StepDefinition step = new StepDefinition("UT-RETRY-SC", 1, stepId, app, action,
                List.of(), "[]", "[]", "[]", 10, retry, onFailure, true);
        step.setAssertRules(asserts);
        return step;
    }

    // ===================== 修复验证：断言失败触发重试 =====================

    @Test
    public void assertionFailureRetriesAndPasses() {
        // 动作第 1 次输出 attempt=1，第 2 次输出 attempt=2；断言 EQ "2"
        // 修复前：首轮断言失败 → 直接 FAILED（不重试）；修复后：重试第 2 轮通过
        CountingAction action = new CountingAction();
        registry.register("UT", "COUNT", action);
        StepDefinition step = step("S1", "UT", "COUNT", OnFailure.RETRY, 0,
                List.of(new AssertionRule("attempt", "", "EQ", List.of("2"), "{}")));

        StepResult result = executor.execute(step, ctx);

        assertEquals(result.getStatus(), StepStatus.PASSED, "断言失败后重试应最终通过: " + result.getMessage());
        assertEquals(result.getAttempts(), 2, "应执行 2 次尝试（首轮断言失败 + 重试通过）");
        assertEquals(action.calls.get(), 2, "Action 应被重新执行（重试包含完整 Action+断言链路）");
    }

    @Test
    public void assertionFailureRetriesThenExhausts() {
        // 断言永远不满足 → 重试耗尽后 FAILED，且尝试次数 = 重试次数+1
        CountingAction action = new CountingAction();
        registry.register("UT", "COUNT", action);
        StepDefinition step = step("S2", "UT", "COUNT", OnFailure.RETRY, 1,
                List.of(new AssertionRule("attempt", "", "EQ", List.of("999"), "{}")));

        StepResult result = executor.execute(step, ctx);

        assertEquals(result.getStatus(), StepStatus.FAILED, "重试耗尽应为 FAILED");
        assertEquals(result.getAttempts(), 2, "RETRY=1 → 共 2 次尝试");
        assertEquals(action.calls.get(), 2, "每次尝试都应重新执行 Action");
    }

    @Test
    public void stopStrategyDoesNotRetryAssertionFailure() {
        // ON_FAILURE=STOP 且 RETRY=0：断言失败不重试（保持原语义）
        CountingAction action = new CountingAction();
        registry.register("UT", "COUNT", action);
        StepDefinition step = step("S3", "UT", "COUNT", OnFailure.STOP, 0,
                List.of(new AssertionRule("attempt", "", "EQ", List.of("999"), "{}")));

        StepResult result = executor.execute(step, ctx);

        assertEquals(result.getStatus(), StepStatus.FAILED);
        assertEquals(result.getAttempts(), 1, "STOP 策略下断言失败不重试");
        assertEquals(action.calls.get(), 1);
    }

    // ===================== Action 失败重试（原有语义回归） =====================

    @Test
    public void actionFailureStillRetried() {
        FailFirstAction action = new FailFirstAction();
        registry.register("UT", "FLAKY", action);
        StepDefinition step = step("S4", "UT", "FLAKY", OnFailure.RETRY, 0,
                List.of(new AssertionRule("attempt", "", "EQ", List.of("2"), "{}")));

        StepResult result = executor.execute(step, ctx);

        assertEquals(result.getStatus(), StepStatus.PASSED, "Action 首次失败 + 断言要求第 2 次 → 第 2 轮全通过");
        assertEquals(result.getAttempts(), 2);
        assertEquals(action.calls.get(), 2);
    }

    @Test
    public void retryColumnDrivesAttempts() {
        // RETRY 列=2（非 ON_FAILURE 驱动）→ 最多 3 次尝试
        CountingAction action = new CountingAction();
        registry.register("UT", "COUNT", action);
        StepDefinition step = step("S5", "UT", "COUNT", OnFailure.STOP, 2,
                List.of(new AssertionRule("attempt", "", "EQ", List.of("3"), "{}")));

        StepResult result = executor.execute(step, ctx);

        assertEquals(result.getStatus(), StepStatus.PASSED);
        assertEquals(result.getAttempts(), 3, "RETRY=2 → 第 3 次尝试通过");
    }
}
