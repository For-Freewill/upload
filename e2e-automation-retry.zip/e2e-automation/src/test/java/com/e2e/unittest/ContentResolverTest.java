package com.e2e.unittest;

import com.e2e.framework.engine.ContentResolver;
import com.e2e.framework.model.AssertionRule;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * ContentResolver 单元测试 —— outputs 取值 / JSONPath/XPath 双路由 / FILE 断言 / 显式路径断言。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class ContentResolverTest {

    private ContentResolver resolver;
    private static Path tempFile;
    private static Path tempJson;
    private static Path tempXml;

    @BeforeClass
    public void setUp() throws Exception {
        resolver = new ContentResolver();
        Path dir = Path.of("test-output", "unit-tests");
        Files.createDirectories(dir);
        tempFile = dir.resolve("sample.txt");
        Files.writeString(tempFile, "line-one\nline-two\nline-three");
        tempJson = dir.resolve("sample.json");
        Files.writeString(tempJson, "{\"user\":{\"name\":\"zhangsan\",\"roles\":[\"admin\",\"tester\"]}}");
        tempXml = dir.resolve("sample.xml");
        Files.writeString(tempXml, "<?xml version=\"1.0\"?><order><status>CREATED</status><amount>99.5</amount></order>");
    }

    @AfterClass
    public void tearDown() throws Exception {
        Files.deleteIfExists(tempFile);
        Files.deleteIfExists(tempJson);
        Files.deleteIfExists(tempXml);
    }

    private Map<String, Object> httpOutputs() {
        Map<String, Object> outputs = new HashMap<>();
        outputs.put("status", 200);
        outputs.put("body", "{\"data\":{\"orderId\":\"ORD-001\",\"items\":[{\"sku\":\"A\"},{\"sku\":\"B\"}]}}");
        return outputs;
    }

    // ===================== outputs 取值 =====================

    @Test
    public void plainSourceFromOutputs() {
        Map<String, Object> outputs = Map.of("status", 200);
        List<String> actual = resolver.loadActual(
                new AssertionRule("status", "", "EQ", List.of("200"), "{}"), outputs, null);
        assertEquals(actual, List.of("200"));
    }

    @Test
    public void sourceCaseInsensitive() {
        Map<String, Object> outputs = Map.of("STATUS", 200);
        List<String> actual = resolver.loadActual(
                new AssertionRule("status", "", "EQ", List.of("200"), "{}"), outputs, null);
        assertEquals(actual, List.of("200"));
    }

    @Test
    public void listOutputFlattened() {
        Map<String, Object> outputs = Map.of("lines", List.of("a", "b"));
        List<String> actual = resolver.loadActual(
                new AssertionRule("lines", "", "EQ", List.of("a"), "{}"), outputs, null);
        assertEquals(actual, List.of("a", "b"));
    }

    @Test
    public void missingSourceReturnsEmptyNotCrash() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("NOT_EXIST", "", "EQ", List.of(), "{}"), Map.of(), null);
        assertTrue(actual.isEmpty());
    }

    // ===================== JSONPath / XPath 自动路由 =====================

    @Test
    public void jsonPathAutoRouting() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("body", "$.data.orderId", "EQ", List.of("ORD-001"), "{}"),
                httpOutputs(), null);
        assertEquals(actual, List.of("ORD-001"));
    }

    @Test
    public void jsonPathArrayIndex() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("body", "$.data.items[1].sku", "EQ", List.of("B"), "{}"),
                httpOutputs(), null);
        assertEquals(actual, List.of("B"));
    }

    @Test
    public void jsonPathNoMatchReturnsEmpty() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("body", "$.not.exist.field", "EQ", List.of(), "{}"),
                httpOutputs(), null);
        assertTrue(actual.isEmpty());
    }

    @Test
    public void xpathAutoRouting() {
        Map<String, Object> outputs = Map.of("firstMessage",
                "<trade><side>BUY</side><price>10.50</price></trade>");
        List<String> actual = resolver.loadActual(
                new AssertionRule("firstMessage", "//trade/side", "EQ", List.of("BUY"), "{}"),
                outputs, null);
        assertEquals(actual, List.of("BUY"));
    }

    // ===================== 显式 JSONPATH / XPATH source =====================

    @Test
    public void explicitJsonpathFromFile() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("JSONPATH", "$.user.name", "EQ", List.of("zhangsan"), 
                        tempJson.toString(), "{}", 0, 0),
                Map.of(), null);
        assertEquals(actual, List.of("zhangsan"));
    }

    @Test
    public void explicitJsonpathFromArray() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("JSONPATH", "$.user.roles[1]", "EQ", List.of("tester"), 
                        tempJson.toString(), "{}", 0, 0),
                Map.of(), null);
        assertEquals(actual, List.of("tester"));
    }

    @Test
    public void explicitXpathFromFile() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("XML", "//order/status", "EQ", List.of("CREATED"), 
                        tempXml.toString(), "{}", 0, 0),
                Map.of(), null);
        assertEquals(actual, List.of("CREATED"));
    }

    @Test
    public void explicitJsonpathFromOutputVariable() {
        Map<String, Object> outputs = Map.of("payload", "{\"k\":\"v1\"}");
        List<String> actual = resolver.loadActual(
                new AssertionRule("JSONPATH", "$.k", "EQ", List.of("v1"), "payload", "{}", 0, 0),
                outputs, null);
        assertEquals(actual, List.of("v1"));
    }

    // ===================== FILE 断言字段 =====================

    @Test
    public void fileLineCount() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", tempFile.toString(), "EQ", List.of("3"), "lineCount", "{}", 0, 0),
                new HashMap<>(), null);
        assertEquals(actual, List.of("3"));
    }

    @Test
    public void fileExists() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", tempFile.toString(), "EQ", List.of("true"), "exists", "{}", 0, 0),
                new HashMap<>(), null);
        assertEquals(actual, List.of("true"));
    }

    @Test
    public void fileNotExists() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", "test-output/unit-tests/no-such.txt", "EQ", List.of("false"), "exists", "{}", 0, 0),
                new HashMap<>(), null);
        assertEquals(actual, List.of("false"));
    }

    @Test
    public void fileSizePositive() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", tempFile.toString(), "GT", List.of("10"), "size", "{}", 0, 0),
                new HashMap<>(), null);
        int size = Integer.parseInt(actual.get(0));
        assertTrue(size > 10, "文件应大于 10 字节，实际 " + size);
    }

    @Test
    public void fileContentLinesAsActual() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", tempFile.toString(), "CONTAINS", List.of("line-two"), "content", "{}", 0, 0),
                new HashMap<>(), null);
        assertEquals(actual.size(), 3, "3 行文件应产出 3 个实际值");
        assertTrue(actual.contains("line-two"));
    }

    @Test
    public void fileMissingPathReturnsEmpty() {
        List<String> actual = resolver.loadActual(
                new AssertionRule("FILE", "", "EQ", List.of(), "content", "{}", 0, 0),
                new HashMap<>(), null);
        assertTrue(actual.isEmpty());
    }

    // ===================== Map 模式行加载 =====================

    @Test
    public void mapRowsFromOutputsList() {
        Map<String, Object> outputs = Map.of("docs",
                List.of(Map.of("id", 1, "status", "NEW"), Map.of("id", 2, "status", "DONE")));
        List<Map<String, Object>> rows = resolver.loadActualRows(
                new AssertionRule("docs", "", "EQ", List.of(), "{}"), outputs, null);
        assertEquals(rows.size(), 2);
        assertEquals(String.valueOf(rows.get(0).get("id")), "1");
    }

    @Test
    public void mapRowsFromNonListOutputReturnsEmpty() {
        Map<String, Object> outputs = Map.of("docs", "not-a-list");
        List<Map<String, Object>> rows = resolver.loadActualRows(
                new AssertionRule("docs", "", "EQ", List.of(), "{}"), outputs, null);
        assertTrue(rows.isEmpty());
    }
}
