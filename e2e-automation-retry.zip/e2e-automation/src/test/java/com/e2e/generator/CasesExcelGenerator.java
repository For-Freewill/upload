package com.e2e.generator;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Excel 真实用例生成器 —— 将 12 个 E2E 测试场景写入 cases/E2E-Test-Scenarios.xlsx。
 *
 * <p>Sheet 结构与模版完全一致：Scenarios / Steps / _GlobalConfig。
 * 生成的 xlsx 放入 src/test/resources/cases/，可通过
 * {@code -De2e.data.excel.path=classpath:cases/E2E-Test-Scenarios.xlsx} 加载运行。
 *
 * <p>本类为一次性生成工具（@Test 标注以便 mvn test 执行），生成后 xlsx 作为静态资源使用。
 * 重新运行会覆盖已有文件（按需更新用例集时使用）。
 *
 * <p>覆盖的 Action 类型：COMMON_HTTP_REQUEST / COMMON_DB_EXECUTE / COMMON_DB_ASSERTIONS /
 * COMMON_WINDOWS_CMD / COMMON_LINUX_CMD / COMMON_MQ_SEND / COMMON_SSH / DRP_UI_REPORTS / 104_UI_BOOK。
 * 覆盖的框架特性：DEPENDS_ON 依赖链 / ${extract.*} 变量传递 / WAIT_UNTIL 异步断言 /
 * ON_FAILURE=RETRY 重试 / Enabled=N 禁用过滤 / 多协议组合编排。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class CasesExcelGenerator {

    @Test
    public void generateCases() throws Exception {
        Path output = Paths.get("src/test/resources/cases/E2E-Test-Scenarios.xlsx");
        Files.createDirectories(output.getParent());

        ExcelWriter writer = com.alibaba.excel.EasyExcel.write(output.toFile()).build();

        // ===== Sheet 1: Scenarios =====
        List<String> scenarioHeader = List.of(
                "Seq", "Scenario_ID", "Scenario_Name", "Enabled", "Tags", "Env", "Timeout", "Description", "Owner");
        List<List<Object>> scenarioRows = new ArrayList<>();
        scenarioRows.add(row(1, "E2E-CASE-HTTP-GET-CHAIN", "HTTP GET 链式请求验证", "Y", "http;smoke", "demo", "120", "验证 HTTP GET 基础请求与带参查询的链式执行", "e2e-team"));
        scenarioRows.add(row(2, "E2E-CASE-MULTI-APP-FAIL", "多APP流程含失败（STOP 级联跳过）", "Y", "flow;multiapp;fail", "demo", "180", "5种APP编排，步骤4失败+ON_FAILURE=STOP导致后续级联SKIPPED", "e2e-team"));
        scenarioRows.add(row(3, "E2E-CASE-MULTI-APP-PARTIAL", "多APP流程含部分失败（CONTINUE 继续）", "Y", "flow;multiapp;partial", "demo", "180", "5种APP编排，步骤4失败+ON_FAILURE=CONTINUE后续继续执行", "e2e-team"));
        scenarioRows.add(row(4, "E2E-CASE-DNS-PARALLEL-FANOUT", "SMARTS→DNS 并行扇出", "Y", "fanout;dns;parallel", "demo", "120", "1个SMARTS下游并行3个DNS，验证 DAG 扇出拓扑", "e2e-team"));
        scenarioRows.add(row(5, "E2E-CASE-DB-CRUD-LIFECYCLE", "DB CRUD 全生命周期", "Y", "db;crud", "demo", "180", "建表→插入→更新→删除全链路 DB 操作验证", "e2e-team"));
        scenarioRows.add(row(6, "E2E-CASE-DB-POLL-CONSISTENCY", "DB 异步轮询一致性", "Y", "db;async;awaitility", "demo", "120", "使用 WAIT_UNTIL 异步断言验证 DB 最终一致性", "e2e-team"));
        scenarioRows.add(row(7, "E2E-CASE-CMD-WINDOWS-MULTI", "Windows 多命令链执行", "Y", "cmd;windows", "demo", "60", "Windows 本地多命令链式执行与输出断言", "e2e-team"));
        scenarioRows.add(row(8, "E2E-CASE-CMD-LINUX-EMULATE", "Linux 命令模拟执行", "Y", "cmd;linux", "demo", "60", "Linux CMD 命令模拟执行与退出码验证", "e2e-team"));
        scenarioRows.add(row(9, "E2E-CASE-MQ-SEND-VERIFY", "MQ 报文发送验证", "Y", "mq;send", "demo", "60", "MQ 报文发送与 stub 回显验证", "e2e-team"));
        scenarioRows.add(row(10, "E2E-CASE-SSH-REMOTE-EXEC", "SSH 远程命令执行", "Y", "ssh;remote", "demo", "90", "SSH 远程命令执行与本地日志记录", "e2e-team"));
        scenarioRows.add(row(11, "E2E-CASE-UI-REPORT-VIEW", "UI 报表浏览交互", "Y", "ui;report", "demo", "120", "UI 报表浏览与交互操作验证（Playwright 桩模式）", "e2e-team"));
        scenarioRows.add(row(12, "E2E-CASE-FLOW-ORDER-LIFECYCLE", "订单全流程端到端", "Y", "flow;e2e;smoke", "demo", "300", "HTTP创建→DB验证→MQ通知→CMD日志→DB清理 端到端流程", "e2e-team"));
        scenarioRows.add(row(13, "E2E-CASE-RETRY-FLAKY-STEP", "失败重试策略验证", "Y", "retry;flaky", "demo", "120", "ON_FAILURE=RETRY 步骤级重试策略验证", "e2e-team"));
        scenarioRows.add(row(14, "E2E-CASE-DISABLED-DEMO", "禁用场景演示", "N", "disabled;demo", "demo", "60", "Enabled=N 的场景应被跳过（验证 enable 过滤）", "e2e-team"));
        scenarioRows.add(row(15, "E2E-CASE-ASSERT-MAP-MODE", "断言 Map 模式测试", "Y", "assert;map", "demo", "120", "多列多行 Map EQ/CONTAINS/EXISTS + FIELD 字符串模式断言", "e2e-team"));
        scenarioRows.add(row(16, "E2E-CASE-UI-PLAYWRIGHT-DEMO", "UI 自动化 Playwright 示例", "Y", "ui;playwright;demo", "demo", "120", "Playwright 反射调用：navigate/fill/click/textContent/title，demo 模式部分跳过", "e2e-team"));
        scenarioRows.add(row(17, "E2E-CASE-JAVA-INVOKE-DEMO", "JAVA 反射调用示例", "Y", "java;invoke;demo", "demo", "60", "Java 反射静态方法调用：System.getProperty/String.valueOf/Math.max + 结果断言", "e2e-team"));
        scenarioRows.add(row(18, "E2E-CASE-UI-AUTOMATION-SERVICE", "UI 自动化服务调用示例", "Y", "ui;java;bean", "demo", "180", "通过 COMMON_JAVA_INVOKE bean 模式反射调用 UiAutomationService：navigate/input/click/text/title/screenshot", "e2e-team"));
        scenarioRows.add(row(19, "E2E-CASE-FILE-OPERATIONS", "文件操作与断言测试", "Y", "file;assert", "demo", "60", "文件 create/write/append/read/delete + FILE 断言（CONTAINS/NOT_CONTAINS/lineCount/exists）", "e2e-team"));
        scenarioRows.add(row(20, "E2E-CASE-FTP-MAIL-DEMO", "FTP/MAIL 协议测试", "Y", "ftp;mail;demo", "demo", "60", "FTP upload/list/exists/delete + MAIL 纯文本/HTML 发送（demo 模式走桩）", "e2e-team"));
        scenarioRows.add(row(21, "E2E-CASE-PROTOCOL-EXTENSIONS", "协议扩展综合测试", "Y", "ext;jwt;redis;mq;mongo;webhook;ws;compare", "demo", "120", "JWT/Redis/MQ收发/Mongo/Webhook/JSONPath/XPath/DataCompare 全链路（demo 内存模拟）", "e2e-team"));
        scenarioRows.add(row(22, "E2E-CASE-EXTRACT-PARAMS", "跨步骤传参验证", "Y", "extract;params;cross-step", "demo", "120", "EXTRACT 增强：JSONPath/XPath/Regex/文件行提取 → 变量跨步骤引用闭环", "e2e-team"));

        WriteSheet sheet1 = com.alibaba.excel.EasyExcel.writerSheet(0, "Scenarios")
                .head(toHead(scenarioHeader)).build();
        writer.write(scenarioRows, sheet1);

        // ===== Sheet 2: Steps =====
        List<String> stepHeader = List.of(
                "Scenario_ID", "SEQ_NO", "STEP_ID", "APP", "ACTION", "DEPENDS_ON",
                "INPUT", "ASSERT", "EXTRACT", "TIMEOUT", "RETRY", "ON_FAILURE", "ENABLED");
        List<List<Object>> stepRows = new ArrayList<>();

        // --- 1. HTTP GET chain (3 steps) ---
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 1, "HTTP-GET-BASIC", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 2, "HTTP-GET-QUERY", "STP", "COMMON_HTTP_REQUEST", "HTTP-GET-BASIC",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}/s?wd=${global.http_search_word}\",\"method\":\"GET\",\"headers\":{\"User-Agent\":\"e2e-test\"}}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"queryStatus\",\"from\":\"HTTP\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-HTTP-GET-CHAIN", 3, "HTTP-VERIFY-OUTPUT", "SMARTS", "COMMON_DB_ASSERTIONS", "HTTP-GET-QUERY",
                "[]",
                "[{\"DB\":\"SELECT '200' WHERE val='200'\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S2. Multi-APP flow with failure (6 steps, 5 APPs, STOP cascade) ---
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 1, "MAF-HTTP-CALL", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 2, "MAF-DB-PREP", "SMARTS", "COMMON_DB_EXECUTE", "MAF-HTTP-CALL",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_maf (id INT, app VARCHAR(20))\",\"INSERT INTO e2e_maf VALUES (1,'TAP')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 3, "MAF-MQ-NOTIFY", "STP", "COMMON_MQ_SEND", "MAF-DB-PREP",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 4, "MAF-CMD-VERIFY", "DATAHUB", "COMMON_LINUX_CMD", "MAF-MQ-NOTIFY",
                "[{\"LINUX-CMD\":{\"cmd\":[\"echo payment-processed\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"INTENTIONAL-FAIL\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 5, "MAF-UI-CHECK", "DRP", "DRP_UI_REPORTS", "MAF-CMD-VERIFY",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"verify\"}}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-FAIL", 6, "MAF-DB-ASSERT", "SMARTS", "COMMON_DB_ASSERTIONS", "MAF-UI-CHECK",
                "[]",
                "[{\"DB\":\"SELECT 'ok' WHERE status='ok'\",\"OP\":\"EQ\",\"EXPECTED\":[\"ok\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S3. Multi-APP flow with partial failure (6 steps, 5 APPs, CONTINUE) ---
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 1, "MAP-MQ-START", "STP", "COMMON_MQ_SEND", "[]",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 2, "MAP-CMD-LOG", "DATAHUB", "COMMON_WINDOWS_CMD", "MAP-MQ-START",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo flow-started\"]}}]",
                "[{\"STDOUT\":\"flow-started\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"flow-started\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 3, "MAP-HTTP-CALL", "TAP", "COMMON_HTTP_REQUEST", "MAP-CMD-LOG",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 4, "MAP-UI-VERIFY", "DRP", "DRP_UI_REPORTS", "MAP-HTTP-CALL",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"verify\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"FAIL\"]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 5, "MAP-DB-EXECUTE", "SMARTS", "COMMON_DB_EXECUTE", "MAP-HTTP-CALL",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_map (id INT, result VARCHAR(20))\",\"INSERT INTO e2e_map VALUES (1,'partial-fail')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MULTI-APP-PARTIAL", 6, "MAP-DB-ASSERT", "SMARTS", "COMMON_DB_ASSERTIONS", "MAP-DB-EXECUTE",
                "[]",
                "[{\"DB\":\"SELECT 'actual' WHERE status='ok'\",\"OP\":\"EQ\",\"EXPECTED\":[\"wrong\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S4. SMARTS→DNS parallel fanout (4 steps: 1 SMARTS → 3 parallel DNS) ---
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 1, "FAN-SMARTS-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_fan (id INT, val VARCHAR(50))\",\"INSERT INTO e2e_fan VALUES (1,'alpha')\",\"INSERT INTO e2e_fan VALUES (2,'beta')\",\"INSERT INTO e2e_fan VALUES (3,'gamma')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 2, "FAN-DNS-CHECK-A", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=1\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"1\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 3, "FAN-DNS-CHECK-B", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=2\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"2\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DNS-PARALLEL-FANOUT", 4, "FAN-DNS-CHECK-C", "DNS", "COMMON_DB_ASSERTIONS", "FAN-SMARTS-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_fan WHERE id=3\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"3\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 3. DB CRUD lifecycle (4 steps) ---
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 1, "DB-CREATE-TABLE", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":\"CREATE TABLE IF NOT EXISTS e2e_crud (id INT PRIMARY KEY, name VARCHAR(100), status VARCHAR(20))\"}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 2, "DB-INSERT-BATCH", "SMARTS", "COMMON_DB_EXECUTE", "DB-CREATE-TABLE",
                "[{\"DB\":[\"INSERT INTO e2e_crud VALUES (1,'order-001','CREATED')\",\"INSERT INTO e2e_crud VALUES (2,'order-002','CREATED')\",\"INSERT INTO e2e_crud VALUES (3,'order-003','SHIPPED')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 3, "DB-ASSERT-COUNT", "SMARTS", "COMMON_DB_ASSERTIONS", "DB-INSERT-BATCH",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_crud WHERE id=1\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"1\"]},{\"DB\":\"SELECT * FROM e2e_crud WHERE status='SHIPPED'\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"SHIPPED\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-CRUD-LIFECYCLE", 4, "DB-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "DB-ASSERT-COUNT",
                "[{\"DB\":\"DROP TABLE e2e_crud\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 4. DB poll consistency with WAIT_UNTIL (3 steps) ---
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 1, "DB-PREP-DATA", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_poll (id INT, val VARCHAR(50))\",\"INSERT INTO e2e_poll VALUES (1,'pending')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 2, "DB-WAIT-UNTIL", "SMARTS", "COMMON_DB_ASSERTIONS", "DB-PREP-DATA",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_poll WHERE id=1\",\"OP\":\"WAIT_UNTIL\",\"EXPECTED\":[\"1\"],\"TIMEOUT\":10,\"POLL_INTERVAL\":1000}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DB-POLL-CONSISTENCY", 3, "DB-POLL-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "DB-WAIT-UNTIL",
                "[{\"DB\":\"DROP TABLE e2e_poll\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- S7. Windows CMD: 本地执行（base_dir + 批量命令 + 断言）(3 steps) ---
        // Step 1: 基础命令 + STDOUT 断言（纯本地，无需 host 字段）
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 1, "WIN-CMD-ECHO", "DATAHUB", "COMMON_WINDOWS_CMD", "[]",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo E2E-WIN-START\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"E2E-WIN-START\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 2: base_dir + 批量命令（设置工作目录后执行多条命令）
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 2, "WIN-CMD-BASEDIR", "DATAHUB", "COMMON_WINDOWS_CMD", "WIN-CMD-ECHO",
                "[{\"WINDOWS-CMD\":{\"base_dir\":\"test-output\",\"cmd\":[\"echo base-dir-works\",\"echo chain-step-2\",\"echo done\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"base-dir-works\",\"chain-step-2\",\"done\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 3: 退出码断言 + 命令数量断言
        addStep(stepRows, "E2E-CASE-CMD-WINDOWS-MULTI", 3, "WIN-CMD-EXIT", "DATAHUB", "COMMON_WINDOWS_CMD", "WIN-CMD-BASEDIR",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo exit-check\"]}}]",
                "[{\"CMD\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]},{\"commandCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S8. Linux CMD: SSH 认证 + 远程文件校验 (4 steps) ---
        // Step 1: 本地基础命令 + STDOUT 断言
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 1, "LINUX-CMD-ECHO", "DATAHUB", "COMMON_LINUX_CMD", "[]",
                "[{\"LINUX-CMD\":{\"host\":\"local\",\"cmd\":[\"echo linux-start\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"linux-start\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 2: base_dir + 批量命令 + EXTRACT
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 2, "LINUX-CMD-BASEDIR", "DATAHUB", "COMMON_LINUX_CMD", "LINUX-CMD-ECHO",
                "[{\"LINUX-CMD\":{\"host\":\"local\",\"base_dir\":\"test-output\",\"cmd\":[\"echo base-dir-works\",\"echo step-2\",\"echo chain-done\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"base-dir-works\",\"chain-done\"]},{\"commandCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"3\"]}]",
                "[{\"name\":\"linuxOutput\",\"from\":\"STDOUT\",\"path\":\"\"}]", 15, 0, "STOP", "Y");
        // Step 3: SSH 远程执行示例（host 指向远程服务器，支持 user/password/port 认证）
        // demo 模式下走桩；live 模式下真实 SSH 连接执行命令
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 3, "LINUX-CMD-SSH-DEMO", "DATAHUB", "COMMON_LINUX_CMD", "LINUX-CMD-BASEDIR",
                "[{\"LINUX-CMD\":{\"host\":\"${global.ssh_host}\",\"port\":22,\"user\":\"${global.ssh_user}\",\"password\":\"${global.ssh_password}\",\"base_dir\":\"/tmp\",\"cmd\":[\"echo remote-exec-ok\",\"ls -la /tmp\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 4: SSH 远程文件内容校验（cat 命令 + STDOUT 断言）
        addStep(stepRows, "E2E-CASE-CMD-LINUX-EMULATE", 4, "LINUX-CMD-FILE-CHECK", "DATAHUB", "COMMON_LINUX_CMD", "LINUX-CMD-SSH-DEMO",
                "[{\"LINUX-CMD\":{\"host\":\"${global.ssh_host}\",\"port\":22,\"user\":\"${global.ssh_user}\",\"password\":\"${global.ssh_password}\",\"cmd\":[\"cat /etc/hostname\",\"df -h /tmp | tail -1\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]},{\"CMD\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]}]",
                "[]", 30, 0, "CONTINUE", "Y");

        // --- 7. MQ send + verify (3 steps) ---
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 1, "MQ-SEND-MSG", "STP", "COMMON_MQ_SEND", "[]",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 2, "MQ-VERIFY-STUB", "SMARTS", "COMMON_DB_ASSERTIONS", "MQ-SEND-MSG",
                "[]",
                "[{\"DB\":\"SELECT * FROM dummy WHERE id=1\",\"OP\":\"EXISTS\",\"EXPECTED\":[]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-MQ-SEND-VERIFY", 3, "MQ-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "MQ-VERIFY-STUB",
                "[{\"DB\":\"SELECT 'mq-cleanup-ok'\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 8. SSH remote exec (3 steps) ---
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 1, "SSH-CONNECT-EXEC", "TAP", "COMMON_SSH", "[]",
                "[{\"SSH\":{\"host\":\"${global.ssh_host}\",\"cmd\":[\"echo ssh-ok\"],\"user\":\"${global.ssh_user}\"}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-ok\"]}]",
                "[{\"name\":\"sshResult\",\"from\":\"STDOUT\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 2, "SSH-VERIFY-OUTPUT", "SMARTS", "COMMON_DB_ASSERTIONS", "SSH-CONNECT-EXEC",
                "[]",
                "[{\"DB\":\"SELECT 'ssh-ok' WHERE result='ssh-ok'\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-ok\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-SSH-REMOTE-EXEC", 3, "SSH-LOCAL-LOG", "DATAHUB", "COMMON_WINDOWS_CMD", "SSH-VERIFY-OUTPUT",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo ssh-log-recorded\"]}}]",
                "[{\"STDOUT\":\"ssh-log-recorded\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"ssh-log-recorded\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 9. UI report view (3 steps) ---
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 1, "UI-NAVIGATE-REPORT", "DRP", "DRP_UI_REPORTS", "[]",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"navigate\",\"target\":\"/reports/daily\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[{\"name\":\"uiNavResult\",\"from\":\"JAVA\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 2, "UI-INTERACT-BOOK", "SMARTS", "104_UI_BOOK", "UI-NAVIGATE-REPORT",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"click\",\"target\":\"report-tab-104\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-UI-REPORT-VIEW", 3, "UI-VERIFY-RESULT", "SMARTS", "COMMON_DB_ASSERTIONS", "UI-INTERACT-BOOK",
                "[]",
                "[{\"DB\":\"SELECT 'OK' WHERE result='OK'\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- 10. Order lifecycle flow (5 steps) ---
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 1, "FLOW-HTTP-CREATE", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"headers\":{\"X-Flow-Id\":\"${global.flow_biz_id}\"}}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"flowHttpStatus\",\"from\":\"HTTP\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 2, "FLOW-DB-VERIFY", "SMARTS", "COMMON_DB_EXECUTE", "FLOW-HTTP-CREATE",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_flow (biz_id VARCHAR(50), status VARCHAR(20))\",\"INSERT INTO e2e_flow VALUES ('${global.flow_biz_id}','HTTP_DONE')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 3, "FLOW-MQ-NOTIFY", "STP", "COMMON_MQ_SEND", "FLOW-DB-VERIFY",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\"}}]",
                "[]", "[]", 30, 0, "CONTINUE", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 4, "FLOW-CMD-LOG", "DATAHUB", "COMMON_WINDOWS_CMD", "FLOW-MQ-NOTIFY",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo flow-${global.flow_biz_id}-completed\"]}}]",
                "[{\"STDOUT\":\"${global.flow_biz_id}\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"${global.flow_biz_id}\"]}]",
                "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-FLOW-ORDER-LIFECYCLE", 5, "FLOW-DB-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "FLOW-CMD-LOG",
                "[{\"DB\":\"DROP TABLE e2e_flow\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 11. Retry flaky step (3 steps) ---
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 1, "RETRY-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_retry (id INT, attempt INT)\",\"INSERT INTO e2e_retry VALUES (1,0)\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 2, "RETRY-ASSERT-FLAKY", "SMARTS", "COMMON_DB_ASSERTIONS", "RETRY-SETUP",
                "[]",
                "[{\"DB\":\"SELECT * FROM e2e_retry WHERE id=1\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]",
                "[]", 10, 2, "RETRY", "Y");
        addStep(stepRows, "E2E-CASE-RETRY-FLAKY-STEP", 3, "RETRY-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "RETRY-ASSERT-FLAKY",
                "[{\"DB\":\"DROP TABLE e2e_retry\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");

        // --- 12. Disabled scenario (3 steps, Enabled=N) ---
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 1, "DISABLED-STEP-1", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"status\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 2, "DISABLED-STEP-2", "SMARTS", "COMMON_DB_EXECUTE", "DISABLED-STEP-1",
                "[{\"DB\":\"SELECT 'should-not-run'\"}]",
                "[]", "[]", 10, 0, "STOP", "Y");
        addStep(stepRows, "E2E-CASE-DISABLED-DEMO", 3, "DISABLED-STEP-3", "DATAHUB", "COMMON_WINDOWS_CMD", "DISABLED-STEP-2",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo should-not-run\"]}}]",
                "[]",                 "[]", 10, 0, "STOP", "Y");

        // --- S15. Assertion Map mode test (4 steps: setup + Map EQ + Map CONTAINS + FIELD string) ---
        addStep(stepRows, "E2E-CASE-ASSERT-MAP-MODE", 1, "AMM-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS e2e_assert (id VARCHAR(20), name VARCHAR(50), status VARCHAR(20))\",\"INSERT INTO e2e_assert VALUES ('1','order-001','CREATED')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        // Map EQ: SELECT 多列 WHERE 多条件 → 期望行所有字段完全匹配
        addStep(stepRows, "E2E-CASE-ASSERT-MAP-MODE", 2, "AMM-MAP-EQ", "DNS", "COMMON_DB_ASSERTIONS", "AMM-SETUP",
                "[]",
                "[{\"DB\":\"SELECT id, name, status FROM e2e_assert WHERE id='1' AND name='order-001' AND status='CREATED'\",\"OP\":\"EQ\",\"EXPECTED\":[{\"id\":\"1\",\"name\":\"order-001\",\"status\":\"CREATED\"}]}]",
                "[]", 10, 0, "STOP", "Y");
        // Map CONTAINS: 期望行是实际行的子集（只断言部分字段）
        addStep(stepRows, "E2E-CASE-ASSERT-MAP-MODE", 3, "AMM-MAP-CONTAINS", "DNS", "COMMON_DB_ASSERTIONS", "AMM-MAP-EQ",
                "[]",
                "[{\"DB\":\"SELECT id, name, status FROM e2e_assert WHERE id='1' AND name='order-001' AND status='CREATED'\",\"OP\":\"CONTAINS\",\"EXPECTED\":[{\"id\":\"1\",\"name\":\"order-001\"}]}]",
                "[]", 10, 0, "STOP", "Y");
        // String FIELD mode: 提取指定列做字符串断言
        addStep(stepRows, "E2E-CASE-ASSERT-MAP-MODE", 4, "AMM-FIELD-STRING", "DNS", "COMMON_DB_ASSERTIONS", "AMM-MAP-CONTAINS",
                "[]",
                "[{\"DB\":\"SELECT id, name FROM e2e_assert WHERE id='1' AND name='order-001'\",\"FIELD\":\"name\",\"OP\":\"EQ\",\"EXPECTED\":[\"order-001\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S16. UI Playwright demo (5 steps: UiHandler + Playwright navigate/fill/click/title) ---
        // Step 1: UiAction 处理器（demo 模式可执行）
        addStep(stepRows, "E2E-CASE-UI-PLAYWRIGHT-DEMO", 1, "UI-NAVIGATE", "DRP", "DRP_UI_REPORTS", "[]",
                "[{\"JAVA\":{\"url\":\"automation.qa.e2e.uiaction1\",\"params\":{\"action\":\"navigate\",\"target\":\"/reports/daily\"}}}]",
                "[{\"JAVA\":\"OK\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[{\"name\":\"uiNavResult\",\"from\":\"JAVA\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        // Step 2: Playwright 反射 navigate（live 模式生效，demo 模式 CONTINUE 跳过）
        addStep(stepRows, "E2E-CASE-UI-PLAYWRIGHT-DEMO", 2, "UI-PW-NAVIGATE", "DRP", "COMMON_JAVA_INVOKE", "UI-NAVIGATE",
                "[{\"JAVA\":{\"engine\":\"playwright\",\"method\":\"navigate\",\"params\":[\"https://www.baidu.com\"]}}]",
                "[]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 3: Playwright fill
        addStep(stepRows, "E2E-CASE-UI-PLAYWRIGHT-DEMO", 3, "UI-PW-FILL", "DRP", "COMMON_JAVA_INVOKE", "UI-PW-NAVIGATE",
                "[{\"JAVA\":{\"engine\":\"playwright\",\"method\":\"fill\",\"params\":[\"#kw\",\"E2E自动化测试\"]}}]",
                "[]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 4: Playwright click
        addStep(stepRows, "E2E-CASE-UI-PLAYWRIGHT-DEMO", 4, "UI-PW-CLICK", "DRP", "COMMON_JAVA_INVOKE", "UI-PW-FILL",
                "[{\"JAVA\":{\"engine\":\"playwright\",\"method\":\"click\",\"params\":[\"#su\"]}}]",
                "[]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 5: Playwright title → 断言标题不为空
        addStep(stepRows, "E2E-CASE-UI-PLAYWRIGHT-DEMO", 5, "UI-PW-TITLE", "DRP", "COMMON_JAVA_INVOKE", "UI-PW-CLICK",
                "[{\"JAVA\":{\"engine\":\"playwright\",\"method\":\"title\",\"params\":[]}}]",
                "[{\"JAVA\":\"result\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"百度\"]}]",
                "[{\"name\":\"pageTitle\",\"from\":\"result\",\"path\":\"\"}]", 30, 0, "CONTINUE", "Y");

        // --- S17. Java reflection invoke demo (3 steps: System.getProperty + String.valueOf + Math.max) ---
        // Step 1: 静态方法 System.getProperty → 提取结果
        addStep(stepRows, "E2E-CASE-JAVA-INVOKE-DEMO", 1, "JI-SYSTEM-PROPERTY", "SMARTS", "COMMON_JAVA_INVOKE", "[]",
                "[{\"JAVA\":{\"class\":\"java.lang.System\",\"method\":\"getProperty\",\"params\":[\"user.home\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"userHome\",\"from\":\"result\",\"path\":\"\"}]", 10, 0, "STOP", "Y");
        // Step 2: 静态方法 String.valueOf → 断言返回值
        addStep(stepRows, "E2E-CASE-JAVA-INVOKE-DEMO", 2, "JI-STRING-VALUEOF", "SMARTS", "COMMON_JAVA_INVOKE", "JI-SYSTEM-PROPERTY",
                "[{\"JAVA\":{\"class\":\"java.lang.String\",\"method\":\"valueOf\",\"params\":[123],\"paramTypes\":[\"int\"]}}]",
                "[{\"result\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"123\"]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 3: 静态方法 Math.max → 断言返回值 + 提取
        addStep(stepRows, "E2E-CASE-JAVA-INVOKE-DEMO", 3, "JI-MATH-MAX", "SMARTS", "COMMON_JAVA_INVOKE", "JI-STRING-VALUEOF",
                "[{\"JAVA\":{\"class\":\"java.lang.Math\",\"method\":\"max\",\"params\":[10,20],\"paramTypes\":[\"int\",\"int\"]}}]",
                "[{\"result\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"20\"]}]",
                "[{\"name\":\"maxValue\",\"from\":\"result\",\"path\":\"\"}]", 10, 0, "STOP", "Y");

        // --- S18. UI Automation Service via COMMON_JAVA_INVOKE bean (6 steps) ---
        // Step 1: 导航到百度首页（bean 模式反射调用 navigateTo）
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 1, "UAS-NAVIGATE", "DRP", "COMMON_JAVA_INVOKE", "[]",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"navigateTo\",\"params\":[\"https://www.baidu.com\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"navStatus\",\"from\":\"result\",\"path\":\"\"}]", 30, 0, "CONTINUE", "Y");
        // Step 2: 输入搜索关键词（bean 模式反射调用 inputText）
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 2, "UAS-INPUT", "DRP", "COMMON_JAVA_INVOKE", "UAS-NAVIGATE",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"inputText\",\"params\":[\"#kw\",\"E2E自动化测试框架\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 3: 点击搜索按钮（bean 模式反射调用 clickElement）
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 3, "UAS-CLICK", "DRP", "COMMON_JAVA_INVOKE", "UAS-INPUT",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"clickElement\",\"params\":[\"#su\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 4: 等待结果加载（bean 模式反射调用 waitForElement）
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 4, "UAS-WAIT", "DRP", "COMMON_JAVA_INVOKE", "UAS-CLICK",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"waitForElement\",\"params\":[\"#content_left\",5000],\"paramTypes\":[\"string\",\"int\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 30, 0, "CONTINUE", "Y");
        // Step 5: 获取页面标题（bean 模式反射调用 getPageTitle）+ 断言 + 提取
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 5, "UAS-TITLE", "DRP", "COMMON_JAVA_INVOKE", "UAS-WAIT",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"getPageTitle\",\"params\":[]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"pageTitle\",\"from\":\"result\",\"path\":\"title\"}]", 30, 0, "CONTINUE", "Y");
        // Step 6: 截图保存证据（bean 模式反射调用 takeScreenshot）
        addStep(stepRows, "E2E-CASE-UI-AUTOMATION-SERVICE", 6, "UAS-SCREENSHOT", "DRP", "COMMON_JAVA_INVOKE", "UAS-TITLE",
                "[{\"JAVA\":{\"bean\":\"uiAutomationService\",\"method\":\"takeScreenshot\",\"params\":[\"e2e-baidu-search\"]}}]",
                "[{\"result\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 30, 0, "STOP", "Y");

        // --- S19. File operations + FILE assertions (7 steps) ---
        // Step 1: 创建文件
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 1, "FILE-CREATE", "DATAHUB", "COMMON_FILE_ACTIONS", "[]",
                "[{\"FILE\":{\"op\":\"create\",\"path\":\"test-output/e2e-test-file.txt\"}}]",
                "[{\"exists\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 2: 写入内容
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 2, "FILE-WRITE", "DATAHUB", "COMMON_FILE_ACTIONS", "FILE-CREATE",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/e2e-test-file.txt\",\"content\":\"line1: hello e2e\\nline2: file test\\nline3: assertion\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 3: 追加内容
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 3, "FILE-APPEND", "DATAHUB", "COMMON_FILE_ACTIONS", "FILE-WRITE",
                "[{\"FILE\":{\"op\":\"append\",\"path\":\"test-output/e2e-test-file.txt\",\"content\":\"\\nline4: appended\"}}]",
                "[{\"appendedBytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 4: FILE 断言 - 文件内容 CONTAINS
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 4, "FILE-ASSERT-CONTAINS", "DNS", "COMMON_DB_ASSERTIONS", "FILE-APPEND",
                "[]",
                "[{\"FILE\":\"test-output/e2e-test-file.txt\",\"FIELD\":\"content\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"hello e2e\",\"appended\"]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 5: FILE 断言 - 文件内容 NOT_CONTAINS
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 5, "FILE-ASSERT-NOT-CONTAINS", "DNS", "COMMON_DB_ASSERTIONS", "FILE-ASSERT-CONTAINS",
                "[]",
                "[{\"FILE\":\"test-output/e2e-test-file.txt\",\"FIELD\":\"content\",\"OP\":\"NOT_CONTAINS\",\"EXPECTED\":[\"should-not-exist\",\"error-message\"]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 6: FILE 断言 - 行数 EQ
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 6, "FILE-ASSERT-LINECOUNT", "DNS", "COMMON_DB_ASSERTIONS", "FILE-ASSERT-NOT-CONTAINS",
                "[]",
                "[{\"FILE\":\"test-output/e2e-test-file.txt\",\"FIELD\":\"lineCount\",\"OP\":\"EQ\",\"EXPECTED\":[\"4\"]}]",
                "[]", 10, 0, "STOP", "Y");
        // Step 7: 删除文件 + 断言 deleted=true
        addStep(stepRows, "E2E-CASE-FILE-OPERATIONS", 7, "FILE-DELETE", "DATAHUB", "COMMON_FILE_ACTIONS", "FILE-ASSERT-LINECOUNT",
                "[{\"FILE\":{\"op\":\"delete\",\"path\":\"test-output/e2e-test-file.txt\"}}]",
                "[{\"deleted\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 10, 0, "STOP", "Y");

        // --- S20. FTP + MAIL demo (4 steps) ---
        // Step 1: FTP 上传（demo 模式走桩，记录虚拟文件）
        addStep(stepRows, "E2E-CASE-FTP-MAIL-DEMO", 1, "FTP-UPLOAD", "DATAHUB", "COMMON_FTP_ACTIONS", "[]",
                "[{\"FTP\":{\"op\":\"upload\",\"local\":\"test-output/test_report.html\",\"remote\":\"/upload/e2e-report.html\"}}]",
                "[{\"success\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 30, 0, "STOP", "Y");
        // Step 2: FTP 列出远程目录 + 断言文件数 >= 1
        addStep(stepRows, "E2E-CASE-FTP-MAIL-DEMO", 2, "FTP-LIST", "DATAHUB", "COMMON_FTP_ACTIONS", "FTP-UPLOAD",
                "[{\"FTP\":{\"op\":\"list\",\"dir\":\"/upload\"}}]",
                "[{\"fileCount\":\"\",\"OP\":\"GTE\",\"EXPECTED\":[\"1\"]}]",
                "[]", 30, 0, "STOP", "Y");
        // Step 3: MAIL 发送 HTML 邮件 + 附件（demo 模式走桩）
        addStep(stepRows, "E2E-CASE-FTP-MAIL-DEMO", 3, "MAIL-SEND", "DATAHUB", "COMMON_MAIL_ACTIONS", "FTP-LIST",
                "[{\"MAIL\":{\"to\":[\"e2e-team@example.com\"],\"cc\":[\"lead@example.com\"],\"subject\":\"E2E 测试报告通知\",\"body\":\"<h2>E2E 测试完成</h2><p>报告已上传至 FTP</p>\",\"html\":true,\"attachments\":[\"test-output/test_report.html\"]}}]",
                "[{\"success\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]},{\"messageId\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"mailMessageId\",\"from\":\"messageId\",\"path\":\"\"}]", 30, 0, "STOP", "Y");
        // Step 4: FTP 检查文件存在 + 删除
        addStep(stepRows, "E2E-CASE-FTP-MAIL-DEMO", 4, "FTP-CLEANUP", "DATAHUB", "COMMON_FTP_ACTIONS", "MAIL-SEND",
                "[{\"FTP\":{\"op\":\"delete\",\"remote\":\"/upload/e2e-report.html\"}}]",
                "[{\"success\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 30, 0, "STOP", "Y");

        // --- S21. Protocol extensions (12 steps, demo 全内存可跑) ---
        // Step 1: JWT 生成（自动写入 ${extract.jwtToken}）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 1, "EXT-JWT-GEN", "TAP", "COMMON_JWT_OPERATE", "[]",
                "[{\"JWT\":{\"op\":\"generate\",\"secret\":\"e2e-test-secret\",\"subject\":\"e2e-user\",\"claims\":{\"role\":\"tester\"},\"expireSeconds\":600}}]",
                "[{\"token\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"jwtToken\",\"from\":\"token\",\"path\":\"\"}]", 15, 0, "STOP", "Y");
        // Step 2: JWT 校验（引用 ${extract.jwtToken}）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 2, "EXT-JWT-VERIFY", "TAP", "COMMON_JWT_OPERATE", "EXT-JWT-GEN",
                "[{\"JWT\":{\"op\":\"verify\",\"secret\":\"e2e-test-secret\",\"token\":\"${extract.jwtToken}\"}}]",
                "[{\"valid\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 3: Redis set
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 3, "EXT-REDIS-SET", "DATAHUB", "COMMON_REDIS_OPERATE", "EXT-JWT-VERIFY",
                "[{\"REDIS\":{\"op\":\"set\",\"key\":\"e2e:user:1001\",\"value\":\"{\\\"name\\\":\\\"zhangsan\\\"}\",\"ttl\":300}}]",
                "[{\"result\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 4: Redis get + 断言 + EXTRACT
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 4, "EXT-REDIS-GET", "DATAHUB", "COMMON_REDIS_OPERATE", "EXT-REDIS-SET",
                "[{\"REDIS\":{\"op\":\"get\",\"key\":\"e2e:user:1001\"}}]",
                "[{\"value\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"zhangsan\"]}]",
                "[{\"name\":\"redisValue\",\"from\":\"value\",\"path\":\"\"}]", 15, 0, "STOP", "Y");
        // Step 5: MQ 发送到指定队列（StubMqClient 内存队列）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 5, "EXT-MQ-SEND", "STP", "COMMON_MQ_SEND", "EXT-REDIS-GET",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\",\"queue\":\"E2E.TEST.CONSUME\"}}]",
                "[{\"MQ\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"SENT\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 6: MQ 消费 + XPath 断言（firstMessage 的 //trade/side = BUY）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 6, "EXT-MQ-CONSUME", "STP", "COMMON_MQ_CONSUME", "EXT-MQ-SEND",
                "[{\"MQ\":{\"op\":\"consume\",\"queue\":\"E2E.TEST.CONSUME\",\"maxMessages\":1,\"timeout\":3}}]",
                "[{\"messageCount\":\"\",\"OP\":\"GTE\",\"EXPECTED\":[\"1\"]},{\"firstMessage\":\"//trade/side\",\"OP\":\"EQ\",\"EXPECTED\":[\"BUY\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 7: Mongo 插入 2 文档
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 7, "EXT-MONGO-INSERT", "SMARTS", "COMMON_NOSQL_EXECUTE", "EXT-MQ-CONSUME",
                "[{\"MONGO\":{\"op\":\"insert\",\"collection\":\"e2e_users\",\"docs\":[{\"id\":1,\"name\":\"alice\"},{\"id\":2,\"name\":\"bob\"}]}}]",
                "[{\"insertedCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"2\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 8: Mongo 断言查询（docCount = 2）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 8, "EXT-MONGO-ASSERT", "DNS", "COMMON_NOSQL_ASSERT", "EXT-MONGO-INSERT",
                "[{\"MONGO\":{\"collection\":\"e2e_users\",\"filter\":{\"id\":1}}}]",
                "[{\"docCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]},{\"firstDoc\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"alice\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 9: Webhook 通知（自定义 URL + JSON body）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 9, "EXT-WEBHOOK", "DATAHUB", "COMMON_WEBHOOK_NOTIFY", "EXT-MONGO-ASSERT",
                "[{\"WEBHOOK\":{\"url\":\"https://hooks.example.com/e2e-test\",\"body\":{\"event\":\"e2e-ext-test\",\"score\":100}}}]",
                "[{\"status\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 10: HTTP 请求 + JSONPath 断言（$.stub = true）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 10, "EXT-HTTP-JSONPATH", "TAP", "COMMON_HTTP_REQUEST", "EXT-WEBHOOK",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"params\":{\"e2e\":\"jsonpath-test\"}}}]",
                "[{\"status\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]},{\"body\":\"$.stub\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 11: 写入比对基准文件
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 11, "EXT-FILE-WRITE", "DATAHUB", "COMMON_FILE_ACTIONS", "EXT-HTTP-JSONPATH",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/ext-compare-a.txt\",\"content\":\"line1: alpha\\nline2: beta\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 12: DataCompare 文件 vs 文件（equal = true）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 12, "EXT-DATA-COMPARE", "SMARTS", "COMMON_DATA_COMPARE", "EXT-FILE-WRITE",
                "[{\"COMPARE\":{\"sourceA\":{\"type\":\"file\",\"path\":\"test-output/ext-compare-a.txt\"},\"sourceB\":{\"type\":\"file\",\"path\":\"test-output/ext-compare-a.txt\"}}}]",
                "[{\"equal\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 13: 写入 JSON 数据文件（供文件型 JSONPath 断言）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 13, "EXT-JSON-WRITE", "DATAHUB", "COMMON_FILE_ACTIONS", "EXT-DATA-COMPARE",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/ext-data.json\",\"content\":\"{\\\"user\\\":{\\\"name\\\":\\\"zhangsan\\\",\\\"role\\\":[\\\"admin\\\",\\\"tester\\\"]}}\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 14: 显式 JSONPath 断言（JSONPATH source + FILE 文件内容）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 14, "EXT-JSONPATH-FILE", "DNS", "COMMON_DB_ASSERTIONS", "EXT-JSON-WRITE",
                "[]",
                "[{\"JSONPATH\":\"$.user.name\",\"FILE\":\"test-output/ext-data.json\",\"OP\":\"EQ\",\"EXPECTED\":[\"zhangsan\"]},{\"JSONPATH\":\"$.user.role[1]\",\"FILE\":\"test-output/ext-data.json\",\"OP\":\"EQ\",\"EXPECTED\":[\"tester\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 15: 显式 XPath 断言（XML source + FILE 读取 MQ 报文文件）
        addStep(stepRows, "E2E-CASE-PROTOCOL-EXTENSIONS", 15, "EXT-XPATH-FILE", "DNS", "COMMON_DB_ASSERTIONS", "EXT-JSONPATH-FILE",
                "[]",
                "[{\"XML\":\"//trade/side\",\"FILE\":\"src/test/resources/data/e2e/stp/mq/test-001.xml\",\"OP\":\"EQ\",\"EXPECTED\":[\"BUY\"]},{\"XPATH\":\"//trade/price\",\"FILE\":\"src/test/resources/data/e2e/stp/mq/test-001.xml\",\"OP\":\"EQ\",\"EXPECTED\":[\"10.50\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // --- S22. 跨步骤传参验证（EXTRACT 增强：JSONPath/XPath/Regex/文件行 → 变量引用闭环）---
        // Step 1: 场景级参数设置（字面量模式：value 直接定义，后续所有步骤可引用）
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 1, "EX-PARAMS-INIT", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"acct\",\"value\":\"999999\"},{\"name\":\"branchCode\",\"value\":\"0755\"},{\"name\":\"bizRef\",\"value\":\"ACCT-${extract.acct}-BR-${extract.branchCode}\"}]", 15, 0, "STOP", "Y");
        // Step 2: HTTP POST → JSONPath 提取 $.body.bizId
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 2, "EX-HTTP-POST", "TAP", "COMMON_HTTP_REQUEST", "EX-PARAMS-INIT",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"bizId\":\"BIZ-EXT-001\",\"amount\":99}}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"bodyBizId\",\"from\":\"body\",\"path\":\"$.body.bizId\"}]", 15, 0, "STOP", "Y");
        // Step 3: 引用 ${extract.bodyBizId} 作为 query 参数 → 断言回显（跨步骤传参证明①）
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 3, "EX-HTTP-USE", "TAP", "COMMON_HTTP_REQUEST", "EX-HTTP-POST",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"params\":{\"ref\":\"${extract.bodyBizId}\",\"acct\":\"${extract.acct}\"}}}]",
                "[{\"body\":\"$.queryParams.ref\",\"OP\":\"EQ\",\"EXPECTED\":[\"BIZ-EXT-001\"]},{\"body\":\"$.queryParams.acct\",\"OP\":\"EQ\",\"EXPECTED\":[\"999999\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 4: 写文件 + FILE 行提取（#L2 取第 2 行）
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 4, "EX-FILE-WRITE", "DATAHUB", "COMMON_FILE_ACTIONS", "EX-HTTP-USE",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/ext-params.txt\",\"content\":\"alpha\\nbeta\\ngamma\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"secondLine\",\"from\":\"FILE\",\"path\":\"test-output/ext-params.txt#L2\"}]", 15, 0, "STOP", "Y");
        // Step 5: 引用 ${extract.secondLine} → 断言回显（跨步骤传参证明②：文件行提取）
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 5, "EX-FILE-USE", "TAP", "COMMON_HTTP_REQUEST", "EX-FILE-WRITE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"line\":\"${extract.secondLine}\"}}}]",
                "[{\"body\":\"$.body.line\",\"OP\":\"EQ\",\"EXPECTED\":[\"beta\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 6: MQ 发送（供 XPath/Regex 提取）
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 6, "EX-MQ-SEND", "STP", "COMMON_MQ_SEND", "EX-FILE-USE",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\",\"queue\":\"E2E.EXT.PARAMS\"}}]",
                "[{\"MQ\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"SENT\"]}]",
                "[]", 15, 0, "STOP", "Y");
        // Step 7: MQ 消费 → XPath 提取 //trade/security + Regex 提取 <price>
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 7, "EX-MQ-CONSUME", "STP", "COMMON_MQ_CONSUME", "EX-MQ-SEND",
                "[{\"MQ\":{\"op\":\"consume\",\"queue\":\"E2E.EXT.PARAMS\",\"maxMessages\":1,\"timeout\":3}}]",
                "[{\"messageCount\":\"\",\"OP\":\"GTE\",\"EXPECTED\":[\"1\"]}]",
                "[{\"name\":\"secCode\",\"from\":\"firstMessage\",\"path\":\"//trade/security\"},{\"name\":\"priceVal\",\"from\":\"firstMessage\",\"path\":\"regex:<price>([\\\\d.]+)</price>\"}]", 15, 0, "STOP", "Y");
        // Step 8: 引用 ${extract.secCode}/${extract.priceVal} + 场景级参数 ${extract.acct}/${extract.bizRef}（组合变量）→ 断言回显
        addStep(stepRows, "E2E-CASE-EXTRACT-PARAMS", 8, "EX-FINAL-USE", "TAP", "COMMON_HTTP_REQUEST", "EX-MQ-CONSUME",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"sec\":\"${extract.secCode}\",\"price\":\"${extract.priceVal}\",\"acct\":\"${extract.acct}\",\"bizRef\":\"${extract.bizRef}\"}}}]",
                "[{\"body\":\"$.body.sec\",\"OP\":\"EQ\",\"EXPECTED\":[\"000001\"]},{\"body\":\"$.body.price\",\"OP\":\"EQ\",\"EXPECTED\":[\"10.50\"]},{\"body\":\"$.body.acct\",\"OP\":\"EQ\",\"EXPECTED\":[\"999999\"]},{\"body\":\"$.body.bizRef\",\"OP\":\"EQ\",\"EXPECTED\":[\"ACCT-999999-BR-0755\"]}]",
                "[]", 15, 0, "STOP", "Y");

        WriteSheet sheet2 = com.alibaba.excel.EasyExcel.writerSheet(1, "Steps")
                .head(toHead(stepHeader)).build();
        writer.write(stepRows, sheet2);

        // ===== Sheet 3: _GlobalConfig =====
        List<List<Object>> configRows = new ArrayList<>();
        Map<String, String> globalConfig = new LinkedHashMap<>();
        globalConfig.put("http_base_url", "http://www.baidu.com");
        globalConfig.put("http_search_word", "e2e-automation");
        globalConfig.put("test_user_name", "e2e-user");
        globalConfig.put("test_user_pwd", "123123");
        globalConfig.put("flow_biz_id", "MIX-FLOW-001");
        globalConfig.put("ssh_host", "127.0.0.1");
        globalConfig.put("ssh_user", "e2e");
        globalConfig.put("ssh_password", "e2e-password");
        globalConfig.put("env_timestamp", "${env.TIMESTAMP}");
        globalConfig.forEach((k, v) -> configRows.add(List.of(k, v)));

        WriteSheet sheet3 = com.alibaba.excel.EasyExcel.writerSheet(2, "_GlobalConfig").build();
        writer.write(configRows, sheet3);

        writer.finish();
        System.out.println("[CasesExcelGenerator] 已生成: " + output.toAbsolutePath()
                + " (" + scenarioRows.size() + " scenarios / " + stepRows.size() + " steps / " + configRows.size() + " globals)");
    }

    // ---- helpers ----

    private static List<Object> row(Object... values) {
        return Arrays.asList(values);
    }

    private static void addStep(List<List<Object>> rows, String scenarioId, int seqNo, String stepId,
                                String app, String action, String dependsOn, String input, String assertJson,
                                String extract, int timeout, int retry, String onFailure, String enabled) {
        rows.add(List.of(scenarioId, seqNo, stepId, app, action, dependsOn,
                input, assertJson, extract, timeout, retry, onFailure, enabled));
    }

    private static List<List<String>> toHead(List<String> headers) {
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        return head;
    }
}
