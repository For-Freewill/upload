package com.e2e.generator;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 框架全面测试用例生成器 —— 生成 cases/test_case_examples.xlsx。
 *
 * <p>覆盖矩阵（22 场景）：
 * <ul>
 *   <li><b>P 组（正向 ×14）</b>：全部 Action 标准用法 + 断言/提取正向验证，预期场景 PASSED</li>
 *   <li><b>N 组（反向断言 ×3）</b>：断言反向条件成立（NOT_CONTAINS/NE/EMPTY/边界值/特殊字符），
 *       预期场景 PASSED（验证断言引擎正确识别"不满足"）</li>
 *   <li><b>R 组（健壮性 ×5）</b>：非法 INPUT / EXTRACT 失败 / 断言失败 / 未知变量 / WAIT_UNTIL 超时，
 *       每场景末尾 SENTINEL 哨兵步骤验证框架未崩溃（场景预期 FAILED，哨兵 PASSED，
 *       失败消息应为优雅的 ActionResult.fail 而非异常堆栈）</li>
 * </ul>
 *
 * <p>运行：{@code mvn test -Dsurefire.suiteXmlFiles=src/test/resources/testng/testng-gen2.xml}
 * 然后用 {@code -De2e.data.excel.path=classpath:cases/test_case_examples.xlsx} 执行测试。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public class TestCaseExamplesGenerator {

    @Test
    public void generateCases() throws Exception {
        Path output = Paths.get("src/test/resources/cases/test_case_examples.xlsx");
        Files.createDirectories(output.getParent());

        ExcelWriter writer = com.alibaba.excel.EasyExcel.write(output.toFile()).build();

        List<List<Object>> scenarioRows = new ArrayList<>();
        List<List<Object>> stepRows = new ArrayList<>();

        // ================= Scenarios =================
        int seq = 1;
        // --- P 组：正向 ---
        scenarioRows.add(row(seq++, "TC-P01-HTTP-METHODS", "HTTP 全 Method 正向", "Y", "positive;http", "demo", "120", "GET/POST/PUT/PATCH/DELETE/HEAD + JSONPath 断言 + EXTRACT", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P02-WINDOWS-CMD", "Windows CMD 正向", "Y", "positive;cmd", "demo", "60", "base_dir + 批量命令 + commandCount 断言 + lines 提取", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P03-LINUX-CMD-LOCAL", "Linux CMD 本地正向", "Y", "positive;cmd", "demo", "60", "本地 sh 命令 + STDOUT 断言", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P04-DB-LIFECYCLE", "DB 全生命周期正向", "Y", "positive;db", "demo", "120", "DDL/DML 执行 + 断言 + EXTRACT", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P05-FILE-OPS", "FILE 全操作正向", "Y", "positive;file", "demo", "60", "create/write/append/read/exists/deletePattern + FILE 断言", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P06-FTP-MAIL", "FTP/MAIL 正向", "Y", "positive;ftp;mail", "demo", "60", "FTP upload/list/delete + MAIL 发送（stub）", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P07-REDIS-OPS", "Redis 全操作正向", "Y", "positive;redis", "demo", "60", "set/get/ttl/hset/hget/del 全链路（内存模拟）", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P08-MONGO-OPS", "Mongo 操作与断言正向", "Y", "positive;mongo", "demo", "60", "insert/assert/update/firstDoc JSONPath 断言", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P09-JWT-FLOW", "JWT 生成解析校验正向", "Y", "positive;jwt", "demo", "60", "generate→parse claims→verify valid", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P10-MQ-LOOP", "MQ 收发闭环正向", "Y", "positive;mq", "demo", "60", "send→consume + XPath/Regex EXTRACT", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P11-WEBHOOK-WS", "Webhook/WebSocket 正向", "Y", "positive;webhook;ws", "demo", "60", "webhook status 200 + WS 回显断言", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P12-DATA-COMPARE", "DataCompare 文件比对正向", "Y", "positive;compare", "demo", "60", "写两相同文件 → equal=true", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P13-EXTRACT-MODES", "EXTRACT 五模式正向", "Y", "positive;extract", "demo", "120", "literal/JSONPath/FILE#L/XPath/Regex 全模式 + 跨步骤引用", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-P14-VARIABLE-REF", "变量引用正向", "Y", "positive;vars", "demo", "60", "global/env/extract 三类占位符引用", "e2e-team"));
        // --- N 组：反向断言（预期 PASS）---
        scenarioRows.add(row(seq++, "TC-N01-ASSERT-NEGATIVE", "断言操作符反向验证", "Y", "negative;assert", "demo", "60", "NOT_CONTAINS/NE/EMPTY/REGEX 反向条件成立（预期 PASS）", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-N02-EDGE-VALUES", "边界值与特殊字符", "Y", "negative;edge", "demo", "60", "中文/emoji/嵌套数组/转义字符值传递断言", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-N03-FILE-NEGATIVE", "FILE 反向断言", "Y", "negative;file", "demo", "60", "exists=false 断言 + deletePattern 无匹配 matched=0", "e2e-team"));
        // --- R 组：健壮性（预期场景 FAILED + 哨兵 PASSED）---
        scenarioRows.add(row(seq++, "TC-R01-INVALID-INPUT", "非法 INPUT 健壮性", "Y", "robust;input", "demo", "120", "缺协议载荷/错误op/缺必填字段 → 优雅报错 + 哨兵存活", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-R02-EXTRACT-FAILURES", "EXTRACT 失败健壮性", "Y", "robust;extract", "demo", "120", "来源键不存在/正则无匹配/JSONPath无效/文件不存在/行号越界 + 哨兵", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-R03-ASSERT-FAILURES", "断言失败健壮性", "Y", "robust;assert", "demo", "120", "EQ不匹配/Map不匹配/NOT_CONTAINS违反 → 清晰失败消息 + 哨兵", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-R04-UNDEFINED-VARS", "未知变量引用健壮性", "Y", "robust;vars", "demo", "60", "未定义 ${extract.x} 引用行为观察 + 哨兵", "e2e-team"));
        scenarioRows.add(row(seq++, "TC-R05-WAIT-UNTIL-TIMEOUT", "WAIT_UNTIL 超时健壮性", "Y", "robust;timeout", "demo", "60", "永不成立的轮询 2 秒超时 → FAILED + 哨兵", "e2e-team"));

        // ================= Steps =================

        // ---- TC-P01 HTTP 全 Method ----
        addStep(stepRows, "TC-P01-HTTP-METHODS", 1, "P01-GET", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"params\":{\"q\":\"e2e\"}}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]},{\"body\":\"$.stub\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P01-HTTP-METHODS", 2, "P01-POST", "TAP", "COMMON_HTTP_REQUEST", "P01-GET",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"name\":\"订单α\",\"qty\":3}}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]},{\"body\":\"$.body.name\",\"OP\":\"EQ\",\"EXPECTED\":[\"订单α\"]}]",
                "[{\"name\":\"postedName\",\"from\":\"body\",\"path\":\"$.body.name\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P01-HTTP-METHODS", 3, "P01-PUT", "TAP", "COMMON_HTTP_REQUEST", "P01-POST",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"PUT\",\"body\":{\"status\":\"UPDATED\"}}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]},{\"body\":\"$.body.status\",\"OP\":\"EQ\",\"EXPECTED\":[\"UPDATED\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P01-HTTP-METHODS", 4, "P01-PATCH", "TAP", "COMMON_HTTP_REQUEST", "P01-PUT",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"PATCH\",\"body\":{\"field\":\"patched\"}}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P01-HTTP-METHODS", 5, "P01-DELETE", "TAP", "COMMON_HTTP_REQUEST", "P01-PATCH",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"DELETE\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P01-HTTP-METHODS", 6, "P01-HEAD", "TAP", "COMMON_HTTP_REQUEST", "P01-DELETE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"HEAD\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P02 Windows CMD ----
        addStep(stepRows, "TC-P02-WINDOWS-CMD", 1, "P02-BASEDIR", "DATAHUB", "COMMON_WINDOWS_CMD", "[]",
                "[{\"WINDOWS-CMD\":{\"base_dir\":\"test-output\",\"cmd\":[\"echo tc-p02-start\",\"echo second-line\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"tc-p02-start\",\"second-line\"]},{\"commandCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"2\"]},{\"CMD\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]}]",
                "[{\"name\":\"p02FirstLine\",\"from\":\"lines\",\"path\":\"[0]\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P02-WINDOWS-CMD", 2, "P02-USE-EXTRACT", "TAP", "COMMON_HTTP_REQUEST", "P02-BASEDIR",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"firstLine\":\"${extract.p02FirstLine}\"}}}]",
                "[{\"body\":\"$.body.firstLine\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"tc-p02-start\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P03 Linux CMD 本地 ----
        addStep(stepRows, "TC-P03-LINUX-CMD-LOCAL", 1, "P03-ECHO", "DATAHUB", "COMMON_LINUX_CMD", "[]",
                "[{\"LINUX-CMD\":{\"host\":\"local\",\"cmd\":[\"echo linux-p03-ok\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"linux-p03-ok\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P04 DB 全生命周期（demo 桩宽松断言）----
        addStep(stepRows, "TC-P04-DB-LIFECYCLE", 1, "P04-SETUP", "SMARTS", "COMMON_DB_EXECUTE", "[]",
                "[{\"DB\":[\"CREATE TABLE IF NOT EXISTS tc_p04 (id INT, name VARCHAR(50))\",\"INSERT INTO tc_p04 VALUES (1,'alpha')\"]}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P04-DB-LIFECYCLE", 2, "P04-ASSERT", "DNS", "COMMON_DB_ASSERTIONS", "P04-SETUP",
                "[]",
                "[{\"DB\":\"SELECT id, name FROM tc_p04\",\"OP\":\"SIZE\",\"EXPECTED\":[\"1\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P04-DB-LIFECYCLE", 3, "P04-UPDATE", "SMARTS", "COMMON_DB_EXECUTE", "P04-ASSERT",
                "[{\"DB\":\"UPDATE tc_p04 SET name='beta' WHERE id=1\"}]",
                "[]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P04-DB-LIFECYCLE", 4, "P04-CLEANUP", "SMARTS", "COMMON_DB_EXECUTE", "P04-UPDATE",
                "[{\"DB\":\"DROP TABLE tc_p04\"}]",
                "[]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-P05 FILE 全操作 ----
        addStep(stepRows, "TC-P05-FILE-OPS", 1, "P05-CREATE", "DATAHUB", "COMMON_FILE_ACTIONS", "[]",
                "[{\"FILE\":{\"op\":\"create\",\"path\":\"test-output/tc-p05.txt\"}}]",
                "[{\"exists\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P05-FILE-OPS", 2, "P05-WRITE", "DATAHUB", "COMMON_FILE_ACTIONS", "P05-CREATE",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/tc-p05.txt\",\"content\":\"line-one\\nline-two\\nline-three\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P05-FILE-OPS", 3, "P05-APPEND", "DATAHUB", "COMMON_FILE_ACTIONS", "P05-WRITE",
                "[{\"FILE\":{\"op\":\"append\",\"path\":\"test-output/tc-p05.txt\",\"content\":\"\\nline-four-appended\"}}]",
                "[{\"appendedBytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P05-FILE-OPS", 4, "P05-READ", "DATAHUB", "COMMON_FILE_ACTIONS", "P05-APPEND",
                "[{\"FILE\":{\"op\":\"read\",\"path\":\"test-output/tc-p05.txt\"}}]",
                "[{\"lineCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"4\"]},{\"content\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"line-one\",\"line-four-appended\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P05-FILE-OPS", 5, "P05-ASSERT-FILE", "DNS", "COMMON_DB_ASSERTIONS", "P05-READ",
                "[]",
                "[{\"FILE\":\"test-output/tc-p05.txt\",\"FIELD\":\"lineCount\",\"OP\":\"EQ\",\"EXPECTED\":[\"4\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P05-FILE-OPS", 6, "P05-DELETE", "DATAHUB", "COMMON_FILE_ACTIONS", "P05-ASSERT-FILE",
                "[{\"FILE\":{\"op\":\"delete\",\"path\":\"test-output/tc-p05.txt\"}}]",
                "[{\"deleted\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-P06 FTP/MAIL ----
        addStep(stepRows, "TC-P06-FTP-MAIL", 1, "P06-FTP-UPLOAD", "DATAHUB", "COMMON_FTP_ACTIONS", "[]",
                "[{\"FTP\":{\"op\":\"upload\",\"local\":\"test-output/test_report.html\",\"remote\":\"/upload/tc-p06.html\"}}]",
                "[{\"success\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "TC-P06-FTP-MAIL", 2, "P06-FTP-LIST", "DATAHUB", "COMMON_FTP_ACTIONS", "P06-FTP-UPLOAD",
                "[{\"FTP\":{\"op\":\"list\",\"dir\":\"/upload\"}}]",
                "[{\"fileCount\":\"\",\"OP\":\"GTE\",\"EXPECTED\":[\"1\"]}]", "[]", 30, 0, "STOP", "Y");
        addStep(stepRows, "TC-P06-FTP-MAIL", 3, "P06-MAIL", "DATAHUB", "COMMON_MAIL_ACTIONS", "P06-FTP-LIST",
                "[{\"MAIL\":{\"to\":[\"tc@example.com\"],\"subject\":\"TC-P06\",\"body\":\"<p>测试通过</p>\",\"html\":true}}]",
                "[{\"success\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]},{\"messageId\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]", "[]", 30, 0, "STOP", "Y");

        // ---- TC-P07 Redis ----
        addStep(stepRows, "TC-P07-REDIS-OPS", 1, "P07-SET", "DATAHUB", "COMMON_REDIS_OPERATE", "[]",
                "[{\"REDIS\":{\"op\":\"set\",\"key\":\"tc:p07:user\",\"value\":\"{\\\"name\\\":\\\"gamma\\\"}\",\"ttl\":120}}]",
                "[{\"result\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P07-REDIS-OPS", 2, "P07-GET", "DATAHUB", "COMMON_REDIS_OPERATE", "P07-SET",
                "[{\"REDIS\":{\"op\":\"get\",\"key\":\"tc:p07:user\"}}]",
                "[{\"value\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"gamma\"]}]",
                "[{\"name\":\"cachedName\",\"from\":\"value\",\"path\":\"$.name\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P07-REDIS-OPS", 3, "P07-TTL", "DATAHUB", "COMMON_REDIS_OPERATE", "P07-GET",
                "[{\"REDIS\":{\"op\":\"ttl\",\"key\":\"tc:p07:user\"}}]",
                "[{\"ttl\":\"\",\"OP\":\"GT\",\"EXPECTED\":[\"0\"]},{\"ttl\":\"\",\"OP\":\"LTE\",\"EXPECTED\":[\"120\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P07-REDIS-OPS", 4, "P07-JSONPATH-EXTRACT", "TAP", "COMMON_HTTP_REQUEST", "P07-TTL",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"cached\":\"${extract.cachedName}\"}}}]",
                "[{\"body\":\"$.body.cached\",\"OP\":\"EQ\",\"EXPECTED\":[\"gamma\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P07-REDIS-OPS", 5, "P07-HSET", "DATAHUB", "COMMON_REDIS_OPERATE", "P07-JSONPATH-EXTRACT",
                "[{\"REDIS\":{\"op\":\"hset\",\"key\":\"tc:p07:session\",\"field\":\"state\",\"value\":\"active\"}}]",
                "[{\"result\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"OK\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P07-REDIS-OPS", 6, "P07-HGET-DEL", "DATAHUB", "COMMON_REDIS_OPERATE", "P07-HSET",
                "[{\"REDIS\":{\"op\":\"hget\",\"key\":\"tc:p07:session\",\"field\":\"state\"}}]",
                "[{\"value\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"active\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-P08 Mongo ----
        addStep(stepRows, "TC-P08-MONGO-OPS", 1, "P08-INSERT", "SMARTS", "COMMON_NOSQL_EXECUTE", "[]",
                "[{\"MONGO\":{\"op\":\"insert\",\"collection\":\"tc_p08\",\"docs\":[{\"id\":1,\"status\":\"NEW\"},{\"id\":2,\"status\":\"DONE\"}]}}]",
                "[{\"insertedCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"2\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P08-MONGO-OPS", 2, "P08-ASSERT", "DNS", "COMMON_NOSQL_ASSERT", "P08-INSERT",
                "[{\"MONGO\":{\"collection\":\"tc_p08\",\"filter\":{\"id\":1}}}]",
                "[{\"docCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]},{\"firstDoc\":\"$.status\",\"OP\":\"EQ\",\"EXPECTED\":[\"NEW\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P08-MONGO-OPS", 3, "P08-UPDATE", "SMARTS", "COMMON_NOSQL_EXECUTE", "P08-ASSERT",
                "[{\"MONGO\":{\"op\":\"update\",\"collection\":\"tc_p08\",\"filter\":{\"id\":1},\"update\":{\"$set\":{\"status\":\"DONE\"}}}}]",
                "[{\"matchedCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P08-MONGO-OPS", 4, "P08-VERIFY", "DNS", "COMMON_NOSQL_ASSERT", "P08-UPDATE",
                "[{\"MONGO\":{\"collection\":\"tc_p08\",\"filter\":{\"status\":\"DONE\"}}}]",
                "[{\"docCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"2\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-P09 JWT ----
        addStep(stepRows, "TC-P09-JWT-FLOW", 1, "P09-GEN", "TAP", "COMMON_JWT_OPERATE", "[]",
                "[{\"JWT\":{\"op\":\"generate\",\"secret\":\"tc-p09-secret\",\"subject\":\"tc-user\",\"claims\":{\"level\":\"P9\"},\"expireSeconds\":300}}]",
                "[{\"token\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P09-JWT-FLOW", 2, "P09-PARSE", "TAP", "COMMON_JWT_OPERATE", "P09-GEN",
                "[{\"JWT\":{\"op\":\"parse\",\"secret\":\"tc-p09-secret\",\"token\":\"${extract.jwtToken}\"}}]",
                "[{\"subject\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"tc-user\"]},{\"claims\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"P9\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P09-JWT-FLOW", 3, "P09-VERIFY", "TAP", "COMMON_JWT_OPERATE", "P09-PARSE",
                "[{\"JWT\":{\"op\":\"verify\",\"secret\":\"tc-p09-secret\",\"token\":\"${extract.jwtToken}\"}}]",
                "[{\"valid\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-P10 MQ 收发闭环 ----
        addStep(stepRows, "TC-P10-MQ-LOOP", 1, "P10-SEND", "STP", "COMMON_MQ_SEND", "[]",
                "[{\"MQ\":{\"file\":\"data/e2e/stp/mq/test-001.xml\",\"queue\":\"TC.P10\"}}]",
                "[{\"MQ\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"SENT\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P10-MQ-LOOP", 2, "P10-CONSUME", "STP", "COMMON_MQ_CONSUME", "P10-SEND",
                "[{\"MQ\":{\"op\":\"consume\",\"queue\":\"TC.P10\",\"maxMessages\":1,\"timeout\":3}}]",
                "[{\"messageCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]},{\"firstMessage\":\"//trade/currency\",\"OP\":\"EQ\",\"EXPECTED\":[\"CNY\"]}]",
                "[{\"name\":\"mqQty\",\"from\":\"firstMessage\",\"path\":\"//trade/qty\"},{\"name\":\"mqPrice\",\"from\":\"firstMessage\",\"path\":\"regex:<price>([\\\\d.]+)</price>\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P10-MQ-LOOP", 3, "P10-USE-VARS", "TAP", "COMMON_HTTP_REQUEST", "P10-CONSUME",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"qty\":\"${extract.mqQty}\",\"price\":\"${extract.mqPrice}\"}}}]",
                "[{\"body\":\"$.body.qty\",\"OP\":\"EQ\",\"EXPECTED\":[\"100\"]},{\"body\":\"$.body.price\",\"OP\":\"EQ\",\"EXPECTED\":[\"10.50\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P11 Webhook + WebSocket ----
        addStep(stepRows, "TC-P11-WEBHOOK-WS", 1, "P11-WEBHOOK", "DATAHUB", "COMMON_WEBHOOK_NOTIFY", "[]",
                "[{\"WEBHOOK\":{\"url\":\"https://hooks.example.com/tc-p11\",\"body\":{\"event\":\"tc-p11\",\"ok\":true}}}]",
                "[{\"status\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P11-WEBHOOK-WS", 2, "P11-WS", "DATAHUB", "COMMON_WEBSOCKET_CLIENT", "P11-WEBHOOK",
                "[{\"WS\":{\"op\":\"send\",\"url\":\"wss://echo.example.com/ws\",\"message\":\"tc-p11-ping\",\"timeout\":3}}]",
                "[{\"connected\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]},{\"lastMessage\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"tc-p11-ping\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P12 DataCompare ----
        addStep(stepRows, "TC-P12-DATA-COMPARE", 1, "P12-WRITE-AB", "DATAHUB", "COMMON_FILE_ACTIONS", "[]",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/tc-p12-a.txt\",\"content\":\"row-1\\nrow-2\\nrow-3\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P12-DATA-COMPARE", 2, "P12-COMPARE", "SMARTS", "COMMON_DATA_COMPARE", "P12-WRITE-AB",
                "[{\"COMPARE\":{\"sourceA\":{\"type\":\"file\",\"path\":\"test-output/tc-p12-a.txt\"},\"sourceB\":{\"type\":\"file\",\"path\":\"test-output/tc-p12-a.txt\"}}}]",
                "[{\"equal\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"true\"]},{\"diffCount\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P13 EXTRACT 五模式 ----
        addStep(stepRows, "TC-P13-EXTRACT-MODES", 1, "P13-INIT", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"acct\",\"value\":\"888888\"},{\"name\":\"ref\",\"value\":\"TC-${extract.acct}\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P13-EXTRACT-MODES", 2, "P13-JSONPATH", "TAP", "COMMON_HTTP_REQUEST", "P13-INIT",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"deep\":{\"list\":[\"a\",\"b\",\"c\"]}}}}]",
                "[{\"body\":\"$.body.deep.list[2]\",\"OP\":\"EQ\",\"EXPECTED\":[\"c\"]}]",
                "[{\"name\":\"deepVal\",\"from\":\"body\",\"path\":\"$.body.deep.list[0]\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P13-EXTRACT-MODES", 3, "P13-FILE-LINE", "DATAHUB", "COMMON_FILE_ACTIONS", "P13-JSONPATH",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/tc-p13.txt\",\"content\":\"AAA\\nBBB\\nCCC\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"fileLine\",\"from\":\"FILE\",\"path\":\"test-output/tc-p13.txt#L2\"}]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P13-EXTRACT-MODES", 4, "P13-VERIFY-ALL", "TAP", "COMMON_HTTP_REQUEST", "P13-FILE-LINE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"acct\":\"${extract.acct}\",\"ref\":\"${extract.ref}\",\"deep\":\"${extract.deepVal}\",\"line\":\"${extract.fileLine}\"}}}]",
                "[{\"body\":\"$.body.acct\",\"OP\":\"EQ\",\"EXPECTED\":[\"888888\"]},{\"body\":\"$.body.ref\",\"OP\":\"EQ\",\"EXPECTED\":[\"TC-888888\"]},{\"body\":\"$.body.deep\",\"OP\":\"EQ\",\"EXPECTED\":[\"a\"]},{\"body\":\"$.body.line\",\"OP\":\"EQ\",\"EXPECTED\":[\"BBB\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-P14 变量引用 ----
        addStep(stepRows, "TC-P14-VARIABLE-REF", 1, "P14-GLOBAL", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\",\"params\":{\"who\":\"${global.test_user_name}\"}}}]",
                "[{\"body\":\"$.queryParams.who\",\"OP\":\"EQ\",\"EXPECTED\":[\"e2e-user\"]}]", "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-P14-VARIABLE-REF", 2, "P14-ENV", "DATAHUB", "COMMON_WINDOWS_CMD", "P14-GLOBAL",
                "[{\"WINDOWS-CMD\":{\"cmd\":[\"echo env-probe-done\"]}}]",
                "[{\"STDOUT\":\"\",\"OP\":\"CONTAINS\",\"EXPECTED\":[\"env-probe-done\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-N01 断言操作符反向（预期 PASS）----
        addStep(stepRows, "TC-N01-ASSERT-NEGATIVE", 1, "N01-NOT-CONTAINS", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"\",\"OP\":\"NOT_CONTAINS\",\"EXPECTED\":[\"这个关键词绝不存在\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N01-ASSERT-NEGATIVE", 2, "N01-NE", "TAP", "COMMON_HTTP_REQUEST", "N01-NOT-CONTAINS",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"$.stub\",\"OP\":\"NE\",\"EXPECTED\":[\"false\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N01-ASSERT-NEGATIVE", 3, "N01-EMPTY-PATH", "TAP", "COMMON_HTTP_REQUEST", "N01-NE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"$.this.field.does.not.exist\",\"OP\":\"EMPTY\",\"EXPECTED\":[]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N01-ASSERT-NEGATIVE", 4, "N01-REGEX", "TAP", "COMMON_HTTP_REQUEST", "N01-EMPTY-PATH",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"$.method\",\"OP\":\"REGEX\",\"EXPECTED\":[\"^GET$\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N01-ASSERT-NEGATIVE", 5, "N01-PERF-BOUND", "TAP", "COMMON_HTTP_REQUEST", "N01-REGEX",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"responseTimeMs\":\"\",\"OP\":\"LTE\",\"EXPECTED\":[\"5000\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-N02 边界值与特殊字符 ----
        addStep(stepRows, "TC-N02-EDGE-VALUES", 1, "N02-UNICODE", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"name\":\"中文测试·αβγ\",\"emoji\":\"🚀\"}}}]",
                "[{\"body\":\"$.body.name\",\"OP\":\"EQ\",\"EXPECTED\":[\"中文测试·αβγ\"]},{\"body\":\"$.body.emoji\",\"OP\":\"EQ\",\"EXPECTED\":[\"🚀\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N02-EDGE-VALUES", 2, "N02-ESCAPES", "TAP", "COMMON_HTTP_REQUEST", "N02-UNICODE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"quoted\":\"say \\\"hello\\\"\",\"path\":\"C:\\\\dev\\\\tmp\"}}}]",
                "[{\"body\":\"$.body.quoted\",\"OP\":\"EQ\",\"EXPECTED\":[\"say \\\"hello\\\"\"]},{\"body\":\"$.body.path\",\"OP\":\"EQ\",\"EXPECTED\":[\"C:\\\\dev\\\\tmp\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N02-EDGE-VALUES", 3, "N02-DEEP-ARRAY", "TAP", "COMMON_HTTP_REQUEST", "N02-ESCAPES",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"matrix\":[[1,2],[3,4],[5,6]]}}}]",
                "[{\"body\":\"$.body.matrix[2][1]\",\"OP\":\"EQ\",\"EXPECTED\":[\"6\"]},{\"body\":\"$.body.matrix[0][0]\",\"OP\":\"EQ\",\"EXPECTED\":[\"1\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-N03 FILE 反向 ----
        addStep(stepRows, "TC-N03-FILE-NEGATIVE", 1, "N03-EXISTS-FALSE", "DNS", "COMMON_DB_ASSERTIONS", "[]",
                "[]",
                "[{\"FILE\":\"test-output/tc-n03-not-exist.txt\",\"FIELD\":\"exists\",\"OP\":\"EQ\",\"EXPECTED\":[\"false\"]}]",
                "[]", 15, 0, "STOP", "Y");
        addStep(stepRows, "TC-N03-FILE-NEGATIVE", 2, "N03-PATTERN-EMPTY", "DATAHUB", "COMMON_FILE_ACTIONS", "N03-EXISTS-FALSE",
                "[{\"FILE\":{\"op\":\"listPattern\",\"path\":\"test-output\",\"pattern\":\"tc-n03-nothing-.*\\\\.xyz\"}}]",
                "[{\"matched\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"0\"]}]",
                "[]", 15, 0, "STOP", "Y");

        // ---- TC-R01 非法 INPUT（预期 FAILED + 哨兵）----
        addStep(stepRows, "TC-R01-INVALID-INPUT", 1, "R01-NO-PAYLOAD", "DATAHUB", "COMMON_FTP_ACTIONS", "[]",
                "[]", "[]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R01-INVALID-INPUT", 2, "R01-BAD-OP", "DATAHUB", "COMMON_FTP_ACTIONS", "R01-NO-PAYLOAD",
                "[{\"FTP\":{\"op\":\"flyToTheMoon\",\"remote\":\"/x\"}}]", "[]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R01-INVALID-INPUT", 3, "R01-MISSING-FIELD", "DATAHUB", "COMMON_FTP_ACTIONS", "R01-BAD-OP",
                "[{\"FTP\":{\"op\":\"upload\",\"local\":\"only-local.txt\"}}]", "[]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R01-INVALID-INPUT", 4, "R01-REDIS-NO-KEY", "DATAHUB", "COMMON_REDIS_OPERATE", "R01-MISSING-FIELD",
                "[{\"REDIS\":{\"op\":\"get\"}}]", "[]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R01-INVALID-INPUT", 5, "R01-SENTINEL", "TAP", "COMMON_HTTP_REQUEST", "R01-REDIS-NO-KEY",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-R02 EXTRACT 失败（预期 FAILED + 哨兵）----
        addStep(stepRows, "TC-R02-EXTRACT-FAILURES", 1, "R02-SRC-NOT-EXIST", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"badVar\",\"from\":\"THIS_KEY_NOT_EXIST\",\"path\":\"x\"}]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R02-EXTRACT-FAILURES", 2, "R02-REGEX-NO-MATCH", "TAP", "COMMON_HTTP_REQUEST", "R02-SRC-NOT-EXIST",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"noMatch\",\"from\":\"body\",\"path\":\"regex:ZZZ_NEVER_MATCH_ZZZ\"}]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R02-EXTRACT-FAILURES", 3, "R02-FILE-NOT-EXIST", "TAP", "COMMON_HTTP_REQUEST", "R02-REGEX-NO-MATCH",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]",
                "[{\"name\":\"noFile\",\"from\":\"FILE\",\"path\":\"test-output/tc-r02-no-such-file.txt\"}]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R02-EXTRACT-FAILURES", 4, "R02-LINE-OOB", "DATAHUB", "COMMON_FILE_ACTIONS", "R02-FILE-NOT-EXIST",
                "[{\"FILE\":{\"op\":\"write\",\"path\":\"test-output/tc-r02.txt\",\"content\":\"only-one-line\"}}]",
                "[{\"bytes\":\"\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[{\"name\":\"oob\",\"from\":\"FILE\",\"path\":\"test-output/tc-r02.txt#L99\"}]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R02-EXTRACT-FAILURES", 5, "R02-SENTINEL", "TAP", "COMMON_HTTP_REQUEST", "R02-LINE-OOB",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-R03 断言失败（预期 FAILED + 哨兵）----
        addStep(stepRows, "TC-R03-ASSERT-FAILURES", 1, "R03-EQ-MISMATCH", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"$.stub\",\"OP\":\"EQ\",\"EXPECTED\":[\"false\"]}]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R03-ASSERT-FAILURES", 2, "R03-MAP-MISMATCH", "DNS", "COMMON_DB_ASSERTIONS", "R03-EQ-MISMATCH",
                "[]",
                "[{\"DB\":\"SELECT id,name FROM tc_r03_table\",\"OP\":\"EQ\",\"EXPECTED\":[{\"id\":\"999\",\"name\":\"不存在行\"}]}]",
                "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R03-ASSERT-FAILURES", 3, "R03-NOTCONTAINS-VIOLATE", "TAP", "COMMON_HTTP_REQUEST", "R03-MAP-MISMATCH",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"body\":\"\",\"OP\":\"NOT_CONTAINS\",\"EXPECTED\":[\"stub\"]}]", "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R03-ASSERT-FAILURES", 4, "R03-SENTINEL", "TAP", "COMMON_HTTP_REQUEST", "R03-NOTCONTAINS-VIOLATE",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-R04 未知变量引用（观察行为 + 哨兵）----
        addStep(stepRows, "TC-R04-UNDEFINED-VARS", 1, "R04-UNDEF-IN-INPUT", "TAP", "COMMON_HTTP_REQUEST", "[]",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"POST\",\"body\":{\"ghost\":\"${extract.ghost_variable_never_set}\"}}}]",
                "[{\"body\":\"$.body.ghost\",\"OP\":\"NOT_EMPTY\",\"EXPECTED\":[]}]",
                "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R04-UNDEFINED-VARS", 2, "R04-SENTINEL", "TAP", "COMMON_HTTP_REQUEST", "R04-UNDEF-IN-INPUT",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");

        // ---- TC-R05 WAIT_UNTIL 超时（预期 FAILED + 哨兵）----
        addStep(stepRows, "TC-R05-WAIT-UNTIL-TIMEOUT", 1, "R05-WAIT-NEVER", "SMARTS", "COMMON_DB_ASSERTIONS", "[]",
                "[]",
                "[{\"DB\":\"SELECT 'pending' AS s\",\"OP\":\"WAIT_UNTIL\",\"EXPECTED\":[\"NEVER_VALUE\"],\"TIMEOUT\":2,\"POLL_INTERVAL\":500}]",
                "[]", 15, 0, "CONTINUE", "Y");
        addStep(stepRows, "TC-R05-WAIT-UNTIL-TIMEOUT", 2, "R05-SENTINEL", "TAP", "COMMON_HTTP_REQUEST", "R05-WAIT-NEVER",
                "[{\"HTTP\":{\"url\":\"${global.http_base_url}\",\"method\":\"GET\"}}]",
                "[{\"HTTP\":\"\",\"OP\":\"EQ\",\"EXPECTED\":[\"200\"]}]", "[]", 15, 0, "STOP", "Y");

        // ================= 写 Sheet =================
        List<String> scenarioHeader = List.of(
                "Seq", "Scenario_ID", "Scenario_Name", "Enabled", "Tags", "Env", "Timeout", "Description", "Owner");
        WriteSheet sheet1 = com.alibaba.excel.EasyExcel.writerSheet(0, "Scenarios")
                .head(toHead(scenarioHeader)).build();
        writer.write(scenarioRows, sheet1);

        List<String> stepHeader = List.of(
                "Scenario_ID", "SEQ_NO", "STEP_ID", "APP", "ACTION", "DEPENDS_ON",
                "INPUT", "ASSERT", "EXTRACT", "TIMEOUT", "RETRY", "ON_FAILURE", "ENABLED");
        WriteSheet sheet2 = com.alibaba.excel.EasyExcel.writerSheet(1, "Steps")
                .head(toHead(stepHeader)).build();
        writer.write(stepRows, sheet2);

        List<List<Object>> configRows = new ArrayList<>();
        Map<String, String> globalConfig = new LinkedHashMap<>();
        globalConfig.put("http_base_url", "http://www.baidu.com");
        globalConfig.put("test_user_name", "e2e-user");
        globalConfig.put("ssh_host", "127.0.0.1");
        globalConfig.put("ssh_user", "e2e");
        globalConfig.put("ssh_password", "e2e-password");
        globalConfig.forEach((k, v) -> configRows.add(List.of(k, v)));

        WriteSheet sheet3 = com.alibaba.excel.EasyExcel.writerSheet(2, "_GlobalConfig").build();
        writer.write(configRows, sheet3);

        writer.finish();
        System.out.println("[TestCaseExamplesGenerator] 已生成: " + output.toAbsolutePath()
                + " (" + scenarioRows.size() + " scenarios / " + stepRows.size() + " steps / " + configRows.size() + " globals)");
    }

    // ---- helpers ----

    private static List<Object> row(Object... values) {
        return Arrays.asList(values);
    }

    private static void addStep(List<List<Object>> rows, String scenarioId, int seqNo, String stepId,
                                String app, String action, String dependsOn, String input, String assertJson,
                                String extract, int timeout, int retry, String onFailure, String enabled) {
        rows.add(List.of(scenarioId, seqNo, stepId, app, action, dependsOn,
                input, assertJson, extract, timeout, retry, onFailure, enabled));
    }

    private static List<List<String>> toHead(List<String> headers) {
        List<List<String>> head = new ArrayList<>();
        for (String h : headers) {
            head.add(List.of(h));
        }
        return head;
    }
}
