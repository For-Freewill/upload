# 断言引擎使用指南（DB / FILE / STDOUT / Map 模式 / FIELD 模式）

## 1. 断言模式总览

| 模式 | 触发条件 | 适用场景 |
|---|---|---|
| 字符串模式 | EXPECTED 为字符串数组 `["200","OK"]` | 单列值断言 |
| Map 模式 | EXPECTED 为 JSON 对象数组 `[{"id":"1","name":"test"}]` | 多列多行批量验证 |
| FIELD 模式 | 指定 `FIELD` 属性 | DB 指定列 / FILE 文件字段提取 |

## 2. DB 断言（字符串模式）

### 2.1 单列 EQ
```json
[{"DB":"SELECT status FROM orders WHERE id=1","OP":"EQ","EXPECTED":["SHIPPED"]}]
```

### 2.2 结果包含
```json
[{"DB":"SELECT name FROM users","OP":"CONTAINS","EXPECTED":["alice","bob"]}]
```

### 2.3 结果不包含
```json
[{"DB":"SELECT error FROM logs","OP":"NOT_CONTAINS","EXPECTED":["FATAL"]}]
```

### 2.4 行数断言
```json
[{"DB":"SELECT * FROM orders","OP":"SIZE","EXPECTED":["3"]}]
```

### 2.5 异步轮询（WAIT_UNTIL）
```json
[{"DB":"SELECT status FROM orders WHERE id=1","OP":"WAIT_UNTIL","EXPECTED":["COMPLETED"],"TIMEOUT":30,"POLL_INTERVAL":2000}]
```
> 在 30 秒内每 2 秒查询一次，直到断言通过或超时。适合 MQ 异步消费 / DB 最终一致性。

## 3. DB 断言（FIELD 模式）— 多列查询指定列

### 3.1 提取指定列
```json
[{"DB":"SELECT id, name, status FROM orders WHERE id=1","FIELD":"name","OP":"EQ","EXPECTED":["order-001"]}]
```
> 从 3 列结果中提取 `name` 列的值进行断言

### 3.2 整行 JSON（FIELD=*）
```json
[{"DB":"SELECT id, name FROM orders WHERE id=1","FIELD":"*","OP":"CONTAINS","EXPECTED":["order-001"]}]
```
> 每行序列化为 JSON，对 JSON 字符串做 CONTAINS

## 4. DB 断言（Map 模式）— 多列多行批量验证 ⭐

### 4.1 Map EQ（行集合完全匹配）
```json
[{"DB":"SELECT id, name, status FROM orders WHERE id IN (1,2)",
  "OP":"EQ",
  "EXPECTED":[
    {"id":"1","name":"order-001","status":"CREATED"},
    {"id":"2","name":"order-002","status":"SHIPPED"}
  ]}]
```
> 实际行集合 == 期望行集合（忽略行序，每行所有字段完全匹配，列名大小写不敏感）

### 4.2 Map CONTAINS（子集匹配）
```json
[{"DB":"SELECT id, name, status FROM orders WHERE id=1",
  "OP":"CONTAINS",
  "EXPECTED":[{"id":"1","name":"order-001"}]}]
```
> 期望行是某个实际行的子集（只断言关心的字段）

### 4.3 Map NOT_CONTAINS
```json
[{"DB":"SELECT * FROM error_logs",
  "OP":"NOT_CONTAINS",
  "EXPECTED":[{"level":"FATAL"}]}]
```

### 4.4 Map EXISTS（至少一行匹配）
```json
[{"DB":"SELECT * FROM users",
  "OP":"EXISTS",
  "EXPECTED":[{"role":"admin","status":"active"}]}]
```

## 5. FILE 断言

### 5.1 内容包含
```json
[{"FILE":"test-output/app.log","FIELD":"content","OP":"CONTAINS","EXPECTED":["Started successfully"]}]
```

### 5.2 行数断言
```json
[{"FILE":"test-output/data.csv","FIELD":"lineCount","OP":"EQ","EXPECTED":["100"]}]
```

### 5.3 文件存在
```json
[{"FILE":"test-output/report.pdf","FIELD":"exists","OP":"EQ","EXPECTED":["true"]}]
```

### 5.4 文件大小
```json
[{"FILE":"test-output/backup.zip","FIELD":"size","OP":"GT","EXPECTED":["1048576"]}]
```

## 6. 命令输出断言（STDOUT / STDERR / CMD）

### 6.1 输出包含
```json
[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["build success"]}]
```

### 6.2 无错误输出
```json
[{"STDERR":"","OP":"NOT_CONTAINS","EXPECTED":["error","fail"]}]
```

### 6.3 退出码
```json
[{"CMD":"","OP":"EQ","EXPECTED":["0"]}]
```

### 6.4 命令数量
```json
[{"commandCount":"","OP":"EQ","EXPECTED":["3"]}]
```

## 7. HTTP 输出断言

### 7.1 状态码
```json
[{"HTTP":"status","OP":"EQ","EXPECTED":["200"]}]
```

### 7.2 响应体包含
```json
[{"HTTP":"body","OP":"CONTAINS","EXPECTED":["success"]}]
```

## 8. JAVA 反射输出断言

```json
// COMMON_JAVA_INVOKE 的方法返回值
[{"result":"","OP":"EQ","EXPECTED":["expected-value"]}]
```

## 9. 操作符速查表

| 操作符 | 语义 | 示例 |
|---|---|---|
| `EQ` | 实际集合 == 期望集合（忽略顺序） | `["1","2"]` |
| `NE` | 不相等 | `["error"]` |
| `CONTAINS` | 每个期望值都存在于实际中 | `["hello","world"]` |
| `NOT_CONTAINS` | 没有期望值出现在实际中 | `["error"]` |
| `EMPTY` | 实际为空 | - |
| `NOT_EMPTY` | 实际非空 | - |
| `SIZE` | 行数/元素数等于 | `["3"]` |
| `GT/GTE/LT/LTE` | 行数/元素数比较 | `["2"]` |
| `REGEX` | 正则匹配 | `["\\d{4}-\\d{2}-\\d{2}"]` |
| `EXISTS` | 至少存在一个值 | - |
| `WAIT_UNTIL` | 异步轮询直到通过 | 配合 `TIMEOUT` + `POLL_INTERVAL` |

## 10. 支持的断言 source

| source | 数据来源 |
|---|---|
| `DB` | 规则自带 SQL 直接查询（FIELD 列选择 / Map 模式） |
| `FILE` | 文件内容/行数/大小/存在性 |
| `HTTP` | HTTP 响应（target `$.` 走 JSONPath、`//` 走 XPath 自动路由） |
| `STDOUT` / `STDERR` / `CMD` | 命令执行输出 |
| `result` / `status` / `body` | COMMON_JAVA_INVOKE / Action outputs |
| `commandCount` / `lines` | 命令数量 / 按行输出 |
| `JSONPATH` | 显式 JSONPath（FROM 输出变量 / FILE 文件） |
| `XPATH` / `XML` | 显式 XPath（FROM 输出变量 / FILE 文件） |
| `docCount` / `firstDoc` | MongoDB 断言输出 |
| `equal` / `diffCount` | DataCompare 输出 |

### 路径断言速查

| 写法 | 模式 | 说明 |
|---|---|---|
| `{"body":"$.a.b","OP":"EQ"}` | JSONPath 自动路由 | target `$.` 前缀 |
| `{"HTTP":"//Node","OP":"EQ"}` | XPath 自动路由 | target `//` 或 `/` 前缀 |
| `{"JSONPATH":"$.a.b","FROM":"body"}` | JSONPath 显式 | FROM 指定输出变量 |
| `{"JSONPATH":"$.a.b","FILE":"xx.json"}` | JSONPath 显式 | FILE 读取 JSON 文件 |
| `{"XML":"//Node","FILE":"xx.xml"}` | XPath 显式 | XML=XPATH 别名，FILE 读 XML 文件 |
