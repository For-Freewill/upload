# HTTP 请求使用指南（COMMON_HTTP_REQUEST）

> Action: `TAP:COMMON_HTTP_REQUEST` / `STP:COMMON_HTTP_REQUEST` | 协议键: `HTTP` | 实现: REST Assured

## 1. 前置环境配置

### 1.1 运行环境
| 项目 | 要求 |
|---|---|
| 网络可达 | live 模式需能访问目标 URL（防火墙/代理放行） |
| 依赖 | 框架内置（rest-assured），无需额外安装 |

### 1.2 无需额外配置
HTTP Action 无全局必填配置；认证信息在 INPUT 中按请求指定（或先跑 COMMON_OAUTH2_TOKEN 拿 token）。

### 1.3 demo / live 行为差异
| 模式 | 行为 |
|---|---|
| demo | StubHttpApiClient：返回 200 + 回显 JSON（含 stub/method/url/echoBody），不断网可跑 |
| live | RestAssured 真实请求，返回真实状态码/响应体/响应头/耗时 |

> demo 回显体示例：`{"stub":true,"method":"POST","url":"...","echoBody":{...}}` — 可用 JSONPath 断言 `$.stub`。

## 2. INPUT 格式

```json
[{"HTTP":{
  "url":"http://api.example.com/v1/orders",
  "method":"POST",
  "params":{"source":"mobile"},
  "headers":{"Accept":"application/json"},
  "body":{"orderId":"ORD-001","items":[{"sku":"A001","qty":2}]},
  "auth":{"type":"bearer","token":"eyJhbGci..."}
}}]
```

## 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `url` | String | 是 | 目标 URL（支持 `${global.}`/`${extract.}` 变量） |
| `method` | String | 否 | `GET`（默认）/ `POST` / `PUT` / `PATCH` / `DELETE` / `HEAD` / `OPTIONS` |
| `params` | Object | 否 | URL query 参数（别名 `queryParams`） |
| `headers` | Object | 否 | 请求头 |
| `body` | Object/String | 否 | Object→JSON body；String→raw body |
| `formParams` | Object | 否 | 表单参数（application/x-www-form-urlencoded） |
| `contentType` | String | 否 | 覆盖 Content-Type（如 `text/plain`、`application/xml`） |
| `auth` | Object | 否 | `{"type":"bearer","token":"..."}` 或 `{"type":"basic","username":"...","password":"..."}` |

## 4. 输出（outputs）枚举

| key | 类型 | 说明 |
|---|---|---|
| `status` / `HTTP` | int | HTTP 状态码 |
| `body` / `HTTP_BODY` | String | 响应体 |
| `headers` / `HTTP_HEADERS` | Map | 响应头 |
| `responseTimeMs` | long | 响应耗时（毫秒） |

## 5. 断言示例

```json
// 状态码
[{"HTTP":"status","OP":"EQ","EXPECTED":["200"]}]

// 响应体包含
[{"HTTP":"body","OP":"CONTAINS","EXPECTED":["success"]}]

// JSONPath 深度路径（$. 自动路由）
[{"body":"$.data.orderId","OP":"EQ","EXPECTED":["ORD-001"]}]
[{"body":"$.items[0].sku","OP":"EQ","EXPECTED":["A001"]}]

// 性能断言（响应时间）
[{"responseTimeMs":"","OP":"LTE","EXPECTED":["2000"]}]

// 响应头
[{"headers":"","OP":"CONTAINS","EXPECTED":["application/json"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"orderId","from":"body","path":"data.orderId"}]
[{"name":"httpStatus","from":"HTTP","path":""}]
```
后续步骤引用：`${extract.orderId}`

## 7. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-HTTP-DEMO | 1 | HTTP-GET | TAP | COMMON_HTTP_REQUEST | [] | `[{"HTTP":{"url":"${global.http_base_url}","method":"GET","params":{"wd":"e2e"}}}]` | `[{"HTTP":"","OP":"EQ","EXPECTED":["200"]}]` | `[]` | 30 | 1 | STOP | Y |
| E2E-HTTP-DEMO | 2 | HTTP-POST | TAP | COMMON_HTTP_REQUEST | HTTP-GET | `[{"HTTP":{"url":"${global.http_base_url}/api","method":"POST","body":{"bizId":"${global.flow_biz_id}"}}}]` | `[{"HTTP":"","OP":"EQ","EXPECTED":["200"]},{"body":"","OP":"NOT_EMPTY","EXPECTED":[]}]` | `[{"name":"respBody","from":"body","path":""}]` | 30 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: JSONPath 断言怎么写？**
A: source 用输出键（如 `body`），target 写 `$.` 开头的路径：`{"body":"$.data.status","OP":"EQ","EXPECTED":["OK"]}`。详见 assertions-guide.md。

**Q2: POST JSON body 中文乱码？**
A: 框架按 UTF-8 处理；若服务端要求其他编码，用 `contentType` 显式指定并加 charset。

**Q3: 需要 token 的接口怎么串联？**
A: 先跑 `COMMON_OAUTH2_TOKEN`（自动写入 `${extract.oauthToken}`），再在 HTTP 步骤用 `"auth":{"type":"bearer","token":"${extract.oauthToken}"}`。

**Q4: demo 模式断言什么？**
A: 断言 `$.stub`（true）、`$.method`、`$.echoBody.xxx`（回显请求体），或直接断言 200。

**Q5: 重试怎么配？**
A: `RETRY` 列填次数（偶发失败重试），或 `OP:WAIT_UNTIL` 轮询类断言（配合 TIMEOUT/POLL_INTERVAL）。
