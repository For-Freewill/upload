# FILE 文件操作使用指南

> Action: `DATAHUB:COMMON_FILE_ACTIONS`
> 断言: `{"FILE":"路径","FIELD":"字段","OP":"操作符","EXPECTED":[...]}`

## 1. 路径规则

| 路径类型 | 示例 | 解析结果 |
|---|---|---|
| 相对路径 | `test-output/test.txt` | 基于工程根目录（user.dir）解析 |
| 绝对路径 | `C:/Users/xxx/test.txt` | 原样使用 |
| 绝对路径（Linux） | `/usr/local/test.txt` | 原样使用 |

## 2. 文件操作（INPUT 列）

### 2.1 创建文件
```json
[{"FILE":{"op":"create","path":"test-output/examples/demo.txt"}}]
```
outputs: `exists=true, path=绝对路径, resolvedPath=解析后路径`

### 2.2 写入文件（覆盖）
```json
[{"FILE":{"op":"write","path":"test-output/examples/demo.txt","content":"第一行内容\n第二行内容"}}]
```
outputs: `path, bytes=字节数`

### 2.3 追加内容
```json
[{"FILE":{"op":"append","path":"test-output/examples/demo.txt","content":"\n第三行：追加的内容"}}]
```
outputs: `path, appendedBytes=追加字节数`

### 2.4 读取文件
```json
[{"FILE":{"op":"read","path":"test-output/examples/demo.txt"}}]
```
outputs: `content=全文, lines=行列表, lineCount=行数, size=字节数`

### 2.5 删除文件
```json
[{"FILE":{"op":"delete","path":"test-output/examples/demo.txt"}}]
```
outputs: `deleted=true/false`

### 2.6 检查文件存在
```json
[{"FILE":{"op":"exists","path":"test-output/examples/demo.txt"}}]
```
outputs: `exists=true/false`

### 2.7 正则批量删除
```json
[{"FILE":{"op":"deletePattern","path":"test-output","pattern":"e2e-.*\\.txt"}}]
```
outputs: `matched=匹配数, deleted=删除数, deletedFiles=删除的文件名列表`

### 2.8 正则批量删除（递归子目录）
```json
[{"FILE":{"op":"deletePattern","path":"test-output","pattern":".*\\.log","recursive":"true"}}]
```

### 2.9 正则列出匹配文件
```json
[{"FILE":{"op":"listPattern","path":"test-output","pattern":"e2e-.*\\.txt"}}]
```
outputs: `matched=匹配数, files=文件名列表`

## 3. FILE 断言（ASSERT 列）

### 3.1 文件内容包含（CONTAINS）
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"content","OP":"CONTAINS","EXPECTED":["第一行内容","追加的内容"]}]
```
> 期望的每个关键词都必须出现在文件某一行中

### 3.2 文件内容不包含（NOT_CONTAINS）
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"content","OP":"NOT_CONTAINS","EXPECTED":["error","exception"]}]
```

### 3.3 文件行数断言（lineCount）
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"lineCount","OP":"EQ","EXPECTED":["3"]}]
```

### 3.4 文件行数大于
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"lineCount","OP":"GT","EXPECTED":["2"]}]
```

### 3.5 文件存在断言
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"exists","OP":"EQ","EXPECTED":["true"]}]
```

### 3.6 文件大小断言
```json
[{"FILE":"test-output/examples/demo.txt","FIELD":"size","OP":"GT","EXPECTED":["100"]}]
```

## 4. FILE 断言字段说明

| FIELD 值 | 返回值 | 支持的操作符 |
|---|---|---|
| `content`（默认） | 文件的每一行作为一个实际值 | CONTAINS / NOT_CONTAINS / EQ / REGEX |
| `lineCount` | 行数（单个值） | EQ / NE / GT / GTE / LT / LTE |
| `exists` | "true" 或 "false" | EQ / NE |
| `size` | 字节数（单个值） | EQ / GT / GTE / LT / LTE |

## 5. 完整步骤示例（Excel Steps 表行）

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-FILE-DEMO | 1 | FILE-WRITE | DATAHUB | COMMON_FILE_ACTIONS | `[{"FILE":{"op":"write","path":"test-output/demo.txt","content":"hello\nworld"}}]` | `[{"bytes":"","OP":"NOT_EMPTY","EXPECTED":[]}]` |
| E2E-FILE-DEMO | 2 | FILE-CHECK | DNS | COMMON_DB_ASSERTIONS | `[]` | `[{"FILE":"test-output/demo.txt","FIELD":"content","OP":"CONTAINS","EXPECTED":["hello"]}]` |
| E2E-FILE-DEMO | 3 | FILE-LINES | DNS | COMMON_DB_ASSERTIONS | `[]` | `[{"FILE":"test-output/demo.txt","FIELD":"lineCount","OP":"EQ","EXPECTED":["2"]}]` |
| E2E-FILE-DEMO | 4 | FILE-DELETE | DATAHUB | COMMON_FILE_ACTIONS | `[{"FILE":{"op":"delete","path":"test-output/demo.txt"}}]` | `[{"deleted":"","OP":"EQ","EXPECTED":["true"]}]` |

## 6. EXTRACT 示例

```json
[{"name":"fileLineCount","from":"lineCount","path":""}]
```
> 提取 read 操作的行数，后续步骤用 `${extract.fileLineCount}` 引用
