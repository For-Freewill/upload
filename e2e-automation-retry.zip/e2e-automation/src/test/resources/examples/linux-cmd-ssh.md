# Linux 命令执行使用指南（COMMON_LINUX_CMD）

> Action: `DATAHUB:COMMON_LINUX_CMD` | 协议键: `LINUX-CMD` | 双模式: 本地 `sh -c` / 远程 SSH（JSch）

## 1. 前置环境配置

### 1.1 模式选择（host 字段路由）

| host 值 | 模式 | 执行方式 | 前置条件 |
|---|---|---|---|
| `local` / `localhost` / 缺省 | 本地 | `sh -c <命令>` | Windows 需 Git Bash（sh 在 PATH） |
| IP / 域名（如 `192.168.1.100`） | 远程 SSH | JSch 连接执行 | 目标服务器开放 SSH + 账号密码 |

### 1.2 application.yml 配置（SSH 全局缺省）
```yaml
e2e:
  ssh:
    user: e2e              # SSH 用户名（INPUT 未指定 user 时使用）
    password: "your-pwd"   # SSH 密码（INPUT 未指定 password 时使用）
    port: 22               # SSH 端口（INPUT 未指定 port 时使用）
```

### 1.3 demo / live 行为差异
| 模式 | 本地 | 远程 SSH |
|---|---|---|
| demo | dry-run（同 WINDOWS-CMD） | StubSshCommandClient 模拟（退出码 0，模拟输出） |
| live | 真实 `sh -c` | JSch 真实连接执行 |

## 2. INPUT 格式

### 2.1 本地模式
```json
[{"LINUX-CMD":{
  "host":"local",
  "base_dir":"/tmp",
  "cmd":["echo hello","ls -la","cat /etc/hostname"]
}}]
```

### 2.2 远程 SSH 模式（完整认证）
```json
[{"LINUX-CMD":{
  "host":"192.168.1.100",
  "port":22,
  "user":"root",
  "password":"secret",
  "base_dir":"/opt/app",
  "cmd":["ls -la","cat config.ini","df -h"]
}}]
```

## 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `host` | String | 否 | `local`（缺省）= 本地；IP/域名 = SSH 远程 |
| `port` | int | 否 | SSH 端口，默认 22（仅远程模式；支持全局配置） |
| `user` | String | 否 | SSH 用户名（别名 `username`；缺省用 `e2e.ssh.user`） |
| `password` | String | 否 | SSH 密码（别名 `pwd`；缺省用 `e2e.ssh.password`） |
| `base_dir` | String | 否 | 工作目录（远程模式自动在命令前加 `cd <base_dir>`） |
| `cmd` | String[]/String | 是 | 命令列表 |

## 4. 输出（outputs）枚举

| key | 类型 | 说明 |
|---|---|---|
| `CMD` | int | 最后一条命令退出码 |
| `STDOUT` | String | 合并标准输出 |
| `STDERR` | String | 合并标准错误 |
| `commandCount` | int | 命令数量 |
| `lastCommand` | String | 最后一条命令 |
| `host` / `port` / `user` | String/int | 实际连接信息（远程模式） |
| `baseDir` | String | 工作目录（设置时） |
| `lines` | List\<String\> | STDOUT 按行分割 |

## 5. 断言示例

```json
// 远程文件内容校验（核心场景）
[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["database=mysql","poolSize=10"]}]

// 远程命令执行成功
[{"CMD":"","OP":"EQ","EXPECTED":["0"]},{"STDOUT":"","OP":"NOT_EMPTY","EXPECTED":[]}]

// 日志无错误
[{"STDOUT":"","OP":"NOT_CONTAINS","EXPECTED":["ERROR","FATAL","Exception"]}]

// XPath 断言（cat XML 文件后）
[{"STDOUT":"//config/env","OP":"EQ","EXPECTED":["production"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"remoteHost","from":"STDOUT","path":""}]
[{"name":"cfgLine","from":"lines","path":"[2]"}]     // 第三行
```

## 7. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-LINUX-DEMO | 1 | LC-LOCAL | DATAHUB | COMMON_LINUX_CMD | [] | `[{"LINUX-CMD":{"host":"local","cmd":["echo local-ok"]}}]` | `[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["local-ok"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-LINUX-DEMO | 2 | LC-SSH | DATAHUB | COMMON_LINUX_CMD | LC-LOCAL | `[{"LINUX-CMD":{"host":"${global.ssh_host}","port":22,"user":"${global.ssh_user}","password":"${global.ssh_password}","cmd":["echo remote-ok","ls /tmp"]}}]` | `[{"STDOUT":"","OP":"NOT_EMPTY","EXPECTED":[]},{"CMD":"","OP":"EQ","EXPECTED":["0"]}]` | `[]` | 30 | 0 | CONTINUE | Y |
| E2E-LINUX-DEMO | 3 | LC-FILE | DATAHUB | COMMON_LINUX_CMD | LC-SSH | `[{"LINUX-CMD":{"host":"${global.ssh_host}","user":"${global.ssh_user}","password":"${global.ssh_password}","cmd":["cat /etc/hostname"]}}]` | `[{"STDOUT":"","OP":"NOT_EMPTY","EXPECTED":[]}]` | `[{"name":"remoteHostname","from":"STDOUT","path":""}]` | 30 | 0 | CONTINUE | Y |

## 8. 常见问题（FAQ）

**Q1: SSH 报 Connection refused？**
A: 目标服务器未开放 SSH 或端口不对。检查 `host`/`port`；本地 127.0.0.1 无 SSH 服务时这是预期失败。

**Q2: 密码里有特殊字符怎么办？**
A: JSON 转义（如 `"` 写成 `\"`）；建议用全局变量 `${global.ssh_password}` 管理。

**Q3: 远程执行多条命令，工作目录怎么保持？**
A: 每条命令独立 SSH exec 通道，`cd` 不跨命令生效。用 `base_dir`（框架自动在最前加 `cd`）或单条内串联。

**Q4: host key 验证失败？**
A: 框架已设置 `StrictHostKeyChecking=no`（测试环境友好），不会出现此问题。

**Q5: 超时参数？**
A: SSH 连接 15s、命令执行 30s（内置）；步骤级用 `TIMEOUT` 列控制。
