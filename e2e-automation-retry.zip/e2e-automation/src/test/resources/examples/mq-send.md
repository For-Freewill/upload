# MQ 消息收发使用指南（COMMON_MQ_SEND / COMMON_MQ_CONSUME）

> Action: `STP:COMMON_MQ_SEND`（发送）/ `STP:COMMON_MQ_CONSUME`（消费）| 协议键: `MQ` | 收发闭环

## 1. 前置环境配置

### 1.1 报文文件（发送必需）
发送报文来自 `file` 字段引用的文件，默认基于 classpath（`src/test/resources/`）：

`src/test/resources/data/e2e/stp/mq/test-001.xml`：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<e2eMessage scenario="E2E-STP-TMS-001" step="STP-SEND-MQ">
  <trade>
    <acctNo>1</acctNo>
    <security>000001</security>
    <side>BUY</side>
    <qty>100</qty>
    <price>10.50</price>
    <currency>CNY</currency>
  </trade>
</e2eMessage>
```

### 1.2 MQ 配置（application.yml）
```yaml
e2e:
  mq:
    host: localhost
    port: 1414
    queue-manager: QM1
    queue: E2E.IN              # 默认队列（MQ 载荷未指定 queue 时使用）
```

### 1.3 demo / live 行为差异
| 模式 | COMMON_MQ_SEND | COMMON_MQ_CONSUME |
|---|---|---|
| demo | StubMqClient：报文存入内存队列 | 从内存队列取回（与 send 形成闭环，完整可测） |
| live | 需实现 MqClient（IBM MQ/RocketMQ 等） | 需覆盖 consume 方法 |

## 2. INPUT 格式

### 2.1 发送（COMMON_MQ_SEND）
```json
// 发送到默认队列（e2e.mq.queue）
[{"MQ":{"file":"data/e2e/stp/mq/test-001.xml"}}]

// 发送到指定队列
[{"MQ":{"file":"data/e2e/stp/mq/test-001.xml","queue":"E2E.TEST.CONSUME"}}]
```

### 2.2 消费（COMMON_MQ_CONSUME）
```json
[{"MQ":{"op":"consume","queue":"E2E.TEST.CONSUME","maxMessages":10,"timeout":5}}]
```

## 3. 参数枚举

### 3.1 COMMON_MQ_SEND

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `file` | String | 是 | 报文文件路径（classpath 相对，支持 `file:` 前缀绝对路径） |
| `queue` | String | 否 | 目标队列（缺省 `e2e.mq.queue`） |

### 3.2 COMMON_MQ_CONSUME

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `op` | String | 是 | 固定 `consume` |
| `queue` | String | 否 | 源队列（缺省 `e2e.mq.queue`） |
| `maxMessages` | int | 否 | 最多消费条数（默认 10） |
| `timeout` | number | 否 | 等待秒数（默认 5；期间轮询到满或超时） |

## 4. 输出（outputs）枚举

| Action | key | 类型 | 说明 |
|---|---|---|---|
| SEND | `MQ` | String | 固定 "SENT" |
| SEND | `file` / `messageBytes` | String/int | 报文引用/字节数 |
| CONSUME | `messages` | List\<String\> | 消费到的报文列表 |
| CONSUME | `messageCount` | int | 消费条数 |
| CONSUME | `firstMessage` / `lastMessage` | String | 首条/末条报文 |
| CONSUME | `queue` | String | 实际队列 |

## 5. 断言示例

```json
// 发送成功
[{"MQ":"","OP":"EQ","EXPECTED":["SENT"]}]

// 消费到消息
[{"messageCount":"","OP":"GTE","EXPECTED":["1"]}]

// 首条报文内容（JSON 报文用 JSONPath）
[{"firstMessage":"$.orderId","OP":"EQ","EXPECTED":["ORD-001"]}]

// XML 报文字段断言（XPath 自动路由）
[{"firstMessage":"//trade/side","OP":"EQ","EXPECTED":["BUY"]}]
[{"firstMessage":"//trade/price","OP":"EQ","EXPECTED":["10.50"]}]

// 报文包含关键字
[{"firstMessage":"","OP":"CONTAINS","EXPECTED":["000001"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"mqPayload","from":"firstMessage","path":""}]
```
后续步骤引用：`${extract.mqPayload}`

## 7. 完整测试案例（发送 → 消费 → 字段校验闭环）

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-MQ-DEMO | 1 | MQ-SEND | STP | COMMON_MQ_SEND | [] | `[{"MQ":{"file":"data/e2e/stp/mq/test-001.xml","queue":"E2E.TEST"}}]` | `[{"MQ":"","OP":"EQ","EXPECTED":["SENT"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-MQ-DEMO | 2 | MQ-CONSUME | STP | COMMON_MQ_CONSUME | MQ-SEND | `[{"MQ":{"op":"consume","queue":"E2E.TEST","maxMessages":1,"timeout":3}}]` | `[{"messageCount":"","OP":"GTE","EXPECTED":["1"]},{"firstMessage":"//trade/side","OP":"EQ","EXPECTED":["BUY"]}]` | `[{"name":"mqPayload","from":"firstMessage","path":""}]` | 15 | 0 | STOP | Y |
| E2E-MQ-DEMO | 3 | MQ-DB-VERIFY | SMARTS | COMMON_DB_ASSERTIONS | MQ-CONSUME | `[]` | `[{"DB":"SELECT status FROM mq_log WHERE id=1","OP":"WAIT_UNTIL","EXPECTED":["OK"],"TIMEOUT":10}]` | `[]` | 15 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: 消费不到消息（messageCount=0）？**
A: 检查：① send 与 consume 的 queue 一致；② timeout 是否太短（demo 内存队列瞬时到达，live 视消费速度调大）；③ live 模式 MqClient 是否实现 consume。

**Q2: XML 报文怎么断言具体字段？**
A: XPath 自动路由：`{"firstMessage":"//trade/side","OP":"EQ","EXPECTED":["BUY"]}`（target 以 `//` 开头即走 XPath）。

**Q3: 异步业务怎么验证消费结果落库？**
A: 消费断言通过后，加 DB 断言步骤用 `OP:WAIT_UNTIL` 轮询（消费方处理可能延迟）。

**Q4: live 接 IBM MQ/RocketMQ？**
A: 实现 MqClient 接口的 send + consume，通过 ProtocolClients 装配或 @ActionSpec 覆盖（见 README 扩展指南）。

**Q5: 报文文件支持 JSON 吗？**
A: 支持——file 指向 .json 文件即可；断言用 JSONPath（`$.field`）而非 XPath。
