# SSH 远程执行与 SFTP 使用指南（COMMON_SSH / COMMON_SFTP_ACTIONS）

> Action: `TAP:COMMON_SSH`（远程命令）/ `DATAHUB:COMMON_SFTP_ACTIONS`（安全文件传输）| 协议键: `SSH` / `SFTP` | 实现: JSch

## 一、SSH 远程命令（COMMON_SSH）

### 1. 前置环境配置

| 项目 | 要求 |
|---|---|
| 目标服务器 | 开放 SSH（默认 22），账号可登录 |
| 认证 | 用户名 + 密码（全局配置，无 INPUT 内联） |
| 依赖 | jsch（框架内置） |

```yaml
e2e:
  ssh:
    user: e2e              # SSH 用户名（COMMON_SSH 使用全局配置）
    password: "your-pwd"
    port: 22
```

> demo 模式走 StubSshCommandClient 模拟；live 真实连接。

### 2. INPUT 格式

```json
// SSH 载荷（标准）
[{"SSH":{"host":"192.168.1.100","cmd":["echo ssh-ok","ls -la /opt/app","cat config.ini"]}}]

// SSH + body 键值对（转换为 KEY=value 命令）
[{"SSH":{"host":"192.168.1.100","body":{"ENV":"alpha2","REGION":"cn-east"}}}]

// HTTP 载荷兼容（取 url 的 host）
[{"HTTP":{"url":"http://alpha2-server:8080/status","cmd":["echo fallback"]}}]
```

### 3. 参数枚举

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `host` / `url` / `server` | String | 是 | 服务器地址（url 自动提取 host） |
| `cmd` | String[] | 否 | 远程命令列表 |
| `body` | Object | 否 | 键值对 → `KEY=value` 命令 |

> 认证使用 `e2e.ssh.*` 全局配置（与 COMMON_LINUX_CMD 的 INPUT 内联认证不同）。

### 4. 输出与断言

| key | 说明 |
|---|---|
| `SSH` | 最终退出码 |
| `STDOUT` / `STDERR` | 合并输出 |
| `lines` | STDOUT 按行 |

```json
[{"STDOUT":"","OP":"NOT_EMPTY","EXPECTED":[]},{"SSH":"","OP":"EQ","EXPECTED":["0"]}]
[{"STDOUT":"","OP":"NOT_CONTAINS","EXPECTED":["FATAL","OutOfMemoryError"]}]
```

### 5. 测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-SSH | 1 | SSH-EXEC | TAP | COMMON_SSH | `[{"SSH":{"host":"${global.ssh_host}","cmd":["cat /etc/hostname","df -h / \| tail -1"]}}]` | `[{"STDOUT":"","OP":"NOT_EMPTY","EXPECTED":[]},{"SSH":"","OP":"EQ","EXPECTED":["0"]}]` |
| E2E-SSH | 2 | SSH-LOG | TAP | COMMON_SSH | `[{"SSH":{"host":"${global.ssh_host}","cmd":["tail -50 /var/log/myapp/error.log"]}}]` | `[{"STDOUT":"","OP":"NOT_CONTAINS","EXPECTED":["FATAL"]}]` |

### 6. COMMON_SSH vs COMMON_LINUX_CMD

| 特性 | COMMON_LINUX_CMD | COMMON_SSH |
|---|---|---|
| 认证参数 | INPUT 内联（user/password/port） | 全局配置（e2e.ssh.*） |
| 本地模式 | 支持（host=local） | 不支持（仅远程） |
| 载荷协议 | LINUX-CMD | SSH（兼容 HTTP） |

---

## 二、SFTP 安全文件传输（COMMON_SFTP_ACTIONS）

### 1. 前置环境配置

| 项目 | 要求 |
|---|---|
| 目标服务器 | 开放 SFTP（SSH 子系统，通常 22 端口） |
| 连接参数优先级 | INPUT 内联 > `e2e.sftp.*` > 复用 `e2e.ssh.*` |

```yaml
e2e:
  sftp:
    host: ""        # 留空复用 e2e.ssh.host 语义（实际取 sftp.host 或回退 ssh 配置）
    port: 22
    user: ""
    password: ""
  ssh:              # sftp 未配置时复用这组
    user: e2e
    password: "your-pwd"
    port: 22
```

### 2. INPUT 格式

```json
// 上传 / 下载（可内联覆盖连接参数）
[{"SFTP":{"op":"upload","local":"test-output/report.pdf","remote":"/upload/report.pdf"}}]
[{"SFTP":{"op":"download","remote":"/data/result.csv","local":"test-output/result.csv"}}]
[{"SFTP":{"op":"upload","host":"192.168.1.100","port":22,"user":"root","password":"xxx",
          "local":"a.txt","remote":"/tmp/a.txt"}}]

// 列目录（pattern 正则过滤）/ 删除 / 建目录 / 存在检查
[{"SFTP":{"op":"list","dir":"/upload","pattern":".*\\.pdf"}}]
[{"SFTP":{"op":"delete","remote":"/upload/old.pdf"}}]
[{"SFTP":{"op":"mkdir","dir":"/upload/e2e"}}]
[{"SFTP":{"op":"exists","remote":"/upload/report.pdf"}}]
```

### 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `op` | String | 是 | `upload` / `download` / `list` / `delete` / `mkdir` / `exists` |
| `local` | String | upload/download | 本地路径（相对=工程根目录） |
| `remote` | String | upload/download/delete/exists | 远程路径（绝对路径） |
| `dir` | String | list/mkdir | 远程目录 |
| `pattern` | String | list 可选 | 文件名正则过滤 |
| `host`/`port`/`user`/`password` | - | 可选 | 内联连接参数（优先级最高） |

### 4. 输出与断言

| key | 出现的 op | 说明 |
|---|---|---|
| `success` | upload/download/delete/mkdir | 操作是否成功 |
| `files` / `fileCount` | list | 文件列表（name/size/type）/ 数量 |
| `exists` | exists | 文件是否存在 |
| `message` | 全部 | 结果消息 |

```json
[{"success":"","OP":"EQ","EXPECTED":["true"]}]
[{"fileCount":"","OP":"GTE","EXPECTED":["1"]}]
[{"exists":"","OP":"EQ","EXPECTED":["true"]}]
```

### 5. 测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-SFTP | 1 | SF-MKDIR | DATAHUB | COMMON_SFTP_ACTIONS | `[{"SFTP":{"op":"mkdir","dir":"/upload/e2e-evidence"}}]` | `[{"success":"","OP":"EQ","EXPECTED":["true"]}]` |
| E2E-SFTP | 2 | SF-UPLOAD | DATAHUB | COMMON_SFTP_ACTIONS | `[{"SFTP":{"op":"upload","local":"test-output/test_report.html","remote":"/upload/e2e-evidence/report.html"}}]` | `[{"success":"","OP":"EQ","EXPECTED":["true"]}]` |
| E2E-SFTP | 3 | SF-LIST | DATAHUB | COMMON_SFTP_ACTIONS | `[{"SFTP":{"op":"list","dir":"/upload/e2e-evidence"}}]` | `[{"fileCount":"","OP":"GTE","EXPECTED":["1"]}]` |

### 6. FAQ

**Q: SFTP 和 FTP 选哪个？**
A: 优先 SFTP（加密、走 22 端口、通常防火墙已放行）；FTP 用 COMMON_FTP_ACTIONS（见 ftp-mail.md）。

**Q: 远程路径必须绝对路径吗？**
A: 是（`/upload/xxx`）；相对路径相对于登录用户的 home 目录，行为因服务器而异。

**Q: 上传大文件超时？**
A: JSch 连接 15s 内置；步骤 TIMEOUT 列调大（如 300 秒）。

**Q: 连接失败会怎样？**
A: 优雅返回 `success=false` + 明确错误消息（不抛异常），断言 `success EQ true` 会失败并展示原因。
