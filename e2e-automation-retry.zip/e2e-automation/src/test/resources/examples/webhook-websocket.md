# Webhook 通知与 WebSocket 使用指南（COMMON_WEBHOOK_NOTIFY / COMMON_WEBSOCKET_CLIENT）

> Action: `DATAHUB:COMMON_WEBHOOK_NOTIFY`（IM 通知）/ `DATAHUB:COMMON_WEBSOCKET_CLIENT`（长连接）| 协议键: `WEBHOOK` / `WS`

## 一、Webhook 通知（COMMON_WEBHOOK_NOTIFY）

### 1. 前置环境配置

| 渠道 | 前置条件 | 配置位置 |
|---|---|---|
| 钉钉 | 群机器人 Webhook 地址 | `e2e.webhook.dingtalk-url` |
| 企业微信 | 群机器人 Webhook 地址 | `e2e.webhook.wecom-url` |
| 飞书 | 群机器人 Webhook 地址 | `e2e.webhook.feishu-url` |
| 自定义 | 任意 HTTP POST 端点 | INPUT 中 `url` 字段（免配置） |

```yaml
e2e:
  webhook:
    dingtalk-url: "https://oapi.dingtalk.com/robot/send?access_token=xxx"
    wecom-url: "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx"
    feishu-url: "https://open.feishu.cn/open-apis/bot/v2/hook/xxx"
```

> demo 模式走 HTTP 桩（返回 200，不真实发送）；live 模式真实 POST。

### 2. INPUT 格式

```json
// 钉钉文本
[{"WEBHOOK":{"channel":"dingtalk","text":"E2E 测试完成，全部通过"}}]

// 企业微信（@ 手机号）
[{"WEBHOOK":{"channel":"wecom","text":"构建失败","mentioned":["13800000000"]}}]

// 飞书（标题 + 正文）
[{"WEBHOOK":{"channel":"feishu","title":"测试报告","text":"通过率 100%"}}]

// 自定义 URL（任意 JSON 体透传）
[{"WEBHOOK":{"url":"https://hooks.example.com/xxx","body":{"event":"e2e-done","score":100}}}]
```

### 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `channel` | String | 与 url 二选一 | `dingtalk`（别名 `dingding`/`dd`）/ `wecom`（别名 `wxwork`）/ `feishu`（别名 `lark`） |
| `url` | String | 与 channel 二选一 | 自定义 webhook 地址（优先级最高） |
| `text` | String | 是 | 通知正文（别名 `content`） |
| `title` | String | 飞书可选 | 消息标题 |
| `mentioned` | String[] | 可选 | @ 的手机号列表（钉钉 atMobiles / 企微 mentioned_mobile_list） |
| `body` | Object | 自定义模式 | 任意 JSON 体直接透传 |

### 4. 输出与断言

| key | 说明 |
|---|---|
| `status` | HTTP 状态码 |
| `responseBody` | 响应体 |
| `channel` / `url` | 实际渠道/地址 |

```json
[{"status":"","OP":"EQ","EXPECTED":["200"]}]
```

### 5. 测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-NOTIFY | 1 | WH-DD | DATAHUB | COMMON_WEBHOOK_NOTIFY | `[{"WEBHOOK":{"channel":"dingtalk","text":"E2E 完成"}}]` | `[{"status":"","OP":"EQ","EXPECTED":["200"]}]` |
| E2E-NOTIFY | 2 | WH-CUSTOM | DATAHUB | COMMON_WEBHOOK_NOTIFY | `[{"WEBHOOK":{"url":"https://hooks.example.com/e2e","body":{"event":"done"}}}]` | `[{"status":"","OP":"EQ","EXPECTED":["200"]}]` |

### 6. FAQ

**Q: 机器人地址哪里拿？**
A: 群设置 → 添加机器人 → 复制 Webhook 地址到 application.yml（钉钉/企微/飞书路径不同，见各平台文档）。

**Q: markdown 消息支持吗？**
A: 当前文本类型；markdown 用自定义 `url` + `body` 自己拼各平台的 msgtype 结构。

---

## 二、WebSocket 客户端（COMMON_WEBSOCKET_CLIENT）

### 1. 前置环境配置

| 项目 | demo 模式 | live 模式 |
|---|---|---|
| WS 服务端 | ❌ 不需要（回显模拟） | ✅ 需要 ws/wss 端点 |
| 依赖 | 框架内置 | JDK 11+ 内置 HttpClient |

### 2. INPUT 格式

```json
// 发送消息 + 等待响应（timeout 秒内收到的全部消息进入 outputs）
[{"WS":{"op":"send","url":"wss://push.example.com/ws","message":"hello","timeout":10}}]

// 仅连接监听服务端推送
[{"WS":{"op":"connect","url":"wss://push.example.com/ws","timeout":15}}]
```

### 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `op` | String | 否 | `send`（默认）/ `connect` |
| `url` | String | 是 | `ws://` 或 `wss://` 端点 |
| `message` | String | send 时 | 发送的文本消息 |
| `timeout` | int | 否 | 监听秒数（默认 10） |

### 4. 输出与断言

| key | 类型 | 说明 |
|---|---|---|
| `connected` | boolean | 是否连接成功 |
| `messages` | List\<String\> | timeout 内收到的全部消息 |
| `messageCount` | int | 消息数 |
| `lastMessage` | String | 最后一条消息 |

```json
// 收到推送
[{"messageCount":"","OP":"GTE","EXPECTED":["1"]}]

// 推送内容断言（JSON 消息用 JSONPath）
[{"lastMessage":"$.event","OP":"EQ","EXPECTED":["order-created"]}]

// 收到消息包含关键字
[{"lastMessage":"","OP":"CONTAINS","EXPECTED":["heartbeat"]}]
```

### 5. 测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-WS-DEMO | 1 | WS-ECHO | DATAHUB | COMMON_WEBSOCKET_CLIENT | `[{"WS":{"op":"send","url":"wss://echo.example.com/ws","message":"ping","timeout":5}}]` | `[{"connected":"","OP":"EQ","EXPECTED":["true"]},{"messageCount":"","OP":"GTE","EXPECTED":["1"]}]` |

### 6. FAQ

**Q: 怎么验证服务端主动推送？**
A: 先触发业务（HTTP/MQ 步骤），再跑 WS connect 监听步骤（timeout 内收到的推送进入 messages 断言）。

**Q: demo 模式回显什么？**
A: send 的 message 会被当作收到的消息回显（messageCount=1），可断言 `lastMessage EQ ping`。

**Q: 二进制帧支持吗？**
A: 当前仅文本帧（onText）；二进制需求需扩展。
