# Redis 缓存操作使用指南（COMMON_REDIS_OPERATE）

> Action: `DATAHUB:COMMON_REDIS_OPERATE` | 协议键: `REDIS` | 实现: demo 内存模拟 / live Jedis

## 1. 前置环境配置

### 1.1 运行环境
| 项目 | demo 模式 | live 模式 |
|---|---|---|
| Redis 服务器 | ❌ 不需要（内存模拟，含 TTL 语义） | ✅ 需要 Redis 2.8+ |
| 依赖 | 框架内置 | 框架内置（jedis 5.x） |

### 1.2 application.yml 配置（live 模式）
```yaml
e2e:
  redis:
    host: localhost       # Redis 地址
    port: 6379            # 端口
    password: ""          # 密码（无密码留空）
    database: 0           # 逻辑库编号
```

### 1.3 demo / live 行为差异
| 模式 | 行为 |
|---|---|
| demo | 进程内存模拟：String/Hash/List/KEYS/TTL 全语义一致（TTL 按真实时间过期） |
| live | Jedis 真实连接（每次操作短连接） |

> demo 模式数据仅在单次 JVM 运行内有效，重启即清空（无持久化）。

## 2. INPUT 格式

```json
[{"REDIS":{"op":"set","key":"user:1001","value":"{\"name\":\"zhangsan\"}","ttl":300}}]
[{"REDIS":{"op":"get","key":"user:1001"}}]
```

## 3. 参数枚举

### 3.1 op 操作枚举（10 种）

| op | 必填参数 | 说明 |
|---|---|---|
| `set` | key, value | 写入 String（可选 `ttl` 秒过期） |
| `get` | key | 读取 String |
| `del` | key | 删除任意类型键 |
| `ttl` | key | 查询剩余过期秒数（-1=永不过期，-2=不存在） |
| `exists` | key | 键是否存在 |
| `keys` | pattern | 按通配符扫描键（`user:*`） |
| `hset` | key, field, value | 写入 Hash 字段 |
| `hget` | key, field | 读取 Hash 字段 |
| `lpush` | key, value | 列表左侧插入 |
| `lrange` | key, start, end | 列表范围查询（0 到 -1=全部） |

### 3.2 通用参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `op` | String | 是 | 见上表 |
| `key` | String | 是 | Redis 键名 |
| `ttl` | int | 否 | set 时过期秒数 |
| `pattern` | String | keys 时 | 通配符模式 |
| `field` | String | hset/hget 时 | Hash 字段名 |
| `start`/`end` | int | lrange 时 | 范围索引（-1=末尾） |

## 4. 输出（outputs）枚举

| key | 出现的 op | 类型 | 说明 |
|---|---|---|---|
| `result` | set/hset | String | "OK" |
| `value` | get/hget | String | 读取值（不存在为 null） |
| `exists` | get/exists | boolean | 键是否存在 |
| `deleted` | del | int | 删除数量（0/1） |
| `ttl` | ttl | long | 剩余秒数 |
| `keys` / `keyCount` | keys | List/int | 匹配键列表/数量 |
| `listSize` | lpush | long | 列表长度 |
| `values` / `listSize` | lrange | List/int | 范围值/数量 |
| `op` / `key` | 全部 | String | 回显操作与键名 |

## 5. 断言示例

```json
// set 成功
[{"result":"","OP":"EQ","EXPECTED":["OK"]}]

// get 值包含
[{"value":"","OP":"CONTAINS","EXPECTED":["zhangsan"]}]

// TTL 生效
[{"ttl":"","OP":"GT","EXPECTED":["0"]}]

// 键存在
[{"exists":"","OP":"EQ","EXPECTED":["true"]}]

// 键数量
[{"keyCount":"","OP":"GTE","EXPECTED":["1"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"cachedValue","from":"value","path":""}]
```
后续步骤引用：`${extract.cachedValue}`

## 7. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-REDIS-DEMO | 1 | RD-SET | DATAHUB | COMMON_REDIS_OPERATE | [] | `[{"REDIS":{"op":"set","key":"e2e:user:1","value":"{\"name\":\"zhangsan\"}","ttl":300}}]` | `[{"result":"","OP":"EQ","EXPECTED":["OK"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-REDIS-DEMO | 2 | RD-GET | DATAHUB | COMMON_REDIS_OPERATE | RD-SET | `[{"REDIS":{"op":"get","key":"e2e:user:1"}}]` | `[{"value":"","OP":"CONTAINS","EXPECTED":["zhangsan"]}]` | `[{"name":"cachedName","from":"value","path":""}]` | 15 | 0 | STOP | Y |
| E2E-REDIS-DEMO | 3 | RD-TTL | DATAHUB | COMMON_REDIS_OPERATE | RD-GET | `[{"REDIS":{"op":"ttl","key":"e2e:user:1"}}]` | `[{"ttl":"","OP":"GT","EXPECTED":["0"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-REDIS-DEMO | 4 | RD-HSET | DATAHUB | COMMON_REDIS_OPERATE | RD-TTL | `[{"REDIS":{"op":"hset","key":"e2e:session:1","field":"status","value":"active"}}]` | `[{"result":"","OP":"EQ","EXPECTED":["OK"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-REDIS-DEMO | 5 | RD-HGET | DATAHUB | COMMON_REDIS_OPERATE | RD-HSET | `[{"REDIS":{"op":"hget","key":"e2e:session:1","field":"status"}}]` | `[{"value":"","OP":"EQ","EXPECTED":["active"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-REDIS-DEMO | 6 | RD-DEL | DATAHUB | COMMON_REDIS_OPERATE | RD-HGET | `[{"REDIS":{"op":"del","key":"e2e:user:1"}}]` | `[{"deleted":"","OP":"EQ","EXPECTED":["1"]}]` | `[]` | 15 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: TTL 返回 -2 是什么意思？**
A: 键不存在（已过期或未创建）。-1 表示存在但永不过期。

**Q2: demo 和 live 的 keys 通配符一致吗？**
A: 一致（`*` 任意、`?` 单字符），demo 内部转换为正则实现。

**Q3: 怎么验证"缓存与 DB 一致"？**
A: 典型链路：DB 写入 → 业务触发缓存刷新 → `get` 断言与 DB 值一致（两个步骤变量比对，用 DataCompare 或 EXTRACT+断言）。

**Q4: 集群/哨兵模式支持吗？**
A: 当前 live 实现是单节点 Jedis；集群需求可实现自定义客户端覆盖。

**Q5: 值是 JSON 可以直接断言字段吗？**
A: 可以，get 后用 JSONPath 断言：`{"value":"$.name","OP":"EQ","EXPECTED":["zhangsan"]}`。
