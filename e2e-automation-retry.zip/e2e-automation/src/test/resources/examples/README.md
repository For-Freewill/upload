# E2E 框架功能示例目录

本目录覆盖框架支持的**全部 24 个 Action、断言引擎、变量提取、失败策略**用法。每份文档包含：**前置环境配置 → INPUT 格式 → 参数枚举 → 输出枚举 → 断言/EXTRACT 示例 → 可直接复制的测试案例 → FAQ**，方便测试人员快速上手。

## 快速上手三步

1. **看懂 Excel 三表**：Scenarios（场景）/ Steps（步骤）/ _GlobalConfig（全局变量）
2. **按协议查文档**：下表找 Action 对应文档，复制「完整测试案例」表格行
3. **先 demo 后 live**：`e2e.mode: demo` 全内存可跑验证用例逻辑，再切 live 连真实环境

## Action 文档索引（按协议分组）

### HTTP / 认证

| 文档 | 覆盖 Action | 核心能力 |
|---|---|---|
| [http-requests.md](http-requests.md) | `COMMON_HTTP_REQUEST` | 全 method + auth + form + query |
| [jwt-oauth2.md](jwt-oauth2.md) | `COMMON_JWT_OPERATE` / `COMMON_OAUTH2_TOKEN` | JWT 生成/解析/校验 + OAuth2 token（自动注入变量） |

### 数据库 / 数据比对

| 文档 | 覆盖 Action | 核心能力 |
|---|---|---|
| [db-execute.md](db-execute.md) | `COMMON_DB_EXECUTE` | SQL 单条/批量（DDL/DML） |
| [data-compare.md](data-compare.md) | `COMMON_DATA_COMPARE` | 双源比对（prod vs pre-prod 跨环境 ⭐） |
| [nosql-mongo.md](nosql-mongo.md) | `COMMON_NOSQL_EXECUTE` / `COMMON_NOSQL_ASSERT` | MongoDB 文档操作与断言 |
| [redis.md](redis.md) | `COMMON_REDIS_OPERATE` | 10 种缓存操作（含 TTL） |

### 命令 / 远程

| 文档 | 覆盖 Action | 核心能力 |
|---|---|---|
| [windows-cmd.md](windows-cmd.md) | `COMMON_WINDOWS_CMD` | 本地 Windows（base_dir + 批量命令） |
| [linux-cmd-ssh.md](linux-cmd-ssh.md) | `COMMON_LINUX_CMD` | 本地 + SSH 远程（内联认证 + 文件校验） |
| [ssh-remote.md](ssh-remote.md) | `COMMON_SSH` / `COMMON_SFTP_ACTIONS` | SSH 远程命令 + SFTP 安全传输 |

### 消息 / 通知

| 文档 | 覆盖 Action | 核心能力 |
|---|---|---|
| [mq-send.md](mq-send.md) | `COMMON_MQ_SEND` / `COMMON_MQ_CONSUME` | MQ 收发闭环 + XML/JSON 报文断言 |
| [webhook-websocket.md](webhook-websocket.md) | `COMMON_WEBHOOK_NOTIFY` / `COMMON_WEBSOCKET_CLIENT` | 钉钉/企微/飞书通知 + WS 长连接 |
| [ftp-mail.md](ftp-mail.md) | `COMMON_FTP_ACTIONS` / `COMMON_MAIL_ACTIONS` | FTP 传输 + 邮件（文本/HTML/附件） |

### 文件 / UI / 反射

| 文档 | 覆盖 Action | 核心能力 |
|---|---|---|
| [file-operations.md](file-operations.md) | `COMMON_FILE_ACTIONS` | 9 种文件操作 + FILE 断言 |
| [java-invoke-ui.md](java-invoke-ui.md) | `COMMON_JAVA_INVOKE` | Java 反射（Bean/静态/Playwright） |
| [ui-actions.md](ui-actions.md) | `DRP_UI_REPORTS` / `104_UI_BOOK` / `109_UPLOAD` | UI 操作三层路由 |

### 通用机制

| 文档 | 内容 |
|---|---|
| [assertions-guide.md](assertions-guide.md) | 断言全模式：DB 字符串/FIELD/Map + FILE + JSONPath/XPath + 操作符速查 |
| [extract-variables.md](extract-variables.md) | EXTRACT 全场景 + 变量流转 + 上下文 API |
| [failure-strategies.md](failure-strategies.md) | ON_FAILURE 5 策略 + RETRY + TIMEOUT + ENABLED |

## 全局环境配置速查（application.yml）

```yaml
e2e:
  mode: demo                    # demo=全内存桩 / live=真实连接
  cmd:
    allow-local-execution: true # 本地命令真实执行开关
  db:    {mode: mysql, driver: jdbc}
  ssh:   {user: e2e, password: "", port: 22}
  sftp:  {host: "", port: 22, user: "", password: ""}   # 留空复用 ssh
  ftp:   {host: localhost, port: 21, user: anonymous, password: ""}
  mail:  {host: localhost, port: 25, from: e2e@localhost, auth-enabled: false}
  mq:    {host: localhost, port: 1414, queue-manager: QM1, queue: E2E.IN}
  redis: {host: localhost, port: 6379, password: "", database: 0}
  nosql: {uri: mongodb://localhost:27017, database: e2e}
  webhook: {dingtalk-url: "", wecom-url: "", feishu-url: ""}
  compare:
    envs:                       # 跨环境比对命名数据源
      prod:     {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
      pre-prod: {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
```

## Excel 三表结构

### Scenarios 表
| Seq | Scenario_ID | Scenario_Name | Enabled | Tags | Env | Timeout | Description | Owner |
|---|---|---|---|---|---|---|---|---|

### Steps 表
| Scenario_ID | SEQ_NO | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

### _GlobalConfig 表
| Key | Value |
|---|---|
| http_base_url | http://www.baidu.com |

## 变量引用

```
${global.xxx}     → _GlobalConfig 表全局变量
${extract.xxx}    → 前序步骤 EXTRACT 提取（或 Action 自动注入如 oauthToken/jwtToken）
${env.xxx}        → 环境变量 / -D 系统属性
```

## APP 域速查

| APP | 常用 Action |
|---|---|
| TAP | COMMON_HTTP_REQUEST / COMMON_SSH / COMMON_JWT_OPERATE / COMMON_OAUTH2_TOKEN |
| SMARTS | COMMON_DB_EXECUTE / COMMON_NOSQL_EXECUTE / COMMON_DATA_COMPARE / COMMON_JAVA_INVOKE |
| STP | COMMON_MQ_SEND / COMMON_MQ_CONSUME / COMMON_HTTP_REQUEST / COMMON_OAUTH2_TOKEN |
| DNS / TMS | COMMON_DB_ASSERTIONS / COMMON_NOSQL_ASSERT |
| DATAHUB | COMMON_WINDOWS_CMD / COMMON_LINUX_CMD / COMMON_FILE_ACTIONS / COMMON_FTP_ACTIONS / COMMON_SFTP_ACTIONS / COMMON_REDIS_OPERATE / COMMON_MAIL_ACTIONS / COMMON_WEBHOOK_NOTIFY / COMMON_WEBSOCKET_CLIENT |
| DRP | DRP_UI_REPORTS / COMMON_JAVA_INVOKE |
