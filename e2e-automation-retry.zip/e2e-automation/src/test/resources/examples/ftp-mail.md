# FTP / MAIL 协议使用指南

> Actions: `DATAHUB:COMMON_FTP_ACTIONS` / `DATAHUB:COMMON_MAIL_ACTIONS`

## 1. FTP 文件传输（COMMON_FTP_ACTIONS）

### 1.1 INPUT 格式（6 种操作）

```json
// 上传文件（本地 → 远程）
[{"FTP":{"op":"upload","local":"test-output/report.pdf","remote":"/upload/report.pdf"}}]

// 下载文件（远程 → 本地）
[{"FTP":{"op":"download","remote":"/data/result.csv","local":"test-output/result.csv"}}]

// 列出远程目录
[{"FTP":{"op":"list","dir":"/upload"}}]

// 删除远程文件
[{"FTP":{"op":"delete","remote":"/upload/old-report.pdf"}}]

// 创建远程目录
[{"FTP":{"op":"mkdir","dir":"/upload/e2e-evidence"}}]

// 检查远程文件存在
[{"FTP":{"op":"exists","remote":"/upload/report.pdf"}}]
```

### 1.2 参数说明

| 参数 | 必填 | 说明 |
|---|---|---|
| `op` | 是 | upload / download / list / delete / mkdir / exists |
| `local` | upload/download | 本地文件路径（相对=工程根目录，支持绝对路径） |
| `remote` | upload/download/delete/exists | 远程文件路径 |
| `dir` | list/mkdir | 远程目录 |

### 1.3 输出（outputs）

| key | 说明 |
|---|---|
| `success` | 操作是否成功（true/false） |
| `message` | 操作结果消息 |
| `fileCount` | list 操作返回的文件数 |
| `files` | list 操作返回的文件列表（name/size/type/modifiedTime） |
| `exists` | exists 操作返回（true/false） |

### 1.4 断言示例

```json
// 上传成功
[{"success":"","OP":"EQ","EXPECTED":["true"]}]

// 目录至少有 1 个文件
[{"fileCount":"","OP":"GTE","EXPECTED":["1"]}]

// 文件存在
[{"exists":"","OP":"EQ","EXPECTED":["true"]}]
```

### 1.5 FTP 配置（application.yml）

```yaml
e2e:
  ftp:
    host: ftp.example.com
    port: 21
    user: e2e-uploader
    password: "your-password"
```

> demo 模式走桩（内存虚拟目录，记录操作）；live 模式走 commons-net 真实 FTP（被动模式 + 二进制传输）。

## 2. MAIL 邮件发送（COMMON_MAIL_ACTIONS）

### 2.1 INPUT 格式

```json
// 纯文本邮件
[{"MAIL":{
  "to":["user1@example.com","user2@example.com"],
  "subject":"E2E 测试完成通知",
  "body":"全部用例执行完成，详见附件报告。"
}}]

// HTML 邮件 + 抄送 + 附件
[{"MAIL":{
  "to":["team@example.com"],
  "cc":["lead@example.com"],
  "subject":"E2E 测试报告",
  "body":"<h2>测试报告</h2><p>通过率 100%</p>",
  "html":true,
  "attachments":["test-output/test_report.html","test-output/test_report.json"]
}}]
```

### 2.2 参数说明

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `to` | 数组/字符串 | 是 | 收件人（数组或逗号分隔字符串） |
| `cc` | 数组/字符串 | 否 | 抄送 |
| `subject` | String | 否 | 邮件主题 |
| `body` | String | 否 | 正文（纯文本或 HTML） |
| `html` | boolean | 否 | true=HTML 正文（默认纯文本） |
| `attachments` | 数组 | 否 | 本地附件文件路径列表 |

### 2.3 输出（outputs）

| key | 说明 |
|---|---|
| `success` | 是否发送成功 |
| `message` | 结果消息 |
| `messageId` | 邮件 Message-ID（可 EXTRACT） |
| `to` | 实际收件人 |
| `subject` | 邮件主题 |
| `attachmentCount` | 附件数量 |

### 2.4 断言 + EXTRACT 示例

```json
ASSERT:  [{"success":"","OP":"EQ","EXPECTED":["true"]},{"messageId":"","OP":"NOT_EMPTY","EXPECTED":[]}]
EXTRACT: [{"name":"mailMessageId","from":"messageId","path":""}]
```

### 2.5 SMTP 配置（application.yml）

```yaml
e2e:
  mail:
    host: smtp.example.com
    port: 465
    from: e2e-bot@example.com
    user: e2e-bot@example.com
    password: "app-password"
    auth-enabled: true
    starttls: true
```

> demo 模式走桩（内存收件箱，记录已发送）；live 模式走 jakarta.mail 真实 SMTP。

## 3. 完整步骤示例（Excel Steps 表行）

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | INPUT | ASSERT |
|---|---|---|---|---|---|---|
| E2E-FTP-MAIL | 1 | FTP-UPLOAD | DATAHUB | COMMON_FTP_ACTIONS | `[{"FTP":{"op":"upload","local":"test-output/report.pdf","remote":"/upload/report.pdf"}}]` | `[{"success":"","OP":"EQ","EXPECTED":["true"]}]` |
| E2E-FTP-MAIL | 2 | FTP-LIST | DATAHUB | COMMON_FTP_ACTIONS | `[{"FTP":{"op":"list","dir":"/upload"}}]` | `[{"fileCount":"","OP":"GTE","EXPECTED":["1"]}]` |
| E2E-FTP-MAIL | 3 | MAIL-SEND | DATAHUB | COMMON_MAIL_ACTIONS | `[{"MAIL":{"to":["team@example.com"],"subject":"报告就绪","body":"<p>见附件</p>","html":true,"attachments":["test-output/report.pdf"]}}]` | `[{"success":"","OP":"EQ","EXPECTED":["true"]}]` |
| E2E-FTP-MAIL | 4 | FTP-CLEANUP | DATAHUB | COMMON_FTP_ACTIONS | `[{"FTP":{"op":"delete","remote":"/upload/report.pdf"}}]` | `[{"success":"","OP":"EQ","EXPECTED":["true"]}]` |

## 4. 典型业务场景

1. **测试报告分发**：跑完测试 → FTP 上传报告 → MAIL 通知团队（附报告）
2. **数据文件交换**：FTP 下载上游数据 → DB 导入校验 → MAIL 发送结果
3. **证据归档**：截图/日志 FTP 上传归档 → MAIL 发送摘要
