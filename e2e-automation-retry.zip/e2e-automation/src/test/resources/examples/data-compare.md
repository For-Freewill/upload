# 双源数据比对使用指南（COMMON_DATA_COMPARE）

> Action: `SMARTS:COMMON_DATA_COMPARE` | 协议键: `COMPARE` | 场景: 迁移验证 / 一致性校验 / prod vs pre-prod

## 1. 前置环境配置

### 1.1 数据源要求

| source type | 前置条件 | 配置位置 |
|---|---|---|
| `db` + `env`（命名环境） | 各环境 JDBC 可达 + 驱动在 classpath | `e2e.compare.envs.*`（yml 预配置） |
| `db` + `url`（内联连接） | 同上 | INPUT 中直接写连接参数（免配置） |
| `db`（默认） | 框架数据源可用 | `spring.datasource.*` |
| `file` | 文件存在（工程根目录相对/绝对路径） | 无 |
| `http` | 前序步骤已产生输出变量 | 无 |

### 1.2 多环境配置（application.yml）⭐ prod vs pre-prod

```yaml
e2e:
  compare:
    envs:
      prod:
        url: jdbc:mysql://prod-host:3306/userdb
        driver: com.mysql.cj.jdbc.Driver
        user: readonly
        password: "prod-secret"
      pre-prod:
        url: jdbc:mysql://pre-prod-host:3306/userdb
        driver: com.mysql.cj.jdbc.Driver
        user: readonly
        password: "pre-secret"
      uat:
        url: jdbc:postgresql://uat-host:5432/userdb
        user: readonly
        password: "uat-secret"
```

### 1.3 驱动枚举
| 数据库 | driver 值 | 状态 |
|---|---|---|
| MySQL 8.x | `com.mysql.cj.jdbc.Driver` | ✅ 内置 |
| PostgreSQL | `org.postgresql.Driver` | ✅ 内置 |
| H2 | 自动识别 | ✅ 内置 |
| Oracle 等 | `oracle.jdbc.OracleDriver` | 需自行加依赖 |

## 2. INPUT 格式（四种比对组合）

### 2.1 跨环境 DB vs DB（prod vs pre-prod 同表）⭐
```json
[{"COMPARE":{
  "sourceA":{"type":"db","env":"prod","sql":"SELECT id,name,status FROM users ORDER BY id"},
  "sourceB":{"type":"db","env":"pre-prod","sql":"SELECT id,name,status FROM users ORDER BY id"},
  "ignoreOrder":true
}}]
```

### 2.2 内联连接 DB vs DB（免预配置）
```json
[{"COMPARE":{
  "sourceA":{"type":"db","url":"jdbc:mysql://prod-host:3306/userdb","user":"r","password":"x",
             "driver":"com.mysql.cj.jdbc.Driver","sql":"SELECT id,name FROM users"},
  "sourceB":{"type":"db","url":"jdbc:mysql://pre-host:3306/userdb","user":"r","password":"y",
             "sql":"SELECT id,name FROM users"}
}}]
```

### 2.3 文件 vs 文件
```json
[{"COMPARE":{
  "sourceA":{"type":"file","path":"test-output/expected.csv"},
  "sourceB":{"type":"file","path":"test-output/actual.csv"}
}}]
```

### 2.4 前序输出 vs 文件（HTTP 响应与期望比对）
```json
[{"COMPARE":{
  "sourceA":{"type":"http","from":"body"},
  "sourceB":{"type":"file","path":"test-output/expected.json"}
}}]
```

## 3. 参数枚举

### 3.1 顶层参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `sourceA` / `sourceB` | Object | 是 | 两个数据源（类型可任意组合） |
| `ignoreOrder` | boolean | 否 | 忽略行序比对（默认 true） |

### 3.2 source 参数枚举

| 参数 | type=db | type=file | type=http |
|---|---|---|---|
| `env` | ✅ 命名环境（优先级最高） | - | - |
| `url`/`user`/`password`/`driver` | ✅ 内联连接 | - | - |
| `sql` | ✅ 查询 SQL | - | - |
| `path` | - | ✅ 文件路径 | - |
| `from` | - | - | ✅ 输出变量名（默认 body） |

**DB 数据源三级路由**：`env` 命名环境 → 内联 `url` → 默认 DbClient。

## 4. 输出（outputs）枚举

| key | 类型 | 说明 |
|---|---|---|
| `equal` | boolean | 两源是否一致 |
| `diffCount` | int | 差异总条数 |
| `onlyInA` | List\<String\> | 仅 A 有的行（最多 20 条，防报告爆炸） |
| `onlyInB` | List\<String\> | 仅 B 有的行 |
| `countA` / `countB` | int | 两源行数 |

> DB 行格式：`{列名=值, 列名=值}`；列序由 SQL SELECT 顺序保证——跨环境比对时两边 SQL 列序写一致。

## 5. 断言示例

```json
// 完全一致
[{"equal":"","OP":"EQ","EXPECTED":["true"]}]

// 差异条数（迁移允许少量差异时）
[{"diffCount":"","OP":"LTE","EXPECTED":["5"]}]

// 行数一致
[{"countA":"","OP":"EQ","EXPECTED":["1000"]}]

// 两侧行数相等（交叉断言写法：提取后比对）
EXTRACT: [{"name":"cntA","from":"countA","path":""}]
下一步 ASSERT: [{"countB":"","OP":"EQ","EXPECTED":["${extract.cntA}"]}]
```

## 6. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-COMPARE | 1 | CP-PREP-A | DATAHUB | COMMON_FILE_ACTIONS | [] | `[{"FILE":{"op":"write","path":"test-output/cmp-a.txt","content":"line1\nline2"}}]` | `[{"bytes":"","OP":"NOT_EMPTY","EXPECTED":[]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-COMPARE | 2 | CP-FILE | SMARTS | COMMON_DATA_COMPARE | CP-PREP-A | `[{"COMPARE":{"sourceA":{"type":"file","path":"test-output/cmp-a.txt"},"sourceB":{"type":"file","path":"test-output/cmp-a.txt"}}}]` | `[{"equal":"","OP":"EQ","EXPECTED":["true"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-COMPARE | 3 | CP-ENV | SMARTS | COMMON_DATA_COMPARE | CP-FILE | `[{"COMPARE":{"sourceA":{"type":"db","env":"prod","sql":"SELECT id,name FROM users ORDER BY id"},"sourceB":{"type":"db","env":"pre-prod","sql":"SELECT id,name FROM users ORDER BY id"}}}]` | `[{"equal":"","OP":"EQ","EXPECTED":["true"]},{"countA":"","OP":"GTE","EXPECTED":["1"]}]` | `[]` | 60 | 0 | CONTINUE | Y |

## 7. 常见问题（FAQ）

**Q1: 行内容相同但比对不一致？**
A: DB 行格式含全部查询列——检查两边 SQL 列序与列集合是否完全一致（`SELECT id,name` 两边都要 `id,name`）。时间戳/浮点精度列建议 SQL 里 FORMAT 掉。

**Q2: 大表比对会超时吗？**
A: 无内置 LIMIT，大表建议 SQL 加 `WHERE`/`LIMIT` 分批；步骤 TIMEOUT 列调大（如 300 秒）。

**Q3: ignoreOrder=false 是什么行为？**
A: 严格按行序比对（第 N 行对第 N 行），适合有序导出文件比对；DB 查询记得 ORDER BY。

**Q4: 连接信息会泄露到日志吗？**
A: 不会——日志中的 URL 已脱敏（`jdbc:mysql://***@host:3306/...`）。

**Q5: 能比对 Mongo/Redis 数据吗？**
A: 当前 source 支持 db(JDBC)/file/http；NoSQL 数据先通过 COMMON_NOSQL_EXECUTE 的 find 导出为文件再比对。
