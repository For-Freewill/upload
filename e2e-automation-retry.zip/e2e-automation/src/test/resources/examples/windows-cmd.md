# 本地 Windows 命令执行使用指南（COMMON_WINDOWS_CMD）

> Action: `DATAHUB:COMMON_WINDOWS_CMD` | 协议键: `WINDOWS-CMD` | 执行方式: 本地 `cmd /c`

## 1. 前置环境配置

### 1.1 运行环境
| 项目 | 要求 |
|---|---|
| 操作系统 | Windows（本机执行，不支持远程） |
| 运行方式 | 框架所在机器直接执行（ProcessBuilder） |
| 安全开关 | `e2e.cmd.allow-local-execution: true` 才真实执行 |

### 1.2 application.yml 配置
```yaml
e2e:
  cmd:
    # true = 真实执行命令；false = dry-run（只记录日志不执行，返回 [dry-run] 输出）
    allow-local-execution: true
```

### 1.3 demo / live 行为差异
| 模式 | 行为 |
|---|---|
| demo + allow-local-execution=false | dry-run：输出 `[dry-run] 命令`，退出码 0 |
| live + allow-local-execution=true | 真实执行 `cmd /c <命令>`，返回真实退出码与输出 |

> ⚠️ dry-run 时 STDOUT 断言应匹配 `[dry-run]` 前缀或只断言退出码。

## 2. INPUT 格式

```json
[{"WINDOWS-CMD":{
  "base_dir":"C:/dev",
  "cmd":["dir","set_env alpha test","cd scratch && dir"]
}}]
```

## 3. 参数枚举

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `cmd` | String[] 或 String | 是 | 命令列表（按序执行）或单命令字符串 |
| `base_dir` | String | 否 | 工作目录（相对=工程根目录；绝对=原样使用；缺省=当前目录） |

> `cmd` 数组中每条命令独立执行（各自的 `cmd /c` 进程）；需要串联时用 `&&` 或 `&` 写在一条里。

## 4. 输出（outputs）枚举

| key | 类型 | 说明 |
|---|---|---|
| `CMD` | int | 最后一条命令的退出码（0=成功） |
| `STDOUT` | String | 全部命令的合并标准输出（含 stderr，redirectErrorStream） |
| `STDERR` | String | 合并标准错误 |
| `commandCount` | int | 执行的命令数量 |
| `lastCommand` | String | 最后一条执行的命令 |
| `host` | String | 固定 "local" |
| `baseDir` | String | 实际使用的工作目录（未设置时不含此键） |
| `lines` | List\<String\> | STDOUT 按行分割 |

## 5. 断言示例

```json
// 输出包含（全部命令合并后的 STDOUT）
[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["E2E-WIN-START"]}]

// 退出码成功
[{"CMD":"","OP":"EQ","EXPECTED":["0"]}]

// 命令数量
[{"commandCount":"","OP":"EQ","EXPECTED":["3"]}]

// 输出无错误
[{"STDOUT":"","OP":"NOT_CONTAINS","EXPECTED":["ERROR","FATAL"]}]

// 组合断言
[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["step-1","done"]},
 {"CMD":"","OP":"EQ","EXPECTED":["0"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"cmdOutput","from":"STDOUT","path":""}]      // 全部输出
[{"name":"hostName","from":"lines","path":"[0]"}]     // 第一行
```
后续步骤引用：`${extract.cmdOutput}` / `${extract.hostName}`

## 7. 完整测试案例（可直接复制到 Excel Steps 表）

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-WIN-DEMO | 1 | WIN-ECHO | DATAHUB | COMMON_WINDOWS_CMD | [] | `[{"WINDOWS-CMD":{"cmd":["echo E2E-START"]}}]` | `[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["E2E-START"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-WIN-DEMO | 2 | WIN-BASEDIR | DATAHUB | COMMON_WINDOWS_CMD | WIN-ECHO | `[{"WINDOWS-CMD":{"base_dir":"test-output","cmd":["echo in-basedir","dir"]}}]` | `[{"STDOUT":"","OP":"CONTAINS","EXPECTED":["in-basedir"]},{"commandCount":"","OP":"EQ","EXPECTED":["2"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-WIN-DEMO | 3 | WIN-EXIT | DATAHUB | COMMON_WINDOWS_CMD | WIN-BASEDIR | `[{"WINDOWS-CMD":{"cmd":["echo done"]}}]` | `[{"CMD":"","OP":"EQ","EXPECTED":["0"]}]` | `[{"name":"lastOut","from":"STDOUT","path":""}]` | 10 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: 为什么 STDOUT 断言失败但命令明明执行了？**
A: 检查 `e2e.cmd.allow-local-execution` 是否为 false（dry-run 模式输出为 `[dry-run] xxx`）。

**Q2: base_dir 用什么路径格式？**
A: Windows 路径 `C:/dev` 或 `C:\\dev` 均可（Java File 兼容）；相对路径基于工程根目录（`user.dir`）。

**Q3: 多条命令之间变量/目录互通吗？**
A: 不互通。每条命令独立进程，`cd` 不影响下一条。需要串联用 `cd scratch && dir` 写在同一条里，或用 `base_dir`。

**Q4: 远程 Windows 机器怎么执行？**
A: 本 Action 仅支持本地。远程场景用 `COMMON_SSH`（远程 Linux）或将框架部署在目标 Windows 机器上。

**Q5: 命令超时怎么控制？**
A: 用步骤 `TIMEOUT` 列（秒）。超时步骤标记 TIMEOUT 并按 ON_FAILURE 处理。
