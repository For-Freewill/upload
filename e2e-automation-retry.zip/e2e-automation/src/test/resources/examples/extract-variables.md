# EXTRACT 变量提取与跨步骤传递使用指南

> EXTRACT 列 + ScenarioExecutionContext 场景上下文

## 1. 变量引擎三类占位符

| 占位符 | 来源 | 示例 |
|---|---|---|
| `${global.x}` | _GlobalConfig 表 | `${global.http_base_url}` |
| `${extract.x}` | 前序步骤 EXTRACT 提取的值 | `${extract.orderId}` |
| `${env.x}` | 环境变量 / -D 系统属性 | `${env.TIMESTAMP}` |

## 2. EXTRACT 列格式（两种模式）

```json
// 模式一：提取模式（from + path）—— 从步骤输出/文件提取
[{"name":"变量名","from":"来源键","path":"路径"}]

// 模式二：字面量模式（value）⭐ 场景级参数设置
[{"name":"acct","value":"999999"}]
```

| 字段 | 必填 | 说明 |
|---|---|---|
| `name` | 是 | 变量名（后续步骤用 `${extract.变量名}` 引用） |
| `from` + `path` | 提取模式 | from：outputs 键（大小写不敏感）或 `FILE`；path 见下表 |
| `value` | 字面量模式 | 直接设置常量；**支持 `${global.}`/`${env.}`/`${extract.}` 引用组合** |

### 字面量模式（场景级参数）⭐

在 scenario 首个 step 的 EXTRACT 中定义通用参数，后续**所有步骤**（INPUT/ASSERT/EXTRACT）均可引用：

```json
// Step 1 的 EXTRACT：定义场景级参数
[{"name":"acct","value":"999999"},
 {"name":"branchCode","value":"0755"},
 {"name":"bizRef","value":"ACCT-${extract.acct}-BR-${extract.branchCode}"}]
```
> `bizRef` 演示组合变量：value 中的 `${extract.acct}` 在设置时即解析 → "ACCT-999999-BR-0755"

后续步骤引用：
```json
INPUT:  [{"HTTP":{"url":"...","params":{"acct":"${extract.acct}"}}}]
ASSERT: [{"body":"$.data.acct","OP":"EQ","EXPECTED":["999999"]}]
```

### path 五种模式（前缀自动路由）⭐

| path 写法 | 模式 | 示例 | 说明 |
|---|---|---|---|
| `$.xxx.yyy` | **JSONPath** | `{"name":"id","from":"body","path":"$.data.orderId"}` | jayway 全语法（`$.items[0].sku` / `$..id`）；单元素 List 自动解包 |
| `//xxx/yyy` 或 `/x/y` | **XPath** | `{"name":"side","from":"firstMessage","path":"//trade/side"}` | JDK XPath 取首个匹配节点文本（XML 输出） |
| `regex:正则` | **正则提取** | `{"name":"price","from":"STDOUT","path":"regex:price=([\\d.]+)"}` | 首个匹配的 group(1)（无分组则整段） |
| `文件路径` 或 `文件路径#L<n>` | **文件内容** | `{"name":"cfg","from":"FILE","path":"test-output/app.cfg#L3"}` | 读全文；`#L3` 取第 3 行 |
| `[0].COL` / `key.sub[1]` | **Token 导航**（默认） | `{"name":"acct","from":"DB_ROWS","path":"[0].ACCT_NO"}` | Map/List 逐级导航；String 输出若为 JSON 自动解析后再导航 |

> from 指定的来源键大小写不敏感；`from: FILE` 时 path 为文件路径（FilePathResolver 解析，支持工程根目录相对路径）。

## 3. 各 Action 的 EXTRACT 示例

### 3.1 HTTP 请求 → JSONPath 提取响应字段 ⭐
```
INPUT:   [{"HTTP":{"url":"http://api.example.com/orders","method":"POST","body":{...}}}]
EXTRACT: [{"name":"orderId","from":"body","path":"$.data.orderId"},
          {"name":"firstSku","from":"body","path":"$.data.items[0].sku"}]
```

### 3.2 HTTP → 提取状态码/响应头
```
EXTRACT: [{"name":"httpStatusCode","from":"HTTP","path":""}]
```
> 后续步骤引用：`${extract.httpStatusCode}`

### 3.3 DB 断言 → 提取查询结果
```
ASSERT:  [{"DB":"SELECT id, name FROM orders WHERE id=1","OP":"CONTAINS","EXPECTED":["order-001"]}]
EXTRACT: [{"name":"orderName","from":"DB_ROWS","path":"[0].name"}]
```
> `DB_ROWS` 为断言查询的完整行列表，`[0].name` 取第一行的 name 列

### 3.4 CMD 命令 → 提取输出 / 正则提取 ⭐
```
INPUT:   [{"WINDOWS-CMD":{"cmd":["hostname"]}}]
EXTRACT: [{"name":"hostName","from":"STDOUT","path":""}]

// 正则提取命令输出中的版本号
INPUT:   [{"WINDOWS-CMD":{"cmd":["java -version"]}}]
EXTRACT: [{"name":"javaVersion","from":"STDOUT","path":"regex:version \"([^\"]+)\""}]
```

### 3.5 CMD → 提取某一行
```
EXTRACT: [{"name":"secondLine","from":"lines","path":"[1]"}]
```

### 3.6 文件内容直接提取（from=FILE）⭐
```
// 读全文（无需前置 FILE action，EXTRACT 所在步骤通过即可）
EXTRACT: [{"name":"configText","from":"FILE","path":"test-output/app.cfg"}]

// 只取第 3 行
EXTRACT: [{"name":"thirdLine","from":"FILE","path":"test-output/app.cfg#L3"}]
```

### 3.7 FILE 读取 action → 提取行数
```
INPUT:   [{"FILE":{"op":"read","path":"test-output/data.txt"}}]
EXTRACT: [{"name":"dataLineCount","from":"lineCount","path":""}]
```

### 3.8 COMMON_JAVA_INVOKE → 提取方法返回值
```
INPUT:   [{"JAVA":{"class":"java.lang.System","method":"getProperty","params":["user.home"]}}]
EXTRACT: [{"name":"userHome","from":"result","path":""}]
```

### 3.9 COMMON_JAVA_INVOKE Bean → 提取返回 Map 字段
```
INPUT:   [{"JAVA":{"bean":"uiAutomationService","method":"getPageTitle","params":[]}}]
EXTRACT: [{"name":"pageTitle","from":"result","path":"title"}]
```
> `result` 是 Map，`path:"title"` 取 Map 中的 title 键

### 3.10 MQ 消费 → XPath/正则提取 XML 报文字段 ⭐
```
INPUT:   [{"MQ":{"op":"consume","queue":"E2E.OUT","maxMessages":1,"timeout":5}}]
EXTRACT: [{"name":"secCode","from":"firstMessage","path":"//trade/security"},
          {"name":"priceVal","from":"firstMessage","path":"regex:<price>([\\d.]+)</price>"}]
```
> XML 报文用 XPath（`//节点`），JSON 报文用 JSONPath（`$.字段`），自由文本用 `regex:`

### 3.11 MQ 发送 → 提取报文引用
```
INPUT:   [{"MQ":{"file":"data/e2e/stp/mq/test-001.xml"}}]
EXTRACT: [{"name":"mqFile","from":"file","path":""}]
```

### 3.12 SSH → 提取远程输出
```
INPUT:   [{"SSH":{"host":"192.168.1.100","cmd":["hostname"]}}]
EXTRACT: [{"name":"remoteHost","from":"STDOUT","path":""}]
```

## 4. 跨步骤变量流转完整示例

```
┌──────────────────────────────────────────────────────────────┐
│ ScenarioExecutionContext（场景级，执行期间存活）              │
│                                                              │
│ Step 1: TAP:COMMON_HTTP_REQUEST                                │
│   INPUT:   [{"HTTP":{"url":"${global.http_base_url}/orders", │
│             "method":"POST","body":{"item":"A001"}}}]       │
│   EXTRACT: [{"name":"orderId","from":"body","path":"id"}]   │
│   → ctx.putExtract("orderId", "ORD-12345")                  │
│                                                              │
│ Step 2: SMARTS:COMMON_DB_EXECUTE（引用 Step1 的变量）        │
│   INPUT:   [{"DB":"INSERT INTO audit VALUES                 │
│             ('${extract.orderId}', 'ORDERED')"}]            │
│   → 变量引擎替换 ${extract.orderId} → "ORD-12345"           │
│                                                              │
│ Step 3: DNS:COMMON_DB_ASSERTIONS（引用变量断言）            │
│   ASSERT:  [{"DB":"SELECT status FROM audit                 │
│             WHERE id='${extract.orderId}'",                 │
│             "OP":"EQ","EXPECTED":["ORDERED"]}]              │
│                                                              │
│ Step 4: DATAHUB:COMMON_WINDOWS_CMD（引用变量写入文件）         │
│   INPUT:   [{"WINDOWS-CMD":{"cmd":[                         │
│             "echo order=${extract.orderId} >> audit.log"]}}]│
│                                                              │
│ 场景结束 → 上下文 GC 回收（不同场景变量完全隔离）           │
└──────────────────────────────────────────────────────────────┘
```

## 5. Excel Steps 表完整示例

| SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | EXTRACT |
|---|---|---|---|---|---|---|
| 1 | HTTP-CREATE | TAP | COMMON_HTTP_REQUEST | [] | `[{"HTTP":{"url":"${global.http_base_url}/orders","method":"POST","body":{"item":"A001"}}}]` | `[{"name":"orderId","from":"body","path":"id"}]` |
| 2 | DB-AUDIT | SMARTS | COMMON_DB_EXECUTE | HTTP-CREATE | `[{"DB":"INSERT INTO audit VALUES ('${extract.orderId}','ORDERED')"}]` | `[]` |
| 3 | DB-CHECK | DNS | COMMON_DB_ASSERTIONS | DB-AUDIT | `[]` | `[]` |
| 4 | CMD-LOG | DATAHUB | COMMON_WINDOWS_CMD | DB-CHECK | `[{"WINDOWS-CMD":{"cmd":["echo ${extract.orderId} >> order.log"]}}]` | `[]` |

> ASSERT（Step 3）: `[{"DB":"SELECT status FROM audit WHERE id='${extract.orderId}'","OP":"EQ","EXPECTED":["ORDERED"]}]`

## 6. Action 内读写变量（自定义 Action）

```java
@Override
public ActionResult execute(ActionContext ctx) {
    // 读取前序步骤的变量
    String prevOrder = (String) ctx.getVar("orderId");

    // 写入变量（供后续步骤 ${extract.x} 引用）
    ctx.setVar("newVariable", "some-value");

    // 读取前序步骤的输出
    Object status = ctx.getStepOutput("HTTP-CREATE", "status");

    // 查询前序步骤是否通过
    boolean done = ctx.isStepCompleted("DB-AUDIT");

    // 获取前序步骤完整结果
    StepResult prev = ctx.getStepResult("HTTP-CREATE");
    ...
}
```

## 7. 生命周期保证

- 每个场景创建独立 `ScenarioExecutionContext`，场景结束 GC 回收
- **不同场景变量完全隔离**，无法跨场景传递
- 并行步骤写入线程安全（ConcurrentHashMap）
- 变量在 EXTRACT 提取后立即可用（同层并行步骤间不保证可见顺序，依赖 DEPENDS_ON 保证）

## 8. _GlobalConfig 全局变量

Excel `_GlobalConfig` 表定义全局变量（所有场景共享）：

| Key | Value |
|---|---|
| http_base_url | http://www.baidu.com |
| ssh_host | 127.0.0.1 |
| ssh_user | e2e |
| flow_biz_id | MIX-FLOW-001 |

引用：`${global.http_base_url}` → `http://www.baidu.com`

支持嵌套环境变量：`${global.env_timestamp}` = `${env.TIMESTAMP}`（动态解析）
