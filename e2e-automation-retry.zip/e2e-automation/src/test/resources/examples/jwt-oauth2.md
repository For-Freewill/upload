# 认证操作使用指南（COMMON_JWT_OPERATE / COMMON_OAUTH2_TOKEN）

> Action: `TAP:COMMON_JWT_OPERATE`（JWT）/ `TAP,STP:COMMON_OAUTH2_TOKEN`（OAuth2）| 协议键: `JWT` / `OAUTH2`

## 1. 前置环境配置

### 1.1 JWT（COMMON_JWT_OPERATE）
| 项目 | 要求 |
|---|---|
| 外部依赖 | ❌ 无（纯本地加解密，demo/live 行为一致） |
| 依赖库 | jjwt 0.12.x（框架内置） |
| 密钥 | HMAC-SHA256，至少 32 字节（不足自动补齐，仅测试用） |

### 1.2 OAuth2（COMMON_OAUTH2_TOKEN）
| 项目 | demo 模式 | live 模式 |
|---|---|---|
| 授权服务器 | ❌ 不需要（HTTP 桩返回回显） | ✅ 需要 OAuth2 授权端点 |
| 配置 | 无 | 无全局配置，全部在 INPUT 中指定 |

## 2. INPUT 格式

### 2.1 JWT 三种操作
```json
// 生成（HMAC-SHA256）
[{"JWT":{"op":"generate","secret":"my-e2e-secret","subject":"e2e-user",
         "claims":{"role":"tester","org":"qa"},"expireSeconds":3600}}]

// 解析（提取 claims）
[{"JWT":{"op":"parse","secret":"my-e2e-secret","token":"eyJhbGci..."}}]

// 校验（签名 + 过期）
[{"JWT":{"op":"verify","secret":"my-e2e-secret","token":"${extract.jwtToken}"}}]
```

### 2.2 OAuth2 两种授权模式
```json
// 密码模式（resource owner password credentials）
[{"OAUTH2":{"tokenUrl":"https://auth.example.com/oauth/token","grantType":"password",
            "username":"e2e-user","password":"secret","clientId":"e2e-client","clientSecret":"cs"}}]

// 客户端凭证模式（client credentials）
[{"OAUTH2":{"tokenUrl":"https://auth.example.com/oauth/token","grantType":"client_credentials",
            "clientId":"e2e-client","clientSecret":"cs","scope":"read write"}}]
```

## 3. 参数枚举

### 3.1 JWT 参数

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `op` | String | 是 | `generate` / `parse` / `verify` |
| `secret` | String | 是 | HMAC 密钥（<32 字节自动补齐） |
| `subject` | String | generate | 令牌主体（sub claim） |
| `claims` | Object | generate | 自定义 claims（任意键值） |
| `expireSeconds` | long | generate | 过期秒数（默认 3600） |
| `token` | String | parse/verify | JWT 字符串（支持 `${extract.jwtToken}`） |

### 3.2 OAuth2 参数

| 参数 | 类型 | 必填 | 枚举值/说明 |
|---|---|---|---|
| `tokenUrl` | String | 是 | 授权服务器 token 端点 |
| `grantType` | String | 否 | `password` / `client_credentials`（默认） |
| `clientId` / `clientSecret` | String | 是 | 客户端凭证 |
| `username` / `password` | String | password 模式 | 用户凭证 |
| `scope` | String | 否 | 授权范围（如 `read write`） |

## 4. 输出（outputs）枚举

| Action | key | 类型 | 说明 |
|---|---|---|---|
| JWT | `token` | String | 生成的 JWT（自动写入 `${extract.jwtToken}`） |
| JWT | `claims` | String | 解析出的 claims |
| JWT | `subject` | String | 解析出的 sub |
| JWT | `expired` | boolean | 是否已过期 |
| JWT | `valid` | boolean | 校验结果（true/false） |
| OAuth2 | `token` | String | access_token（自动写入 `${extract.oauthToken}`） |
| OAuth2 | `tokenType` | String | 如 "Bearer" |
| OAuth2 | `expiresIn` | int | 有效期秒数 |
| OAuth2 | `status` | int | token 端点状态码 |

## 5. 断言 + 自动变量注入（核心特性）

```json
// JWT generate 后：token 非空
[{"token":"","OP":"NOT_EMPTY","EXPECTED":[]}]

// JWT verify 后：校验通过
[{"valid":"","OP":"EQ","EXPECTED":["true"]}]

// JWT parse 后：claims 包含角色
[{"claims":"","OP":"CONTAINS","EXPECTED":["tester"]}]

// OAuth2 成功后：token 非空
[{"token":"","OP":"NOT_EMPTY","EXPECTED":[]}]
```

**自动变量注入**：generate/OAuth2 成功后框架自动执行：
- JWT → `ctx.setVar("jwtToken", token)`
- OAuth2 → `ctx.setVar("oauthToken", token)`

后续步骤直接引用（无需 EXTRACT）：
```json
[{"HTTP":{"url":"https://api.example.com/secure","method":"GET",
          "auth":{"type":"bearer","token":"${extract.oauthToken}"}}}]
```

## 6. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-AUTH-DEMO | 1 | JWT-GEN | TAP | COMMON_JWT_OPERATE | [] | `[{"JWT":{"op":"generate","secret":"e2e-secret","subject":"e2e-user","claims":{"role":"tester"},"expireSeconds":600}}]` | `[{"token":"","OP":"NOT_EMPTY","EXPECTED":[]}]` | `[{"name":"jwtToken","from":"token","path":""}]` | 15 | 0 | STOP | Y |
| E2E-AUTH-DEMO | 2 | JWT-PARSE | TAP | COMMON_JWT_OPERATE | JWT-GEN | `[{"JWT":{"op":"parse","secret":"e2e-secret","token":"${extract.jwtToken}"}}]` | `[{"subject":"","OP":"EQ","EXPECTED":["e2e-user"]},{"claims":"","OP":"CONTAINS","EXPECTED":["tester"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-AUTH-DEMO | 3 | JWT-VERIFY | TAP | COMMON_JWT_OPERATE | JWT-PARSE | `[{"JWT":{"op":"verify","secret":"e2e-secret","token":"${extract.jwtToken}"}}]` | `[{"valid":"","OP":"EQ","EXPECTED":["true"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-AUTH-DEMO | 4 | OAUTH2 | TAP | COMMON_OAUTH2_TOKEN | JWT-VERIFY | `[{"OAUTH2":{"tokenUrl":"${global.http_base_url}/oauth/token","grantType":"client_credentials","clientId":"e2e-client","clientSecret":"cs"}}]` | `[{"status":"","OP":"EQ","EXPECTED":["200"]}]` | `[{"name":"oauthToken","from":"token","path":""}]` | 30 | 0 | CONTINUE | Y |
| E2E-AUTH-DEMO | 5 | API-BEARER | TAP | COMMON_HTTP_REQUEST | OAUTH2 | `[{"HTTP":{"url":"${global.http_base_url}/secure","method":"GET","auth":{"type":"bearer","token":"${extract.oauthToken}"}}}]` | `[{"HTTP":"","OP":"EQ","EXPECTED":["200"]}]` | `[]` | 30 | 0 | CONTINUE | Y |

## 7. 常见问题（FAQ）

**Q1: JWT 和 OAuth2 该用哪个？**
A: 系统直接校验自签 JWT → COMMON_JWT_OPERATE；走标准授权服务器换 token → COMMON_OAUTH2_TOKEN。

**Q2: RS256 非对称算法支持吗？**
A: 当前仅 HMAC-SHA256（HS256）；RS256 需扩展（jjwt 支持公私钥，欢迎贡献）。

**Q3: token 过期了怎么测？**
A: generate 时 `expireSeconds: 1`，等待后 verify 断言 `valid EQ false`（或 parse 断言 `expired EQ true`）。

**Q4: OAuth2 demo 模式能拿到 token 吗？**
A: HTTP 桩返回回显 JSON（无标准 access_token 字段）→ 获取会失败。demo 下建议跳过 OAuth2 步骤（ON_FAILURE=CONTINUE）或仅验证请求发出（status EQ 200）。

**Q5: 密钥要写在 Excel 里吗？**
A: 生产环境建议用 `${global.jwt_secret}` 全局变量管理，避免敏感信息散落在用例中。
