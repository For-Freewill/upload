# 失败策略 / 重试 / 超时使用指南

> Steps 表 ON_FAILURE / RETRY / TIMEOUT 列 + Scenarios 表 Timeout 列

## 1. ON_FAILURE 五种策略

| 值 | 行为 | 适用场景 |
|---|---|---|
| `STOP` | 失败后终止后续步骤（级联 SKIPPED） | 关键路径步骤（默认） |
| `CONTINUE` | 失败后继续执行后续步骤 | 非关键检查项 |
| `RETRY` | 失败后重试（至少 1 次） | 偶发性失败 |
| `SCREENSHOT` | 失败截图后终止 | UI 自动化取证 |
| `SAVE_EVIDENCE` | 截图 + 保存全部 outputs 后终止 | 需要完整证据链 |

## 2. RETRY 列（步骤级重试次数）

| RETRY 值 | 行为 |
|---|---|
| `0` | 不重试（默认） |
| `N` | 失败后重试 N 次（最多执行 N+1 次） |

优先级：`RETRY 列 > e2e.retry.step-retry-default > 0`；`ON_FAILURE=RETRY` 时强制至少 1 次。

## 3. TIMEOUT 列（步骤级超时秒数）

| TIMEOUT 值 | 行为 |
|---|---|
| `0` | 使用默认 `e2e.executor.step-timeout-default-seconds`（180s） |
| `N` | N 秒超时，超时步骤标记 TIMEOUT |

## 4. 使用示例

### 4.1 STOP（默认）— 关键路径
```
STEP_ID: DB-INSERT, ON_FAILURE: STOP
失败 → 本步骤 FAILED，后续全部 SKIPPED
```

### 4.2 CONTINUE — 非关键检查
```
STEP_ID: LOG-CHECK, ON_FAILURE: CONTINUE
失败 → 本步骤 FAILED，后续继续执行
```

### 4.3 RETRY — 偶发性失败
```
STEP_ID: HTTP-POLL, RETRY: 3, ON_FAILURE: RETRY
失败 → 重试最多 3 次（共 4 次尝试），全部失败才标记 FAILED
```

### 4.4 SCREENSHOT — UI 失败取证
```
STEP_ID: UI-CHECKOUT, ON_FAILURE: SCREENSHOT
失败 → 截图保存到 test-output/screenshots/ → 后续 SKIPPED
```

### 4.5 场景级超时（Scenarios 表 Timeout 列）
```
Scenario: E2E-LONG-FLOW, Timeout: 600
超过 600 秒 → 场景标记 TIMEOUT
```

## 5. 完整步骤示例（Excel Steps 表）

| SEQ | STEP_ID | APP | ACTION | ON_FAILURE | RETRY | TIMEOUT | 说明 |
|---|---|---|---|---|---|---|---|
| 1 | HTTP-ORDER | TAP | COMMON_HTTP_REQUEST | STOP | 0 | 30 | 关键步骤，30s 超时 |
| 2 | DB-VERIFY | DNS | COMMON_DB_ASSERTIONS | STOP | 0 | 10 | 数据校验 |
| 3 | LOG-CHECK | DATAHUB | COMMON_WINDOWS_CMD | CONTINUE | 0 | 15 | 非关键，失败继续 |
| 4 | HTTP-POLL | TAP | COMMON_HTTP_REQUEST | RETRY | 3 | 60 | 偶发失败，重试 3 次 |
| 5 | UI-CONFIRM | DRP | COMMON_JAVA_INVOKE | SCREENSHOT | 0 | 30 | UI 失败截图 |

## 6. 全局配置（application.yml）

```yaml
e2e:
  executor:
    step-timeout-default-seconds: 180   # 步骤默认超时
  retry:
    scenario-retry-count: 0             # 场景级 TestNG 重试
    scenario-retry-delay-ms: 3000
    step-retry-default: 0               # 步骤默认重试
    step-retry-delay-ms: 1000
```

## 7. 场景级重试（TestNG IRetryAnalyzer）

```yaml
e2e:
  retry:
    scenario-retry-count: 1   # 场景失败后 TestNG 层重试 1 次
```

> 与步骤级 RETRY 区别：场景级是 TestNG 重新执行整个场景（所有步骤重新跑），步骤级是单步骤重试。

## 8. ENABLED 列（步骤/场景级开关）

| ENABLED 值 | 行为 |
|---|---|
| `Y`（默认） | 正常执行 |
| `N` | 跳过（步骤级/场景级） |

场景级 `Enabled=N` → 整个场景 SKIPPED；步骤级 `Enabled=N` → 该步骤 SKIPPED。
依赖被禁用步骤的下游步骤自动降级为根节点执行（记录 DataQuality 告警）。
