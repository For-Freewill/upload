# MongoDB 文档库使用指南（COMMON_NOSQL_EXECUTE / COMMON_NOSQL_ASSERT）

> Action: `SMARTS:COMMON_NOSQL_EXECUTE`（操作）/ `SMARTS,DNS:COMMON_NOSQL_ASSERT`（断言）| 协议键: `MONGO` | 实现: demo 内存文档库 / live mongodb-driver

## 1. 前置环境配置

### 1.1 运行环境
| 项目 | demo 模式 | live 模式 |
|---|---|---|
| MongoDB | ❌ 不需要（内存文档库） | ✅ 需要 MongoDB 3.6+ |
| 依赖 | 框架内置 | 框架内置（mongodb-driver-sync 5.x） |

### 1.2 application.yml 配置（live 模式）
```yaml
e2e:
  nosql:
    uri: mongodb://localhost:27017     # 连接 URI（副本集：mongodb://host1,host2/?replicaSet=rs0）
    database: e2e                      # 默认数据库
```

### 1.3 demo / live 行为差异
| 模式 | 行为 |
|---|---|
| demo | 进程内存文档库：insert/find/update/delete/count 全语义（等值 filter） |
| live | mongodb-driver 真实操作（filter 支持 MongoDB 完整查询语法） |

> demo 模式的 filter 仅支持等值匹配；live 模式支持 `$gt`/`$in`/正则等完整语法。

## 2. INPUT 格式

### 2.1 COMMON_NOSQL_EXECUTE（数据操作）
```json
[{"MONGO":{"op":"insert","collection":"orders","docs":[{"id":1,"status":"CREATED"}]}}]
[{"MONGO":{"op":"find","collection":"orders","filter":{"status":"CREATED"}}}]
```

### 2.2 COMMON_NOSQL_ASSERT（断言查询，INPUT + ASSERT 联合）
```json
INPUT:  [{"MONGO":{"collection":"orders","filter":{"id":1}}}]
ASSERT: [{"docCount":"","OP":"EQ","EXPECTED":["1"]}]
```

## 3. 参数枚举

### 3.1 op 操作枚举（COMMON_NOSQL_EXECUTE，5 种）

| op | 必填参数 | 说明 |
|---|---|---|
| `insert` | collection, docs | 批量插入文档 |
| `find` | collection, filter（可选） | 查询文档（上限 1000 条） |
| `update` | collection, filter, update | 批量更新（update 为 `{"$set":{...}}` 表达式） |
| `delete` | collection, filter（可选） | 批量删除 |
| `count` | collection, filter（可选） | 计数 |

### 3.2 通用参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `collection` | String | 是 | 集合名 |
| `filter` | Object | 否 | 查询条件（demo 仅等值；live 完整语法） |
| `docs` | Array | insert 时 | 文档数组 |
| `update` | Object | update 时 | 更新表达式（`$set` 等） |

## 4. 输出（outputs）枚举

| key | 出现的 Action/op | 类型 | 说明 |
|---|---|---|---|
| `docs` | EXECUTE:find / ASSERT | List\<Object\> | 匹配文档列表 |
| `docCount` | EXECUTE:find / ASSERT | int | 匹配文档数 |
| `insertedCount` | EXECUTE:insert | int | 插入数 |
| `matchedCount` / `modifiedCount` | EXECUTE:update | long | 匹配/修改数 |
| `deletedCount` | EXECUTE:delete | long | 删除数 |
| `count` | EXECUTE:count | long | 计数 |
| `firstDoc` | ASSERT | String | 首个文档 JSON（CONTAINS 断言用） |

## 5. 断言示例

```json
// 文档数
[{"docCount":"","OP":"EQ","EXPECTED":["1"]}]

// 首文档字段值（JSONPath）
[{"firstDoc":"$.status","OP":"EQ","EXPECTED":["CREATED"]}]

// 首文档包含
[{"firstDoc":"","OP":"CONTAINS","EXPECTED":["alice"]}]

// 文档列表包含
[{"docs":"","OP":"CONTAINS","EXPECTED":["bob"]}]
```

## 6. EXTRACT 示例

```json
[{"name":"firstUserName","from":"firstDoc","path":"$.name"}]
```
后续步骤引用：`${extract.firstUserName}`

## 7. 完整测试案例

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-MONGO-DEMO | 1 | MG-INSERT | SMARTS | COMMON_NOSQL_EXECUTE | [] | `[{"MONGO":{"op":"insert","collection":"e2e_users","docs":[{"id":1,"name":"alice"},{"id":2,"name":"bob"}]}}]` | `[{"insertedCount":"","OP":"EQ","EXPECTED":["2"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-MONGO-DEMO | 2 | MG-ASSERT | DNS | COMMON_NOSQL_ASSERT | MG-INSERT | `[{"MONGO":{"collection":"e2e_users","filter":{"id":1}}}]` | `[{"docCount":"","OP":"EQ","EXPECTED":["1"]},{"firstDoc":"","OP":"CONTAINS","EXPECTED":["alice"]}]` | `[{"name":"userName","from":"firstDoc","path":"$.name"}]` | 15 | 0 | STOP | Y |
| E2E-MONGO-DEMO | 3 | MG-UPDATE | SMARTS | COMMON_NOSQL_EXECUTE | MG-ASSERT | `[{"MONGO":{"op":"update","collection":"e2e_users","filter":{"id":1},"update":{"$set":{"status":"active"}}}}]` | `[{"matchedCount":"","OP":"EQ","EXPECTED":["1"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-MONGO-DEMO | 4 | MG-VERIFY | DNS | COMMON_NOSQL_ASSERT | MG-UPDATE | `[{"MONGO":{"collection":"e2e_users","filter":{"id":1}}}]` | `[{"firstDoc":"$.status","OP":"EQ","EXPECTED":["active"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-MONGO-DEMO | 5 | MG-CLEANUP | SMARTS | COMMON_NOSQL_EXECUTE | MG-VERIFY | `[{"MONGO":{"op":"delete","collection":"e2e_users","filter":{}}}]` | `[{"deletedCount":"","OP":"GTE","EXPECTED":["2"]}]` | `[]` | 15 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: filter 里的 `_id` ObjectId 怎么写？**
A: live 模式：`{"_id":{"$oid":"65f..."}}`（标准扩展 JSON）。

**Q2: demo 模式 filter 支持范围查询吗？**
A: 不支持（仅等值）。范围查询用 `find` 后对 `docs` 做断言，或切 live 模式。

**Q3: EXECUTE 和 ASSERT 用哪个查数据？**
A: 查数据 + 断言用 ASSERT（输出 docCount/firstDoc 面向断言设计）；纯数据准备/清理用 EXECUTE。

**Q4: find 上限？**
A: 1000 条（防止大集合拖垮报告）。需要更多用 `count` 先验证总量。

**Q5: 副本集/认证连接？**
A: URI 里配全：`mongodb://user:pwd@host1:27017,host2:27017/?replicaSet=rs0&authSource=admin`。
