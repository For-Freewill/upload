# JAVA 反射调用 + UI 自动化使用指南

> Action: `SMARTS:COMMON_JAVA_INVOKE` / `DRP:COMMON_JAVA_INVOKE` / `DRP:DRP_UI_REPORTS`

## 1. COMMON_JAVA_INVOKE 三种调用模式

### 1.1 Spring Bean 调用（bean + method + params）
```json
[{"JAVA":{"bean":"uiAutomationService","method":"navigateTo","params":["https://www.baidu.com"]}}]
```

### 1.2 静态方法调用（class + method + params）
```json
[{"JAVA":{"class":"java.lang.System","method":"getProperty","params":["user.home"]}}]
```

### 1.3 Playwright 页面方法（engine + method + params）
```json
[{"JAVA":{"engine":"playwright","method":"navigate","params":["https://www.baidu.com"]}}]
```

## 2. 参数类型

自动推断：String / Integer / Long / Double / Boolean / JSONObject / JSONArray

可选 `paramTypes` 精确指定：
```json
[{"JAVA":{"class":"java.lang.Math","method":"max","params":[10,20],"paramTypes":["int","int"]}}]
```

| paramTypes | Java 类型 |
|---|---|
| `string` | String |
| `int` / `integer` | int |
| `long` | long |
| `double` | double |
| `boolean` / `bool` | boolean |
| `object` | JSONObject |
| `array` | JSONArray |
| 全限定类名 | Class.forName |

## 3. 输出（outputs）

| key | 说明 |
|---|---|
| `JAVA` | 固定 "OK" |
| `result` | 方法返回值 |
| `method` | 调用的方法名 |
| `target` | 目标类名 |
| `resultType` | 返回值类型 |

## 4. 内置 UI 自动化服务（UiAutomationService）

Spring Bean 名：`uiAutomationService`，封装 Playwright 常用操作：

| 方法 | 参数 | 返回 | 说明 |
|---|---|---|---|
| `navigateTo(url)` | URL | `{status, url, title}` | 导航到页面 |
| `inputText(selector, text)` | CSS选择器, 文本 | `{status, selector, text}` | 填充输入框 |
| `clickElement(selector)` | CSS选择器 | `{status, selector}` | 点击元素 |
| `getElementText(selector)` | CSS选择器 | `{status, selector, text}` | 获取元素文本 |
| `getPageTitle()` | 无 | `{status, title}` | 获取页面标题 |
| `waitForElement(selector, timeoutMs)` | 选择器, 超时 | `{status, selector}` | 等待元素出现 |
| `takeScreenshot(fileName)` | 文件名 | `{status, screenshotPath}` | 全页截图 |

> demo 模式返回 `status=skipped`（不抛异常）；live 模式执行真实浏览器操作

## 5. 完整用例示例

### 5.1 静态方法 + 断言 + 提取
```
INPUT:   [{"JAVA":{"class":"java.lang.System","method":"getProperty","params":["user.home"]}}]
ASSERT:  [{"result":"","OP":"NOT_EMPTY","EXPECTED":[]}]
EXTRACT: [{"name":"userHome","from":"result","path":""}]
```

### 5.2 带类型参数的静态方法
```
INPUT:   [{"JAVA":{"class":"java.lang.Math","method":"max","params":[10,20],"paramTypes":["int","int"]}}]
ASSERT:  [{"result":"","OP":"EQ","EXPECTED":["20"]}]
```

### 5.3 UI 自动化完整流程（百度搜索）
```
Step 1 - 导航:
  INPUT:  [{"JAVA":{"bean":"uiAutomationService","method":"navigateTo","params":["https://www.baidu.com"]}}]
  ASSERT: [{"result":"","OP":"NOT_EMPTY","EXPECTED":[]}]

Step 2 - 输入:
  INPUT:  [{"JAVA":{"bean":"uiAutomationService","method":"inputText","params":["#kw","E2E自动化测试"]}}]

Step 3 - 点击:
  INPUT:  [{"JAVA":{"bean":"uiAutomationService","method":"clickElement","params":["#su"]}}]

Step 4 - 获取标题:
  INPUT:  [{"JAVA":{"bean":"uiAutomationService","method":"getPageTitle","params":[]}}]
  ASSERT: [{"result":"","OP":"NOT_EMPTY","EXPECTED":[]}]
  EXTRACT: [{"name":"pageTitle","from":"result","path":"title"}]

Step 5 - 截图:
  INPUT:  [{"JAVA":{"bean":"uiAutomationService","method":"takeScreenshot","params":["baidu-search"]}}]
```

### 5.4 Playwright 直接反射（绕过 UiAutomationService）
```
INPUT: [{"JAVA":{"engine":"playwright","method":"navigate","params":["https://example.com"]}}]
INPUT: [{"JAVA":{"engine":"playwright","method":"fill","params":["#username","admin"]}}]
INPUT: [{"JAVA":{"engine":"playwright","method":"click","params":["#login-btn"]}}]
INPUT: [{"JAVA":{"engine":"playwright","method":"textContent","params":["#welcome"]}}]
```

## 6. 自定义 Java 方法接入

### 6.1 编写 Spring Bean
```java
@Component("myBusinessService")
public class MyBusinessService {
    public Map<String, Object> createOrder(String orderId, int amount) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("orderId", orderId);
        result.put("amount", amount);
        result.put("status", "CREATED");
        return result;
    }
}
```

### 6.2 通过 COMMON_JAVA_INVOKE 调用
```json
[{"JAVA":{"bean":"myBusinessService","method":"createOrder","params":["ORD-001",100],"paramTypes":["string","int"]}}]
```

### 6.3 断言返回值
```json
[{"result":"","OP":"CONTAINS","EXPECTED":["CREATED","ORD-001"]}]
```

## 7. 向后兼容：UiAction 处理器

当 INPUT 包含 `url` 字段时，回退到 UiAction 处理器查找：
```json
[{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":{"action":"navigate","target":"/reports"}}}]
```

## 8. 注意事项

- **Playwright 需要 live 模式**：`e2e.mode=live` + 浏览器已安装
- **Bean 名必须已注册**：`bean` 字段指向的 Spring Bean 必须存在
- **方法查找**：按方法名 + 参数数量 + 类型兼容匹配；可用 `paramTypes` 消除重载歧义
- **异常处理**：方法抛异常时步骤 FAILED，异常信息进入 message
