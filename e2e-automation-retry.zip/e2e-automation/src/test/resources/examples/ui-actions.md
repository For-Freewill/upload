# UI 操作使用指南（DRP_UI_REPORTS / 104_UI_BOOK / 109_UPLOAD / COMMON_JAVA_INVOKE）

> Actions: `DRP:DRP_UI_REPORTS` / `SMARTS:104_UI_BOOK` / `SMARTS:109_UPLOAD`
> 底层：JAVA 协议 → AbstractUiAction 三层路由（UiHandler / Playwright 反射 / 子类自定义）

## 1. UI Action 总览

| Action | APP | 业务场景 | 推荐载荷 |
|---|---|---|---|
| `DRP_UI_REPORTS` | DRP | 报表浏览验证 | `url`（UiHandler）或 `engine`（Playwright） |
| `104_UI_BOOK` | SMARTS | 104 报文 BOOK 预订 | `url`（UiHandler） |
| `109_UPLOAD` | SMARTS | 109 报文上传 | `url`（UiHandler） |
| `COMMON_JAVA_INVOKE` | SMARTS / DRP | 通用反射（Bean/静态/Playwright） | `bean` / `class` / `engine` |

## 2. INPUT 格式（三种路由方式）

### 2.1 UiHandler 处理器（url 字段）— 向后兼容
```json
[{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":{"action":"navigate","target":"/reports/daily"}}}]
```
> `url` 为 `@UiHandler` 注册名；`params` 透传给处理器

### 2.2 Playwright 反射（engine 字段）— 直连浏览器
```json
[{"JAVA":{"engine":"playwright","method":"navigate","params":["https://example.com"]}}]
[{"JAVA":{"engine":"playwright","method":"fill","params":["#search","keyword"]}}]
[{"JAVA":{"engine":"playwright","method":"click","params":["#submit"]}}]
```

### 2.3 UiAutomationService Bean（bean 字段）— 封装好的 UI 操作
```json
[{"JAVA":{"bean":"uiAutomationService","method":"navigateTo","params":["https://www.baidu.com"]}}]
```

## 3. 常用 Playwright 方法（engine 模式）

| 方法 | 参数 | 说明 |
|---|---|---|
| `navigate(url)` | URL | 导航 |
| `fill(selector, text)` | 选择器, 文本 | 填充输入框 |
| `click(selector)` | 选择器 | 点击 |
| `textContent(selector)` | 选择器 | 获取元素文本 |
| `title()` | 无 | 页面标题 |
| `waitForSelector(selector, options)` | 选择器, 选项 | 等待元素 |
| `screenshot(options)` | 选项 | 截图 |

## 4. UiAutomationService 方法（bean 模式）

| 方法 | 参数 | 返回 |
|---|---|---|
| `navigateTo(url)` | URL | `{status, url, title}` |
| `inputText(selector, text)` | 选择器, 文本 | `{status, selector, text}` |
| `clickElement(selector)` | 选择器 | `{status, selector}` |
| `getElementText(selector)` | 选择器 | `{status, selector, text}` |
| `getPageTitle()` | 无 | `{status, title}` |
| `waitForElement(selector, timeoutMs)` | 选择器, 超时 | `{status, selector}` |
| `takeScreenshot(fileName)` | 文件名 | `{status, screenshotPath}` |

## 5. 完整 UI 自动化流程示例

### 5.1 DRP 报表验证（UiHandler）
```
Step 1: DRP:DRP_UI_REPORTS（导航到报表页）
  INPUT:  [{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":{"action":"navigate","target":"/reports/daily"}}}]
  ASSERT: [{"JAVA":"","OP":"EQ","EXPECTED":["OK"]}]

Step 2: SMARTS:104_UI_BOOK（点击报表 Tab）
  INPUT:  [{"JAVA":{"url":"automation.qa.e2e.uiaction1","params":{"action":"click","target":"report-tab-104"}}}]
  ASSERT: [{"JAVA":"","OP":"EQ","EXPECTED":["OK"]}]
```

### 5.2 百度搜索（Playwright 直连）
```
Step 1: DRP:COMMON_JAVA_INVOKE — 导航
  INPUT:  [{"JAVA":{"engine":"playwright","method":"navigate","params":["https://www.baidu.com"]}}]

Step 2: DRP:COMMON_JAVA_INVOKE — 输入
  INPUT:  [{"JAVA":{"engine":"playwright","method":"fill","params":["#kw","E2E自动化测试"]}}]

Step 3: DRP:COMMON_JAVA_INVOKE — 点击搜索
  INPUT:  [{"JAVA":{"engine":"playwright","method":"click","params":["#su"]}}]

Step 4: DRP:COMMON_JAVA_INVOKE — 获取标题
  INPUT:  [{"JAVA":{"engine":"playwright","method":"title","params":[]}}]
  ASSERT: [{"result":"","OP":"CONTAINS","EXPECTED":["百度"]}]
  EXTRACT: [{"name":"pageTitle","from":"result","path":""}]
```

### 5.3 登录 + 预订 + 校验（UiAutomationService）
```
Step 1: navigateTo → https://app.example.com/login
Step 2: inputText → #username, admin
Step 3: inputText → #password, secret123
Step 4: clickElement → #login-btn
Step 5: waitForElement → #dashboard, 5000
Step 6: getPageTitle → 断言标题
Step 7: takeScreenshot → login-success（保存证据）
```

## 6. 自定义 UiHandler 接入

```java
@UiHandler("my.custom.page.action")
@Component
public class MyPageAction implements UiAction {
    @Override
    public Map<String, Object> execute(String params) {
        // params 为 INPUT 中 params 字段的字符串
        // 封装 Selenium / Playwright 真实页面操作
        Map<String, Object> outputs = new LinkedHashMap<>();
        outputs.put("result", "operation-completed");
        return outputs;
    }
}
```

Excel 引用：
```json
[{"JAVA":{"url":"my.custom.page.action","params":{"action":"click","target":"#btn"}}}]
```

## 7. 输出（outputs）

| key | 说明 |
|---|---|
| `JAVA` | 固定 "OK" |
| `result` | 方法返回值（engine/bean 模式） |
| UiHandler 的输出 | 处理器返回的 Map 键值 |

## 8. 注意事项

- **demo 模式**：UiHandler 走桩；engine（Playwright）不可用返回错误
- **live 模式**：Playwright 需浏览器安装（`mvn exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"`）
- **页面复用**：PlaywrightUiEngine 会话内单页面复用（跨步骤保持登录态）
- **截图证据**：`ON_FAILURE=SCREENSHOT` 自动截图失败现场
