# DB SQL 执行使用指南（COMMON_DB_EXECUTE）

> Action: `SMARTS:COMMON_DB_EXECUTE` / `STP:COMMON_DB_EXECUTE` | 协议键: `DB` | 双驱动: JDBC / MyBatis-Plus

## 1. 前置环境配置

### 1.1 数据源配置（application.yml）
```yaml
e2e:
  mode: live                       # demo=桩；live=真实数据源
  db:
    mode: mysql                    # 数据源模式（demo 时内嵌 H2 可用）
    driver: jdbc                   # jdbc | mybatis-plus
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/e2e_db?useSSL=false&serverTimezone=Asia/Shanghai
    username: e2e
    password: "your-password"
    driver-class-name: com.mysql.cj.jdbc.Driver
```

### 1.2 驱动枚举
| 驱动 | 配置值 | 说明 |
|---|---|---|
| 原生 JDBC | `e2e.db.driver: jdbc` | PreparedStatement 直接执行（默认） |
| MyBatis-Plus | `e2e.db.driver: mybatis-plus` | SqlSession 动态 statement（适合已有 MP 环境） |

### 1.3 demo / live 行为差异
| 模式 | 行为 |
|---|---|
| demo | StubDbClient：记录 SQL 不执行，返回模拟行 |
| live | 真实执行（JDBC 或 MP），DDL/DML 均可 |

## 2. INPUT 格式

### 2.1 单条 SQL
```json
[{"DB":"CREATE TABLE IF NOT EXISTS e2e_demo (id INT, name VARCHAR(50))"}]
```

### 2.2 批量 SQL（数组，按序执行）
```json
[{"DB":[
  "CREATE TABLE IF NOT EXISTS e2e_orders (id INT, status VARCHAR(20), amount DECIMAL(10,2))",
  "INSERT INTO e2e_orders VALUES (1, 'CREATED', 100.50)",
  "INSERT INTO e2e_orders VALUES (2, 'SHIPPED', 200.00)",
  "UPDATE e2e_orders SET status='COMPLETED' WHERE id=1"
]}]
```

## 3. 参数枚举

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `DB` | String / String[] | 是 | 单条 SQL 或 SQL 数组（DDL/DML/查询均可，按序执行） |

SQL 中支持变量：`${global.x}` / `${extract.x}` / `${env.x}`。

## 4. 输出（outputs）枚举

| key | 类型 | 说明 |
|---|---|---|
| `DB` | List\<Integer\> | 每条语句的影响行数（DDL 返回 0） |
| `affectedRows` | int | 总影响行数 |

## 5. 断言示例

```json
// 影响行数
[{"affectedRows":"","OP":"EQ","EXPECTED":["3"]}]

// 数据校验（配合 COMMON_DB_ASSERTIONS，见 assertions-guide.md）
[{"DB":"SELECT status FROM e2e_orders WHERE id=1","OP":"EQ","EXPECTED":["COMPLETED"]}]
```

## 6. EXTRACT 示例

COMMON_DB_EXECUTE 本身主要做数据准备/变更；查询提取用 COMMON_DB_ASSERTIONS 步骤：
```json
ASSERT:  [{"DB":"SELECT id,name FROM orders WHERE id=1","OP":"EQ","EXPECTED":["order-001"]}]
EXTRACT: [{"name":"orderName","from":"DB_ROWS","path":"[0].name"}]
```

## 7. 完整测试案例（准备 → 断言 → 清理三段式）

| Scenario_ID | SEQ | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E2E-DB-DEMO | 1 | DB-SETUP | SMARTS | COMMON_DB_EXECUTE | [] | `[{"DB":["CREATE TABLE IF NOT EXISTS e2e_t (id INT, name VARCHAR(50))","INSERT INTO e2e_t VALUES (1,'alice'),(2,'bob')"]}]` | `[{"affectedRows":"","OP":"GTE","EXPECTED":["2"]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-DB-DEMO | 2 | DB-ASSERT | DNS | COMMON_DB_ASSERTIONS | DB-SETUP | `[]` | `[{"DB":"SELECT id,name FROM e2e_t","OP":"EQ","EXPECTED":[{"id":"1","name":"alice"},{"id":"2","name":"bob"}]}]` | `[]` | 15 | 0 | STOP | Y |
| E2E-DB-DEMO | 3 | DB-CLEANUP | SMARTS | COMMON_DB_EXECUTE | DB-ASSERT | `[{"DB":"DROP TABLE e2e_t"}]` | `[]` | `[]` | 15 | 0 | STOP | Y |

## 8. 常见问题（FAQ）

**Q1: Map 模式断言怎么写？**
A: EXPECTED 为 JSON 对象数组：`[{"DB":"SELECT id,name FROM t","OP":"EQ","EXPECTED":[{"id":"1","name":"alice"}]}]`（行集合完全匹配，忽略行序）。详见 assertions-guide.md。

**Q2: 异步数据怎么断言？**
A: `OP:WAIT_UNTIL` 轮询：`{"DB":"SELECT status FROM t WHERE id=1","OP":"WAIT_UNTIL","EXPECTED":["DONE"],"TIMEOUT":30,"POLL_INTERVAL":2000}`。

**Q3: 批量 SQL 中间失败怎么办？**
A: 当前无事务回滚（逐条独立执行）；失败步骤按 ON_FAILURE 处理，建议清理步骤独立设 CONTINUE。

**Q4: 跨环境比对（prod vs pre-prod）？**
A: 用 `COMMON_DATA_COMPARE`（见 data-compare.md），支持 env 命名环境连接。

**Q5: demo 模式 SQL 断言能过吗？**
A: StubDbClient 返回模拟行；设计断言时 demo 场景用宽松断言（NOT_EMPTY/EXIT），数据级断言留给 live。
