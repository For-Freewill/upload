# E2E Test Automation Framework

> A data-driven end-to-end test automation framework built on Java 17 + Spring Boot 4 + TestNG 7, designed around the principle of **data-driven test cases + pluggable action registration**.

## Overview

This framework fully decouples test case data from execution code: complete test scenarios are described in Excel templates (Scenarios / Steps / _GlobalConfig sheets), and adding new test cases requires only adding data rows — zero code changes. Each APP domain's single-point operations (ACTIONs) are auto-registered via the `@ActionSpec` annotation, making it trivial to add new APPs and actions.

### Core Capabilities

| Feature | Description |
|---|---|
| Data-Driven | Excel/YAML dual data sources; Scenarios + Steps + GlobalConfig sheets describe complete test cases |
| Action SPI | `@ActionSpec(apps, action)` + `AppAction` interface; Spring auto-scans and registers (24 built-in actions, 31 registrations) |
| DAG Scheduling | DEPENDS_ON dependency graph with layered topological sort; supports intra-layer parallelism |
| Scenario Context | `ScenarioExecutionContext` manages variable storage, step history, and cross-step variable passing within scenario lifetime |
| Variable Engine | `${global.}` / `${extract.}` / `${env.}` placeholders; EXTRACT dual mode (extraction + literal scenario params) |
| Assertion Engine | String/FIELD/Map modes + JSONPath/XPath dual routing (prefix auto + explicit source) + 14 operators |
| Timeout & Retry | Step-level timeout + retry (RETRY column / ON_FAILURE=RETRY) + scenario-level TestNG IRetryAnalyzer |
| Failure Strategy | STOP / CONTINUE / SCREENSHOT / RETRY / SAVE_EVIDENCE — five modes |
| Async Assertions | Awaitility-based WAIT_UNTIL polling — for MQ async consumption / DB eventual consistency |
| Protocol Layer | DB(JDBC+MyBatis-Plus) / HTTP / MQ(send+consume loop) / SSH / SFTP / FTP / CMD / FILE / REDIS / MONGODB / MAIL / WEBHOOK / WEBSOCKET / JWT / OAUTH2 / DATACOMPARE(cross-env) / JAVA reflection / UI(Playwright) |
| Demo/Live Dual Mode | Demo mode with built-in stubs runs out-of-the-box (Redis/Mongo/WebSocket in-memory); live mode switches to real protocol connections |
| AI Hooks | TestCaseGenerator / ReportInterpreter / StepOptimizer / AnomalyDetector — four SPI extension points |
| Reporting | HTML + JSON reports with pie chart, summary table, DAG diagrams, step details, data quality hints |

### Technology Stack

| Component | Technology | Version |
|---|---|---|
| Runtime | Java | 17 |
| Framework | Spring Boot | 4.1.1 |
| Testing | TestNG | 7.12.0 |
| Excel | EasyExcel | 4.0.3 |
| JSON | fastjson2 | 2.0.65 |
| HTTP | REST Assured | 5.5.7 |
| UI | Playwright | 1.63.0 |
| Database | MyBatis-Plus / Native JDBC | 3.5.17 |
| SSH/SFTP | JSch | 2.28.8 |
| FTP | commons-net | 3.11.1 |
| Mail | angus-mail (jakarta.mail) | 2.0.3 |
| Redis | Jedis | 5.2.0 |
| MongoDB | mongodb-driver-sync | 5.2.0 |
| JWT | jjwt | 0.12.6 |
| JSONPath | jayway json-path | 2.9.0 |
| Async | Awaitility | 4.3.0 |

---

## Quick Start

### Prerequisites
- JDK 17+
- Maven 3.9+

### Three Ways to Run

#### Option 1: IDE Right-Click Run (Recommended for Testers)

Open `E2ETestRunner.java` in your IDE (IntelliJ IDEA / Eclipse), right-click → Run:

```
File location: src/test/java/com/e2e/test/E2ETestRunner.java
```

This automatically executes the `main()` method:
1. Bootstraps Spring context
2. Loads all enabled scenarios (default from `classpath:cases/E2E-Test-Scenarios.xlsx`)
3. Executes each scenario
4. Generates `test-output/test_report.html`
5. Prints summary to console (passed/failed/skipped/duration)

#### Option 2: Maven Command Line

```bash
# Full suite (includes Excel generator + tests + DB driver verification)
mvn clean test

# Framework core unit tests (99 tests: assertion engine / parsers / variable engine / DAG / path, no Spring)
mvn clean test -Dsurefire.suiteXmlFiles=src/test/resources/testng/testng-unit.xml

# Run E2ETestRunner only (standalone entry, bypasses testng.xml)
mvn exec:java -Dexec.mainClass=com.e2e.test.E2ETestRunner -Dexec.classpathScope=test

# Specify external Excel data source
mvn clean test -De2e.data.excel.path=file:C:/my-test-cases.xlsx

# Switch to YAML data source
mvn clean test -De2e.data.source=yaml

# Switch to live mode (real protocol connections)
mvn clean test -De2e.mode=live \
        -De2e.db.mode=LIVE \
        -De2e.db.driver=mybatis-plus \
        -Dspring.datasource.url="jdbc:h2:mem:test;DB_CLOSE_DELAY=-1" \
        -Dspring.datasource.driver-class-name=org.h2.Driver
```

#### Option 3: Command Line Direct Execution

```bash
# Compile then run directly
mvn clean test-compile
java -cp target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DforceStdout) \
     com.e2e.test.E2ETestRunner
```

### Generate Excel Test Case File

```bash
# Generate E2E-Test-Scenarios.xlsx (22 scenarios / 105 steps / 9 global variables, S14 disabled)
mvn test -Dsurefire.suiteXmlFiles=testng-gen.xml

# Output: src/test/resources/cases/E2E-Test-Scenarios.xlsx
```

### Generate Global Scenario DAG Report

```bash
# Generate Global_Scenarios_Dag_Report.html (topology DAG only, no test execution)
mvn test -Dsurefire.suiteXmlFiles=testng-global-dag.xml

# Output: test-output/Global_Scenarios_Dag_Report.html
```

This report loads scenario definitions directly from Excel and renders a DAG topology diagram for each scenario (nodes=seq-APP, edges=dependency arrows), useful for previewing all scenario dependency structures before execution.

### Report Files

| Report File | Generated When | Content |
|---|---|---|
| `test-output/test_report.html` | When tests are executed | Sidebar navigation + summary table + pie chart + DAG diagrams + step details |
| `test-output/test_report.json` | When tests are executed | JSON format complete results |
| `test-output/Global_Scenarios_Dag_Report.html` | When global-dag is run separately | All scenarios' topology DAG (card layout, APP-domain colored) |

---

## ScenarioExecutionContext

### Overview

`ScenarioExecutionContext` is the complete shared state during scenario execution. Its lifecycle is tied to a single scenario execution — created when the scenario starts, garbage-collected when it ends. Contexts from different scenarios are completely isolated and cannot share data.

### Architecture

```
ScenarioExecutor.doExecute()
  │
  ├── Create ScenarioExecutionContext (scenario-scoped, lifecycle = scenario execution)
  │     │
  │     ├── Variable Storage extractVars (ConcurrentHashMap)
  │     │     └── Step A → ctx.putExtract("x", value)  ← write variable
  │     │     └── Step B → ${extract.x} reference         ← read variable
  │     │
  │     ├── Step History stepHistory (ConcurrentHashMap<stepId, StepResult>)
  │     │     └── After each step → ctx.recordStepResult(result)
  │     │     └── Subsequent steps → ctx.getStepResult(stepId)
  │     │
  │     ├── Step Timeline stepStartTimes
  │     │     └── ctx.markStepStart(stepId)
  │     │
  │     ├── Abort Control aborted (volatile)
  │     │     └── STOP strategy → ctx.abort() → subsequent steps auto-skipped
  │     │
  │     └── Lifecycle startTime / endTime
  │           └── ctx.markEnd() → scenario ends, context eligible for GC
  │
  └── GC collected (different scenario contexts fully isolated)
```

### Using Context in Actions

Actions access the full `ScenarioExecutionContext` via `ActionContext`:

```java
@Override
public ActionResult execute(ActionContext ctx) {
    // ① Protocol parameters
    JSONObject params = ctx.jsonParams("HTTP");
    String url = params.getString("url");

    // ② Scenario-level variable read/write (EXTRACT, cross-step passing)
    ctx.setVar("orderId", "123");                    // write variable
    String prevId = ctx.getVar("orderId");            // read variable from previous step
    Integer code = ctx.getVar("httpCode", Integer.class); // with type conversion

    // ③ Previous step queries
    StepResult prev = ctx.getStepResult("HTTP-POST-SEND");       // get previous step result
    Object status = ctx.getStepOutput("HTTP-POST-SEND", "status"); // get previous step output
    boolean done = ctx.isStepCompleted("DB-INSERT-LOG");          // check if previous step passed

    // ④ Protocol clients
    ctx.clients().http().execute(spec);
    ctx.clients().db().query(sql);

    // ⑤ Return result (outputs available for ASSERT / EXTRACT)
    return ActionResult.ok("Success", Map.of("status", 200));
}
```

### Variable Flow Example

```
┌─────────────────────────────────────────────────────────────────┐
│ ScenarioExecutionContext (scenario-scoped, alive during execution) │
│                                                                 │
│  Step 1: TAP:COMMON_HTTP_REQUEST                                  │
│    → ctx.setVar("httpStatus", 200)           ← Action writes    │
│    → return ActionResult.ok(outputs={"status":200})            │
│    → ctx.recordStepResult(result)             ← Engine records  │
│                                                                 │
│  Step 2: SMARTS:COMMON_DB_EXECUTE (depends on Step 1)          │
│    → INPUT ${extract.httpStatus} → "200"     ← Variable engine  │
│    → ctx.getStepOutput("STEP-1", "status") → 200  ← Query output │
│    → ctx.isStepCompleted("STEP-1") → true       ← Check status   │
│                                                                 │
│  Step 3: SMARTS:COMMON_DB_ASSERTIONS (depends on Step 2)       │
│    → ctx.getVar("httpStatus") → 200           ← Variable visible  │
│    → ASSERT: DB SELECT ... OP=EQ EXPECTED=["200"]              │
│                                                                 │
│  Scenario ends → ctx.markEnd() → context GC collected           │
└─────────────────────────────────────────────────────────────────┘
```

### Lifecycle Guarantees

- Each Scenario creates an **independent** `ScenarioExecutionContext` in `doExecute()`
- `ctx.markEnd()` is called when execution completes, then GC collects it
- **Different Scenario contexts are fully isolated** — no cross-scenario data leakage
- Thread-safe: `ConcurrentHashMap` + `volatile`, supports DAG intra-layer parallel step writes

### EXTRACT Dual Mode (Extraction / Scenario Params)

```json
// Mode 1: Extraction (from + path, prefix-routed across five engines)
[{"name":"orderId","from":"body","path":"$.data.orderId"}]       // JSONPath
[{"name":"side","from":"firstMessage","path":"//trade/side"}]    // XPath
[{"name":"price","from":"STDOUT","path":"regex:price=([\\d.]+)"}]  // Regex
[{"name":"cfg","from":"FILE","path":"app.cfg#L3"}]               // File line
[{"name":"acct","from":"DB_ROWS","path":"[0].ACCT_NO"}]          // Token navigation

// Mode 2: Literal (value) — scenario-level param setup ⭐
[{"name":"acct","value":"999999"},
 {"name":"bizRef","value":"ACCT-${extract.acct}"}]   // combined variables supported
```

> Typical literal usage: define common params (acct/branchCode) in the first step's EXTRACT,
> then reference `${extract.acct}` in all subsequent steps' INPUT/ASSERT for parameterized passing.
> See [extract-variables.md](src/test/resources/examples/extract-variables.md) for details.

### Assertion Path Dual Routing (JSONPath / XPath)

```json
[{"body":"$.data.status","OP":"EQ","EXPECTED":["CREATED"]}]        // $. → JSONPath
[{"firstMessage":"//trade/side","OP":"EQ","EXPECTED":["BUY"]}]     // // → XPath
[{"JSONPATH":"$.user.name","FILE":"data.json","OP":"EQ",...}]      // explicit + file
[{"XML":"//Node","FILE":"order.xml","OP":"EQ",...}]                // explicit + file
```

### ScenarioExecutionContext API Reference

| Method | Purpose |
|---|---|
| `ctx.putExtract(name, value)` | Write EXTRACT variable |
| `ctx.getExtract(name)` | Read EXTRACT variable |
| `ctx.getExtractVars()` | Get all variables (read-only) |
| `ctx.markStepStart(stepId)` | Record step start time |
| `ctx.recordStepResult(result)` | Record step result to history |
| `ctx.getStepResult(stepId)` | Query previous step result |
| `ctx.isStepCompleted(stepId)` | Check if previous step passed |
| `ctx.getStepOutput(stepId, key)` | Get previous step output value |
| `ctx.getStepHistory()` | Get all step history (read-only) |
| `ctx.isAborted()` / `ctx.abort()` | Abort control |
| `ctx.markEnd()` | Mark scenario end |
| `ctx.summarize()` | Generate context summary |

---

## Adding New APPs and Actions

### Three Simple Steps

```java
// Step 1: Implement AppAction interface + annotate with @ActionSpec
@Component
@ActionSpec(apps = {"NEWAPP"}, action = "NEW_OPERATION",
            description = "New APP single-point operation")
public class NewAppOperationAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext ctx) {
        // Get protocol parameters
        JSONObject params = ctx.jsonParams("HTTP");
        if (params == null) {
            return ActionResult.fail("Missing HTTP protocol payload");
        }

        // Read/write scenario-level variables
        ctx.setVar("requestUrl", params.getString("url"));

        // Call protocol client
        HttpResult result = ctx.clients().http().execute(spec);

        // Return result
        return ActionResult.ok("Operation succeeded",
                Map.of("status", result.getStatusCode()));
    }
}
```

```text
Step 2: Add a row in the Excel Steps sheet
Scenario_ID | SEQ_NO | STEP_ID | APP    | ACTION        | DEPENDS_ON | INPUT                              | ...
E2E-NEW-001 | 1      | STEP-1 | NEWAPP | NEW_OPERATION | []         | [{"HTTP":{"url":"...","method":"GET"}}] | ...

Step 3: Run
mvn clean test
# Or IDE right-click E2ETestRunner → Run
```

### ActionContext API Reference

| Method | Purpose |
|---|---|
| `ctx.jsonParams("HTTP")` | Get HTTP protocol params as JSONObject (null if missing) |
| `ctx.requireJsonParams("DB")` | Get DB params (throws descriptive error if missing) |
| `ctx.paramStr("HTTP", "url")` | Get a string value from protocol params |
| `ctx.setVar("key", value)` | **Write scenario-level variable** (for subsequent steps ${extract.key}) |
| `ctx.getVar("key")` | **Read scenario-level variable** (written by previous steps) |
| `ctx.getVar("key", Type.class)` | Read variable (with type conversion) |
| `ctx.getStepResult("stepId")` | **Query previous step execution result** |
| `ctx.getStepOutput("stepId", "key")` | **Get previous step output value** |
| `ctx.isStepCompleted("stepId")` | **Check if previous step passed** |
| `ctx.scenarioContext()` | Get underlying ScenarioExecutionContext (advanced API) |
| `ctx.clients().http()` | Get HTTP client |
| `ctx.clients().db()` | Get DB client |
| `ctx.clients().ssh()` | Get SSH client |
| `ctx.clients().cmd()` | Get local command client |
| `ctx.props()` | Get framework configuration |

### Built-in Action Index

| APP | ACTION | Description | Examples |
|---|---|---|---|
| TAP / STP | COMMON_HTTP_REQUEST | HTTP request (all methods + auth + form) | [http-requests.md](src/test/resources/examples/http-requests.md) |
| SMARTS | COMMON_DB_EXECUTE | Execute SQL (data setup/cleanup) | - |
| SMARTS / TMS / DNS | COMMON_DB_ASSERTIONS | Assertion engine (DB/FILE/STDOUT/Map mode) | [assertions-guide.md](src/test/resources/examples/assertions-guide.md) |
| DATAHUB | COMMON_WINDOWS_CMD | Local Windows command (base_dir + batch) | [windows-cmd.md](src/test/resources/examples/windows-cmd.md) |
| DATAHUB | COMMON_LINUX_CMD | Linux command (local + remote SSH auth) | [linux-cmd-ssh.md](src/test/resources/examples/linux-cmd-ssh.md) |
| DATAHUB | COMMON_FILE_ACTIONS | File operations (create/write/read/delete/regex batch) | [file-operations.md](src/test/resources/examples/file-operations.md) |
| DATAHUB | COMMON_FTP_ACTIONS | FTP transfer (upload/download/list/delete) | [ftp-mail.md](src/test/resources/examples/ftp-mail.md) |
| DATAHUB | COMMON_MAIL_ACTIONS | Mail sending (text/HTML/attachments) | [ftp-mail.md](src/test/resources/examples/ftp-mail.md) |
| DATAHUB | COMMON_SFTP_ACTIONS | SFTP secure transfer | [ssh-remote.md](src/test/resources/examples/ssh-remote.md) |
| DATAHUB | COMMON_REDIS_OPERATE | Redis cache (get/set/del/ttl/hash/list) | [redis.md](src/test/resources/examples/redis.md) |
| DATAHUB | COMMON_WEBHOOK_NOTIFY | IM webhook (DingTalk/WeCom/Feishu/custom) | [webhook-websocket.md](src/test/resources/examples/webhook-websocket.md) |
| DATAHUB | COMMON_WEBSOCKET_CLIENT | WebSocket client (push receive) | [webhook-websocket.md](src/test/resources/examples/webhook-websocket.md) |
| TAP | COMMON_JWT_OPERATE | JWT generate/parse/verify | [jwt-oauth2.md](src/test/resources/examples/jwt-oauth2.md) |
| TAP / STP | COMMON_OAUTH2_TOKEN | OAuth2 token (auto-inject) | [jwt-oauth2.md](src/test/resources/examples/jwt-oauth2.md) |
| STP | COMMON_MQ_CONSUME | MQ consume (send/receive loop) | [mq-send.md](src/test/resources/examples/mq-send.md) |
| SMARTS | COMMON_NOSQL_EXECUTE | MongoDB document operations | [nosql-mongo.md](src/test/resources/examples/nosql-mongo.md) |
| SMARTS / DNS | COMMON_NOSQL_ASSERT | MongoDB document assertions | [nosql-mongo.md](src/test/resources/examples/nosql-mongo.md) |
| SMARTS | COMMON_DATA_COMPARE | Dual-source compare (db/file/http) | [data-compare.md](src/test/resources/examples/data-compare.md) |
| SMARTS / DRP | COMMON_JAVA_INVOKE | Java reflection (Bean/static/Playwright) | [java-invoke-ui.md](src/test/resources/examples/java-invoke-ui.md) |
| TAP | COMMON_SSH | SSH remote command execution | - |
| STP | COMMON_MQ_SEND | Send MQ message | - |
| DRP | DRP_UI_REPORTS | UI report browsing (Playwright) | - |
| SMARTS | 104_UI_BOOK / 109_UPLOAD | UI interaction operations | - |

> 📁 **Complete examples directory**: `src/test/resources/examples/` — one detailed doc per feature with INPUT format, parameter reference, assertion examples, and copy-paste-ready Excel step rows.

---

## HTTP Request Complete Usage

The `COMMON_HTTP_REQUEST` Action supports all HTTP methods (GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS),
JSON body, form params, raw string body, query params, headers, and Bearer/Basic authentication.

### INPUT Format

The INPUT column is a JSON array with an `HTTP` key in the first element:

```json
[{"HTTP": { ... request params ... }}]
```

### Complete Examples

#### GET with Query Params

```json
[{"HTTP": {
  "url": "http://api.example.com/users",
  "method": "GET",
  "params": {"page": "1", "size": "10", "sort": "desc"}
}}]
```

Can also be embedded in URL: `"url": "http://api.example.com/users?page=1&size=10"`

#### POST with JSON Body

```json
[{"HTTP": {
  "url": "http://api.example.com/users",
  "method": "POST",
  "body": {"name": "John", "age": 25, "roles": ["admin", "tester"]}
}}]
```

#### PUT with JSON Body + Headers

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "PUT",
  "body": {"name": "Updated Name", "status": "active"},
  "headers": {"X-Request-Id": "req-001", "X-Trace-Id": "trace-abc"}
}}]
```

#### PATCH Partial Update

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "PATCH",
  "body": {"status": "inactive"}
}}]
```

#### DELETE

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "DELETE"
}}]
```

#### POST with Form Params

```json
[{"HTTP": {
  "url": "http://api.example.com/login",
  "method": "POST",
  "formParams": {"username": "admin", "password": "123456", "remember": "true"}
}}]
```

#### POST with Raw String Body + Custom Content-Type

```json
[{"HTTP": {
  "url": "http://api.example.com/echo",
  "method": "POST",
  "body": "plain text content here",
  "contentType": "text/plain"
}}]
```

#### Bearer Token Authentication

```json
[{"HTTP": {
  "url": "http://api.example.com/secure/data",
  "method": "GET",
  "auth": {"type": "bearer", "token": "eyJhbGciOiJIUzI1NiJ9..."}
}}]
```

#### Basic Authentication

```json
[{"HTTP": {
  "url": "http://api.example.com/admin",
  "method": "GET",
  "auth": {"type": "basic", "username": "admin", "password": "secret"}
}}]
```

#### Full Combination (Headers + Query + Body + Auth)

```json
[{"HTTP": {
  "url": "http://api.example.com/v1/orders",
  "method": "POST",
  "params": {"source": "mobile"},
  "headers": {
    "Accept": "application/json",
    "X-Custom-Header": "value"
  },
  "body": {
    "orderId": "ORD-${global.flow_biz_id}",
    "items": [{"sku": "A001", "qty": 2}, {"sku": "B002", "qty": 1}],
    "address": {"city": "Shanghai", "zip": "200000"}
  },
  "auth": {"type": "bearer", "token": "${extract.authToken}"}
}}]
```

### Parameter Reference

| Parameter | Type | Required | Description |
|---|---|---|---|
| `url` | String | Yes | Request URL (supports `${global.}` / `${extract.}` variable substitution) |
| `method` | String | No | HTTP method, default `GET` (GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS) |
| `headers` | Object | No | Request header key-value pairs |
| `params` | Object | No | URL query parameters (alias: `queryParams`) |
| `formParams` | Object | No | Form parameters (auto-sets `application/x-www-form-urlencoded`) |
| `body` | Object/String | No | Request body (Object→JSON string, String→raw body) |
| `contentType` | String | No | Override Content-Type (default: `application/json` when body is Object) |
| `auth` | Object | No | Auth config: `{"type":"bearer","token":"..."}` or `{"type":"basic","username":"...","password":"..."}` |

### Output (for ASSERT / EXTRACT)

| Key | Description |
|---|---|
| `status` / `HTTP` | HTTP status code (e.g., 200, 404, 500) |
| `body` / `HTTP_BODY` | Response body string |
| `headers` / `HTTP_HEADERS` | Response header key-value pairs |
| `responseTimeMs` | Response time in milliseconds |

### ASSERT Example

```json
// Assert status code = 200
[{"HTTP": "status", "OP": "EQ", "EXPECTED": ["200"]}]

// Assert response body contains keyword
[{"HTTP": "body", "OP": "CONTAINS", "EXPECTED": ["success"]}]
```

### EXTRACT Example

```json
// Extract status code for subsequent steps
[{"name": "httpStatusCode", "from": "HTTP", "path": ""}]
// Reference in later steps: ${extract.httpStatusCode}
```

---

## JAVA Reflection Complete Usage

The `COMMON_JAVA_INVOKE` Action executes Java methods via reflection as specified in INPUT. Supports three invocation modes.
UI automation (Playwright/Selenium) is also implemented via reflection on browser Page objects.

### INPUT Format

The INPUT column is a JSON array with a `JAVA` key in the first element:

```json
[{"JAVA": { ... invocation params ... }}]
```

### Three Invocation Modes

#### Mode 1: Spring Bean Invocation

Look up a Spring bean by name and invoke a method via reflection.

```json
[{"JAVA": {
  "bean": "orderService",
  "method": "createOrder",
  "params": ["ORD-001", 100, true]
}}]
```

- `bean`: Spring bean name (must be registered)
- `method`: Method name to invoke
- `params`: Parameter array (auto type inference)

#### Mode 2: Static Method Invocation

Load class by fully qualified name and invoke a static method via reflection.

```json
[{"JAVA": {
  "class": "java.lang.System",
  "method": "getProperty",
  "params": ["user.home"]
}}]

// Custom utility class
[{"JAVA": {
  "class": "com.e2e.framework.util.DateUtils",
  "method": "formatNow",
  "params": ["yyyy-MM-dd HH:mm:ss"]
}}]
```

#### Mode 3: Playwright Page Methods (UI Automation)

Specify engine to get a Playwright Page object, then invoke page methods via reflection.

```json
// Navigate to URL
[{"JAVA": {
  "engine": "playwright",
  "method": "navigate",
  "params": ["http://example.com/login"]
}}]

// Fill input field
[{"JAVA": {
  "engine": "playwright",
  "method": "fill",
  "params": ["#username", "admin"]
}}]

// Click element
[{"JAVA": {
  "engine": "playwright",
  "method": "click",
  "params": ["#submit-btn"]
}}]

// Get element text content
[{"JAVA": {
  "engine": "playwright",
  "method": "textContent",
  "params": ["#welcome-message"]
}}]

// Get page title
[{"JAVA": {
  "engine": "playwright",
  "method": "title",
  "params": []
}}]

// Wait for selector
[{"JAVA": {
  "engine": "playwright",
  "method": "waitForSelector",
  "params": ["#loaded", "{\"timeout\": 10000}"]
}}]
```

> **Note**: Playwright methods require `e2e.mode=live` (real browser). Not available in demo mode.

### Parameter Types

Parameters are auto-inferred, or explicitly specified via `paramTypes`:

```json
[{"JAVA": {
  "bean": "calcService",
  "method": "compute",
  "params": ["price", 100, 0.95, true],
  "paramTypes": ["string", "int", "double", "boolean"]
}}]
```

| paramTypes Value | Java Type |
|---|---|
| `string` / `str` | String |
| `int` / `integer` | int |
| `long` | long |
| `double` | double |
| `boolean` / `bool` | boolean |
| `object` / `jsonobject` | JSONObject |
| `array` / `jsonarray` | JSONArray |
| `map` | Map |
| Fully qualified class name | Class.forName |

### Output (for ASSERT / EXTRACT)

| Key | Description |
|---|---|
| `JAVA` | Fixed value `"OK"` |
| `result` | Method return value |
| `method` | Invoked method name |
| `target` | Target class name |
| `resultType` | Return value type (e.g., String/Integer/Page...) |

### EXTRACT Example

```json
// Extract method return value for subsequent steps
[{"name": "pageTitle", "from": "result", "path": ""}]
// Reference in later steps: ${extract.pageTitle}
```

### Backward Compatible: UiAction Handler

When INPUT contains a `url` field, falls back to UiAction handler lookup (registered `@UiHandler`):

```json
[{"JAVA": {
  "url": "automation.qa.e2e.uiaction1",
  "params": {"action": "navigate", "target": "/reports/daily"}
}}]
```

---

## Data-Driven Format

### Scenarios Sheet

| Seq | Scenario_ID | Scenario_Name | Enabled | Tags | Env | Timeout | Description | Owner |
|---|---|---|---|---|---|---|---|---|
| 1 | E2E-CASE-HTTP-001 | HTTP Test | Y | http;smoke | demo | 120 | Verify HTTP requests | e2e-team |

### Steps Sheet

| Scenario_ID | SEQ_NO | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

### ASSERT Column Format

```json
[
  {"DB": "SELECT * FROM orders WHERE id=1", "OP": "EQ", "EXPECTED": ["1"]},
  {"HTTP": "status", "OP": "CONTAINS", "EXPECTED": ["200"]},
  {"DB": "SELECT COUNT(*) FROM x", "OP": "WAIT_UNTIL", "EXPECTED": ["1"], "TIMEOUT": 30, "POLL_INTERVAL": 2000}
]
```

Supported operators: EQ / NE / CONTAINS / NOT_CONTAINS / EMPTY / NOT_EMPTY / SIZE / GT / GTE / LT / LTE / REGEX / EXISTS / WAIT_UNTIL

### EXTRACT Column Format

```json
[{"name": "orderId", "from": "HTTP", "path": "status"}]
```

### Variable Engine

| Placeholder | Source |
|---|---|
| `${global.x}` | _GlobalConfig sheet |
| `${extract.x}` | Value extracted by a prior step's EXTRACT rule (or written via `ctx.setVar("x", ...)` in Action) |
| `${env.x}` | Environment variable / `-Dx=...` system property |

---

## Configuration Reference

```yaml
e2e:
  mode: demo              # demo / live
  strict: false            # Strict mode
  data:
    source: excel          # excel / yaml
    excel:
      path: classpath:cases/E2E-Test-Scenarios.xlsx
    yaml:
      path: classpath:cases/scenarios-examples.yml
  executor:
    parallel-threads: 1    # Step parallelism
    step-timeout-default-seconds: 180
  retry:
    scenario-retry-count: 0    # Scenario-level retry count
    step-retry-default: 0      # Step-level default retry
  db:
    mode: AUTO              # AUTO / STUB / LIVE
    driver: jdbc            # jdbc / mybatis-plus
  http:
    default-url: http://localhost:18080/ping
  cmd:
    allow-local-execution: false  # Local command real execution switch (false=dry-run)
  mq:
    host: localhost         # MQ access (live custom MqClient reads this)
    port: 1414
    queue: E2E.IN           # Default queue (when send/consume unspecified)
  ssh:
    user: e2e               # SSH/SFTP global default credentials
    password: ""
    port: 22
  sftp:                     # Empty fields fall back to e2e.ssh.*
    host: ""
    port: 22
    user: ""
    password: ""
  ftp:
    host: localhost         # FTP server (live COMMON_FTP_ACTIONS)
    port: 21
    user: anonymous
    password: ""
  mail:                     # SMTP (live COMMON_MAIL_ACTIONS)
    host: localhost
    port: 25
    from: e2e@localhost
    auth-enabled: false
    starttls: false
  redis:                    # live COMMON_REDIS_OPERATE (demo in-memory)
    host: localhost
    port: 6379
    password: ""
    database: 0
  nosql:                    # live COMMON_NOSQL_* (demo in-memory doc store)
    uri: mongodb://localhost:27017
    database: e2e
  webhook:                  # IM notification channel URLs
    dingtalk-url: ""
    wecom-url: ""
    feishu-url: ""
  compare:                  # Cross-environment compare named datasources
    envs:
      prod:     {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
      pre-prod: {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
  ui:
    browser: chromium
    headless: true
  ai:
    enabled: false
    provider: noop          # noop / custom / openai
```

---

## Project Structure

```
e2e-automation/
├── pom.xml / testng.xml / testng-gen.xml / testng-global-dag.xml
├── src/main/java/com/e2e/framework/
│   ├── ai/             # AI assistance SPI (4 extension points + NoOp default)
│   ├── registry/       # Action SPI: @ActionSpec + AppAction + ActionRegistry + ActionContext
│   ├── engine/         # DAG scheduling / step execution / context / assertions (AssertionEngine + ContentResolver + OperatorEvaluator)
│   ├── actions/        # Built-in action implementations (by protocol, 24 actions)
│   │   ├── cmd/        # Windows/Linux local commands (COMMON_WINDOWS_CMD / COMMON_LINUX_CMD)
│   │   ├── database/   # DB execute & assertions (COMMON_DB_EXECUTE / COMMON_DB_ASSERTIONS)
│   │   ├── file/       # Local file operations (COMMON_FILE_ACTIONS + FilePathResolver)
│   │   ├── ftp/        # FTP transfer (COMMON_FTP_ACTIONS)
│   │   ├── http/       # HTTP requests (COMMON_HTTP_REQUEST)
│   │   ├── java/       # JAVA reflection invoke (COMMON_JAVA_INVOKE)
│   │   ├── mail/       # Mail sending (COMMON_MAIL_ACTIONS)
│   │   ├── mq/         # MQ messaging (COMMON_MQ_SEND)
│   │   ├── ssh/        # SSH remote execution (COMMON_SSH)
│   │   ├── ui/         # UI operations (AbstractUiAction / DRP_UI_REPORTS / 104 / 109)
│   │   └── service/    # Helper services (UiAutomationService)
│   ├── data/           # Excel/YAML loaders + JSON sanitizer + variable engine
│   ├── protocol/       # Protocol interfaces (9 SPIs) + impl grouped by protocol
│   │   └── impl/       # db / http / mq / ssh / ftp / mail / cmd (demo stubs + live impls)
│   ├── model/          # Scenario/step/assertion/extract/result models
│   ├── report/         # HTML/JSON report generation (test_report.html)
│   ├── config/         # Spring wiring and properties
│   ├── bootstrap/      # Test run infrastructure (E2ESpringBootstrap / ResultStore / listeners / retry)
│   └── core/           # Cross-layer shared base (FilePathResolver)
├── src/test/java/com/e2e/
│   ├── test/           # E2ETestRunner (test entry) / GlobalDagReport
│   ├── generator/      # xlsx case generators (CasesExcelGenerator / TestCaseExamplesGenerator)
│   └── integration/    # Integration tests (DbDriverModesTest)
├── src/test/resources/
│   ├── cases/          # E2E-Test-Scenarios.xlsx + test_case_examples.xlsx (comprehensive suite)
│   ├── data/           # MQ message payloads and other data files
│   ├── examples/       # ★ Feature usage examples (19 docs: setup/usage/enums/test cases/FAQ)
│   └── testng/         # testng.xml / testng-gen.xml / testng-gen2.xml / testng-global-dag.xml
└── src/main/resources/
    └── application.yml  # Spring configuration
```
