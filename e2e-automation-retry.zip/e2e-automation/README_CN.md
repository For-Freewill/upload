# E2E 自动化测试框架

> 基于 Java 17 + Spring Boot 4 + TestNG 7 的端到端自动化测试框架，以「数据驱动 + 单点操作注册」为核心设计理念。

## 框架简介

本框架将测试用例数据与执行代码彻底解耦：完整测试用例由 Excel 模版（Scenarios / Steps / _GlobalConfig 三张表）描述，新增用例只需加数据行，零代码改动。每个 APP 域的单点操作（ACTION）通过 `@ActionSpec` 注解自动注册，新增 APP / 新操作三步完成。

### 核心能力

| 能力 | 说明 |
|---|---|
| 数据驱动 | Excel/YAML 双数据源，Scenarios + Steps + GlobalConfig 三表描述完整用例 |
| Action SPI | `@ActionSpec(apps, action)` + `AppAction` 接口，Spring 自动扫描注册（24 个内置 Action，31 个注册项） |
| DAG 调度 | DEPENDS_ON 依赖图分层调度，支持层内并行 |
| 场景上下文 | `ScenarioExecutionContext` 管理场景生命周期内的变量存储、步骤历史、跨步骤变量传递 |
| 变量引擎 | `${global.}` / `${extract.}` / `${env.}` 三类占位符；EXTRACT 双模式（提取 + 字面量场景参数） |
| 断言引擎 | 字符串/FIELD/Map 三模式 + JSONPath/XPath 双路由（自动前缀 + 显式 source）+ 14 种操作符 |
| 超时重试 | 步骤级超时 + 重试（RETRY 列 / ON_FAILURE=RETRY）+ 场景级 TestNG IRetryAnalyzer |
| 失败策略 | STOP / CONTINUE / SCREENSHOT / RETRY / SAVE_EVIDENCE 五种模式 |
| 异步断言 | Awaitility 轮询式 WAIT_UNTIL，适配 MQ 异步消费 / DB 最终一致性 |
| 协议层 | DB(JDBC+MyBatis-Plus) / HTTP / MQ(收发闭环) / SSH / SFTP / FTP / CMD / FILE / REDIS / MONGODB / MAIL / WEBHOOK / WEBSOCKET / JWT / OAUTH2 / DATACOMPARE(跨环境) / JAVA反射 / UI(Playwright) |
| demo/live 双模式 | demo 内置桩开箱即跑（Redis/Mongo/WebSocket 内存模拟）；live 切换真实协议连接 |
| AI 预留 | TestCaseGenerator / ReportInterpreter / StepOptimizer / AnomalyDetector 四个 SPI 接入点 |
| 报告 | HTML + JSON 报告，含饼图、汇总表、DAG 依赖图、步骤明细、数据质量提示 |

### 技术栈

| 组件 | 技术 | 版本 |
|---|---|---|
| 运行时 | Java | 17 |
| 框架 | Spring Boot | 4.1.1 |
| 测试 | TestNG | 7.12.0 |
| Excel | EasyExcel | 4.0.3 |
| JSON | fastjson2 | 2.0.65 |
| HTTP | REST Assured | 5.5.7 |
| UI | Playwright | 1.63.0 |
| DB | MyBatis-Plus / 原生 JDBC | 3.5.17 |
| SSH/SFTP | JSch | 2.28.8 |
| FTP | commons-net | 3.11.1 |
| MAIL | angus-mail (jakarta.mail) | 2.0.3 |
| Redis | Jedis | 5.2.0 |
| MongoDB | mongodb-driver-sync | 5.2.0 |
| JWT | jjwt | 0.12.6 |
| JSONPath | jayway json-path | 2.9.0 |
| 异步 | Awaitility | 4.3.0 |

---

## 快速开始

### 环境要求
- JDK 17+
- Maven 3.9+

### 三种运行方式

#### 方式一：IDE 右键运行（推荐测试人员使用）

在 IDE（IntelliJ IDEA / Eclipse）中打开 `E2ETestRunner.java`，右键 → Run：

```
文件位置：src/test/java/com/e2e/test/E2ETestRunner.java
```

此方式自动执行 `main()` 方法：
1. 引导 Spring 上下文
2. 加载全部启用的场景（默认从 `classpath:cases/E2E-Test-Scenarios.xlsx`）
3. 逐个执行场景
4. 生成 `test-output/test_report.html`
5. 控制台输出汇总（通过/失败/跳过/耗时）

#### 方式二：Maven 命令行

```bash
# 完整套件运行（含 Excel 生成器 + 测试 + DB 双驱动验证）
mvn clean test

# 框架核心单元测试（99 个：断言引擎/解析器/变量引擎/DAG/路径解析，毫秒级不启动 Spring）
mvn clean test -Dsurefire.suiteXmlFiles=src/test/resources/testng/testng-unit.xml

# 仅运行 E2ETestRunner（独立入口，不经过 testng.xml）
mvn exec:java -Dexec.mainClass=com.e2e.test.E2ETestRunner -Dexec.classpathScope=test

# 指定外部 Excel 数据源
mvn clean test -De2e.data.excel.path=file:C:/my-test-cases.xlsx

# 切换 YAML 数据源
mvn clean test -De2e.data.source=yaml

# 切换 live 模式（真实协议连接）
mvn clean test -De2e.mode=live \
        -De2e.db.mode=LIVE \
        -De2e.db.driver=mybatis-plus \
        -Dspring.datasource.url="jdbc:h2:mem:test;DB_CLOSE_DELAY=-1" \
        -Dspring.datasource.driver-class-name=org.h2.Driver
```

#### 方式三：命令行直接执行

```bash
# 编译后直接运行
mvn clean test-compile
java -cp target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DforceStdout) \
     com.e2e.test.E2ETestRunner
```

### 生成 Excel 用例文件

```bash
# 生成 E2E-Test-Scenarios.xlsx（22 场景 / 105 步骤 / 9 全局变量，其中 S14 禁用）
mvn test -Dsurefire.suiteXmlFiles=testng-gen.xml

# 文件输出到：src/test/resources/cases/E2E-Test-Scenarios.xlsx
```

### 生成全局场景 DAG 报告

```bash
# 生成 Global_Scenarios_Dag_Report.html（纯拓扑 DAG，不执行测试）
mvn test -Dsurefire.suiteXmlFiles=testng-global-dag.xml

# 文件输出到：test-output/Global_Scenarios_Dag_Report.html
```

此报告从 Excel 直接加载场景定义，为每个场景渲染 DAG 拓扑图（节点=序号-APP，边=依赖箭头），方便在执行前预览全部场景的依赖结构。

### 查看报告

| 报告文件 | 生成条件 | 内容 |
|---|---|---|
| `test-output/test_report.html` | 执行测试时自动生成 | 侧边栏导航 + 汇总表 + 饼图 + DAG 依赖图 + 步骤明细 |
| `test-output/test_report.json` | 执行测试时自动生成 | JSON 格式完整结果 |
| `test-output/Global_Scenarios_Dag_Report.html` | 单独执行 global-dag 时生成 | 全部场景的拓扑 DAG（卡片式布局，APP 域配色） |

---

## 场景执行上下文（ScenarioExecutionContext）

### 概述

`ScenarioExecutionContext` 是场景执行期间的完整共享状态，生命周期与单个场景执行同生共死。不同场景的上下文完全隔离，无法互传数据。

### 架构

```
ScenarioExecutor.doExecute()
  │
  ├── 创建 ScenarioExecutionContext（场景级，生命周期=场景执行期间）
  │     │
  │     ├── 变量存储 extractVars (ConcurrentHashMap)
  │     │     └── Step A → ctx.putExtract("x", value)  ← 写入变量
  │     │     └── Step B → ${extract.x} 引用              ← 读取变量
  │     │
  │     ├── 步骤历史 stepHistory (ConcurrentHashMap<stepId, StepResult>)
  │     │     └── 每个步骤执行后 → ctx.recordStepResult(result)
  │     │     └── 后续步骤可查询 → ctx.getStepResult(stepId)
  │     │
  │     ├── 步骤时间线 stepStartTimes
  │     │     └── ctx.markStepStart(stepId)
  │     │
  │     ├── 终止控制 aborted (volatile)
  │     │     └── STOP 策略 → ctx.abort() → 后续步骤自动跳过
  │     │
  │     └── 生命周期 startTime / endTime
  │           └── ctx.markEnd() → 场景结束，上下文可回收
  │
  └── GC 回收（不同场景上下文完全隔离）
```

### 在 Action 中使用上下文

Action 通过 `ActionContext` 访问 `ScenarioExecutionContext` 的全部能力：

```java
@Override
public ActionResult execute(ActionContext ctx) {
    // ① 协议参数
    JSONObject params = ctx.jsonParams("HTTP");
    String url = params.getString("url");

    // ② 场景级变量读写（EXTRACT，跨步骤传递）
    ctx.setVar("orderId", "123");                    // 写入变量
    String prevId = ctx.getVar("orderId");            // 读取前序步骤写入的变量
    Integer code = ctx.getVar("httpCode", Integer.class); // 带类型转换

    // ③ 前序步骤查询
    StepResult prev = ctx.getStepResult("HTTP-POST-SEND");       // 获取前序步骤结果
    Object status = ctx.getStepOutput("HTTP-POST-SEND", "status"); // 获取前序步骤输出
    boolean done = ctx.isStepCompleted("DB-INSERT-LOG");          // 检查前序步骤是否通过

    // ④ 协议客户端
    ctx.clients().http().execute(spec);
    ctx.clients().db().query(sql);

    // ⑤ 返回结果（outputs 供 ASSERT / EXTRACT 使用）
    return ActionResult.ok("成功", Map.of("status", 200));
}
```

### 变量流转示例

```
┌─────────────────────────────────────────────────────────────────┐
│ ScenarioExecutionContext (场景级，场景执行期间存活)              │
│                                                                 │
│  Step 1: TAP:COMMON_HTTP_REQUEST                                  │
│    → ctx.setVar("httpStatus", 200)           ← Action 写入变量  │
│    → return ActionResult.ok(outputs={"status":200})            │
│    → ctx.recordStepResult(result)             ← 引擎记录历史    │
│                                                                 │
│  Step 2: SMARTS:COMMON_DB_EXECUTE (depends on Step 1)          │
│    → INPUT 中 ${extract.httpStatus} → "200"   ← 变量引擎替换   │
│    → ctx.getStepOutput("STEP-1", "status") → 200  ← 查询输出   │
│    → ctx.isStepCompleted("STEP-1") → true       ← 检查状态      │
│                                                                 │
│  Step 3: SMARTS:COMMON_DB_ASSERTIONS (depends on Step 2)       │
│    → ctx.getVar("httpStatus") → 200           ← 变量仍然可见    │
│    → ASSERT: DB SELECT ... OP=EQ EXPECTED=["200"]              │
│                                                                 │
│  场景结束 → ctx.markEnd() → 上下文 GC 回收                      │
└─────────────────────────────────────────────────────────────────┘
```

### 生命周期保证

- 每个 Scenario 在 `doExecute()` 创建**独立** `ScenarioExecutionContext`
- 场景执行完毕后调用 `ctx.markEnd()` 并由 GC 回收
- **不同 Scenario 的上下文完全隔离**，无法互传数据
- 线程安全：`ConcurrentHashMap` + `volatile`，支持 DAG 层内并行步骤安全写入

### EXTRACT 双模式（变量提取 / 场景参数设置）

```json
// 模式一：提取模式（from + path，path 前缀自动路由五种引擎）
[{"name":"orderId","from":"body","path":"$.data.orderId"}]      // JSONPath
[{"name":"side","from":"firstMessage","path":"//trade/side"}]   // XPath
[{"name":"price","from":"STDOUT","path":"regex:price=([\\d.]+)"}] // 正则
[{"name":"cfg","from":"FILE","path":"app.cfg#L3"}]              // 文件行
[{"name":"acct","from":"DB_ROWS","path":"[0].ACCT_NO"}]         // Token 导航

// 模式二：字面量模式（value）—— 场景级参数快速设置 ⭐
[{"name":"acct","value":"999999"},
 {"name":"bizRef","value":"ACCT-${extract.acct}"}]   // 支持组合变量
```

> 字面量模式典型用法：scenario 首个 step 定义通用参数（acct/branchCode 等），
> 后续所有步骤的 INPUT/ASSERT 以 `${extract.acct}` 引用，实现场景维度参数化传参。
> 详细用法见 [extract-variables.md](src/test/resources/examples/extract-variables.md)。

### 断言路径双路由（JSONPath / XPath）

```json
[{"body":"$.data.status","OP":"EQ","EXPECTED":["CREATED"]}]           // $. → JSONPath
[{"firstMessage":"//trade/side","OP":"EQ","EXPECTED":["BUY"]}]        // // → XPath
[{"JSONPATH":"$.user.name","FILE":"data.json","OP":"EQ",...}]         // 显式 + 文件
[{"XML":"//Node","FILE":"order.xml","OP":"EQ",...}]                   // 显式 + 文件
```

### ScenarioExecutionContext API 速查

| 方法 | 用途 |
|---|---|
| `ctx.putExtract(name, value)` | 写入 EXTRACT 变量 |
| `ctx.getExtract(name)` | 读取 EXTRACT 变量 |
| `ctx.getExtractVars()` | 获取全部变量（只读） |
| `ctx.markStepStart(stepId)` | 记录步骤开始时间 |
| `ctx.recordStepResult(result)` | 记录步骤执行结果到历史 |
| `ctx.getStepResult(stepId)` | 查询前序步骤结果 |
| `ctx.isStepCompleted(stepId)` | 检查前序步骤是否通过 |
| `ctx.getStepOutput(stepId, key)` | 获取前序步骤输出值 |
| `ctx.getStepHistory()` | 获取全部步骤历史（只读） |
| `ctx.isAborted()` / `ctx.abort()` | 终止控制 |
| `ctx.markEnd()` | 标记场景结束 |
| `ctx.summarize()` | 生成上下文摘要 |

---

## 新增 APP / Action 指南

### 三步完成

```java
// 第 1 步：实现 AppAction 接口 + 标注 @ActionSpec
@Component
@ActionSpec(apps = {"NEWAPP"}, action = "NEW_OPERATION",
            description = "新 APP 的单点操作")
public class NewAppOperationAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext ctx) {
        // 取协议参数
        JSONObject params = ctx.jsonParams("HTTP");
        if (params == null) {
            return ActionResult.fail("缺少 HTTP 协议载荷");
        }

        // 读写场景级变量
        ctx.setVar("requestUrl", params.getString("url"));

        // 调用协议客户端
        HttpResult result = ctx.clients().http().execute(spec);

        // 返回结果
        return ActionResult.ok("操作成功",
                Map.of("status", result.getStatusCode()));
    }
}
```

```text
第 2 步：在 Excel Steps 表新增行
Scenario_ID | SEQ_NO | STEP_ID | APP    | ACTION        | DEPENDS_ON | INPUT                              | ...
E2E-NEW-001 | 1      | STEP-1 | NEWAPP | NEW_OPERATION | []         | [{"HTTP":{"url":"...","method":"GET"}}] | ...

第 3 步：运行
mvn clean test
# 或 IDE 右键 E2ETestRunner → Run
```

### ActionContext API 速查

| 方法 | 用途 |
|---|---|
| `ctx.jsonParams("HTTP")` | 取 HTTP 协议参数为 JSONObject（缺失返回 null） |
| `ctx.requireJsonParams("DB")` | 取 DB 参数（缺失时抛带提示的异常） |
| `ctx.paramStr("HTTP", "url")` | 取协议参数的字符串值 |
| `ctx.setVar("key", value)` | **写入场景级变量**（供后续步骤 ${extract.key} 引用） |
| `ctx.getVar("key")` | **读取场景级变量**（前序步骤写入的） |
| `ctx.getVar("key", Type.class)` | 读取变量（带类型转换） |
| `ctx.getStepResult("stepId")` | **查询前序步骤执行结果** |
| `ctx.getStepOutput("stepId", "key")` | **获取前序步骤输出值** |
| `ctx.isStepCompleted("stepId")` | **检查前序步骤是否通过** |
| `ctx.scenarioContext()` | 获取底层 ScenarioExecutionContext（高级 API） |
| `ctx.clients().http()` | 获取 HTTP 客户端 |
| `ctx.clients().db()` | 获取 DB 客户端 |
| `ctx.clients().ssh()` | 获取 SSH 客户端 |
| `ctx.clients().cmd()` | 获取本地命令客户端 |
| `ctx.props()` | 获取框架配置 |

### 内置 Action 索引

| APP | ACTION | 说明 | 详细示例 |
|---|---|---|---|
| TAP / STP | COMMON_HTTP_REQUEST | HTTP 请求（全 method + auth + form） | [http-requests.md](src/test/resources/examples/http-requests.md) |
| SMARTS | COMMON_DB_EXECUTE | 执行 SQL（数据准备/清理） | - |
| SMARTS / TMS / DNS | COMMON_DB_ASSERTIONS | 断言引擎（DB/FILE/STDOUT/Map 模式） | [assertions-guide.md](src/test/resources/examples/assertions-guide.md) |
| DATAHUB | COMMON_WINDOWS_CMD | 本地 Windows 命令（base_dir + 批量） | [windows-cmd.md](src/test/resources/examples/windows-cmd.md) |
| DATAHUB | COMMON_LINUX_CMD | Linux 命令（本地 + SSH 远程认证） | [linux-cmd-ssh.md](src/test/resources/examples/linux-cmd-ssh.md) |
| DATAHUB | COMMON_FILE_ACTIONS | 文件操作（create/write/read/delete/正则批量） | [file-operations.md](src/test/resources/examples/file-operations.md) |
| DATAHUB | COMMON_FTP_ACTIONS | FTP 文件传输（upload/download/list/delete） | [ftp-mail.md](src/test/resources/examples/ftp-mail.md) |
| DATAHUB | COMMON_MAIL_ACTIONS | 邮件发送（纯文本/HTML/附件） | [ftp-mail.md](src/test/resources/examples/ftp-mail.md) |
| DATAHUB | COMMON_SFTP_ACTIONS | SFTP 安全传输（upload/download/list） | [ssh-remote.md](src/test/resources/examples/ssh-remote.md) |
| DATAHUB | COMMON_REDIS_OPERATE | Redis 缓存（get/set/del/ttl/hash/list） | [redis.md](src/test/resources/examples/redis.md) |
| DATAHUB | COMMON_WEBHOOK_NOTIFY | IM Webhook（钉钉/企微/飞书/自定义） | [webhook-websocket.md](src/test/resources/examples/webhook-websocket.md) |
| DATAHUB | COMMON_WEBSOCKET_CLIENT | WebSocket 客户端（推送接收断言） | [webhook-websocket.md](src/test/resources/examples/webhook-websocket.md) |
| TAP | COMMON_JWT_OPERATE | JWT 生成/解析/校验 | [jwt-oauth2.md](src/test/resources/examples/jwt-oauth2.md) |
| TAP / STP | COMMON_OAUTH2_TOKEN | OAuth2 Token 获取（自动注入） | [jwt-oauth2.md](src/test/resources/examples/jwt-oauth2.md) |
| STP | COMMON_MQ_CONSUME | MQ 消费（收发闭环） | [mq-send.md](src/test/resources/examples/mq-send.md) |
| SMARTS | COMMON_NOSQL_EXECUTE | MongoDB 文档操作 | [nosql-mongo.md](src/test/resources/examples/nosql-mongo.md) |
| SMARTS / DNS | COMMON_NOSQL_ASSERT | MongoDB 文档断言 | [nosql-mongo.md](src/test/resources/examples/nosql-mongo.md) |
| SMARTS | COMMON_DATA_COMPARE | 双数据源比对（db/file/http） | [data-compare.md](src/test/resources/examples/data-compare.md) |
| SMARTS / DRP | COMMON_JAVA_INVOKE | Java 反射调用（Bean/静态/Playwright） | [java-invoke-ui.md](src/test/resources/examples/java-invoke-ui.md) |
| TAP | COMMON_SSH | SSH 远程命令执行 | - |
| STP | COMMON_MQ_SEND | 发送 MQ 报文 | - |
| DRP | DRP_UI_REPORTS | UI 报表浏览（Playwright） | - |
| SMARTS | 104_UI_BOOK / 109_UPLOAD | UI 交互操作 | - |

> 📁 **完整功能示例目录**：`src/test/resources/examples/` — 每个功能一份详细文档，含 INPUT 格式、参数说明、断言示例和可直接复制到 Excel 的完整步骤。

---

## HTTP 请求完整用法

`COMMON_HTTP_REQUEST` Action 支持 GET / POST / PUT / PATCH / DELETE / HEAD / OPTIONS 全部 HTTP method，
支持 JSON body / form 表单 / raw 字符串 / query 参数 / headers / Bearer+Basic 认证。

### INPUT 格式

INPUT 列为 JSON 数组，第一个元素的 `HTTP` 键包含请求参数：

```json
[{"HTTP": { ... 请求参数 ... }}]
```

### 完整示例

#### GET 请求 + Query 参数

```json
[{"HTTP": {
  "url": "http://api.example.com/users",
  "method": "GET",
  "params": {"page": "1", "size": "10", "sort": "desc"}
}}]
```

也可直接写在 URL 中：`"url": "http://api.example.com/users?page=1&size=10"`

#### POST + JSON Body

```json
[{"HTTP": {
  "url": "http://api.example.com/users",
  "method": "POST",
  "body": {"name": "张三", "age": 25, "roles": ["admin", "tester"]}
}}]
```

#### PUT + JSON Body + Headers

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "PUT",
  "body": {"name": "更新后的名称", "status": "active"},
  "headers": {"X-Request-Id": "req-001", "X-Trace-Id": "trace-abc"}
}}]
```

#### PATCH 局部更新

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "PATCH",
  "body": {"status": "inactive"}
}}]
```

#### DELETE

```json
[{"HTTP": {
  "url": "http://api.example.com/users/1",
  "method": "DELETE"
}}]
```

#### POST + Form 表单提交

```json
[{"HTTP": {
  "url": "http://api.example.com/login",
  "method": "POST",
  "formParams": {"username": "admin", "password": "123456", "remember": "true"}
}}]
```

#### POST + Raw 字符串 Body + 自定义 Content-Type

```json
[{"HTTP": {
  "url": "http://api.example.com/echo",
  "method": "POST",
  "body": "plain text content here",
  "contentType": "text/plain"
}}]
```

#### Bearer Token 认证

```json
[{"HTTP": {
  "url": "http://api.example.com/secure/data",
  "method": "GET",
  "auth": {"type": "bearer", "token": "eyJhbGciOiJIUzI1NiJ9..."}
}}]
```

#### Basic 认证

```json
[{"HTTP": {
  "url": "http://api.example.com/admin",
  "method": "GET",
  "auth": {"type": "basic", "username": "admin", "password": "secret"}
}}]
```

#### 完整组合（Headers + Query + Body + Auth）

```json
[{"HTTP": {
  "url": "http://api.example.com/v1/orders",
  "method": "POST",
  "params": {"source": "mobile"},
  "headers": {
    "Accept": "application/json",
    "X-Custom-Header": "value"
  },
  "body": {
    "orderId": "ORD-${global.flow_biz_id}",
    "items": [{"sku": "A001", "qty": 2}, {"sku": "B002", "qty": 1}],
    "address": {"city": "上海", "zip": "200000"}
  },
  "auth": {"type": "bearer", "token": "${extract.authToken}"}
}}]
```

### 参数说明

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `url` | String | 是 | 请求 URL（支持 `${global.}` / `${extract.}` 变量替换） |
| `method` | String | 否 | HTTP method，默认 `GET`（GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS） |
| `headers` | Object | 否 | 请求头键值对 |
| `params` | Object | 否 | URL query 参数（也可用 `queryParams`） |
| `formParams` | Object | 否 | 表单参数（自动设为 `application/x-www-form-urlencoded`） |
| `body` | Object/String | 否 | 请求体（Object→JSON 字符串，String→raw body） |
| `contentType` | String | 否 | 覆盖 Content-Type（默认根据 body 自动推断为 `application/json`） |
| `auth` | Object | 否 | 认证配置：`{"type":"bearer","token":"..."}` 或 `{"type":"basic","username":"...","password":"..."}` |

### 输出（outputs，供 ASSERT / EXTRACT 使用）

| key | 说明 |
|---|---|
| `status` / `HTTP` | HTTP 状态码（如 200、404、500） |
| `body` / `HTTP_BODY` | 响应体字符串 |
| `headers` / `HTTP_HEADERS` | 响应头键值对 |
| `responseTimeMs` | 响应耗时（毫秒） |

### ASSERT 示例

```json
// 断言状态码 = 200
[{"HTTP": "status", "OP": "EQ", "EXPECTED": ["200"]}]

// 断言响应体包含关键字
[{"HTTP": "body", "OP": "CONTAINS", "EXPECTED": ["success"]}]
```

### EXTRACT 示例

```json
// 提取状态码供后续步骤引用
[{"name": "httpStatusCode", "from": "HTTP", "path": ""}]
// 后续步骤引用：${extract.httpStatusCode}
```

---

## JAVA 反射调用完整用法

`COMMON_JAVA_INVOKE` Action 通过反射执行 INPUT 中指定的 Java 方法，支持三种调用模式。
UI 自动化（Playwright/Selenium）底层也是通过反射调用浏览器 Page 对象的方法实现。

### INPUT 格式

INPUT 列为 JSON 数组，第一个元素的 `JAVA` 键包含调用参数：

```json
[{"JAVA": { ... 调用参数 ... }}]
```

### 三种调用模式

#### 模式 1：Spring Bean 调用

通过 Spring Bean 名称查找实例，反射执行指定方法。

```json
[{"JAVA": {
  "bean": "orderService",
  "method": "createOrder",
  "params": ["ORD-001", 100, true]
}}]
```

- `bean`：Spring Bean 名称（必须已注册）
- `method`：要调用的方法名
- `params`：参数数组（自动类型推断）

#### 模式 2：静态方法调用

通过全限定类名加载类，反射执行静态方法。

```json
[{"JAVA": {
  "class": "java.lang.System",
  "method": "getProperty",
  "params": ["user.home"]
}}]

// 调用自定义工具类
[{"JAVA": {
  "class": "com.e2e.framework.util.DateUtils",
  "method": "formatNow",
  "params": ["yyyy-MM-dd HH:mm:ss"]
}}]
```

#### 模式 3：Playwright 页面方法（UI 自动化）

通过 `engine` 字段指定引擎，获取 Playwright Page 对象，反射调用页面操作方法。

```json
// 导航到指定 URL
[{"JAVA": {
  "engine": "playwright",
  "method": "navigate",
  "params": ["http://example.com/login"]
}}]

// 输入文本
[{"JAVA": {
  "engine": "playwright",
  "method": "fill",
  "params": ["#username", "admin"]
}}]

// 点击元素
[{"JAVA": {
  "engine": "playwright",
  "method": "click",
  "params": ["#submit-btn"]
}}]

// 获取元素文本内容
[{"JAVA": {
  "engine": "playwright",
  "method": "textContent",
  "params": ["#welcome-message"]
}}]

// 获取页面标题
[{"JAVA": {
  "engine": "playwright",
  "method": "title",
  "params": []
}}]

// 等待选择器出现
[{"JAVA": {
  "engine": "playwright",
  "method": "waitForSelector",
  "params": ["#loaded", "{\"timeout\": 10000}"]
}}]
```

> **注意**：Playwright 方法需要 `e2e.mode=live`（真实浏览器），demo 模式下引擎不可用。

### 参数类型

参数自动推断类型，也可通过 `paramTypes` 精确指定：

```json
[{"JAVA": {
  "bean": "calcService",
  "method": "compute",
  "params": ["price", 100, 0.95, true],
  "paramTypes": ["string", "int", "double", "boolean"]
}}]
```

| paramTypes 值 | Java 类型 |
|---|---|
| `string` / `str` | String |
| `int` / `integer` | int |
| `long` | long |
| `double` | double |
| `boolean` / `bool` | boolean |
| `object` / `jsonobject` | JSONObject |
| `array` / `jsonarray` | JSONArray |
| `map` | Map |
| 全限定类名 | Class.forName |

### 输出（outputs，供 ASSERT / EXTRACT 使用）

| key | 说明 |
|---|---|
| `JAVA` | 固定值 `"OK"` |
| `result` | 方法返回值 |
| `method` | 调用的方法名 |
| `target` | 目标类名 |
| `resultType` | 返回值类型（如 String/Integer/Page...） |

### EXTRACT 示例

```json
// 提取方法返回值供后续步骤引用
[{"name": "pageTitle", "from": "result", "path": ""}]
// 后续步骤引用：${extract.pageTitle}
```

### 向后兼容：UiAction 处理器

当 INPUT 包含 `url` 字段时，回退到 UiAction 处理器查找（已注册的 `@UiHandler`）：

```json
[{"JAVA": {
  "url": "automation.qa.e2e.uiaction1",
  "params": {"action": "navigate", "target": "/reports/daily"}
}}]
```

---

## 数据驱动格式

### Scenarios 表

| Seq | Scenario_ID | Scenario_Name | Enabled | Tags | Env | Timeout | Description | Owner |
|---|---|---|---|---|---|---|---|---|
| 1 | E2E-CASE-HTTP-001 | HTTP 测试 | Y | http;smoke | demo | 120 | 验证 HTTP 请求 | e2e-team |

### Steps 表

| Scenario_ID | SEQ_NO | STEP_ID | APP | ACTION | DEPENDS_ON | INPUT | ASSERT | EXTRACT | TIMEOUT | RETRY | ON_FAILURE | ENABLED |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

### ASSERT 列格式

```json
[
  {"DB": "SELECT * FROM orders WHERE id=1", "OP": "EQ", "EXPECTED": ["1"]},
  {"HTTP": "status", "OP": "CONTAINS", "EXPECTED": ["200"]},
  {"DB": "SELECT COUNT(*) FROM x", "OP": "WAIT_UNTIL", "EXPECTED": ["1"], "TIMEOUT": 30, "POLL_INTERVAL": 2000}
]
```

支持的操作符：EQ / NE / CONTAINS / NOT_CONTAINS / EMPTY / NOT_EMPTY / SIZE / GT / GTE / LT / LTE / REGEX / EXISTS / WAIT_UNTIL

**路径断言**（target 自动路由）：`$.` 开头 → JSONPath 求值（如 `{"HTTP":"$.data.status","OP":"EQ"}`）；`//` 或 `/` 开头 → XPath 求值（如 `{"firstMessage":"//trade/side","OP":"EQ"}`）

### EXTRACT 列格式

```json
[{"name": "orderId", "from": "HTTP", "path": "status"}]
```

### 变量引擎

| 占位符 | 来源 |
|---|---|
| `${global.x}` | _GlobalConfig 表 |
| `${extract.x}` | 前序步骤 EXTRACT 提取的值（或 Action 中 `ctx.setVar("x", ...)` 写入的） |
| `${env.x}` | 环境变量 / `-Dx=...` 系统属性 |

---

## 配置参考

```yaml
e2e:
  mode: demo              # demo / live
  strict: false            # 严格模式
  data:
    source: excel          # excel / yaml
    excel:
      path: classpath:cases/E2E-Test-Scenarios.xlsx
    yaml:
      path: classpath:cases/scenarios-examples.yml
  executor:
    parallel-threads: 1    # 步骤并行度
    step-timeout-default-seconds: 180
  retry:
    scenario-retry-count: 0    # 场景级重试次数
    step-retry-default: 0      # 步骤级默认重试
  db:
    mode: AUTO              # AUTO / STUB / LIVE
    driver: jdbc            # jdbc / mybatis-plus
  http:
    default-url: http://localhost:18080/ping
  cmd:
    allow-local-execution: false  # 本地命令真实执行开关（false=dry-run）
  mq:
    host: localhost         # MQ 接入（live 自定义 MqClient 读取）
    port: 1414
    queue: E2E.IN           # 默认队列（send/consume 未指定时）
  ssh:
    user: e2e               # SSH/SFTP 全局缺省认证
    password: ""
    port: 22
  sftp:                     # 留空复用 e2e.ssh.*
    host: ""
    port: 22
    user: ""
    password: ""
  ftp:
    host: localhost         # FTP 服务器（live COMMON_FTP_ACTIONS）
    port: 21
    user: anonymous
    password: ""
  mail:                     # SMTP（live COMMON_MAIL_ACTIONS）
    host: localhost
    port: 25
    from: e2e@localhost
    auth-enabled: false
    starttls: false
  redis:                    # live COMMON_REDIS_OPERATE（demo 内存模拟）
    host: localhost
    port: 6379
    password: ""
    database: 0
  nosql:                    # live COMMON_NOSQL_*（demo 内存文档库）
    uri: mongodb://localhost:27017
    database: e2e
  webhook:                  # IM 通知渠道 URL
    dingtalk-url: ""
    wecom-url: ""
    feishu-url: ""
  compare:                  # 跨环境数据比对命名数据源
    envs:
      prod:     {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
      pre-prod: {url: jdbc:mysql://..., driver: com.mysql.cj.jdbc.Driver, user: r, password: ""}
  ui:
    browser: chromium
    headless: true
  ai:
    enabled: false
    provider: noop          # noop / custom / openai
```

---

## 工程结构

```
e2e-automation/
├── pom.xml / testng.xml / testng-gen.xml / testng-gen2.xml / testng-global-dag.xml
├── src/main/java/com/e2e/framework/
│   ├── ai/             # AI 辅助 SPI（4 个接入点 + NoOp 默认实现）
│   ├── bootstrap/      # 测试运行基础设施（E2ESpringBootstrap / ResultStore / Suite 监听 / 重试分析）
│   ├── core/           # 跨层共享基础（FilePathResolver 路径解析）
│   ├── registry/       # Action SPI：@ActionSpec + AppAction + ActionRegistry + ActionContext
│   ├── engine/         # 执行引擎：DAG 调度 / 步骤执行 / 场景上下文
│   │   ├── AssertionEngine.java       # 断言编排（同步/异步分发）
│   │   ├── ContentResolver.java       # 断言内容加载（DB/FILE/JSONPath/XPath）
│   │   └── OperatorEvaluator.java     # 操作符评估（字符串 14 种 + Map 模式）
│   ├── actions/        # 内置 Action 实现（按协议分目录，24 个）
│   │   ├── cmd/        # Windows/Linux 本地命令（COMMON_WINDOWS_CMD / COMMON_LINUX_CMD）
│   │   ├── compare/    # 双源数据比对（COMMON_DATA_COMPARE）
│   │   ├── database/   # DB 执行与断言（COMMON_DB_EXECUTE / COMMON_DB_ASSERTIONS）
│   │   ├── file/       # 本地文件操作（COMMON_FILE_ACTIONS）
│   │   ├── ftp/        # FTP 传输（COMMON_FTP_ACTIONS）
│   │   ├── http/       # HTTP 请求 / Webhook / OAuth2
│   │   ├── java/       # JAVA 反射调用（COMMON_JAVA_INVOKE）
│   │   ├── jwt/        # JWT 操作（COMMON_JWT_OPERATE）
│   │   ├── mail/       # 邮件发送（COMMON_MAIL_ACTIONS）
│   │   ├── mq/         # MQ 收发（COMMON_MQ_SEND / COMMON_MQ_CONSUME）
│   │   ├── nosql/      # MongoDB（COMMON_NOSQL_EXECUTE / COMMON_NOSQL_ASSERT）
│   │   ├── redis/      # Redis 缓存（COMMON_REDIS_OPERATE）
│   │   ├── ssh/        # SSH 远程 + SFTP（COMMON_SSH / COMMON_SFTP_ACTIONS）
│   │   ├── ui/         # UI 操作（AbstractUiAction / DRP_UI_REPORTS / 104 / 109）
│   │   ├── websocket/  # WebSocket 客户端（COMMON_WEBSOCKET_CLIENT）
│   │   └── service/    # 辅助服务（UiAutomationService）
│   ├── data/           # Excel/YAML 加载器 + JSON 修复 + 变量引擎
│   ├── protocol/       # 协议接口（9 个 SPI）+ impl 按协议分子包
│   │   └── impl/       # db / http / mq / ssh / ftp / mail / cmd（各含 demo桩 + live实现）
│   ├── model/          # 场景/步骤/断言/提取/结果 模型
│   ├── report/         # HTML/JSON 报告生成（test_report.html）
│   └── config/         # Spring 装配与属性
├── src/test/java/com/e2e/
│   ├── test/           # E2ETestRunner（测试入口）/ GlobalDagReport
│   ├── generator/      # xlsx 用例生成器（CasesExcelGenerator / TestCaseExamplesGenerator）
│   └── integration/    # 集成测试（DbDriverModesTest）
├── src/test/resources/
│   ├── cases/          # E2E-Test-Scenarios.xlsx + test_case_examples.xlsx（全面测试套件）
│   ├── data/           # MQ 报文等数据文件
│   ├── examples/       # ★ 功能使用示例（19 个文档：前置配置/用法/枚举/测试案例/FAQ）
│   └── testng/         # testng.xml / testng-gen.xml / testng-gen2.xml / testng-global-dag.xml
└── src/main/resources/
    └── application.yml  # Spring 配置
```
