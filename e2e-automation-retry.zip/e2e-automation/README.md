# E2E Automation Framework

基于 **Java 17 + Spring Boot 4 + TestNG 7** 的端到端自动化测试框架。以「数据驱动 + 单点操作注册」为核心设计：

- **数据与代码彻底解耦**：完整测试用例由 Excel 模版（Scenarios / Steps / _GlobalConfig 三张表）描述，新增用例只需加数据行，零代码改动；
- **APP 域单点操作注册机制**：每个 (APP, ACTION) 组合是一个可独立注册的实现，通过注解自动发现，灵活扩展新 APP / 新操作；
- **执行引擎内置依赖图调度**（DEPENDS_ON）、超时、重试、ON_FAILURE 失败策略（STOP / CONTINUE / SCREENSHOT）、断言引擎、变量提取传递；
- **协议层 demo/live 双模式**：demo 模式内置桩实现开箱即跑全链路，live 模式切换真实连接。

## 技术栈

| 领域 | 选型 | 版本 |
|---|---|---|
| 运行底座 | Java + Spring Boot + TestNG | 17 / 4.1.x / 7.12 |
| Excel 解析 | **Alibaba EasyExcel**（`doReadAll` 多 Sheet 全量收集，POI 由其传递管理） | 4.0.3 |
| JSON 解析 | **Alibaba fastjson2**（模版解析、变量树、报告序列化） | 2.0.65 |
| HTTP 请求 | **REST Assured**（live 模式 `given/when/then` DSL） | 5.5.7 |
| UI 自动化 | **Microsoft Playwright**（live 模式 Chromium/Firefox/WebKit，demo 走桩） | 1.63.0 |
| DB ① | **MyBatis-Plus**（`mybatis-plus-spring-boot4-starter`，`e2e.db.driver=mybatis-plus`） | 3.5.17 |
| DB ② | **原生 JDBC**（DataSource + PreparedStatement 手写执行，`e2e.db.driver=jdbc` 默认） | — |
| SSH | JSch | 0.2.x |

## 快速开始

```bash
# 前置：JDK 17 + Maven 3.9+（本机验证版本：Spring Boot 4.1.1 / TestNG 7.12.0）
mvn test
```

执行输出（demo 模式，开箱即跑）：

```
Tests run: 4, Failures: 0, Errors: 0, Skipped: 1
合计: 4 个场景（通过 3 / 失败 0 / 跳过 1）
```

- 跳过的 `E2E-STP-TMS-002` 是模版中的"孤儿场景"（已启用但无步骤），框架按数据质量问题标注并 SKIP，而非报错。
- 报告生成于 `target/e2e-report/`（`report.html` / `report.json` / `screenshots/`）。

## 架构总览

```
┌────────────────────────────────────────────────────────────┐
│ TestNG 层  testng.xml → @Factory 数据驱动 E2ETestRunner     │
│            E2ESuiteLifecycleListener（Spring 启停/报告落盘） │
├────────────────────────────────────────────────────────────┤
│ 执行引擎    DagResolver（DEPENDS_ON→分层拓扑）               │
│            ScenarioExecutor / StepExecutor（超时/重试/策略） │
│            AssertionEngine（EQ/NE/CONTAINS/EXISTS…）        │
├────────────────────────────────────────────────────────────┤
│ Action SPI  ActionRegistry ← @ActionSpec 自动扫描注册        │
│            AppAction(apps, action)  ← 新增 APP 操作的扩展点   │
├────────────────────────────────────────────────────────────┤
│ 协议层      DB(MyBatis-Plus/原生JDBC) / HTTP(REST Assured) / MQ /    │
│            SSH(JSch) / CMD(ProcessBuilder)                  │
│            JAVA-UI → PlaywrightUiEngine ← @UiHandler        │
├────────────────────────────────────────────────────────────┤
│ 数据驱动层  ExcelTestDataLoader(EasyExcel) / YamlTestData   │
│            Loader(SnakeYAML)；JsonPayloadSanitizer(fastjson2│
│            模版脏数据自动修复)；VariableResolver（${global.}/ │
│            ${extract.}/${env.}）                             │
└────────────────────────────────────────────────────────────┘
```

## 数据驱动：模版三张表

数据源默认为 `src/main/resources/e2e/E2E-Test-Scenarios.xlsx`，通过 `e2e.data.source` 切换为 yaml。

### Scenarios 表（场景级）
| 列 | 说明 |
|---|---|
| SCENARIO_ID | 场景唯一 ID（= 一个 TestNG 用例） |
| NAME / DESCRIPTION / OWNER | 描述信息 |
| ENABLED | Y/N（模版拼写 ENBALED 亦兼容） |
| TAGS / ENV / TIMEOUT_S | 标签、环境、场景级超时 |

### Steps 表（步骤级，E2E 用例的编排核心）
| 列 | 说明 |
|---|---|
| SCENARIO_ID + STEP_ID | 归属场景 + 步骤 ID |
| APP + ACTION | **单点操作定位键**，路由到注册的实现 |
| SEQ_NO | 步骤顺序 |
| DEPENDS_ON | 前置步骤（逗号分隔，形成 DAG，支持并行层） |
| INPUT | JSON 载荷数组（MQ/DB/HTTP/SSH/CMD/JAVA-UI 协议体），支持 `file:` 引用报文文件 |
| ASSERT | 断言 JSON（EQ/NE/CONTAINS/EXISTS 等 12 种操作符） |
| EXTRACT | 变量提取 JSON（供后续步骤 `${extract.xxx}` 引用） |
| RETRY / TIMEOUT_S / ON_FAILURE | 重试次数 / 超时 / 失败策略（STOP/CONTINUE/SCREENSHOT） |

### _GlobalConfig 表
全局键值对，步骤中以 `${global.键名}` 引用（如 `${global.test_url}`）。

### 变量引擎（VariableResolver）
| 占位符 | 来源 |
|---|---|
| `${global.x}` | _GlobalConfig 表 |
| `${extract.x}` | 前序步骤 EXTRACT 提取的值 |
| `${env.x}` | 环境变量 / `-Dx=...` 系统属性 |

### 数据质量容错（strict=false 时）
模版中存在已知的脏数据，框架自动修复并记录在报告的「数据质量提示」中：
- 非法 JSON（键值对游离在数组结构外、智能引号）→ 结构修复后装载；
- 场景启用但无步骤（孤儿场景）→ SKIP 并标注；
- 步骤携带异构协议载荷（如 CMD 步骤带 SSH 载荷）→ 逐级回退匹配。

`e2e.strict=true` 时以上问题直接抛错，适合 CI 门禁。

## 扩展指南 ①：注册新增 APP 的单点操作（核心 SPI）

三步完成，无需改动框架任何代码：

```java
// 1. 实现接口 + 2. 打注册注解（含 @Component，Spring 自动扫描进 ActionRegistry）
@ActionSpec(
        apps = {"NEWAPP"},              // 新 APP 域，可一次注册多个域
        action = "NEW_OPERATION",       // 操作名
        description = "新 APP 的单点操作")
public class NewAppNewOperationAction implements AppAction {

    @Override
    public ActionResult execute(ActionContext ctx) throws Exception {
        // ctx.payload("HTTP") / ctx.payload("MQ") … 取 INPUT 中替换变量后的协议载荷
        // ctx.clients().http() / db() / mq() / ssh() / cmd() … 取协议客户端
        // ctx.extractVars() 读写场景级变量
        var response = ctx.clients().http().call(ctx.payload("HTTP"));
        return ActionResult.success(Map.of("respCode", response.code())); // outputs 供断言/提取
    }
}
```

```text
3. 模版 Steps 表新增行：APP=NEWAPP, ACTION=NEW_OPERATION, INPUT={...协议载荷...}
```

注册键为 `APP:ACTION`（忽略大小写）。**覆盖内置实现**：同 key 下 `order` 大者生效（内置默认 order=0，覆盖实现设 order=100）。也支持编程式动态注册：`actionRegistry.register("NEWAPP:NEW_OPERATION", instance, 100)`。

内置实现索引（11 个，均以同机制注册，可作参考模板）：

| APP | ACTION | 说明 |
|---|---|---|
| STP | SEND_MQ | 发送 MQ 报文（file: 引用 XML 报文 + 变量替换） |
| TMS/SMARTS/DNS/DRP… | COMMON_DB_EXECUTE / COMMON_DB_ASSERTIONS | 通用 DB 执行与查询断言 |
| COMMON（任意 APP） | SEND_HTTP_REQUEST | 通用 HTTP 调用 |
| TAP | SSH_ALPHA2 / WINDOWS_CMD / LINUX_CMD | 远程 SSH / 本地 Windows/Linux 命令（含异构载荷回退） |
| DRP | UI_REPORTS | 报表 UI 操作（走 JAVA-UI 协议） |
| SMARTS | UPLOAD_109 / BOOK_104_UI | 上传/预订 UI 操作 |
| DATAHUB | （复用 TAP/COMMON） | — |

## 扩展指南 ②：注册 JAVA-UI 协议处理器（Playwright）

UI 自动化通过 `@UiHandler` 接入 Playwright（`PlaywrightUiEngine` 提供页面会话管理，跨步骤复用同一页面模拟连续操作流）：

```java
@UiHandler(value = "automation.qa.e2e.xxx", description = "XXX 系统登录 UI 流程")
public class XxxUiHandler implements UiAction {

    private final PlaywrightUiEngine engine;   // Spring 注入

    @Override
    public Map<String, Object> execute(String params) {
        JSONObject p = JSON.parseObject(params);        // {"url":"...","account":"..."}
        Page page = engine.page();                      // live 模式获取/复用页面
        page.navigate(p.getString("url"));
        page.fill("#username", p.getString("account"));
        page.click("#login");
        return Map.of("loginResult", "OK");             // 输出供断言 / EXTRACT
    }
}
```

步骤侧只需在 INPUT 中写：`"JAVA-UI"` 或 `"JAVA": {"url": "automation.qa.e2e.xxx", "params": {...}}`。

**运行模式**：demo 模式 Playwright 完全不启动（离线可用）；live 模式（`-De2e.mode=live`）首次使用时自动启动
`e2e.ui.browser` 配置的浏览器（默认 Chromium 无头）。浏览器二进制首次启动自动下载；CI 离线环境可预装：

```bash
mvn compile exec:java -e -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"
```

内置 `PlaywrightUiHandler`（注册名 `automation.qa.e2e.uiaction1`，与模版数据对应）已实现该双模式行为，可作参考模板。

## Demo / Live 模式

| 配置 | demo（默认） | live |
|---|---|---|
| `e2e.mode` | demo | live |
| `e2e.db.driver` | —（桩） | **jdbc**（默认，原生 JDBC） / **mybatis-plus**（MyBatis-Plus） |
| DB | Stub（模拟查询结果） | **JdbcDbClient**（原生 PreparedStatement，批量显式事务）或 **MybatisPlusDbClient**（SqlSessionTemplate 动态 statement，均配置 DataSource） |
| HTTP | Stub | **RestAssuredHttpApiClient**（REST Assured） |
| SSH | Stub | JschSshClient（JSch 0.2.x） |
| CMD | 模拟输出 | ProcessBuilder（`e2e.cmd.allow-local-execution=true` 才真执行） |
| UI | 桩（不启动浏览器） | **Playwright**（`e2e.ui.*` 配置浏览器/无头/基础地址） |
| MQ | Stub | 需按队列管理器扩展 |

**DB 双驱动说明**（`e2e.db.driver` 切换，数据链路对上层 Action 完全透明）：

- **原生 JDBC（`jdbc`，默认）**：`DataSource.getConnection()` + `PreparedStatement` 手写执行，`ResultSetMetaData` 列名映射；批量执行采用「单连接 + 显式事务」（全部成功才 commit，失败整批 rollback）；
- **MyBatis-Plus（`mybatis-plus`）**：基于 starter 自动装配的 `SqlSessionFactory`（MybatisConfiguration），以「动态注册 MappedStatement + SqlSessionTemplate」执行任意 SQL，完整走 MyBatis 执行链（StatementHandler → ParameterHandler → ResultSetHandler 的 Map 结果映射）；相同 SQL 按内容缓存 statement，断言轮询零注册开销。注：MyBatis-Plus 3.5.9 起移除了旧版 SqlRunner，官方 Db/SqlHelper 面向实体 CRUD，故任意 SQL 走动态 statement 方案。

双驱动行为一致性由 `DbDriverModesTest`（H2 内存库）回归保障：建表 / 批量插入 / 查询映射 / 更新 / COUNT 聚合 / 删除全链路断言。

live 模式的连接参数（`e2e.db/http/mq/ssh/ui` 节点）全部支持环境变量与命令行覆盖：

```bash
mvn test -De2e.mode=live -De2e.db.driver=mybatis-plus -De2e.ssh.user=ci_robot -De2e.ui.base-url=https://uat.example.com -De2e.data.excel.path=file:D:/cases.xlsx
```

## 运行与报告

```bash
mvn test                       # 全量执行启用场景
mvn test -Dscenario=E2E-STP-TMS-001   # （经 testng.xml 方法级过滤可扩展）
```

- **TestNG 报告**：`target/surefire-reports/`（每个场景一个用例， failures 即场景失败）；
- **框架报告**：`target/e2e-report/report.html|json`（场景/步骤明细、重试次数、断言详情、数据质量提示、截图目录）；
- **失败策略**：`ON_FAILURE` 支持 STOP / CONTINUE / SCREENSHOT / RETRY / SAVE_EVIDENCE 五种模式（见下文）；
- **失败重试**：场景级（TestNG IRetryAnalyzer）+ 步骤级（RETRY 列 / ON_FAILURE=RETRY）双层重试；
- **异步断言**：`OP=WAIT_UNTIL` 配合 Awaitility 轮询等待异步结果（MQ 消费、DB 最终一致性等）。

## 高级特性

### ① 失败重试（场景级 + 步骤级）

| 层级 | 配置方式 | 说明 |
|---|---|---|
| 场景级 | `e2e.retry.scenario-retry-count=N` | TestNG IRetryAnalyzer，整个场景失败后自动重试 N 次（默认 0=不重试） |
| 步骤级 | Steps 表 `RETRY` 列 / `e2e.retry.step-retry-default=N` | 单步骤失败后重试，`ON_FAILURE=RETRY` 时强制至少 1 次重试 |

```bash
mvn test -De2e.retry.scenario-retry-count=1 -De2e.retry.step-retry-default=1
```

### ② ON_FAILURE 失败策略（5 种模式）

| 模式 | 行为 |
|---|---|
| `STOP` | 终止整个场景，后续步骤 SKIPPED（默认） |
| `CONTINUE` | 记录失败但继续执行后续步骤 |
| `SCREENSHOT` | 调用截图钩子留存证据，再按 STOP 终止 |
| `RETRY` | 按 `e2e.retry` 配置重试，重试耗尽则按 STOP 终止 |
| `SAVE_EVIDENCE` | 保存截图 + outputs 快照 + 协议报文，再按 STOP 终止 |

### ③ Enable 设置（场景级 + 步骤级）

- **场景级**：Scenarios 表 `Enabled` 列（Y/N），`N` 的场景不创建 TestNG 用例；
- **步骤级**：Steps 表 `ENABLED` 列（Y/N），`N` 的步骤标记为 SKIPPED 并跳过执行。

### ④ 异步断言（Awaitility）

ASSERT 列中使用 `OP=WAIT_UNTIL` + `TIMEOUT=N` + `POLL_INTERVAL=ms` 实现轮询式等待：

```json
[{"DB":"SELECT * FROM orders WHERE status='PAID'","OP":"WAIT_UNTIL","EXPECTED":["PAID"],"TIMEOUT":30,"POLL_INTERVAL":2000}]
```

引擎在 timeout 内每隔 pollInterval 重新查询，直到断言通过或超时。适用于 MQ 异步消费、DB 最终一致性、HTTP 异步回调等场景。

### ⑤ AI 辅助支持（预留 SPI）

框架在四个阶段预留 AI 接入点，默认 NoOp 实现（零行为影响），通过 `e2e.ai.*` 配置启用：

| 接入点 | 接口 | 触发时机 | 配置开关 |
|---|---|---|---|
| 测试用例生成 | `AiTestCaseGenerator` | 数据装载 / CLI 命令 | `e2e.ai.features.test-case-generation` |
| 测试报告解读 | `AiReportInterpreter` | ReportWriter 生成报告后 | `e2e.ai.features.report-interpretation` |
| 步骤优化建议 | `AiStepOptimizer` | StepExecutor 步骤失败后 | `e2e.ai.features.step-optimization` |
| 异常检测 | `AiAnomalyDetector` | 数据装载后 / 执行中 | `e2e.ai.features.anomaly-detection` |

**接入方式**：实现 `AiAssistant` 接口（或各子接口）并注册为 Spring Bean，设置 `e2e.ai.enabled=true + e2e.ai.provider=custom`。

## Excel 真实用例集（cases/e2e-cases.xlsx）

`src/main/resources/cases/e2e-cases.xlsx` 是一套**12 个场景 / 39 个步骤**的 Excel 格式真实用例集，Sheet 结构与模版完全一致（Scenarios / Steps / _GlobalConfig），覆盖所有内置 Action 类型：

| 场景 | Action 类型 | 覆盖特性 |
|---|---|---|
| `E2E-CASE-HTTP-GET-CHAIN` | SEND_HTTP_REQUEST × 2 + COMMON_DB_ASSERTIONS | GET 链式请求、变量提取、跨步骤验证 |
| `E2E-CASE-HTTP-POST-JSON` | SEND_HTTP_REQUEST + COMMON_DB_EXECUTE + COMMON_DB_ASSERTIONS | POST JSON body、DB 日志写入与验证 |
| `E2E-CASE-DB-CRUD-LIFECYCLE` | COMMON_DB_EXECUTE × 2 + COMMON_DB_ASSERTIONS | 建表→批量插入→断言→清理 全生命周期 |
| `E2E-CASE-DB-POLL-CONSISTENCY` | COMMON_DB_EXECUTE + COMMON_DB_ASSERTIONS + COMMON_DB_EXECUTE | **WAIT_UNTIL 异步轮询断言**（Awaitility） |
| `E2E-CASE-CMD-WINDOWS-MULTI` | TAP_WINDOWS_CMD × 3 | Windows 多命令链式执行、STDOUT/CMD 断言 |
| `E2E-CASE-CMD-LINUX-EMULATE` | TAP_LINUX_CMD × 3 | Linux 命令模拟、变量提取 |
| `E2E-CASE-MQ-SEND-VERIFY` | SEND_MQ + COMMON_DB_ASSERTIONS + COMMON_DB_EXECUTE | MQ 报文发送、DB 存在性验证 |
| `E2E-CASE-SSH-REMOTE-EXEC` | TAP_SSH_ALPHA2 + COMMON_DB_ASSERTIONS + TAP_WINDOWS_CMD | SSH 远程命令、跨协议编排 |
| `E2E-CASE-UI-REPORT-VIEW` | DRP_UI_REPORTS + 104_UI_BOOK + COMMON_DB_ASSERTIONS | UI 交互（Playwright 桩）、JAVA 协议 |
| `E2E-CASE-FLOW-ORDER-LIFECYCLE` | 5 种 Action 组合 | **HTTP→DB→MQ→CMD→DB 端到端编排**、DEPENDS_ON 链 |
| `E2E-CASE-RETRY-FLAKY-STEP` | COMMON_DB_EXECUTE + COMMON_DB_ASSERTIONS | **ON_FAILURE=RETRY 步骤级重试** |
| `E2E-CASE-DISABLED-DEMO` | 3 种 Action | **Enabled=N 场景跳过**验证 |

**运行方式**：

```bash
# 先生成 xlsx（CasesExcelGenerator 写入 cases/e2e-cases.xlsx）
mvn test -Dsurefire.suiteXmlFiles=testng-gen.xml

# 再运行 cases 用例集
mvn test -De2e.data.excel.path=classpath:cases/e2e-cases.xlsx
```

## 内置示例用例集（scenarios-examples.yml）

`src/main/resources/e2e/scenarios-examples.yml` 是一套**开箱可跑的功能示例用例集**，覆盖 HTTP、DB、CMD 三种执行方式及组合编排，demo / live 双模式断言一致（已全矩阵验证）：

| 场景 | 演示的执行方式 | 覆盖的框架特性 |
|---|---|---|
| `E2E-DEMO-HTTP-001` | **HTTP**（GET + POST） | headers 传递、body 断言、`$.headers` 提取变量、`NOT_NULL` / `CONTAINS` / `EQ` 操作符、EXISTS 语义（期望空即存在性校验） |
| `E2E-DEMO-DB-001` | **DB**（COMMON_DB_EXECUTE） | 建表 / 批量插入 / UPDATE / COUNT / DELETE 全链路；`GT` 数值断言、`CONTAINS` 回显断言、`$.rows.0.0` 行列定位提取 |
| `E2E-DEMO-CMD-001` | **CMD**（本地命令） | 多命令数组执行、`(?s)` 行级 CONTAINS 断言、退出码 EQ 断言、`TIMESTAMP` 变量注入 |
| `E2E-DEMO-FLOW-001` | **组合端到端** | HTTP → DB → CMD 跨域编排、`DEPENDS_ON` 依赖链、`${extract.*}` 变量跨步骤传递、`SQL IN (${extract.x})` 动态拼装 |

**运行方式**：

```bash
# demo 模式（桩执行，断言全通过，离线可跑）
mvn test -De2e.data.source=yaml -De2e.data.yaml.path=classpath:e2e/scenarios-examples.yml

# live 模式（REST Assured 真实 HTTP + H2 真库 + 原生 JDBC + 真实本地命令）
mvn test -De2e.data.source=yaml -De2e.data.yaml.path=classpath:e2e/scenarios-examples.yml \
        -De2e.mode=live -De2e.db.mode=LIVE \
        -Dspring.datasource.url="jdbc:h2:mem:examples;DB_CLOSE_DELAY=-1" \
        -Dspring.datasource.driver-class-name=org.h2.Driver

# live 模式 + MyBatis-Plus 驱动（仅换一个参数）
mvn test ... -De2e.db.driver=mybatis-plus -Dspring.datasource.url="jdbc:h2:mem:examples-mp;DB_CLOSE_DELAY=-1"
```

**用例数据编写要点**（从示例集提炼，写新用例可直接套用）：

- **INPUT** 是协议数组：`[{HTTP:{...}}]` / `[{DB:["sql1","sql2"]}]` / `[{CMD:{cmd:["..."]}}]` / `[{SSH:{...}}]`；
- **ASSERT** 每条规则形如 `{HTTP: "$.status", OP: "EQ", EXPECTED: ["200"]}`，来源键（DB/HTTP/STDOUT…）+ JSONPath 目标 + 操作符；命令输出断言用 `STDOUT: ""` + `OP:CONTAINS` + 正则 `(?s)` 跨行匹配；
- **EXTRACT** 是变量提取：`[{NAME: "var", FROM: "HTTP", PATH: "$.body.id"}]`（键大小写不敏感），DB 轮询断言必须与 EXTRACT 同步骤挂载；
- **变量引用**：`${global.x}`（全局表）、`${extract.x}`（前序提取）、`${env.x}`（环境变量 / -D 属性），SQL / EXPECTED / INPUT 三处均可引用；
- **DEPENDS_ON** 填前序 stepId 数组，无依赖填 `[]`；引擎按依赖图分层调度。

## 工程结构

```
e2e-automation/
├── pom.xml / testng.xml
├── src/main/java/com/e2e/framework/
│   ├── registry/        # Action SPI：@ActionSpec + AppAction + ActionRegistry（核心扩展点）
│   ├── engine/          # DAG 调度 / 步骤执行（超时重试）/ 断言引擎 / 截图（Playwright 优先）
│   ├── actions/         # 内置 11 个 APP 单点操作（stp/tap/drp/smarts/common）
│   ├── data/            # Excel(EasyExcel)/YAML(SnakeYAML) 加载器 + JSON 修复(fastjson2) + 变量引擎
│   ├── protocol/        # 协议接口 + impl（demo 桩 / live：REST Assured、JSch、DB 双驱动）
│   │   └── ui/          # PlaywrightUiEngine + PlaywrightUiHandler + @UiHandler 注册表
│   ├── model/           # 场景/步骤/断言/提取/结果 模型（参数体统一 fastjson2 对象）
│   ├── report/          # 控制台摘要 + html/json 报告写出（fastjson2 序列化）
│   └── config/          # Spring 装配与属性
├── src/test/java/com/e2e/test/   # TestNG 入口：@Factory Runner + 生命周期监听
└── src/main/resources/
    ├── e2e/E2E-Test-Scenarios.xlsx   # 模版数据（Scenarios/Steps/_GlobalConfig）
    ├── e2e/scenarios.yml             # YAML 等价数据源
    ├── e2e/scenarios-examples.yml    # HTTP/DB/CMD/组合编排 示例用例集（demo/live 双模式）
    └── json/e2e/stp/mq/test-001.xml  # MQ 报文样例（file: 引用）
```

## 版本与兼容性说明

- Excel 解析统一走 **EasyExcel** `doReadAll`（`headRowNumber(0)` 自管表头归一化，与 YAML 数据源行为一致）；POI 由 EasyExcel 传递引入（5.2.5），业务代码零 POI 依赖；
- JSON 全链路统一 **fastjson2**（`JSON.parse`/`JSONObject`/`JSONArray`），无需注入解析器实例；fastjson2 对模版脏数据的自动修复（游离键合并、非法结构重写）与断言引擎语义已对齐验证；
- HTTP live 客户端为 **REST Assured** `given().request(method, url)`（非 2xx 不抛异常，由 Action 按状态码判定，与桩语义一致）。**注意**：REST Assured 5.5.7 自带的 groovy 5.0.8 在部分环境触发 NPE，工程已显式 pin `org.apache.groovy:groovy:4.0.28`（+ groovy-json/xml）修复，请勿移除该 pin；
- DB live 双驱动：**MyBatis-Plus 3.5.17**（`mybatis-plus-spring-boot4-starter`，官方 Spring Boot 4 适配，传递 mybatis 3.5.19 + mybatis-spring 4.0.0）与**原生 JDBC**；MyBatis-Plus 3.5.9 起移除 SqlRunner，任意 SQL 走动态 MappedStatement（Map 类型 inline ResultMap 等价 `resultType="map"`）；
- Playwright demo 模式零启动（不下载浏览器，离线可跑）；live 模式浏览器二进制首启自动下载；
- Surefire 需 ≤ 3.5.x（3.6.0 弃用 `suiteXmlFiles`，会导致 testng.xml 不生效）；
- TestNG `parallel` 属性已使用 `NONE` 取值（`false` 已废弃）。
