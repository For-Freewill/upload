package com.e2e.framework.data;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.e2e.framework.model.AssertionRule;
import com.e2e.framework.model.DataQualityIssue;
import com.e2e.framework.model.ExtractRule;
import com.e2e.framework.model.ProtocolPayload;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * INPUT / ASSERT / EXTRACT 三列 JSON 的容错解析与清洗（fastjson2 实现）。
 *
 * <p>模版中已知的数据问题（如 INPUT 数组中游离的 {@code "headers"} 键）会被自动修复，
 * 并记录 DataQualityIssue；严格模式由装配层抛出异常。
 * @author: e695040/wulei
 * @date: 2026/10/9
 */
public final class JsonPayloadSanitizer {

    /** 已知协议白名单：INPUT 元素的单键若不在其中，则视为参数碎片并入前一个载荷 */
    private static final Set<String> KNOWN_PROTOCOLS = new LinkedHashSet<>(List.of(
            "MQ", "DB", "HTTP", "HTTPS", "SSH", "WINDOWS-CMD", "LINUX-CMD", "JAVA", "UI", "FTP", "MAIL", "FILE",
            "SFTP", "REDIS", "WS", "MONGO", "JWT", "OAUTH2", "WEBHOOK", "COMPARE"));

    private static final Set<String> ASSERT_META_KEYS = Set.of(
            "OP", "EXPECTED", "EXPECTEDVALUES", "MESSAGE", "RETRY", "FIELD",
            "TIMEOUT", "POLLINTERVAL", "POLL_INTERVAL", "FROM", "FILE");

    private JsonPayloadSanitizer() {
    }

    /** 注册新的协议键（供自定义协议扩展时避免误判为参数碎片） */
    public static void registerProtocol(String protocol) {
        KNOWN_PROTOCOLS.add(protocol.toUpperCase());
    }

    /** 解析 INPUT 列：[{协议:{参数...}}, ...] -> ProtocolPayload 列表（含容错合并） */
    public static List<ProtocolPayload> parseInputPayloads(String raw, String scenarioId,
                                                           String stepId, List<DataQualityIssue> issues) {
        List<ProtocolPayload> payloads = new ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return payloads;
        }
        Object root = parse(raw, "INPUT", scenarioId, stepId, issues);
        if (root == null) {
            return payloads;
        }
        if (!(root instanceof JSONArray)) {
            issues.add(issue(scenarioId, stepId, "INPUT", "INPUT 不是 JSON 数组，已自动包裹为数组", "容错包裹"));
            JSONArray wrapped = new JSONArray();
            wrapped.add(root);
            root = wrapped;
        }
        for (Object element : (JSONArray) root) {
            if (!(element instanceof JSONObject obj)) {
                issues.add(issue(scenarioId, stepId, "INPUT",
                        "数组元素不是对象: " + JSON.toJSONString(element), "跳过该元素"));
                continue;
            }
            if (obj.isEmpty()) {
                issues.add(issue(scenarioId, stepId, "INPUT", "数组元素为空对象", "跳过该元素"));
                continue;
            }
            // 情形一：多键对象 —— 取白名单协议键作为载荷，其余键并入参数体
            if (obj.size() > 1) {
                String protocolKey = firstKnownProtocol(obj);
                if (protocolKey != null) {
                    JSONObject params = new JSONObject();
                    params.putAll(obj);
                    payloads.add(new ProtocolPayload(protocolKey, params));
                    issues.add(issue(scenarioId, stepId, "INPUT",
                            "多键元素 " + JSON.toJSONString(obj) + " 以 " + protocolKey + " 为主协议，全部键并入参数体", "容错合并"));
                } else {
                    mergeIntoPrevious(payloads, obj, scenarioId, stepId, issues);
                }
                continue;
            }
            // 情形二：单键对象
            Map.Entry<String, Object> only = obj.entrySet().iterator().next();
            String key = only.getKey();
            Object value = only.getValue();
            if (KNOWN_PROTOCOLS.contains(key.toUpperCase())) {
                payloads.add(new ProtocolPayload(key.toUpperCase(), value));
            } else if (payloads.isEmpty()) {
                payloads.add(new ProtocolPayload(key.toUpperCase(), value));
                issues.add(issue(scenarioId, stepId, "INPUT",
                        "未知协议键 " + key + "（可用 JsonPayloadSanitizer.registerProtocol 注册），按原样透传", "告警透传"));
            } else {
                // 模版已知问题：如 "headers" 游离在数组元素外 -> 并入前一个载荷参数
                mergeIntoPrevious(payloads, obj, scenarioId, stepId, issues);
            }
        }
        return payloads;
    }

    /** 解析 ASSERT 列：[{"DB":sql,"OP":"EQ","EXPECTED":["1"]}, ...] */
    public static List<AssertionRule> parseAssertRules(String raw, String scenarioId,
                                                       String stepId, List<DataQualityIssue> issues) {
        List<AssertionRule> rules = new ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return rules;
        }
        Object root = parse(raw, "ASSERT", scenarioId, stepId, issues);
        if (root == null) {
            return rules;
        }
        if (!(root instanceof JSONArray)) {
            JSONArray wrapped = new JSONArray();
            wrapped.add(root);
            root = wrapped;
            issues.add(issue(scenarioId, stepId, "ASSERT", "ASSERT 不是 JSON 数组，已自动包裹为数组", "容错包裹"));
        }
        for (Object element : (JSONArray) root) {
            if (!(element instanceof JSONObject obj)) {
                issues.add(issue(scenarioId, stepId, "ASSERT",
                        "数组元素不是对象: " + JSON.toJSONString(element), "跳过该元素"));
                continue;
            }
            // 键大小写不敏感（Excel 源惯用大写 DB/OP/EXPECTED，YAML 源惯用小写 db/op/expected）
            String sourceKey = null;
            for (String f : List.of("DB", "HTTP", "SSH", "OUTPUT", "CMD", "UI",
                    "JSONPATH", "XPATH", "XML", "FILE",
                    "RESULT", "STATUS", "BODY", "STDOUT", "STDERR", "LINES")) {
                String hit = ciKey(obj, f);
                if (hit != null) { sourceKey = hit; break; }
            }
            if (sourceKey == null) {
                // 兜底：第一个非元数据键作为来源
                for (String f : obj.keySet()) {
                    if (!isAssertMetaKey(f)) { sourceKey = f; break; }
                }
            }
            if (sourceKey == null) {
                issues.add(issue(scenarioId, stepId, "ASSERT",
                        "无法识别断言来源键: " + JSON.toJSONString(obj), "跳过该元素"));
                continue;
            }
            Object targetObj = obj.get(sourceKey);
            String target = targetObj instanceof String s ? s : JSON.toJSONString(targetObj);
            String op = ciText(obj, "OP");
            if (op == null || op.isBlank()) {
                op = "EQ";
            }
            List<String> expected = new ArrayList<>();
            Object expObj = ciGet(obj, "EXPECTED", "EXPECTEDVALUES");
            if (expObj instanceof JSONArray expArr) {
                for (Object n : expArr) {
                    expected.add(n instanceof String s ? s : JSON.toJSONString(n));
                }
            }
            // 异步轮询字段（仅 WAIT_UNTIL/POLL_UNTIL 生效）
            int timeoutSec = parseInt(ciText(obj, "TIMEOUT"), 0);
            long pollIntervalMs = parseLong(ciText(obj, "POLLINTERVAL", "POLL_INTERVAL"), 0);
            // FIELD：DB 断言指定提取的列名（null=第一列，*=全行JSON）
            String field = ciText(obj, "FIELD");
            // JSONPATH/XPATH/XML 显式模式：FROM（输出变量）或 FILE（文件路径）作为内容来源，
            // 复用 field 传递（这些 source 无列选择语义，field 可安全复用）
            if (sourceKey != null && ("JSONPATH".equalsIgnoreCase(sourceKey)
                    || "XPATH".equalsIgnoreCase(sourceKey) || "XML".equalsIgnoreCase(sourceKey))) {
                String contentRef = ciText(obj, "FROM", "FILE");
                if (contentRef != null && !contentRef.isBlank()) {
                    field = contentRef;
                }
            }
            rules.add(new AssertionRule(sourceKey.toUpperCase(), target, op.toUpperCase(), expected,
                    field, JSON.toJSONString(element), timeoutSec, pollIntervalMs));
        }
        return rules;
    }

    /** 解析 EXTRACT 列：[{"name":"var","from":"DB","path":"rows[0].ACCT_NO"}] */
    public static List<ExtractRule> parseExtractRules(String raw, String scenarioId,
                                                      String stepId, List<DataQualityIssue> issues) {
        List<ExtractRule> rules = new ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return rules;
        }
        Object root = parse(raw, "EXTRACT", scenarioId, stepId, issues);
        if (root == null) {
            return rules;
        }
        if (!(root instanceof JSONArray)) {
            JSONArray wrapped = new JSONArray();
            wrapped.add(root);
            root = wrapped;
        }
        for (Object element : (JSONArray) root) {
            if (!(element instanceof JSONObject obj)) {
                issues.add(issue(scenarioId, stepId, "EXTRACT",
                        "数组元素不是对象: " + JSON.toJSONString(element), "跳过该元素"));
                continue;
            }
            // 键大小写不敏感：name/NAME、from/FROM、path/PATH 均可（YAML 小写 / Excel 大写）
            String name = ciText(obj, "NAME", "VAR");
            String from = ciText(obj, "FROM", "SOURCE");
            String path = ciText(obj, "PATH", "EXPR");
            // 字面量模式：value/VAL 直接设置场景级变量（如 {"name":"acct","value":"999999"}）
            String value = ciText(obj, "VALUE", "VAL");
            if (value == null && obj.containsKey("value")) {
                Object v = obj.get("value");
                value = v == null ? null : String.valueOf(v);
            }
            if (name == null || name.isBlank()) {
                issues.add(issue(scenarioId, stepId, "EXTRACT",
                        "提取规则缺少 name: " + JSON.toJSONString(element), "跳过该元素"));
                continue;
            }
            if (value != null) {
                // 字面量模式：from/path 不需要
                rules.add(new ExtractRule(name, "LITERAL", "", JSON.toJSONString(element), value));
            } else {
                rules.add(new ExtractRule(name, from == null ? "OUTPUT" : from, path, JSON.toJSONString(element)));
            }
        }
        return rules;
    }

    // ---------------- 内部工具 ----------------

    /** 大小写不敏感取键：先精确命中，再忽略大小写扫描（保留原键返回） */
    private static String ciKey(JSONObject obj, String key) {
        if (obj.containsKey(key)) {
            return key;
        }
        for (String k : obj.keySet()) {
            if (k.equalsIgnoreCase(key)) {
                return k;
            }
        }
        return null;
    }

    /** 大小写不敏感取值（Object，供数组型字段如 EXPECTED） */
    private static Object ciGet(JSONObject obj, String... keys) {
        for (String k : keys) {
            String hit = ciKey(obj, k);
            if (hit != null) {
                return obj.get(hit);
            }
        }
        return null;
    }

    /** 大小写不敏感取字符串值 */
    private static String ciText(JSONObject obj, String... keys) {
        Object v = ciGet(obj, keys);
        return v instanceof String s ? s : null;
    }

    private static int parseInt(String s, int defaultValue) {
        if (s == null || s.isBlank()) return defaultValue;
        try { return Integer.parseInt(s.trim()); }
        catch (NumberFormatException e) { return defaultValue; }
    }

    private static long parseLong(String s, long defaultValue) {
        if (s == null || s.isBlank()) return defaultValue;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return defaultValue; }
    }

    /** 断言元数据键（OP/EXPECTED/...）判断，大小写不敏感 */
    private static boolean isAssertMetaKey(String key) {
        for (String k : ASSERT_META_KEYS) {
            if (k.equalsIgnoreCase(key)) {
                return true;
            }
        }
        return false;
    }

    private static void mergeIntoPrevious(List<ProtocolPayload> payloads, JSONObject fragment,
                                          String scenarioId, String stepId, List<DataQualityIssue> issues) {
        ProtocolPayload previous = payloads.get(payloads.size() - 1);
        JSONObject merged = new JSONObject();
        if (previous.getParams() instanceof JSONObject prevObj) {
            merged.putAll(prevObj);
        }
        merged.putAll(fragment);
        payloads.set(payloads.size() - 1, new ProtocolPayload(previous.getProtocol(), merged));
        issues.add(issue(scenarioId, stepId, "INPUT",
                "游离键 " + JSON.toJSONString(fragment) + " 不在数组对象结构内（模版已知问题）", "已自动并入前一个 "
                        + previous.getProtocol() + " 载荷参数体"));
    }

    private static String firstKnownProtocol(JSONObject obj) {
        for (String f : obj.keySet()) {
            if (KNOWN_PROTOCOLS.contains(f.toUpperCase())) {
                return f.toUpperCase();
            }
        }
        return null;
    }

    private static Object parse(String raw, String field, String scenarioId,
                                String stepId, List<DataQualityIssue> issues) {
        String text = raw.trim();
        // 智能修复：智能引号 / 中文引号导致的 JSON 解析失败
        text = text.replace('“', '"').replace('”', '"').replace('，', ',');
        try {
            return JSON.parse(text);
        } catch (Exception first) {
            // 二级修复：模版已知问题 —— 对象闭合后的数组尾部出现裸键值对
            // 如 [{"HTTP":{...}},"headers":{"token":"x"}]（"headers" 键游离在数组元素结构外）
            // 修复为 [{"HTTP":{...}},{"headers":{"token":"x"}}]
            String repaired = text.replaceAll(
                    "\\}\\s*,\\s*\"(\\w+)\"\\s*:\\s*(\\{.*?\\}|\"[^\"]*\"|[^,\\]]+?)\\s*\\]",
                    "},{\"$1\":$2}]");
            try {
                Object node = JSON.parse(repaired);
                issues.add(new DataQualityIssue(field, scenarioId, stepId, field,
                        "JSON 结构非法（键值对游离在数组对象结构外，模版已知问题），已自动修复: "
                                + abbreviate(raw, 120), "按修复后结构装载"));
                return node;
            } catch (Exception second) {
                issues.add(new DataQualityIssue(field, scenarioId, stepId, field,
                        "JSON 解析失败: " + second.getMessage() + "；原文: " + abbreviate(raw, 200),
                        "按原始文本保留，执行到该步骤时以 DATA_ERROR 失败并提示修复"));
                return null;
            }
        }
    }

    private static DataQualityIssue issue(String scenarioId, String stepId, String field, String msg, String handling) {
        return new DataQualityIssue(field, scenarioId, stepId, field, msg, handling);
    }

    private static String abbreviate(String s, int max) {
        return s != null && s.length() > max ? s.substring(0, max) + "..." : s;
    }
}
